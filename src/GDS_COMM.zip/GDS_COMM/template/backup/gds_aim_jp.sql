SELECT 
	B.EBLNO_ALL                           as CUSTOMER_WAYBILL_NO
	,B.EBL_SYBTKBN                        as WAYBILL_TYPE
	,''                                   as FREIGHT_TERMS
	,DECODE(B.EDEPTAREA,'1','TC1','2','TC2','3','TC3','')  as ORIGIN_TC
	,''                                   as ORIGIN_POLAR_REGION_A
	,B.EDEPTCNT                           as ORIGIN_COUNTRY
	,''                                   as ORIGIN_COMPANY_ID
	,B.EFWDRCD                            as ORIGIN_TERMINAL_ID
	,''                                   as ORIGN_CITY
	,B.EDEPTCD                            as ORIGIN_PORT
	,'TC3'                                as DEST_TC
	,'JP'                                 as DEST_POLAR_REGION_A
	,'JP'                                 as DEST_COUNTRY
	,'100'                                as DEST_COMPANY_ID
	,B.EBB_TNT_KSYCD                      as DEST_TERMINAL_ID
	,''                                   as DEST_CITY
	,B.EDESTCD                            as DEST_PORT
	,''                                   as STATUS
	,''                                   as HWB_ISSUE_DATE_LOCAL
	,TO_CHAR(A.DSIRE_KJODTM,'YYYY/MM/DD') as IMP_GL_DATE_LOCAL
	,B.NBL_CRG_CHGWT                      as CHARGEABLE_WEIGHT
	,B.EBL_CRG_CHGWT_TANI                 as CHARGEABLE_WEIGHT_UOM
	,DECODE(B.ETKN_JTKBN,'0','TO','1','CUS','') as DISPOSITION
	,B.ESRIMAK_TNT_KSYCD                  as DESTINATION_BROKER_ID
	,''                                   as DESTINATION_BROKER

FROM  TKJ351A A,
      TKJ351A B
WHERE A.ESHIPID = B.ESHIPID
AND   A.DSIRE_KJODTM = TO_DATE('$DATE_VALUE','YYYYMMDD')
AND   A.NGENNO = 1
AND   B.EDELKBN != '1'
AND   B.ESISNKBN = '1'
AND   NVL(B.EBLNO_ALL,' ') NOT LIKE 'ZZML100%'
AND   B.EBL_SYBTKBN = 'HAW'

ORDER BY B.EBLNO_ALL
