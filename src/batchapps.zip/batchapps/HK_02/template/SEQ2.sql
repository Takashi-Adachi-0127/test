select 
TO_CHAR((sysdate),'yyyymmdd') as XTODAY 
--'20110213' as XTODAY 
from dual
