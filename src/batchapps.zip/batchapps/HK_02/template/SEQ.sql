select 
TO_CHAR((sysdate),'yyyy/mm/dd') as TODAY 
--'2011/02/13' as TODAY 
from DUAL
