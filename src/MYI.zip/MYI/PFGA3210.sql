CREATE OR REPLACE PACKAGE PFGA3210 AS
--**********************************************
--�y �ӏ��ʋ��z���э쐬 �z
--  �p�b�P�[�W
--  PFGA3210
--  �Ăяo���K�w
--  CRE_TFJ321                             �ӏ��ʋ��z���т̍쐬
--    +-- INSERT_TFJ321                    �ӏ��ʋ��z���э쐬INSERT Main����
--          +-- SEL_TFJ321                 �ӏ��ʋ��z���т�����
--          +-- INS_TFJ321                 �ӏ��ʋ��z���э쐬INSERT����
--          +-- UPD_TFJ321                 �ӏ��ʋ��z���э쐬UPDATE����
--**********************************************

--******************************************
--�y �ӏ��ʋ��z���э쐬 �z�p�b�P�[�W�d�l��
--             PFGA3210
--******************************************

    -- ���[Tag���z�̒��o
    CURSOR CUR_TFJ311(
        wk_gyomdate     DATE
    ) IS
        SELECT  *
          FROM  TFJ311
         WHERE  DGYMDTM = wk_gyomdate
         ORDER  BY EIM_EX_IND,
                   ETRANS_MODE,
                   EWB_TYPE,
                   DKJODTM,
                   ECOMPANY_ID,
                   ETERMINAL_ID,
                   EDEPARTMENT_ID,
                   NKMK_ITI;

    -- �װ�����ϐ�
    WK_ERROR            NUMBER;

    -- ���[Tag���z�iTFJ311�j�̒��o�p�v�j�ϐ��J�E���^
    TFJ311_new_cnt      NUMBER ;
    TFJ311_adj_cnt      NUMBER ;

    -- �ӏ��ʋ��z���сiTFJ321�j�}���p�v�j�ϐ��J�E���^
    TFJ321_ins_cnt      NUMBER ;
    TFJ321_upd_cnt      NUMBER ;

    REC_TFJ311          CUR_TFJ311%ROWTYPE ;

    -- ���[Tag���z�L�[�u���C�N�v�j�ϐ�
    wk_EIM_EX_IND       TFJ311.EIM_EX_IND%TYPE;
    wk_ETRANS_MODE      TFJ311.ETRANS_MODE%TYPE;
    wk_EWB_TYPE         TFJ311.EWB_TYPE%TYPE;
    wk_DKJODTM          TFJ311.DKJODTM%TYPE;
    wk_ECOMPANY_ID      TFJ311.ECOMPANY_ID%TYPE;
    wk_ETERMINAL_ID     TFJ311.ETERMINAL_ID%TYPE;
    wk_EDEPARTMENT_ID   TFJ311.EDEPARTMENT_ID%TYPE;
    wk_NKMK_ITI         TFJ311.NKMK_ITI%TYPE;        --���ڈʒu


    -- �ӏ��ʋ��z���сiTFJ321�j�}���p�v�j�ϐ�
    wki_ETRKDTM         TFJ321.ETRKDTM%TYPE;
    wki_EUPDDTM         TFJ321.EUPDDTM%TYPE;
    wki_DHNEDTM         TFJ321.DHNEDTM%TYPE;
    wki_EUPD_OFCCD      TFJ321.EUPD_OFCCD%TYPE;
    wki_EUPD_TNTCD      TFJ321.EUPD_TNTCD%TYPE;
    wki_DGYMDTM         TFJ321.DGYMDTM%TYPE;
    wki_EIM_EX_IND      TFJ321.EIM_EX_IND%TYPE;
    wki_ETRANS_MODE     TFJ321.ETRANS_MODE%TYPE;
    wki_EWB_TYPE        TFJ321.EWB_TYPE%TYPE;
    wki_DKJODTM         TFJ321.DKJODTM%TYPE;
    wki_ECOMPANY_ID     TFJ321.ECOMPANY_ID%TYPE;
    wki_ETERMINAL_ID    TFJ321.ETERMINAL_ID%TYPE;
    wki_EDEPARTMENT_ID  TFJ321.EDEPARTMENT_ID%TYPE;
    wki_NKMK_ITI        TFJ321.NKMK_ITI%TYPE;
    wki_EPRT_TAG        TFJ321.EPRT_TAG%TYPE;
    wki_NHSI_HBI_KIN    TFJ321.NHSI_HBI_KIN%TYPE;
    wki_NSYSI_HBI_KIN   TFJ321.NSYSI_HBI_KIN%TYPE;
    wki_NHSI_COST_KIN   TFJ321.NHSI_COST_KIN%TYPE;
    wki_NSYSI_COST_KIN  TFJ321.NSYSI_COST_KIN%TYPE;

--==========================================
-- PROCEDURE / FUNCTION
--==========================================
-- �f�[�^���o�E�W�v�E�쐬�v���V�[�W��
PROCEDURE CRE_TFJ321(
    in_date             IN      DATE                    -- �Ɩ����t
 ) ;

-- �ӏ��ʋ��z���э쐬INSERT Main����
PROCEDURE INSERT_TFJ321 ;

-- �ӏ��ʋ��z���ь�������
    FUNCTION SEL_TFJ321(
        OUT_TFJ321       IN OUT TFJ321%ROWTYPE )        -- �ӏ��ʋ��z����
    RETURN NUMBER;

-- �ӏ��ʋ��z���э쐬INSERT����
PROCEDURE INS_TFJ321 ;

-- �ӏ��ʋ��z���э쐬UPDATE����
PROCEDURE UPD_TFJ321 ;

END PFGA3210 ;
CREATE OR REPLACE PACKAGE BODY PFGA3210 AS
--******************************************
--�y �ӏ��ʋ��z���э쐬 �z�p�b�P�[�W�{�̕�
--             PFGA3210
--******************************************

--******************************************
--==========================================
-- �ӏ��ʋ��z���т̍쐬
-- �iTFJ311�ATKM011����ATFJ321�ցj
--==========================================
PROCEDURE CRE_TFJ321(
    in_date             IN      DATE                    -- �Ɩ����t
) IS

    wk_rtn              NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3210','CRE_TFJ321');
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || in_date );

    -- �ϐ��N���A
    wk_EIM_EX_IND       := '#' ;
    wk_ETRANS_MODE      := '#' ;
    wk_EWB_TYPE         := '#' ;
    wk_DKJODTM          := TO_DATE('2000/01/01','YYYY/MM/DD') ;
    wk_ECOMPANY_ID      := '#' ;
    wk_ETERMINAL_ID     := '#' ;
    wk_EDEPARTMENT_ID   := '#' ;
    wk_NKMK_ITI         := 0 ;    --���ڈʒu

    WK_ERROR            := 0;
    TFJ311_new_cnt      := 0 ;
    TFJ311_adj_cnt      := 0 ;
    TFJ321_ins_cnt      := 0 ;
    TFJ321_upd_cnt      := 0 ;

    -- ���[Tag���zð��ٵ����
    OPEN CUR_TFJ311( in_date ) ;
    LOOP
        FETCH CUR_TFJ311 INTO REC_TFJ311 ;
        EXIT WHEN CUR_TFJ311%NOTFOUND ;

        IF REC_TFJ311.EIM_EX_IND     != wk_EIM_EX_IND     OR
           REC_TFJ311.ETRANS_MODE    != wk_ETRANS_MODE    OR
           REC_TFJ311.EWB_TYPE       != wk_EWB_TYPE       OR
           REC_TFJ311.DKJODTM        != wk_DKJODTM        OR
           REC_TFJ311.ECOMPANY_ID    != wk_ECOMPANY_ID    OR
           REC_TFJ311.ETERMINAL_ID   != wk_ETERMINAL_ID   OR
           REC_TFJ311.EDEPARTMENT_ID != wk_EDEPARTMENT_ID OR
           REC_TFJ311.NKMK_ITI       != wk_NKMK_ITI       THEN
            IF wk_ECOMPANY_ID != '#' THEN
                --�L�[�u���C�N���ӏ��ʋ��z����INSERT
                INSERT_TFJ321 ;
            END IF;

            wk_EIM_EX_IND      := REC_TFJ311.EIM_EX_IND;
            wk_ETRANS_MODE     := REC_TFJ311.ETRANS_MODE;
            wk_EWB_TYPE        := REC_TFJ311.EWB_TYPE;
            wk_DKJODTM         := REC_TFJ311.DKJODTM;
            wk_ECOMPANY_ID     := REC_TFJ311.ECOMPANY_ID;
            wk_ETERMINAL_ID    := REC_TFJ311.ETERMINAL_ID;
            wk_EDEPARTMENT_ID  := REC_TFJ311.EDEPARTMENT_ID;
            wk_NKMK_ITI        := REC_TFJ311.NKMK_ITI;

            -- ���[Tag���z���ڂ��ӏ��ʋ��z����ܰ��̈�ɃZ�b�g
            -- ����
            wki_ETRKDTM        := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
            wki_EUPDDTM        := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
            wki_DHNEDTM        := SYSDATE;
            wki_EUPD_OFCCD     := '!';
            wki_EUPD_TNTCD     := '!';
            -- �j�d�x
            wki_DGYMDTM        := REC_TFJ311.DGYMDTM;
            wki_EIM_EX_IND     := REC_TFJ311.EIM_EX_IND;
            wki_ETRANS_MODE    := REC_TFJ311.ETRANS_MODE;
            wki_EWB_TYPE       := REC_TFJ311.EWB_TYPE;
            wki_DKJODTM        := REC_TFJ311.DKJODTM;
            wki_ECOMPANY_ID    := REC_TFJ311.ECOMPANY_ID;
            wki_ETERMINAL_ID   := REC_TFJ311.ETERMINAL_ID;
            wki_EDEPARTMENT_ID := REC_TFJ311.EDEPARTMENT_ID;
            wki_NKMK_ITI       := REC_TFJ311.NKMK_ITI;
            wki_EPRT_TAG       := REC_TFJ311.EPRT_TAG;

            -- ���z��������
            wki_NHSI_HBI_KIN   := 0;
            wki_NSYSI_HBI_KIN  := 0;
            wki_NHSI_COST_KIN  := 0;
            wki_NSYSI_COST_KIN := 0;
        END IF;

        -- ���z�����Z
        IF REC_TFJ311.EOPE_KBN = '0' THEN  --�f�[�^�����敪�i�V�K�j
            wki_NHSI_HBI_KIN   := wki_NHSI_HBI_KIN
                               + (REC_TFJ311.NURI_KIN * REC_TFJ311.NAKKBN);
            wki_NHSI_COST_KIN  := wki_NHSI_COST_KIN
                               + (REC_TFJ311.NOROS_KIN * REC_TFJ311.NAKKBN);
            TFJ311_new_cnt     := TFJ311_new_cnt + 1 ;
        ELSE                               --�f�[�^�����敪�i�C���j
            wki_NSYSI_HBI_KIN  := wki_NSYSI_HBI_KIN
                               + (REC_TFJ311.NURI_KIN * REC_TFJ311.NAKKBN);
            wki_NSYSI_COST_KIN := wki_NSYSI_COST_KIN
                               + (REC_TFJ311.NOROS_KIN * REC_TFJ311.NAKKBN);
            TFJ311_adj_cnt     := TFJ311_adj_cnt + 1 ;
        END IF;

    END LOOP ;
    CLOSE CUR_TFJ311 ;

    IF wk_ECOMPANY_ID != '#' THEN
        --�Ō�̉ӏ��ʋ��z����INSERT
        INSERT_TFJ321 ;
    END IF;

    PFGA3910.TRACE_LOG('I','���[Tag���z�i�V�K�j���͌��� = ' || TFJ311_new_cnt);
    PFGA3910.TRACE_LOG('I','���[Tag���z�i�C���j���͌��� = ' || TFJ311_adj_cnt);
    PFGA3910.TRACE_LOG('I','�ӏ��ʋ��z���� �V�K����     = ' || TFJ321_ins_cnt);
    PFGA3910.TRACE_LOG('I','�ӏ��ʋ��z���� �X�V����     = ' || TFJ321_upd_cnt);
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ311: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        IF CUR_TFJ311%ISOPEN THEN
            CLOSE CUR_TFJ311 ;
        END IF ;
        RAISE ;
END ;

--================================================
-- �ӏ��ʋ��z���э쐬INSERT Main����
--================================================
PROCEDURE INSERT_TFJ321
IS
    WK_RC         NUMBER;
    WK_TFJ321     TFJ321%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3210','INSERT_TFJ321');

    -- �ӏ��ʋ��z���т�����
    WK_RC := SEL_TFJ321( WK_TFJ321 );

    IF WK_RC = 0 THEN
        -- �ӏ��ʋ��z���т�V�K�쐬
        INS_TFJ321;
    ELSE
        -- �ӏ��ʋ��z���тɉ��Z����
        wki_NHSI_HBI_KIN   := wki_NHSI_HBI_KIN   + WK_TFJ321.NHSI_HBI_KIN;
        wki_NSYSI_HBI_KIN  := wki_NSYSI_HBI_KIN  + WK_TFJ321.NSYSI_HBI_KIN;
        wki_NHSI_COST_KIN  := wki_NHSI_COST_KIN  + WK_TFJ321.NHSI_COST_KIN;
        wki_NSYSI_COST_KIN := wki_NSYSI_COST_KIN + WK_TFJ321.NSYSI_COST_KIN;

        -- �ӏ��ʋ��z���т��X�V�쐬
        UPD_TFJ321;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- �ӏ��ʋ��z���т�����
--================================================
FUNCTION SEL_TFJ321(
    OUT_TFJ321       IN OUT TFJ321%ROWTYPE )         -- �ӏ��ʋ��z����
    RETURN NUMBER
IS
    -- �ӏ��ʋ��z���ђ��o�J�[�\��
    CURSOR CUR_TFJ321( IN_DGYMDTM        IN TFJ321.DGYMDTM%TYPE,
                       IN_EIM_EX_IND     IN TFJ321.EIM_EX_IND%TYPE,
                       IN_ETRANS_MODE    IN TFJ321.ETRANS_MODE%TYPE,
                       IN_EWB_TYPE       IN TFJ321.EWB_TYPE%TYPE,
                       IN_DKJODTM        IN TFJ321.DKJODTM%TYPE,
                       IN_ECOMPANY_ID    IN TFJ321.ECOMPANY_ID%TYPE,
                       IN_ETERMINAL_ID   IN TFJ321.ETERMINAL_ID%TYPE,
                       IN_EDEPARTMENT_ID IN TFJ321.EDEPARTMENT_ID%TYPE,
                       IN_NKMK_ITI       IN TFJ321.NKMK_ITI%TYPE,
                       IN_EPRT_TAG       IN TFJ321.EPRT_TAG%TYPE ) IS
        SELECT *
          FROM TFJ321
          WHERE DGYMDTM        = IN_DGYMDTM
            AND EIM_EX_IND     = IN_EIM_EX_IND
            AND ETRANS_MODE    = IN_ETRANS_MODE
            AND EWB_TYPE       = IN_EWB_TYPE
            AND DKJODTM        = IN_DKJODTM
            AND ECOMPANY_ID    = IN_ECOMPANY_ID
            AND ETERMINAL_ID   = IN_ETERMINAL_ID
            AND EDEPARTMENT_ID = IN_EDEPARTMENT_ID
            AND NKMK_ITI       = IN_NKMK_ITI
            AND EPRT_TAG       = IN_EPRT_TAG;

    WK_RC         NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3210','SEL_TFJ321');

    WK_RC := 0;
    OUT_TFJ321 := NULL;

    FOR WK_REC IN CUR_TFJ321( wki_DGYMDTM,
                              wki_EIM_EX_IND,
                              wki_ETRANS_MODE,
                              wki_EWB_TYPE,
                              wki_DKJODTM,
                              wki_ECOMPANY_ID,
                              wki_ETERMINAL_ID,
                              wki_EDEPARTMENT_ID,
                              wki_NKMK_ITI,
                              wki_EPRT_TAG ) LOOP
        WK_RC := 1;
        OUT_TFJ321 := WK_REC;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

    RETURN WK_RC;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ321: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- �ӏ��ʋ��z���э쐬INSERT����
-- �ӏ��ʋ��z����ܰ����ް��Z�b�g�ς�
--==========================================
PROCEDURE INS_TFJ321
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3210','INS_TFJ321');

-- insert���s
    INSERT  INTO TFJ321 (
            --����
            ETRKDTM,
            EUPDDTM,
            DHNEDTM,
            EUPD_OFCCD,
            EUPD_TNTCD,
            -- �j�d�x
            DGYMDTM,
            EIM_EX_IND,
            ETRANS_MODE,
            EWB_TYPE,
            DKJODTM,
            ECOMPANY_ID,
            ETERMINAL_ID,
            EDEPARTMENT_ID,
            NKMK_ITI,
            EPRT_TAG,
            -- ���z�ر�i������z�j
            NHSI_HBI_KIN,
            NSYSI_HBI_KIN,
            -- ���z�ر�i�R�X�g�j
            NHSI_COST_KIN,
            NSYSI_COST_KIN )
    VALUES(
            --����
            wki_ETRKDTM,
            wki_EUPDDTM,
            wki_DHNEDTM,
            wki_EUPD_OFCCD,
            wki_EUPD_TNTCD,
            -- �j�d�x
            wki_DGYMDTM,
            wki_EIM_EX_IND,
            wki_ETRANS_MODE,
            wki_EWB_TYPE,
            wki_DKJODTM,
            wki_ECOMPANY_ID,
            wki_ETERMINAL_ID,
            wki_EDEPARTMENT_ID,
            wki_NKMK_ITI,
            wki_EPRT_TAG,
            -- ���z�ر�i������z�j
            wki_NHSI_HBI_KIN,
            wki_NSYSI_HBI_KIN,
            -- ���z�ر�i�R�X�g�j
            wki_NHSI_COST_KIN,
            wki_NSYSI_COST_KIN );

    TFJ321_ins_cnt  := TFJ321_ins_cnt + 1 ;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 4;
            PFGA3910.TRACE_LOG('E','TFJ321: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE ;
END ;

--==========================================
-- �ӏ��ʋ��z���э쐬UPDATE����
-- �ӏ��ʋ��z����ܰ����ް��Z�b�g�ς�
--==========================================
PROCEDURE UPD_TFJ321
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3210','UPD_TFJ321');

-- update���s
        UPDATE  TFJ321
           SET  NHSI_HBI_KIN   = wki_NHSI_HBI_KIN,
                NSYSI_HBI_KIN  = wki_NSYSI_HBI_KIN,
                NHSI_COST_KIN  = wki_NHSI_COST_KIN,
                NSYSI_COST_KIN = wki_NSYSI_COST_KIN
         WHERE  DGYMDTM        = wki_DGYMDTM
            AND EIM_EX_IND     = wki_EIM_EX_IND
            AND ETRANS_MODE    = wki_ETRANS_MODE
            AND EWB_TYPE       = wki_EWB_TYPE
            AND DKJODTM        = wki_DKJODTM
            AND ECOMPANY_ID    = wki_ECOMPANY_ID
            AND ETERMINAL_ID   = wki_ETERMINAL_ID
            AND EDEPARTMENT_ID = wki_EDEPARTMENT_ID
            AND NKMK_ITI       = wki_NKMK_ITI
            AND EPRT_TAG       = wki_EPRT_TAG;

    TFJ321_upd_cnt  := TFJ321_upd_cnt + 1 ;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ321: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE ;
END ;

END PFGA3210 ;