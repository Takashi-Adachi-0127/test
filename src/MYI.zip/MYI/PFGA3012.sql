CREATE OR REPLACE PACKAGE PFGA3012 AS
--********************************************************************
--�y ���і��׍쐬 �z
--  �߯����
--  PFGA3012
--  �Ăяo���K�w
--  CRE_MEISAI_JISSEKI                    ���і��ׂ��쐬
--    +-- SEL_MWB                         MWB ���o
--    +-- SET_TFJ301_MWB                  MWB ���і��ׁA�ҏW
--********************************************************************

--************************************************
--�y ���і��׍쐬 �z�߯���ގd�l��
--     PFGA3012
--************************************************

-- (1) �{���X�V����HWB�𒊏o���ACategory���ɋ��z�����v
    CURSOR CUR_TFJ301_HWB( KEY_DGYMDTM   DATE ) IS
        SELECT T.EDATKBN,
               T.PIPELINE_TX_ID,
               T.DGYMDTM,
               T.NGENNO,
               SUM(DECODE(T.EPRT_TAG,'FRT',T.SALES_AMT,0)) as FRT_SALES_AMT,
               SUM(DECODE(T.EPRT_TAG,'FOT',T.SALES_AMT,0)) as FOT_SALES_AMT,
               SUM(DECODE(T.EPRT_TAG,'CCO',T.COST_AMT * -1,0)) as CCO_SALES_AMT,
               SUM(DECODE(T.EPRT_TAG,'CHG',T.SALES_AMT,0)) as CHG_SALES_AMT,
               SUM(DECODE(T.EPRT_TAG,'FRT',T.COST_AMT,0))  as FRT_COST_AMT,
               SUM(DECODE(T.EPRT_TAG,'FOT',T.COST_AMT,0))  as FOT_COST_AMT,
               SUM(DECODE(T.EPRT_TAG,'AGT',T.COST_AMT,0))  as AGT_COST_AMT,
               SUM(DECODE(T.EPRT_TAG,'CHG',T.COST_AMT,0))  as CHG_COST_AMT
        FROM ( SELECT TFJ301.EDATKBN,
                      TFJ301.PIPELINE_TX_ID,
                      TFJ301.DGYMDTM,
                      TFJ301.NGENNO,
                      TFM205.EURI_PRT_TAG10 as EPRT_TAG,
                      SUM(NVL(TFJ303.OC_INVOICE_CHARGE_AMT,0)) as SALES_AMT,
                      SUM(NVL(TFJ303.OC_COST_AMT,0))           as COST_AMT
               FROM TFJ301,
                    TFJ303,
                    TFM205
               WHERE TFJ303.EDATKBN        = TFJ301.EDATKBN
                 AND TFJ303.PIPELINE_TX_ID = TFJ301.PIPELINE_TX_ID
                 AND TFJ303.DGYMDTM        = TFJ301.DGYMDTM
                 AND TFJ303.NGENNO         = TFJ301.NGENNO
                 -- Global��TFM205���
                 AND TFM205.COMPANY_ID        = TFJ301.ECOMPANY_ID
                 AND TFM205.IMPORT_EXPORT_IND = TFJ301.EIM_EX_IND
                 AND TFM205.TRANSPORT_MODE    = TFJ301.ETRANS_MODE
                 AND TFM205.CHARGE_CODE       = TFJ303.CHARGE_CODE
                 AND TFJ301.EDATKBN        = '1'             -- House
                 AND TFJ301.DGYMDTM        = KEY_DGYMDTM
                 AND TFJ301.ESISNKBN       = '1'
                 AND TFJ301.EDELKBN        = '0'
                 AND TFM205.ESISNKBN       = '1'
                 AND TFM205.EDELKBN        = '0'
                 AND TFM205.EYKOKBN10      = '1'
                 -- CHARGE_STATUS='O'  :Open �܂�UAF�v�サ�Ă��Ȃ�
                 -- CHARGE_STATUS='DNI':UAS Interface���Ȃ�Charge
                 -- 2005.10.01 DNI�����Z����B
                 AND TFJ303.CHARGE_STATUS <> 'O'
                 -- AND TFJ303.CHARGE_STATUS <> 'DNI'
               GROUP BY TFJ301.EDATKBN,
                        TFJ301.PIPELINE_TX_ID,
                        TFJ301.DGYMDTM,
                        TFJ301.NGENNO,
                        TFM205.EURI_PRT_TAG10 ) T
        GROUP BY T.EDATKBN,
                 T.PIPELINE_TX_ID,
                 T.DGYMDTM,T.NGENNO
        ORDER BY T.PIPELINE_TX_ID;

-- (2) �{���X�V����HWB���AMWB�𒊏o
    CURSOR CUR_TFJ301_HWB_SEL ( KEY_DGYMDTM   DATE ) IS
        SELECT TFJ301.MWB_TX_ID
          FROM TFJ301
         WHERE TFJ301.EDATKBN  = '1'                   -- House
           AND TFJ301.DGYMDTM  = KEY_DGYMDTM
           AND TFJ301.ESISNKBN = '1'
           AND TFJ301.EDELKBN  = '0'
           AND TFJ301.MWB_TX_ID <> 0
         GROUP BY TFJ301.MWB_TX_ID
         ORDER BY TFJ301.MWB_TX_ID;

-- (3) HWB���X�V����ĂȂ��A�{���X�V���ꂽMWB�𒊏o
    CURSOR CUR_TFJ301_MWB_SEL ( KEY_DGYMDTM   DATE ) IS
        SELECT TFJ301.PIPELINE_TX_ID as MWB_TX_ID
          FROM TFJ301
         WHERE TFJ301.EDATKBN  = '3'                   -- Master
           AND TFJ301.DGYMDTM  = KEY_DGYMDTM
           AND TFJ301.ESISNKBN = '1'
           AND TFJ301.EDELKBN  = '0'
           AND TFJ301.HAWB_CNT IS NULL                 -- �X�V���ڂ͂ǂ�ł��ǂ����AHAWB_CNT���\�ɂ���B
         ORDER BY TFJ301.PIPELINE_TX_ID;

-- (4) MWB�𒊏o
--  2005.12.05 ETERMINAL_ID��ǉ�
    CURSOR CUR_TFJ301_MWB(
        KEY_MWB_TX_ID   TFJ301.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT EDATKBN,
               PIPELINE_TX_ID,
               DGYMDTM,
               NGENNO,
               DKJODTM,
               ETERMINAL_ID,
               EDEPARTMENT_ID,
               PIPELINE_REF_TYPE,
               ECOMPANY_ID,
               EIM_EX_IND,
               ETRANS_MODE
        FROM TFJ301
        WHERE EDATKBN        = '3'                      -- Master
          AND PIPELINE_TX_ID = KEY_MWB_TX_ID
          AND ESISNKBN       = '1'
          AND EDELKBN        = '0';

-- (5) MWB�P�ʂ�HWB�̋��z��Category���ɍ��v
    CURSOR CUR_TFJ301_HWB_SUM (
        KEY_MWB_TX_ID   TFJ301.MWB_TX_ID%TYPE
    ) IS
        SELECT HWB.MWB_TX_ID,
               COUNT(HWB.PIPELINE_TX_ID)            as HAWB_CNT,
               SUM(NVL(HWB.NUM_PIECES,0))           as HAWB_PCS,
               SUM(NVL(HWB.CHARGEABLE_WEIGHT_KG,0)) as HAWB_CGWT,
               SUM(NVL(HWB.ACTUAL_WEIGHT_KG,0))     as HAWB_AGWT,
               SUM(NVL(HWB.VOLUME_CBM,0))           as HAWB_M3,
               SUM(NVL(HWB.VOLUME_WEIGHT_KG,0))     as HAWB_VWT,
               SUM(NVL(HWB.FRT_SALES_AMT,0))        as FRT_SALES_AMT,
               SUM(NVL(HWB.FOT_SALES_AMT,0))        as FOT_SALES_AMT,
               SUM(NVL(HWB.CCO_SALES_AMT,0))        as CCO_SALES_AMT,
               SUM(NVL(HWB.CHG_SALES_AMT,0))        as CHG_SALES_AMT,
               SUM(NVL(HWB.AGT_COST_AMT,0))         as AGT_COST_AMT,
               SUM(NVL(HWB.CHG_COST_AMT,0))         as CHG_COST_AMT
        FROM TFJ301 HWB
        WHERE HWB.EDATKBN   = '1'                            -- House
          AND HWB.MWB_TX_ID = KEY_MWB_TX_ID
          AND HWB.ESISNKBN  = '1'
          AND HWB.EDELKBN   = '0'
        GROUP BY HWB.MWB_TX_ID;

-- (6) MASTER���g��Cost Charge���v
    CURSOR CUR_TFJ301_MWB_SUM(
        KEY_MWB_TX_ID   TFJ301.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT T.EDATKBN,
               T.PIPELINE_TX_ID,
               T.DGYMDTM,
               T.NGENNO,
               SUM(DECODE(T.EPRT_TAG,'FRT',T.COST_AMT,0)) as FRT_COST_AMT,
               SUM(DECODE(T.EPRT_TAG,'FOT',T.COST_AMT,0)) as FOT_COST_AMT,
               SUM(DECODE(T.EPRT_TAG,'CHG',T.COST_AMT,0)) as CHG_COST_AMT
        FROM ( SELECT TFJ301.EDATKBN,
                      TFJ301.PIPELINE_TX_ID,
                      TFJ301.DGYMDTM,
                      TFJ301.NGENNO,
                      TFM205.EURI_PRT_TAG10 as EPRT_TAG,
                      SUM(NVL(TFJ303.OC_COST_AMT,0)) as COST_AMT
               FROM TFJ301,
                    TFJ303,
                    TFM205
               WHERE TFJ303.EDATKBN        = TFJ301.EDATKBN
                 AND TFJ303.PIPELINE_TX_ID = TFJ301.PIPELINE_TX_ID
                 AND TFJ303.DGYMDTM        = TFJ301.DGYMDTM
                 AND TFJ303.NGENNO         = TFJ301.NGENNO
                 -- Global��TFM205���
                 AND TFM205.COMPANY_ID        = TFJ301.ECOMPANY_ID
                 AND TFM205.IMPORT_EXPORT_IND = TFJ301.EIM_EX_IND
                 AND TFM205.TRANSPORT_MODE    = TFJ301.ETRANS_MODE
                 AND TFM205.CHARGE_CODE       = TFJ303.CHARGE_CODE
                 AND TFJ301.EDATKBN        = '3'                -- Master
                 AND TFJ301.PIPELINE_TX_ID = KEY_MWB_TX_ID
                 AND TFJ301.ESISNKBN       = '1'
                 AND TFJ301.EDELKBN        = '0'
                 AND TFM205.ESISNKBN       = '1'
                 AND TFM205.EDELKBN        = '0'
                 AND TFM205.EYKOKBN10      = '1'
                 -- 2005.05.14 BBF/PRS�̊C�O�R�X�g��House�̍��v���g�p
                 AND TFJ303.CHARGE_CODE not in ('BBAB','PSAB')
               GROUP BY TFJ301.EDATKBN,
                        TFJ301.PIPELINE_TX_ID,
                        TFJ301.DGYMDTM,
                        TFJ301.NGENNO,
                        TFM205.EURI_PRT_TAG10 ) T
        GROUP BY T.EDATKBN,
                 T.PIPELINE_TX_ID,
                 T.DGYMDTM,
                 T.NGENNO
        ORDER BY T.PIPELINE_TX_ID;


    --�y ܰ��ϐ� �z

    -- ���͌������ėpܰ��ϐ�
    WK_HWB_IN_CNT           NUMBER;
    WK_MWB_IN_CNT           NUMBER;
    WK_TFJ301_UPD_CNT       NUMBER;

    --�y PROCEDURE / FUNCTION �z

    -- ���і��ׂ��쐬
    PROCEDURE CRE_MEISAI_JISSEKI(
        IN_DATE     IN DATE );                  -- �Ɩ����t(yyyymmdd)

    -- �{���X�V����HWB���z���ڍX�V
    PROCEDURE UPD_HWB_AMT(
        IN_DATE     IN DATE );                  -- �Ɩ����t(yyyymmdd)

    -- �{���X�V����HWB���MWB�̕��ʁE���z���ڍX�V
    PROCEDURE UPD_MWB_AMT1(
        IN_DATE       IN         DATE,          -- �Ɩ����t(yyyymmdd)
        IN_MWB_TX_ID  IN         TFJ301.MWB_TX_ID%TYPE );

    -- �{���X�V����MWB��蕨�ʁE���z���ڍX�V
    PROCEDURE UPD_MWB_AMT2(
        IN_DATE       IN         DATE,          -- �Ɩ����t(yyyymmdd)
        IN_MWB_TX_ID  IN         TFJ301.MWB_TX_ID%TYPE );

    -- �Ɩ������������Ȃ��ꍇ�͐���t�o
    PROCEDURE UP_NGENNO_MWB(
        IN_DATE            IN      DATE,                      -- �Ɩ����t(yyyymmdd)
        IN_TFJ301_MWB      IN      CUR_TFJ301_MWB%ROWTYPE,
        OUT_NGENNO         IN OUT  TFJ301.NGENNO%TYPE );      -- ����ԍ�

    -- MWB�P�ʂ�HWB�̋��z��Category���ɍ��v
    PROCEDURE SUM_HWB(
        IN_MWB_TX_ID       IN      TFJ301.MWB_TX_ID%TYPE,
        OUT_HWB_SUM        IN OUT  CUR_TFJ301_HWB_SUM%ROWTYPE );

    -- MASTER���g��Charge���v
    PROCEDURE SUM_MWB_COST(
        IN_MWB_TX_ID       IN      TFJ301.PIPELINE_TX_ID%TYPE,
        OUT_FRT_COST_AMT   IN OUT  TFJ301.FRT_COST_AMT%TYPE,
        OUT_FOT_COST_AMT   IN OUT  TFJ301.FRT_COST_AMT%TYPE,
        OUT_CHG_COST_AMT   IN OUT  TFJ301.FOT_COST_AMT%TYPE );


END PFGA3012;
CREATE OR REPLACE PACKAGE BODY PFGA3012 AS
--************************************************
--�y ���і��׍쐬 �z�߯���ޖ{�̕�
--     PFGA3012
--
--************************************************

--================================================
-- ���і��ׂ̍��ڃf�[�^���Z�b�g
--
--                      MAWB      HAWB
-- FRT_SALES_AMT        �� H���v  ��
-- FOT_SALES_AMT        �� H���v  ��
-- CCO_SALES_AMT        �� H���v  ��
-- CHG_SALES_AMT        �� H���v  ��
-- FRT_COST_AMT         �� M      ��
-- FOT_COST_AMT         �� M      ��
-- AGT_COST_AMT         �� H���v  ��
-- CHG_COST_AMT         �� M      ��
-- JPAEX �ǉ��iCarrier Waybill:M�̂݁j
-- HAWB_CNT             �� H���v  �~
-- HAWB_AGWT            �� H���v  �~
-- HAWB_CGWT            �� H���v  �~
-- HAWB_M3              �� H���v  �~
-- HAWB_VWT             �� H���v  �~
-- HAWB_PCS             �� H���v  �~
--================================================
PROCEDURE CRE_MEISAI_JISSEKI(
    IN_DATE     IN DATE )                 -- �Ɩ����t(yyyymmdd)
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'CRE_MEISAI_JISSEKI' );
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || IN_DATE );

    PFGA3010.C_EUPD_TNTCD  := 'PFGA3012';
    PFGA3010.WK_ERROR      := 0;

    -- �����������ėpܰ��ϐ�
    WK_HWB_IN_CNT      := 0;
    WK_MWB_IN_CNT      := 0;
    WK_TFJ301_UPD_CNT  := 0;
    PFGA3010.WK_TFJ301_AKA_CNT  := 0;
    PFGA3010.WK_TFJ301_KURO_CNT := 0;
    PFGA3010.WK_TFJ303_AKA_CNT  := 0;
    PFGA3010.WK_TFJ303_KURO_CNT := 0;

    -- �{���X�V����HWB���z���ڍX�V
    UPD_HWB_AMT( IN_DATE );

    -- �{���X�V����HWB���MWB�𒊏o
    FOR WK_REC IN CUR_TFJ301_HWB_SEL( IN_DATE ) LOOP

        WK_MWB_IN_CNT := WK_MWB_IN_CNT + 1;

        -- MWB�̕��ʁE���z���ڍX�V
        UPD_MWB_AMT1( IN_DATE, WK_REC.MWB_TX_ID );
    END LOOP;

    -- 2005.10.01�ǉ� Master�̂ݍX�V���ꂽ�ꍇ�̃o�O�C��
    -- HWB���X�V����ĂȂ��A�{���X�V����MWB�𒊏o
    FOR WK_REC IN CUR_TFJ301_MWB_SEL( IN_DATE ) LOOP

        WK_MWB_IN_CNT := WK_MWB_IN_CNT + 1;

        -- MWB�̕��ʁE���z���ڍX�V
        UPD_MWB_AMT2( IN_DATE, WK_REC.MWB_TX_ID );
    END LOOP;

    PFGA3910.TRACE_LOG( 'I', 'HWB      ��������   = ' || WK_HWB_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'MWB      ��������   = ' || WK_MWB_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� �X�V����   = ' || WK_TFJ301_UPD_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� �ԏo�͌��� = ' || PFGA3010.WK_TFJ301_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� ���o�͌��� = ' || PFGA3010.WK_TFJ301_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z �ԏo�͌��� = ' || PFGA3010.WK_TFJ303_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z ���o�͌��� = ' || PFGA3010.WK_TFJ303_KURO_CNT );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �{���X�V����HWB���z���ڍX�V
--================================================
PROCEDURE UPD_HWB_AMT(
    IN_DATE     IN DATE )                 -- �Ɩ����t(yyyymmdd)
IS

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'UPD_HWB_AMT' );

    -- �{���X�V����HWB��HWB���Ƃɒ��o
    FOR WK_REC IN CUR_TFJ301_HWB( IN_DATE ) LOOP

        WK_HWB_IN_CNT := WK_HWB_IN_CNT + 1;

        -- HWB�̎��і��ׂ̋��z�i���E�R�X�g�j���Z�b�g
        UPDATE TFJ301
              SET FRT_SALES_AMT = WK_REC.FRT_SALES_AMT,
                  FOT_SALES_AMT = WK_REC.FOT_SALES_AMT,
                  CCO_SALES_AMT = WK_REC.CCO_SALES_AMT,
                  CHG_SALES_AMT = WK_REC.CHG_SALES_AMT,
                  FRT_COST_AMT  = WK_REC.FRT_COST_AMT,
                  FOT_COST_AMT  = WK_REC.FOT_COST_AMT,
                  AGT_COST_AMT  = WK_REC.AGT_COST_AMT,
                  CHG_COST_AMT  = WK_REC.CHG_COST_AMT
              WHERE EDATKBN        = WK_REC.EDATKBN
                AND PIPELINE_TX_ID = WK_REC.PIPELINE_TX_ID
                AND DGYMDTM        = WK_REC.DGYMDTM
                AND NGENNO         = WK_REC.NGENNO;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �{���X�V����HWB���MWB�̕��ʁE���z���ڍX�V
--================================================
PROCEDURE UPD_MWB_AMT1(
    IN_DATE       IN         DATE,                      -- �Ɩ����t(yyyymmdd)
    IN_MWB_TX_ID  IN         TFJ301.MWB_TX_ID%TYPE )
IS

    WK_NGENNO                TFJ301.NGENNO%TYPE;
    WK_HWB_SUM               CUR_TFJ301_HWB_SUM%ROWTYPE;
    WK_FRT_COST_AMT          TFJ301.FRT_COST_AMT%TYPE;
    WK_FOT_COST_AMT          TFJ301.FOT_COST_AMT%TYPE;
    WK_CHG_COST_AMT          TFJ301.FOT_COST_AMT%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'UPD_MWB_AMT1' );

    -- MWB ���o
    FOR WK_REC IN CUR_TFJ301_MWB( IN_MWB_TX_ID ) LOOP

        -- �Ɩ������������Ȃ��ꍇ�͐���t�o
        IF WK_REC.DGYMDTM != IN_DATE THEN
            UP_NGENNO_MWB( IN_DATE, WK_REC, WK_NGENNO );
        ELSE
            WK_NGENNO         := WK_REC.NGENNO;
        END IF;

        -- MWB�P�ʂ�HWB�̋��z��Category���ɍ��v
        SUM_HWB( IN_MWB_TX_ID, WK_HWB_SUM );
        -- MASTER���g��Charge���v
        SUM_MWB_COST( IN_MWB_TX_ID, WK_FRT_COST_AMT, WK_FOT_COST_AMT, WK_CHG_COST_AMT );

        -- HWB�̎��і��ׂ̋��z�i���E�R�X�g�j���Z�b�g
        -- 2005/06/27 Upd �X�VKey��DGYMDTM��WK_REC.DGYMDTM����IN_DATE�i�����j�ɕύX
        --                ����t�o�������AWK_REC.DGYMDTM�ł͍X�V����Ȃ��B
        UPDATE TFJ301
              SET FRT_SALES_AMT = WK_HWB_SUM.FRT_SALES_AMT,
                  FOT_SALES_AMT = WK_HWB_SUM.FOT_SALES_AMT,
                  CCO_SALES_AMT = WK_HWB_SUM.CCO_SALES_AMT,
                  CHG_SALES_AMT = WK_HWB_SUM.CHG_SALES_AMT,
                  FRT_COST_AMT  = WK_FRT_COST_AMT,
                  FOT_COST_AMT  = WK_FOT_COST_AMT,
                  AGT_COST_AMT  = WK_HWB_SUM.AGT_COST_AMT,
                  CHG_COST_AMT  = WK_CHG_COST_AMT,
                  HAWB_CNT      = WK_HWB_SUM.HAWB_CNT,
                  HAWB_AGWT     = WK_HWB_SUM.HAWB_AGWT,
                  HAWB_CGWT     = WK_HWB_SUM.HAWB_CGWT,
                  HAWB_M3       = WK_HWB_SUM.HAWB_M3,
                  HAWB_VWT      = WK_HWB_SUM.HAWB_VWT,
                  HAWB_PCS      = WK_HWB_SUM.HAWB_PCS
              WHERE EDATKBN        = WK_REC.EDATKBN
                AND PIPELINE_TX_ID = WK_REC.PIPELINE_TX_ID
                AND DGYMDTM        = IN_DATE
                AND NGENNO         = WK_NGENNO;

        WK_TFJ301_UPD_CNT := WK_TFJ301_UPD_CNT + 1;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �{���X�V����MWB��蕨�ʁE���z���ڍX�V
--================================================
PROCEDURE UPD_MWB_AMT2(
    IN_DATE       IN         DATE,                      -- �Ɩ����t(yyyymmdd)
    IN_MWB_TX_ID  IN         TFJ301.MWB_TX_ID%TYPE )
IS

    WK_HWB_SUM               CUR_TFJ301_HWB_SUM%ROWTYPE;
    WK_FRT_COST_AMT          TFJ301.FRT_COST_AMT%TYPE;
    WK_FOT_COST_AMT          TFJ301.FOT_COST_AMT%TYPE;
    WK_CHG_COST_AMT          TFJ301.FOT_COST_AMT%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'UPD_MWB_AMT2' );

    -- MWB ���o
    FOR WK_REC IN CUR_TFJ301_MWB( IN_MWB_TX_ID ) LOOP

        -- MWB�P�ʂ�HWB�̋��z��Category���ɍ��v
        SUM_HWB( IN_MWB_TX_ID, WK_HWB_SUM );
        -- MASTER���g��Charge���v
        SUM_MWB_COST( IN_MWB_TX_ID, WK_FRT_COST_AMT, WK_FOT_COST_AMT, WK_CHG_COST_AMT );

        -- HWB�̎��і��ׂ̋��z�i���E�R�X�g�j���Z�b�g
        UPDATE TFJ301
              SET FRT_SALES_AMT = WK_HWB_SUM.FRT_SALES_AMT,
                  FOT_SALES_AMT = WK_HWB_SUM.FOT_SALES_AMT,
                  CCO_SALES_AMT = WK_HWB_SUM.CCO_SALES_AMT,
                  CHG_SALES_AMT = WK_HWB_SUM.CHG_SALES_AMT,
                  FRT_COST_AMT  = WK_FRT_COST_AMT,
                  FOT_COST_AMT  = WK_FOT_COST_AMT,
                  AGT_COST_AMT  = WK_HWB_SUM.AGT_COST_AMT,
                  CHG_COST_AMT  = WK_CHG_COST_AMT,
                  HAWB_CNT      = WK_HWB_SUM.HAWB_CNT,
                  HAWB_AGWT     = WK_HWB_SUM.HAWB_AGWT,
                  HAWB_CGWT     = WK_HWB_SUM.HAWB_CGWT,
                  HAWB_M3       = WK_HWB_SUM.HAWB_M3,
                  HAWB_VWT      = WK_HWB_SUM.HAWB_VWT,
                  HAWB_PCS      = WK_HWB_SUM.HAWB_PCS
              WHERE EDATKBN        = WK_REC.EDATKBN
                AND PIPELINE_TX_ID = WK_REC.PIPELINE_TX_ID
                AND DGYMDTM        = WK_REC.DGYMDTM
                AND NGENNO         = WK_REC.NGENNO;

        WK_TFJ301_UPD_CNT := WK_TFJ301_UPD_CNT + 1;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 4;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �Ɩ������������Ȃ��ꍇ�͐���t�o
--================================================
PROCEDURE UP_NGENNO_MWB(
    IN_DATE            IN      DATE,                      -- �Ɩ����t(yyyymmdd)
    IN_TFJ301_MWB      IN      CUR_TFJ301_MWB%ROWTYPE,
    OUT_NGENNO         IN OUT  TFJ301.NGENNO%TYPE )       -- ����ԍ�
IS

    WK_TFJ201                TFJ201%ROWTYPE;
    WK_MWB                   PFGA3010.CUR_MWB%ROWTYPE;

    WK_TFJ301                TFJ301%ROWTYPE;
    WK_ORIGINAL_KJODTM       TFJ301.ORIGINAL_KJODTM%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'UP_NGENNO_MWB' );

    WK_TFJ201.WAYBILL_TYPE      := IN_TFJ301_MWB.PIPELINE_REF_TYPE;
    WK_TFJ201.PIPELINE_TX_ID    := IN_TFJ301_MWB.PIPELINE_TX_ID;
    WK_TFJ201.DGYMDTM           := IN_DATE;
    WK_TFJ201.ACCOUNTING_DATE   := IN_TFJ301_MWB.DKJODTM;             -- �ŐV�̌v���
    WK_TFJ201.COMPANY_ID        := IN_TFJ301_MWB.ECOMPANY_ID;
    WK_TFJ201.IMPORT_EXPORT_IND := TRIM(IN_TFJ301_MWB.EIM_EX_IND);
    WK_TFJ201.TRANSPORT_MODE    := IN_TFJ301_MWB.ETRANS_MODE;
    WK_TFJ201.INVOICE_DATE      := NULL;
    WK_TFJ201.ORIGINAL_INVOICE_DATE    := NULL;
    WK_TFJ201.MWB_TX_ID         := IN_TFJ301_MWB.PIPELINE_TX_ID;
    WK_TFJ201.HWB_TX_ID         := NULL;
    WK_TFJ201.RECORD_IND        := 'AP';
    WK_TFJ201.INVOICE_NO        := NULL;
    WK_TFJ201.INVOICE_TX_ID     := NULL;
    -- 2005.12.05 �v��ς݃f�[�^���
    WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := IN_TFJ301_MWB.ETERMINAL_ID;
    WK_TFJ201.GL_GROUP                    := IN_TFJ301_MWB.EDEPARTMENT_ID;

    -- MWB ���o
    PFGA3010.SEL_MWB( WK_MWB, WK_TFJ201 );

    IF WK_MWB.PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
        -- �v��f�[�^�ς݂̃f�[�^���������A
        -- �f�[�^������ꍇ�ԃf�[�^�쐬
        -- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
        PFGA3010.CHECK_KEIJYOU_MEISAI( WK_MWB.PIPELINE_TX_STATUS,
                                       WK_TFJ201,
                                       OUT_NGENNO,
                                       WK_ORIGINAL_KJODTM );

        -- �폜�f�[�^�ȊO�̏ꍇ
        IF WK_MWB.PIPELINE_TX_STATUS NOT IN ('VD','CAN') THEN
            -- MWB ���і��ׁA�ҏW
            PFGA3010.SET_TFJ301_MWB( WK_TFJ301,
                                     WK_MWB,
                                     WK_TFJ201,
                                     OUT_NGENNO,
                                     WK_ORIGINAL_KJODTM );
            -- ���і��ׂ�V�K�쐬
            PFGA3010.INS_TFJ301( WK_TFJ301 );

            -- HWB/MWB ���і��׋��z�A�ҏW�o��
            PFGA3010.OUTPUT_TFJ303( WK_TFJ201, WK_TFJ301, OUT_NGENNO );
        END IF;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ301/TFJ303: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- MWB�P�ʂ�HWB�̋��z��Category���ɍ��v
--================================================
PROCEDURE SUM_HWB(
    IN_MWB_TX_ID       IN      TFJ301.MWB_TX_ID%TYPE,
    OUT_HWB_SUM        IN OUT  CUR_TFJ301_HWB_SUM%ROWTYPE )
IS

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'SUM_HWB' );

    OUT_HWB_SUM.FRT_SALES_AMT := 0;
    OUT_HWB_SUM.FOT_SALES_AMT := 0;
    OUT_HWB_SUM.CCO_SALES_AMT := 0;
    OUT_HWB_SUM.CHG_SALES_AMT := 0;
    OUT_HWB_SUM.AGT_COST_AMT  := 0;
    OUT_HWB_SUM.CHG_COST_AMT  := 0;
    OUT_HWB_SUM.HAWB_CNT      := 0;
    OUT_HWB_SUM.HAWB_AGWT     := 0;
    OUT_HWB_SUM.HAWB_CGWT     := 0;
    OUT_HWB_SUM.HAWB_M3       := 0;
    OUT_HWB_SUM.HAWB_VWT      := 0;
    OUT_HWB_SUM.HAWB_PCS      := 0;
    FOR WK_REC IN CUR_TFJ301_HWB_SUM( IN_MWB_TX_ID ) LOOP
        OUT_HWB_SUM := WK_REC;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 6;
            PFGA3910.TRACE_LOG('E','TFJ303: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- MASTER���g��Charge���v
--================================================
PROCEDURE SUM_MWB_COST(
    IN_MWB_TX_ID       IN      TFJ301.PIPELINE_TX_ID%TYPE,
    OUT_FRT_COST_AMT   IN OUT  TFJ301.FRT_COST_AMT%TYPE,
    OUT_FOT_COST_AMT   IN OUT  TFJ301.FRT_COST_AMT%TYPE,
    OUT_CHG_COST_AMT   IN OUT  TFJ301.FOT_COST_AMT%TYPE )
IS

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3012', 'SUM_MWB_COST' );

    OUT_FRT_COST_AMT := 0;
    OUT_FOT_COST_AMT := 0;
    FOR WK_REC IN CUR_TFJ301_MWB_SUM( IN_MWB_TX_ID ) LOOP
        OUT_FRT_COST_AMT := WK_REC.FRT_COST_AMT;
        OUT_FOT_COST_AMT := WK_REC.FOT_COST_AMT;
        OUT_CHG_COST_AMT := WK_REC.CHG_COST_AMT;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 7;
            PFGA3910.TRACE_LOG('E','TFJ303: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

END PFGA3012;
