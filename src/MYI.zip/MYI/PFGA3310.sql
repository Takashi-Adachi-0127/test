CREATE OR REPLACE PACKAGE PFGA3310 AS
--**********************************************
--�y �ڋq�ʋ��z���э쐬 �z
--  �p�b�P�[�W
--  PFGA3310
--  �Ăяo���K�w
--  CRE_TFJ331                            �ڋq�ʋ��z���т̍쐬
--    +-- INSERT_TFJ331                   �ڋq�ʋ��z���э쐬INSERT Main����
--          +-- SEL_TFJ331                �ڋq�ʋ��z���ь�������
--          +-- INS_TFJ331                �ڋq�ʋ��z���э쐬INSERT����
--          +-- UPD_TFJ331                �ڋq�ʋ��z���э쐬UPDATE����
--**********************************************

--******************************************
--�y �ڋq�ʋ��z���э쐬 �z�p�b�P�[�W�d�l��
--             PFGA3310
--******************************************

    -- ���[Tag���z�̒��o
    CURSOR CUR_TFJ311(
        wk_gyomdate     DATE
    ) IS
        SELECT  *
          FROM  TFJ311
         WHERE  DGYMDTM = wk_gyomdate
         ORDER  BY EIM_EX_IND,
                   ETRANS_MODE,
                   EWB_TYPE,
                   DKJODTM,
                   ECOMPANY_ID,
                   ETERMINAL_ID,
                   EDEPARTMENT_ID,
                   EHBI_TNTCD,
                   ECNORCD,
                   NKMK_ITI;

    -- �װ�����ϐ�
    WK_ERROR            NUMBER;

    -- ���[Tag���z�iTFJ311�j�̒��o�p�v�j�ϐ��J�E���^
    TFJ311_new_cnt      NUMBER ;
    TFJ311_adj_cnt      NUMBER ;

    -- �ڋq�ʋ��z���сiTFJ331�j�}���p�v�j�ϐ��J�E���^
    TFJ331_ins_cnt      NUMBER ;
    TFJ331_upd_cnt      NUMBER ;

    REC_TFJ311          CUR_TFJ311%ROWTYPE ;

    -- ���[Tag���z�L�[�u���C�N�v�j�ϐ�
    wk_EIM_EX_IND       TFJ311.EIM_EX_IND%TYPE;
    wk_ETRANS_MODE      TFJ311.ETRANS_MODE%TYPE;
    wk_EWB_TYPE         TFJ311.EWB_TYPE%TYPE;
    wk_DKJODTM          TFJ311.DKJODTM%TYPE;
    wk_ECOMPANY_ID      TFJ311.ECOMPANY_ID%TYPE;
    wk_ETERMINAL_ID     TFJ311.ETERMINAL_ID%TYPE;
    wk_EDEPARTMENT_ID   TFJ311.EDEPARTMENT_ID%TYPE;
    wk_EHBI_TNTCD       TFJ311.EHBI_TNTCD%TYPE;
    wk_ECNORCD          TFJ311.ECNORCD%TYPE;
    wk_NKMK_ITI         TFJ311.NKMK_ITI%TYPE;        --���ڈʒu


    -- �ڋq�ʋ��z���сiTFJ331�j�}���p�v�j�ϐ�
    wki_ETRKDTM         TFJ331.ETRKDTM%TYPE;
    wki_EUPDDTM         TFJ331.EUPDDTM%TYPE;
    wki_DHNEDTM         TFJ331.DHNEDTM%TYPE;
    wki_EUPD_OFCCD      TFJ331.EUPD_OFCCD%TYPE;
    wki_EUPD_TNTCD      TFJ331.EUPD_TNTCD%TYPE;
    wki_DGYMDTM         TFJ331.DGYMDTM%TYPE;
    wki_EIM_EX_IND      TFJ331.EIM_EX_IND%TYPE;
    wki_ETRANS_MODE     TFJ331.ETRANS_MODE%TYPE;
    wki_EWB_TYPE        TFJ331.EWB_TYPE%TYPE;
    wki_DKJODTM         TFJ331.DKJODTM%TYPE;
    wki_ECOMPANY_ID     TFJ331.ECOMPANY_ID%TYPE;
    wki_ETERMINAL_ID    TFJ331.ETERMINAL_ID%TYPE;
    wki_EDEPARTMENT_ID  TFJ331.EDEPARTMENT_ID%TYPE;
    wki_EHBI_TNTCD      TFJ331.EHBI_TNTCD%TYPE;
    wki_ECNORCD         TFJ331.ECNORCD%TYPE;
    wki_NKMK_ITI        TFJ331.NKMK_ITI%TYPE;
    wki_EPRT_TAG        TFJ331.EPRT_TAG%TYPE;
    wki_NHSI_HBI_KIN    TFJ331.NHSI_HBI_KIN%TYPE;
    wki_NSYSI_HBI_KIN   TFJ331.NSYSI_HBI_KIN%TYPE;
    wki_NHSI_COST_KIN   TFJ331.NHSI_COST_KIN%TYPE;
    wki_NSYSI_COST_KIN  TFJ331.NSYSI_COST_KIN%TYPE;

--==========================================
-- PROCEDURE / FUNCTION
--==========================================
-- �f�[�^���o�E�W�v�E�쐬�v���V�[�W��
PROCEDURE CRE_TFJ331(
    in_date             IN      DATE                    -- �Ɩ����t
 ) ;

-- �ڋq�ʋ��z���э쐬INSERT Main����
PROCEDURE INSERT_TFJ331 ;

-- �ڋq�ʋ��z���ь�������
    FUNCTION SEL_TFJ331(
        OUT_TFJ331       IN OUT TFJ331%ROWTYPE )        -- �ڋq�ʋ��z����
    RETURN NUMBER;

-- �ڋq�ʋ��z���э쐬INSERT����
PROCEDURE INS_TFJ331 ;

-- �ڋq�ʋ��z���э쐬UPDATE����
PROCEDURE UPD_TFJ331 ;

END PFGA3310 ;
CREATE OR REPLACE PACKAGE BODY PFGA3310 AS
--******************************************
--�y �ڋq�ʋ��z���э쐬 �z�p�b�P�[�W�{�̕�
--             PFGA3310
--******************************************

--******************************************
--==========================================
-- �ڋq�ʋ��z���т̍쐬
-- �iTFJ311�ATKM011����ATFJ331�ցj
--==========================================
PROCEDURE CRE_TFJ331(
    in_date             IN      DATE                    -- �Ɩ����t
) IS

    wk_rtn              NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3310','CRE_TFJ331');
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || in_date );

    -- �ϐ��N���A
    wk_EIM_EX_IND       := '#' ;
    wk_ETRANS_MODE      := '#' ;
    wk_EWB_TYPE         := '#' ;
    wk_DKJODTM          := TO_DATE('2000/01/01','YYYY/MM/DD') ;
    wk_ECOMPANY_ID      := '#' ;
    wk_ETERMINAL_ID     := '#' ;
    wk_EDEPARTMENT_ID   := '#' ;
    wk_EHBI_TNTCD       := '#' ;
    wk_ECNORCD          := '#' ;
    wk_NKMK_ITI         := 0 ;    --���ڈʒu

    WK_ERROR            := 0;
    TFJ311_new_cnt      := 0 ;
    TFJ311_adj_cnt      := 0 ;
    TFJ331_ins_cnt      := 0 ;
    TFJ331_upd_cnt      := 0 ;

    -- ���[Tag���zð��ٵ����
    OPEN CUR_TFJ311( in_date ) ;
    LOOP
        FETCH CUR_TFJ311 INTO REC_TFJ311 ;
        EXIT WHEN CUR_TFJ311%NOTFOUND ;

        IF REC_TFJ311.EIM_EX_IND     != wk_EIM_EX_IND     OR
           REC_TFJ311.ETRANS_MODE    != wk_ETRANS_MODE    OR
           REC_TFJ311.EWB_TYPE       != wk_EWB_TYPE       OR
           REC_TFJ311.DKJODTM        != wk_DKJODTM        OR
           REC_TFJ311.ECOMPANY_ID    != wk_ECOMPANY_ID    OR
           REC_TFJ311.ETERMINAL_ID   != wk_ETERMINAL_ID   OR
           REC_TFJ311.EDEPARTMENT_ID != wk_EDEPARTMENT_ID OR
           REC_TFJ311.EHBI_TNTCD     != wk_EHBI_TNTCD     OR
           REC_TFJ311.ECNORCD        != wk_ECNORCD        OR
           REC_TFJ311.NKMK_ITI       != wk_NKMK_ITI       THEN
            IF wk_ECOMPANY_ID != '#' THEN
                --�L�[�u���C�N���ڋq�ʋ��z����INSERT
                INSERT_TFJ331 ;
            END IF;

            wk_EIM_EX_IND      := REC_TFJ311.EIM_EX_IND;
            wk_ETRANS_MODE     := REC_TFJ311.ETRANS_MODE;
            wk_EWB_TYPE        := REC_TFJ311.EWB_TYPE;
            wk_DKJODTM         := REC_TFJ311.DKJODTM;
            wk_ECOMPANY_ID     := REC_TFJ311.ECOMPANY_ID;
            wk_ETERMINAL_ID    := REC_TFJ311.ETERMINAL_ID;
            wk_EDEPARTMENT_ID  := REC_TFJ311.EDEPARTMENT_ID;
            wk_EHBI_TNTCD      := REC_TFJ311.EHBI_TNTCD;
            wk_ECNORCD         := REC_TFJ311.ECNORCD;
            wk_NKMK_ITI        := REC_TFJ311.NKMK_ITI;

            -- ���[Tag���z���ڂ��ڋq�ʋ��z����ܰ��̈�ɃZ�b�g
            -- ����
            wki_ETRKDTM        := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
            wki_EUPDDTM        := TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS');
            wki_DHNEDTM        := SYSDATE;
            wki_EUPD_OFCCD     := '!';
            wki_EUPD_TNTCD     := '!';
            -- �j�d�x
            wki_DGYMDTM        := REC_TFJ311.DGYMDTM;
            wki_EIM_EX_IND     := REC_TFJ311.EIM_EX_IND;
            wki_ETRANS_MODE    := REC_TFJ311.ETRANS_MODE;
            wki_EWB_TYPE       := REC_TFJ311.EWB_TYPE;
            wki_DKJODTM        := REC_TFJ311.DKJODTM;
            wki_ECOMPANY_ID    := REC_TFJ311.ECOMPANY_ID;
            wki_ETERMINAL_ID   := REC_TFJ311.ETERMINAL_ID;
            wki_EDEPARTMENT_ID := REC_TFJ311.EDEPARTMENT_ID;
            wki_EHBI_TNTCD     := REC_TFJ311.EHBI_TNTCD;
            wki_ECNORCD        := REC_TFJ311.ECNORCD;
            wki_NKMK_ITI       := REC_TFJ311.NKMK_ITI;
            wki_EPRT_TAG       := REC_TFJ311.EPRT_TAG;

            -- ���z��������
            wki_NHSI_HBI_KIN   := 0;
            wki_NSYSI_HBI_KIN  := 0;
            wki_NHSI_COST_KIN  := 0;
            wki_NSYSI_COST_KIN := 0;
        END IF;

        -- ���z�����Z
        IF REC_TFJ311.EOPE_KBN = '0' THEN  --�f�[�^�����敪�i�V�K�j
            wki_NHSI_HBI_KIN   := wki_NHSI_HBI_KIN
                               + (REC_TFJ311.NURI_KIN * REC_TFJ311.NAKKBN);
            wki_NHSI_COST_KIN  := wki_NHSI_COST_KIN
                               + (REC_TFJ311.NOROS_KIN * REC_TFJ311.NAKKBN);
            TFJ311_new_cnt     := TFJ311_new_cnt + 1 ;
        ELSE                               --�f�[�^�����敪�i�C���j
            wki_NSYSI_HBI_KIN  := wki_NSYSI_HBI_KIN
                               + (REC_TFJ311.NURI_KIN * REC_TFJ311.NAKKBN);
            wki_NSYSI_COST_KIN := wki_NSYSI_COST_KIN
                               + (REC_TFJ311.NOROS_KIN * REC_TFJ311.NAKKBN);
            TFJ311_adj_cnt     := TFJ311_adj_cnt + 1 ;
        END IF;

    END LOOP ;
    CLOSE CUR_TFJ311 ;

    IF wk_ECOMPANY_ID != '#' THEN
        --�Ō�̌ڋq�ʋ��z����INSERT
        INSERT_TFJ331 ;
    END IF;

    PFGA3910.TRACE_LOG('I','���[Tag���z�i�V�K�j���͌��� = ' || TFJ311_new_cnt);
    PFGA3910.TRACE_LOG('I','���[Tag���z�i�C���j���͌��� = ' || TFJ311_adj_cnt);
    PFGA3910.TRACE_LOG('I','�ڋq�ʋ��z���� �V�K����     = ' || TFJ331_ins_cnt);
    PFGA3910.TRACE_LOG('I','�ڋq�ʋ��z���� �X�V����     = ' || TFJ331_upd_cnt);
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ311: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        IF CUR_TFJ311%ISOPEN THEN
            CLOSE CUR_TFJ311 ;
        END IF ;
        RAISE ;
END ;

--================================================
-- �ڋq�ʋ��z���э쐬INSERT Main����
--================================================
PROCEDURE INSERT_TFJ331
IS
    WK_RC         NUMBER;
    WK_TFJ331     TFJ331%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3310','INSERT_TFJ331');

    -- �ڋq�ʋ��z���т�����
    WK_RC := SEL_TFJ331( WK_TFJ331 );

    IF WK_RC = 0 THEN
        -- �ڋq�ʋ��z���т�V�K�쐬
        INS_TFJ331;
    ELSE
        -- �ڋq�ʋ��z���тɉ��Z����
        wki_NHSI_HBI_KIN   := wki_NHSI_HBI_KIN   + WK_TFJ331.NHSI_HBI_KIN;
        wki_NSYSI_HBI_KIN  := wki_NSYSI_HBI_KIN  + WK_TFJ331.NSYSI_HBI_KIN;
        wki_NHSI_COST_KIN  := wki_NHSI_COST_KIN  + WK_TFJ331.NHSI_COST_KIN;
        wki_NSYSI_COST_KIN := wki_NSYSI_COST_KIN + WK_TFJ331.NSYSI_COST_KIN;

        -- �ڋq�ʋ��z���т��X�V�쐬
        UPD_TFJ331;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- �ڋq�ʋ��z���т�����
--================================================
FUNCTION SEL_TFJ331(
    OUT_TFJ331       IN OUT TFJ331%ROWTYPE )         -- �ڋq�ʋ��z����
    RETURN NUMBER
IS
    -- �ڋq�ʋ��z���ђ��o�J�[�\��
    CURSOR CUR_TFJ331( IN_DGYMDTM        IN TFJ331.DGYMDTM%TYPE,
                       IN_EIM_EX_IND     IN TFJ331.EIM_EX_IND%TYPE,
                       IN_ETRANS_MODE    IN TFJ331.ETRANS_MODE%TYPE,
                       IN_EWB_TYPE       IN TFJ331.EWB_TYPE%TYPE,
                       IN_DKJODTM        IN TFJ331.DKJODTM%TYPE,
                       IN_ECOMPANY_ID    IN TFJ331.ECOMPANY_ID%TYPE,
                       IN_ETERMINAL_ID   IN TFJ331.ETERMINAL_ID%TYPE,
                       IN_EDEPARTMENT_ID IN TFJ331.EDEPARTMENT_ID%TYPE,
                       IN_EHBI_TNTCD     IN TFJ331.EHBI_TNTCD%TYPE,
                       IN_ECNORCD        IN TFJ331.ECNORCD%TYPE,
                       IN_NKMK_ITI       IN TFJ331.NKMK_ITI%TYPE,
                       IN_EPRT_TAG       IN TFJ331.EPRT_TAG%TYPE ) IS
        SELECT *
          FROM TFJ331
          WHERE DGYMDTM        = IN_DGYMDTM
            AND EIM_EX_IND     = IN_EIM_EX_IND
            AND ETRANS_MODE    = IN_ETRANS_MODE
            AND EWB_TYPE       = IN_EWB_TYPE
            AND DKJODTM        = IN_DKJODTM
            AND ECOMPANY_ID    = IN_ECOMPANY_ID
            AND ETERMINAL_ID   = IN_ETERMINAL_ID
            AND EDEPARTMENT_ID = IN_EDEPARTMENT_ID
            AND EHBI_TNTCD     = IN_EHBI_TNTCD
            AND ECNORCD        = IN_ECNORCD
            AND NKMK_ITI       = IN_NKMK_ITI
            AND EPRT_TAG       = IN_EPRT_TAG;

    WK_RC         NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3310','SEL_TFJ331');

    WK_RC := 0;
    OUT_TFJ331 := NULL;

    FOR WK_REC IN CUR_TFJ331( wki_DGYMDTM,
                              wki_EIM_EX_IND,
                              wki_ETRANS_MODE,
                              wki_EWB_TYPE,
                              wki_DKJODTM,
                              wki_ECOMPANY_ID,
                              wki_ETERMINAL_ID,
                              wki_EDEPARTMENT_ID,
                              wki_EHBI_TNTCD,
                              wki_ECNORCD,
                              wki_NKMK_ITI,
                              wki_EPRT_TAG ) LOOP
        WK_RC := 1;
        OUT_TFJ331 := WK_REC;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

    RETURN WK_RC;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ331: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- �ڋq�ʋ��z���э쐬INSERT����
-- �ڋq�ʋ��z����ܰ����ް��Z�b�g�ς�
--==========================================
PROCEDURE INS_TFJ331
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3310','INS_TFJ331');

-- insert���s
    INSERT  INTO TFJ331 (
            --����
            ETRKDTM,
            EUPDDTM,
            DHNEDTM,
            EUPD_OFCCD,
            EUPD_TNTCD,
            -- �j�d�x
            DGYMDTM,
            EIM_EX_IND,
            ETRANS_MODE,
            EWB_TYPE,
            DKJODTM,
            ECOMPANY_ID,
            ETERMINAL_ID,
            EDEPARTMENT_ID,
            EHBI_TNTCD,
            ECNORCD,
            NKMK_ITI,
            EPRT_TAG,
            -- ���z�ر�i������z�j
            NHSI_HBI_KIN,
            NSYSI_HBI_KIN,
            -- ���z�ر�i�R�X�g�j
            NHSI_COST_KIN,
            NSYSI_COST_KIN )
    VALUES(
            --����
            wki_ETRKDTM,
            wki_EUPDDTM,
            wki_DHNEDTM,
            wki_EUPD_OFCCD,
            wki_EUPD_TNTCD,
            -- �j�d�x
            wki_DGYMDTM,
            wki_EIM_EX_IND,
            wki_ETRANS_MODE,
            wki_EWB_TYPE,
            wki_DKJODTM,
            wki_ECOMPANY_ID,
            wki_ETERMINAL_ID,
            wki_EDEPARTMENT_ID,
            wki_EHBI_TNTCD,
            wki_ECNORCD,
            wki_NKMK_ITI,
            wki_EPRT_TAG,
            -- ���z�ر�i������z�j
            wki_NHSI_HBI_KIN,
            wki_NSYSI_HBI_KIN,
            -- ���z�ر�i�R�X�g�j
            wki_NHSI_COST_KIN,
            wki_NSYSI_COST_KIN );

    TFJ331_ins_cnt  := TFJ331_ins_cnt + 1 ;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 4;
            PFGA3910.TRACE_LOG('E','TFJ331: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE ;
END ;

--==========================================
-- �ڋq�ʋ��z���э쐬UPDATE����
-- �ڋq�ʋ��z����ܰ����ް��Z�b�g�ς�
--==========================================
PROCEDURE UPD_TFJ331
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3310','UPD_TFJ331');

-- update���s
        UPDATE  TFJ331
           SET  NHSI_HBI_KIN   = wki_NHSI_HBI_KIN,
                NSYSI_HBI_KIN  = wki_NSYSI_HBI_KIN,
                NHSI_COST_KIN  = wki_NHSI_COST_KIN,
                NSYSI_COST_KIN = wki_NSYSI_COST_KIN
         WHERE  DGYMDTM      = wki_DGYMDTM
            AND EIM_EX_IND     = wki_EIM_EX_IND
            AND ETRANS_MODE    = wki_ETRANS_MODE
            AND EWB_TYPE       = wki_EWB_TYPE
            AND DKJODTM        = wki_DKJODTM
            AND ECOMPANY_ID    = wki_ECOMPANY_ID
            AND ETERMINAL_ID   = wki_ETERMINAL_ID
            AND EDEPARTMENT_ID = wki_EDEPARTMENT_ID
            AND EHBI_TNTCD     = wki_EHBI_TNTCD
            AND ECNORCD        = wki_ECNORCD
            AND NKMK_ITI       = wki_NKMK_ITI
            AND EPRT_TAG       = wki_EPRT_TAG;

    TFJ331_upd_cnt  := TFJ331_upd_cnt + 1 ;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ331: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE ;
END ;

END PFGA3310 ;