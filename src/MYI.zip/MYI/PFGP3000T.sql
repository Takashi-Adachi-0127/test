CREATE OR REPLACE PROCEDURE           PFGP3000T
--(
--    in_kjo_dtm      IN  DATE
--)
IS
    user_id		CMN_JOB_BOOT.USER_ID%TYPE;
    add_day 	        NUMBER;
    rtn 	        NUMBER;
    rtn_job		NUMBER;
    rtn_string    	VARCHAR2(512);
    updateStatus 	NUMBER;
    start_date 		VARCHAR2(255);
    end_date 		VARCHAR2(255);
    mail_address 	PFGA4910.MAIL_ADDRESS;

    wk_rtn              NUMBER(2) ;
    wk_cnt              NUMBER;
    -- �Ɩ����t�i�v����t�j�擾�p�ϐ�
    wk_kjo_dtm          DATE ;
    wk_kjo_dtm_d        DATE ;

    WK_ROWID            ROWID ;                     -- ROW ID

BEGIN

    PFGA3910.TRACE_INIT(PFGA4910.LOG_DIR,'myi_log.inf');
    PFGA3910.TRACE_PROC_ENTRY('PFGP3000', 'MAIN');

    rtn_job      := -1;

    updateStatus := 3;                         --- CMN_JOB_BOOT.STATUS UPDATE
    ORSYS_COMMON.UPDATE_STATUS( PFGP3000.job_name, updateStatus, rtn);
    start_date := TO_CHAR(SYSDATE , 'YYYY/MM/DD HH24:MI:SS');

    -- �Ɩ����tTBL(�ް��敪='D') ����
    SELECT DGYOMDTM + 1
      INTO wk_kjo_dtm_d
      FROM TKD909J
      WHERE EDATKBN = 'D';

    wk_kjo_dtm      := wk_kjo_dtm_d;

    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 JPUFSPR IF(Air Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','A',302);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 JPUFSPR IF(Air Import) JOB END' ) ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 JPUFSPR IF(Ocean Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','O',302);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 JPUFSPR IF(Ocean Import) JOB END' ) ;

    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 AMUFSPR IF(Air Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','A',202);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 AMUFSPR IF(Air Import) JOB END' ) ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 AMUFSPR IF(Ocean Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','O',202);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 AMUFSPR IF(Ocean Import) JOB END' ) ;

    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 UFSPlus IF(Air Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','A',802);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 UFSPlus IF(Air Import) JOB END' ) ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 UFSPlus IF(Ocean Import) JOB START' ) ;
    PFGA2010.CRE_TFJ201(wk_kjo_dtm,'560','I','O',802);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2010 UFSPlus IF(Ocean Import) JOB END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA2030 AR Interface JOB START' ) ;
    PFGA2030.CRE_TFJ203(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA2030 AR Interface JOB END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3010 START' ) ;
    PFGA3010.CRE_MEISAI_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3010 END' ) ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3011 START' ) ;
    PFGA3011.CRE_MEISAI_JISSEKI(wk_kjo_dtm,'560','I','A');
    COMMIT ;
    PFGA3011.CRE_MEISAI_JISSEKI(wk_kjo_dtm,'560','I','O');
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3011 END' ) ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3012 START' ) ;
    PFGA3012.CRE_MEISAI_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3012 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3020 START' ) ;
    PFGA3020.CRE_TFJ302(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3020 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3110 START' ) ;
    PFGA3110.CRE_TFJ311(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3110 END' ) ;
    -- �ӏ��ʎ��э쐬
    PFGA3910.TRACE_LOG( 'I',  'PFGA3210 START' ) ;
    PFGA3210.CRE_TFJ321(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3210 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3220 START' ) ;
    PFGA3220.CRE_BUTSURYOU_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3220 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3230 START' ) ;
    PFGA3230.CRE_TFJ323(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3230 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3240 START' ) ;
    PFGA3240.CRE_MON_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3240 END' ) ;
    -- �ڋq�ʎ��э쐬
    PFGA3910.TRACE_LOG( 'I',  'PFGA3310 START' ) ;
    PFGA3310.CRE_TFJ331(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3310 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3320 START' ) ;
    PFGA3320.CRE_BUTSURYOU_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3320 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3330 START' ) ;
    PFGA3330.CRE_TFJ333(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3330 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3340 START' ) ;
    PFGA3340.CRE_MON_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3340 END' ) ;
    --
    PFGA3910.TRACE_LOG( 'I',  'PFGA3350 START' ) ;
    PFGA3350.CRE_TORIHIKI_JISSEKI(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3350 END' ) ;
    --
    -- �ӏ��ʉ��d�����э쐬
    PFGA3910.TRACE_LOG( 'I',  'PFGA3430 START' ) ;
    PFGA3430.CRE_TFJ343(wk_kjo_dtm);
    COMMIT ;
    PFGA3910.TRACE_LOG( 'I',  'PFGA3430 END' ) ;

    -- ����Server�̋Ɩ����tTBL(�ް��敪='D') ����
    SELECT ROWID
      INTO WK_ROWID
      FROM TKD909J
      WHERE EDATKBN = 'D'
      FOR UPDATE ;

    -- �Ɩ����tTBL(�ް��敪='D') �X�V
    UPDATE TKD909J
      SET EUPDDTM    = TO_CHAR( SYSDATE, 'YYYYMMDDHH24MISS' ),  -- �X�V����
          DHNEDTM    = SYSDATE,                                 -- ���f����
          EUPD_OFCCD = '!',                                     -- �X�V��������
          EUPD_TNTCD = '!',                                     -- �X�V�S���Һ���
          DGYOMDTM   = wk_kjo_dtm                               -- �v����t
      WHERE ROWID = WK_ROWID ;
    COMMIT ;

    updateStatus := 9;                         --- CMN_JOB_BOOT.STATUS UPDATE
    ORSYS_COMMON.UPDATE_STATUS( PFGP3000.job_name, updateStatus, rtn);
    end_date := TO_CHAR(SYSDATE , 'YYYY/MM/DD HH24:MI:SS');

    rtn_job      := 0;                         --- Normal End
    rtn_string   := 'Normal End' ;

    -- send mail
    --mail_address := GET_MAIL_ADDRESS( job_name, updateStatus);
    --SEND_MAIL( PFGP3000.job_name, mail_address, start_date, end_date, rtn_string);
    ORSYS_COMMON.SEND_MAIL( PFGP3000.JOB_NAME,
                            UPDATESTATUS,
                            START_DATE,
                            END_DATE,
                            RTN_STRING);
    --OUT_ERRMSG := OUT_ERRMSG || COMMON_MY.CR_LF || RTN_STRING;

    -- write history
    user_id := ORSYS_COMMON.GET_USERID( PFGP3000.job_name);
    ORSYS_COMMON.ADD_HISTORY( PFGP3000.job_name,
             updateStatus,
             user_id,
             start_date,
             end_date,
             rtn_string,
             rtn);

    -- next run set
    add_day      := 1;
    --ORSYS_COMMON.UPDATE_RSVTIME( PFGP3000.job_name, add_day, rtn);
    ORSYS_COMMON.UPDATE_RSVTIME(PFGP3000.JOB_NAME,RTN);

    updateStatus := 2;                         --- CMN_JOB_BOOT.STATUS UPDATE
    ORSYS_COMMON.UPDATE_STATUS( PFGP3000.job_name, updateStatus, rtn);

    PFGA3910.TRACE_PROC_EXIT;

    return ;

EXCEPTION
    WHEN OTHERS THEN
        PFGA3910.TRACE_LOG( 'E',  ' SQLERRM=' || SQLERRM ) ;
        PFGA3910.TRACE_STACK( 'E' );
        ROLLBACK ;
        dbms_output.put_line(SQLERRM);

        updateStatus := 8;                         --- CMN_JOB_BOOT.STATUS UPDATE
        ORSYS_COMMON.UPDATE_STATUS( PFGP3000.job_name, updateStatus, rtn);
        end_date := TO_CHAR(SYSDATE , 'YYYY/MM/DD HH24:MI:SS');

        rtn_string         :=  'Err:'  || SQLERRM ;

        -- send mail
        --mail_address := GET_MAIL_ADDRESS( job_name, updateStatus);
        --SEND_MAIL( PFGP3000.job_name, mail_address, start_date, end_date, rtn_string);
        ORSYS_COMMON.SEND_MAIL( PFGP3000.JOB_NAME,
                            UPDATESTATUS,
                            START_DATE,
                            END_DATE,
                            RTN_STRING);
        -- write history
        user_id := ORSYS_COMMON.GET_USERID( PFGP3000.job_name);
        ORSYS_COMMON.ADD_HISTORY( PFGP3000.job_name,
                    updateStatus,
                 user_id,
                 start_date,
                 end_date,
                 rtn_string,
                 rtn);

        PFGA3910.TRACE_PROC_EXIT;

        return ;

END PFGP3000T ;
