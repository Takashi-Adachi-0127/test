CREATE OR REPLACE PACKAGE           PFGA3011 AS
--********************************************************************
--�y ���і��׍쐬 �z
--  �߯����
--  PFGA3011
--  �Ăяo���K�w
--  CRE_MEISAI_JISSEKI                    ���і��ׂ��쐬
--    +-- CRE_ISSUE                       ISSUE �f�[�^�쐬
--********************************************************************

--************************************************
--�y ���і��׍쐬 �z�߯���ގd�l��
--     PFGA3011
--************************************************

    -- EXPORT HWB(SH)
    CURSOR CUR_QUEUE_EX_SH(
        KEY_DATE               TFJ101.MODIFIED_DATE%TYPE,
        KEY_COMPANY_ID         TFJ101.ORIG_COMPANY_ID%TYPE,
        KEY_TRANSPORT_MODE     TFJ101.TRANSPORT_MODE%TYPE
    ) IS
      SELECT PIPELINE_TX_ID,
             TRUNC(STATUS_DATE) as ACCOUNTING_DATE
        FROM TFJ101
       WHERE PIPELINE_TX_TYPE   = 'SH'
         AND EXPORT_TX_STATUS   in ('IS','MFT','CNF','VD','CAN')
         AND MODIFIED_DATE      = KEY_DATE - 1
         AND ORIG_COMPANY_ID    = KEY_COMPANY_ID
         AND TRANSPORT_MODE     = KEY_TRANSPORT_MODE
         AND MODIFIED_COUNTRY   = ORIG_COUNTRY_CODE
         AND DATA_SOURCE_CODE   IS NULL
         AND CREATED_BY         <> 'css'
       ORDER BY PIPELINE_TX_ID;

    -- EXPORT MWB(CS)
    -- 2005.08.07
    -- ACCOUNTING_DATA��EXECUTION_DATE(PIPELINE_TX_DATE)���
    CURSOR CUR_QUEUE_EX_CS(
        KEY_DATE               TFJ101.MODIFIED_DATE%TYPE,
        KEY_COMPANY_ID         TFJ101.ORIG_COMPANY_ID%TYPE,
        KEY_TRANSPORT_MODE     TFJ101.TRANSPORT_MODE%TYPE
    ) IS
      SELECT PIPELINE_TX_ID,
             TRUNC(EXECUTION_DATE) as ACCOUNTING_DATE
        FROM TFJ101
       WHERE PIPELINE_TX_TYPE   = 'CS'
         AND PIPELINE_TX_STATUS in ('CNF','ICF')
         AND MODIFIED_DATE      = KEY_DATE - 1
         AND ORIG_COMPANY_ID    = KEY_COMPANY_ID
         AND TRANSPORT_MODE     = KEY_TRANSPORT_MODE
         AND MODIFIED_COUNTRY   = ORIG_COUNTRY_CODE
       ORDER BY PIPELINE_TX_ID;

    -- IMPORT HWB(SH)
    CURSOR CUR_QUEUE_IM_SH(
        KEY_DATE               TFJ101.MODIFIED_DATE%TYPE,
        KEY_COMPANY_ID         TFJ101.ORIG_COMPANY_ID%TYPE,
        KEY_TRANSPORT_MODE     TFJ101.TRANSPORT_MODE%TYPE
    ) IS
      SELECT PIPELINE_TX_ID,
             TRUNC(STATUS_DATE) as ACCOUNTING_DATE
        FROM TFJ101
       WHERE PIPELINE_TX_TYPE   = 'SH'
         AND IMPORT_TX_STATUS   in ('OIE','OI','ICF','VD','CAN')
         AND MODIFIED_DATE      = KEY_DATE - 1
         AND DEST_COMPANY_ID    = KEY_COMPANY_ID
         AND TRANSPORT_MODE     = KEY_TRANSPORT_MODE
         AND MODIFIED_COUNTRY   = DEST_COUNTRY_CODE
       ORDER BY PIPELINE_TX_ID;

    -- IMPORT MWB(CS)
    -- 2005.08.07
    CURSOR CUR_QUEUE_IM_CS(
        KEY_DATE               TFJ101.MODIFIED_DATE%TYPE,
        KEY_COMPANY_ID         TFJ101.ORIG_COMPANY_ID%TYPE,
        KEY_TRANSPORT_MODE     TFJ101.TRANSPORT_MODE%TYPE
    ) IS
      SELECT PIPELINE_TX_ID,
             TRUNC(STATUS_DATE) as ACCOUNTING_DATE
        FROM TFJ101
       WHERE PIPELINE_TX_TYPE   = 'CS'
         AND PIPELINE_TX_STATUS = 'ICF'
         AND MODIFIED_DATE      = KEY_DATE - 1
         AND DEST_COMPANY_ID    = KEY_COMPANY_ID
         AND TRANSPORT_MODE     = KEY_TRANSPORT_MODE
         AND MODIFIED_COUNTRY   = DEST_COUNTRY_CODE
       ORDER BY PIPELINE_TX_ID;


    --�y ܰ��ϐ� �z

    -- ���͌������ėpܰ��ϐ�
    WK_QUEUE_SH_IN_CNT      NUMBER;
    WK_QUEUE_CS_IN_CNT      NUMBER;
    WK_TFJ201_SKIP_CNT      NUMBER;

    --�y PROCEDURE / FUNCTION �z

    -- ���і��ׂ��쐬
    PROCEDURE CRE_MEISAI_JISSEKI(
        IN_DATE              IN  DATE,      -- �Ɩ�������
        IN_COMPANY_ID        IN  VARCHAR2,  -- ��ЃR�[�h
        IN_IMPORT_EXPORT_IND IN  VARCHAR2,  -- �A�o�^�A���敪
        IN_TRANSPORT_MODE    IN  VARCHAR2   -- �Ɩ��敪
    );

    -- ISSUE �f�[�^�쐬(SH)
    PROCEDURE CRE_ISSUE_SH(
        IN_DGYMDTM           IN     TFJ201.DGYMDTM%TYPE,          -- �Ɩ�������
        IN_COMPANY_ID        IN     TFJ201.COMPANY_ID%TYPE,       -- ��ЃR�[�h
        IN_IMPORT_EXPORT_IND IN     TFJ201.IMPORT_EXPORT_IND%TYPE,-- �A�o�^�A���敪
        IN_TRANSPORT_MODE    IN     TFJ201.TRANSPORT_MODE%TYPE,   -- �Ɩ��敪
        IN_PIPELINE_TX_ID    IN     TFJ201.PIPELINE_TX_ID%TYPE,
        IN_ACCOUNTING_DATE   IN     TFJ201.ACCOUNTING_DATE%TYPE );

    -- ISSUE �f�[�^�쐬(CS)
    PROCEDURE CRE_ISSUE_CS(
        IN_DGYMDTM           IN     TFJ201.DGYMDTM%TYPE,          -- �Ɩ�������
        IN_COMPANY_ID        IN     TFJ201.COMPANY_ID%TYPE,       -- ��ЃR�[�h
        IN_IMPORT_EXPORT_IND IN     TFJ201.IMPORT_EXPORT_IND%TYPE,-- �A�o�^�A���敪
        IN_TRANSPORT_MODE    IN     TFJ201.TRANSPORT_MODE%TYPE,   -- �Ɩ��敪
        IN_PIPELINE_TX_ID    IN     TFJ201.PIPELINE_TX_ID%TYPE,
        IN_ACCOUNTING_DATE   IN     TFJ201.ACCOUNTING_DATE%TYPE );

END PFGA3011;
CREATE OR REPLACE PACKAGE BODY PFGA3011 AS
--************************************************
--�y ���і��׍쐬 �z�߯���ޖ{�̕�
--     PFGA3011
--
-- HWB �� Issue �f�[�^����荞��(JPAEX�Ή�)
-- 2005.08.07 MWB Confirm�f�[�^����荞��
--            Carrier WB�̋��z��UAS I/F�ɔ������Ȃ��Ă�
--            TFJ301--TFJ303���쐬
--
-- �C��  --2005.10.23 Accounting Table Replication�Ή�
--         TFJ202��HOST_ID��ǉ��B
--************************************************

--================================================
-- ���і��ׂ��쐬
--================================================
PROCEDURE CRE_MEISAI_JISSEKI(
    IN_DATE              IN  DATE,      -- �Ɩ�������
    IN_COMPANY_ID        IN  VARCHAR2,  -- ��ЃR�[�h
    IN_IMPORT_EXPORT_IND IN  VARCHAR2,  -- �A�o�^�A���敪
    IN_TRANSPORT_MODE    IN  VARCHAR2   -- �Ɩ��敪
) IS

    WK_PIPELINE_TX_ID     INTERFACE_QUEUE_HISTORY.KEY_ID%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3011', 'CRE_MEISAI_JISSEKI' );
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t      =' || IN_DATE );
    PFGA3910.TRACE_LOG( 'I', '��ЃR�[�h    =' || IN_COMPANY_ID );
    PFGA3910.TRACE_LOG( 'I', '�A�o�^�A���敪=' || IN_IMPORT_EXPORT_IND );
    PFGA3910.TRACE_LOG( 'I', '�Ɩ��敪      =' || IN_TRANSPORT_MODE );

    PFGA3010.C_EUPD_TNTCD  := 'PFGA3011';
    PFGA3010.WK_ERROR      := 0;

    -- �����������ėpܰ��ϐ�
    WK_QUEUE_SH_IN_CNT    := 0;
    WK_QUEUE_CS_IN_CNT    := 0;
    WK_TFJ201_SKIP_CNT    := 0;
    PFGA3010.WK_TFJ201_NEW_CNT  := 0;
    PFGA3010.WK_TFJ201_ADJ_CNT  := 0;
    PFGA3010.WK_TFJ201_DEL_CNT  := 0;
    PFGA3010.WK_HWB_IN_CNT      := 0;
    PFGA3010.WK_TFJ301_AKA_CNT  := 0;
    PFGA3010.WK_TFJ301_KURO_CNT := 0;
    PFGA3010.WK_TFJ303_AKA_CNT  := 0;
    PFGA3010.WK_TFJ303_KURO_CNT := 0;
    PFGA3010.WK_TFJ304_AKA_CNT  := 0;
    PFGA3010.WK_TFJ304_KURO_CNT := 0;
    PFGA3010.WK_TFJ305_AKA_CNT  := 0;                            -- 2005.04.09
    PFGA3010.WK_TFJ305_KURO_CNT := 0;                            -- 2005.04.09

    IF IN_IMPORT_EXPORT_IND = 'E' THEN
        -- Export HWB(SH)
        FOR WK_REC IN CUR_QUEUE_EX_SH( IN_DATE,
                                       IN_COMPANY_ID,
                                       IN_TRANSPORT_MODE ) LOOP
            WK_PIPELINE_TX_ID     := WK_REC.PIPELINE_TX_ID;
            WK_QUEUE_SH_IN_CNT    := WK_QUEUE_SH_IN_CNT + 1;

            IF WK_REC.ACCOUNTING_DATE IS NOT NULL THEN
                -- ISSUE �f�[�^�쐬(SH)
                CRE_ISSUE_SH( IN_DATE,
                              IN_COMPANY_ID,
                              IN_IMPORT_EXPORT_IND,
                              IN_TRANSPORT_MODE,
                              WK_REC.PIPELINE_TX_ID,
                              WK_REC.ACCOUNTING_DATE );
            END IF;
        END LOOP;

        -- Export MWB(CS)
        FOR WK_REC IN CUR_QUEUE_EX_CS( IN_DATE,
                                       IN_COMPANY_ID,
                                       IN_TRANSPORT_MODE ) LOOP
            WK_PIPELINE_TX_ID     := WK_REC.PIPELINE_TX_ID;
            WK_QUEUE_CS_IN_CNT    := WK_QUEUE_CS_IN_CNT + 1;

            IF WK_REC.ACCOUNTING_DATE IS NOT NULL THEN
                -- ISSUE �f�[�^�쐬(CS)
                CRE_ISSUE_CS( IN_DATE,
                              IN_COMPANY_ID,
                              IN_IMPORT_EXPORT_IND,
                              IN_TRANSPORT_MODE,
                              WK_REC.PIPELINE_TX_ID,
                              WK_REC.ACCOUNTING_DATE );
            END IF;
        END LOOP;
    ELSIF IN_IMPORT_EXPORT_IND = 'I' THEN
        -- Import HWB(SH)
        FOR WK_REC IN CUR_QUEUE_IM_SH( IN_DATE,
                                       IN_COMPANY_ID,
                                       IN_TRANSPORT_MODE ) LOOP
            WK_PIPELINE_TX_ID     := WK_REC.PIPELINE_TX_ID;
            WK_QUEUE_SH_IN_CNT    := WK_QUEUE_SH_IN_CNT + 1;

            IF WK_REC.ACCOUNTING_DATE IS NOT NULL THEN
                -- ISSUE �f�[�^�쐬(SH)
                CRE_ISSUE_SH( IN_DATE,
                              IN_COMPANY_ID,
                              IN_IMPORT_EXPORT_IND,
                              IN_TRANSPORT_MODE,
                              WK_REC.PIPELINE_TX_ID,
                              WK_REC.ACCOUNTING_DATE );
            END IF;
        END LOOP;

        -- Import MWB(CS)
        FOR WK_REC IN CUR_QUEUE_IM_CS( IN_DATE,
                                       IN_COMPANY_ID,
                                       IN_TRANSPORT_MODE ) LOOP
            WK_PIPELINE_TX_ID     := WK_REC.PIPELINE_TX_ID;
            WK_QUEUE_CS_IN_CNT    := WK_QUEUE_CS_IN_CNT + 1;

            IF WK_REC.ACCOUNTING_DATE IS NOT NULL THEN
                -- ISSUE �f�[�^�쐬(CS)
                CRE_ISSUE_CS( IN_DATE,
                              IN_COMPANY_ID,
                              IN_IMPORT_EXPORT_IND,
                              IN_TRANSPORT_MODE,
                              WK_REC.PIPELINE_TX_ID,
                              WK_REC.ACCOUNTING_DATE );
            END IF;
        END LOOP;
    END IF;

    PFGA3910.TRACE_LOG( 'I', 'UASIF(SH)���͌���   = ' || WK_QUEUE_SH_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF(CS)���͌���   = ' || WK_QUEUE_CS_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �����ό��� = ' || WK_TFJ201_SKIP_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �V�K����   = ' || PFGA3010.WK_TFJ201_NEW_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �C������   = ' || PFGA3010.WK_TFJ201_ADJ_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �폜����   = ' || PFGA3010.WK_TFJ201_DEL_CNT );
    PFGA3910.TRACE_LOG( 'I', 'HWB      ���͌���   = ' || PFGA3010.WK_HWB_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� �ԏo�͌��� = ' || PFGA3010.WK_TFJ301_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� ���o�͌��� = ' || PFGA3010.WK_TFJ301_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z �ԏo�͌��� = ' || PFGA3010.WK_TFJ303_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z ���o�͌��� = ' || PFGA3010.WK_TFJ303_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', '����Inv  �ԏo�͌��� = ' || PFGA3010.WK_TFJ304_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '����Inv  ���o�͌��� = ' || PFGA3010.WK_TFJ304_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', 'Inv���z  �ԏo�͌��� = ' || PFGA3010.WK_TFJ305_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', 'Inv���z  ���o�͌��� = ' || PFGA3010.WK_TFJ305_KURO_CNT );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','INTERFACE_QUEUE_HISTORY: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_LOG( 'E', '�G���[�f�[�^'
                         || ' PIPELINE_TX_ID = ' || WK_PIPELINE_TX_ID );
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ISSUE �f�[�^�쐬(SH)
--================================================
PROCEDURE CRE_ISSUE_SH(
    IN_DGYMDTM           IN     TFJ201.DGYMDTM%TYPE,          -- �Ɩ�������
    IN_COMPANY_ID        IN     TFJ201.COMPANY_ID%TYPE,       -- ��ЃR�[�h
    IN_IMPORT_EXPORT_IND IN     TFJ201.IMPORT_EXPORT_IND%TYPE,-- �A�o�^�A���敪
    IN_TRANSPORT_MODE    IN     TFJ201.TRANSPORT_MODE%TYPE,   -- �Ɩ��敪
    IN_PIPELINE_TX_ID    IN     TFJ201.PIPELINE_TX_ID%TYPE,
    IN_ACCOUNTING_DATE   IN     TFJ201.ACCOUNTING_DATE%TYPE
) IS
    -- 2005.12.02 �ŐV�敪����MAX����ɕύX
    -- ���і��ג��o�J�[�\��
    CURSOR CUR_TFJ301( KEY_EDATKBN         IN TFJ301.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ301.PIPELINE_TX_ID%TYPE ) IS
        SELECT DGYMDTM, DKJODTM, ETERMINAL_ID, EDEPARTMENT_ID
          FROM TFJ301
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
--            AND ESISNKBN        = '1';
            AND NGENNO          = ( SELECT MAX(B.NGENNO)
                                     FROM  TFJ301 B
                                    WHERE  B.EDATKBN        = KEY_EDATKBN
                                      AND  B.PIPELINE_TX_ID = KEY_PIPELINE_TX_ID);

    WK_TFJ201             TFJ201%ROWTYPE;
    WK_HWB                PFGA3010.CUR_HWB%ROWTYPE;
    WK_NGENNO             TFJ301.NGENNO%TYPE;
    WK_ORIGINAL_KJODTM    TFJ301.ORIGINAL_KJODTM%TYPE;
    WK_TFJ301             TFJ301%ROWTYPE;

    WK_DKJODTM            TFJ301.DKJODTM%TYPE;
    WK_ETERMINAL_ID       TFJ301.ETERMINAL_ID%TYPE;
    WK_EDEPARTMENT_ID     TFJ301.EDEPARTMENT_ID%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3011', 'CRE_ISSUE_SH' );

    -- HWB ���o
    WK_TFJ201.PIPELINE_TX_ID    := IN_PIPELINE_TX_ID;
    PFGA3010.SEL_HWB( WK_HWB, WK_TFJ201 );

    WK_DKJODTM                  := NULL;
    IF WK_HWB.PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
        FOR WK_REC IN CUR_TFJ301( '1',
                                  WK_TFJ201.PIPELINE_TX_ID ) LOOP
            -- �ŐV�̏��
            WK_DKJODTM          := WK_REC.DKJODTM;
            WK_ETERMINAL_ID     := WK_REC.ETERMINAL_ID;
            WK_EDEPARTMENT_ID   := WK_REC.EDEPARTMENT_ID;
            IF WK_REC.DGYMDTM = IN_DGYMDTM THEN
                WK_HWB.PIPELINE_TX_ID := 0;
                WK_TFJ201_SKIP_CNT    := WK_TFJ201_SKIP_CNT + 1;
            END IF;
        END LOOP;
    ELSE
        PFGA3910.TRACE_LOG( 'E', 'HWB ���o�G���[  PIPELINE_TX_ID='
                                            || IN_PIPELINE_TX_ID );
    END IF;

    IF WK_HWB.PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
        WK_TFJ201.WAYBILL_TYPE      := WK_HWB.PIPELINE_REF_TYPE;
        WK_TFJ201.DGYMDTM           := IN_DGYMDTM;
        IF WK_DKJODTM IS NOT NULL THEN
            -- �v��ς݃f�[�^������P�[�X --> �ŐV�̌v���
            WK_TFJ201.ACCOUNTING_DATE   := WK_DKJODTM;
        ELSE
            -- �v��ς݂̃f�[�^���Ȃ��iISSUE��荞�݁j
            WK_TFJ201.ACCOUNTING_DATE   := IN_ACCOUNTING_DATE;
        END IF;
        WK_TFJ201.COMPANY_ID        := IN_COMPANY_ID;
        WK_TFJ201.IMPORT_EXPORT_IND := IN_IMPORT_EXPORT_IND;
        WK_TFJ201.TRANSPORT_MODE    := IN_TRANSPORT_MODE;
        WK_TFJ201.INVOICE_DATE      := NULL;
        WK_TFJ201.ORIGINAL_INVOICE_DATE    := NULL;
        WK_TFJ201.HWB_TX_ID         := NULL;
        WK_TFJ201.RECORD_IND        := 'AR';
        WK_TFJ201.INVOICE_NO        := NULL;
        WK_TFJ201.INVOICE_TX_ID     := NULL;
        IF WK_DKJODTM IS NOT NULL THEN
            -- �v��ς݃f�[�^������P�[�X --> �ŐV�̏��
            WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID     := WK_ETERMINAL_ID;
            WK_TFJ201.GL_GROUP                        := WK_EDEPARTMENT_ID;
        ELSE
            IF IN_IMPORT_EXPORT_IND = 'E' THEN
                -- Export
                WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := WK_HWB.ORIG_TERMINAL_ID;
                WK_TFJ201.GL_GROUP                    := WK_HWB.ORIG_DEPARTMENT_ID;
            ELSIF IN_IMPORT_EXPORT_IND = 'I' THEN
                -- Import
                WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := WK_HWB.DEST_TERMINAL_ID;
                WK_TFJ201.GL_GROUP                    := WK_HWB.DEST_DEPARTMENT_ID;
            END IF;
        END IF;

        -- �v��f�[�^�ς݂̃f�[�^���������A
        -- �f�[�^������ꍇ�ԃf�[�^�쐬
        -- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
        PFGA3010.CHECK_KEIJYOU_MEISAI( WK_HWB.PIPELINE_TX_STATUS,
                                       WK_TFJ201,
                                       WK_NGENNO,
                                       WK_ORIGINAL_KJODTM );

        -- �폜�f�[�^�ȊO�̏ꍇ
        IF WK_HWB.PIPELINE_TX_STATUS NOT IN ('VD','CAN') THEN
            -- HWB ���і��ׁA�ҏW
            PFGA3010.SET_TFJ301_HWB( WK_TFJ301,
                                     WK_HWB,
                                     WK_TFJ201,
                                     WK_NGENNO,
                                     WK_ORIGINAL_KJODTM );

            -- ���і��ׂ�V�K�쐬
            PFGA3010.INS_TFJ301( WK_TFJ301 );

            -- HWB/MWB ���і��׋��z�A�ҏW�o��
            PFGA3010.OUTPUT_TFJ303( WK_TFJ201, WK_TFJ301, WK_NGENNO );

            -- HWB ����Invoice�A�ҏW�o��
            PFGA3010.OUTPUT_TFJ304( WK_TFJ201, WK_NGENNO );
        END IF;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ202: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- ISSUE �f�[�^�쐬(CS)
--================================================
PROCEDURE CRE_ISSUE_CS(
    IN_DGYMDTM           IN     TFJ201.DGYMDTM%TYPE,          -- �Ɩ�������
    IN_COMPANY_ID        IN     TFJ201.COMPANY_ID%TYPE,       -- ��ЃR�[�h
    IN_IMPORT_EXPORT_IND IN     TFJ201.IMPORT_EXPORT_IND%TYPE,-- �A�o�^�A���敪
    IN_TRANSPORT_MODE    IN     TFJ201.TRANSPORT_MODE%TYPE,   -- �Ɩ��敪
    IN_PIPELINE_TX_ID    IN     TFJ201.PIPELINE_TX_ID%TYPE,
    IN_ACCOUNTING_DATE   IN     TFJ201.ACCOUNTING_DATE%TYPE
) IS
    -- 2005.12.02 �ŐV�敪����MAX����ɕύX
    -- ���і��ג��o�J�[�\��
    CURSOR CUR_TFJ301( KEY_EDATKBN         IN TFJ301.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ301.PIPELINE_TX_ID%TYPE ) IS
        SELECT DGYMDTM, DKJODTM, ETERMINAL_ID, EDEPARTMENT_ID
          FROM TFJ301
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
--            AND ESISNKBN        = '1';
            AND NGENNO          = ( SELECT MAX(B.NGENNO)
                                     FROM  TFJ301 B
                                    WHERE  B.EDATKBN        = KEY_EDATKBN
                                      AND  B.PIPELINE_TX_ID = KEY_PIPELINE_TX_ID);

    WK_TFJ201             TFJ201%ROWTYPE;
    WK_MWB                PFGA3010.CUR_MWB%ROWTYPE;
    WK_NGENNO             TFJ301.NGENNO%TYPE;
    WK_ORIGINAL_KJODTM    TFJ301.ORIGINAL_KJODTM%TYPE;
    WK_TFJ301             TFJ301%ROWTYPE;

    WK_DKJODTM            TFJ301.DKJODTM%TYPE;
    WK_ETERMINAL_ID       TFJ301.ETERMINAL_ID%TYPE;
    WK_EDEPARTMENT_ID     TFJ301.EDEPARTMENT_ID%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3011', 'CRE_ISSUE_CS' );

    -- MWB ���o
    WK_TFJ201.PIPELINE_TX_ID    := IN_PIPELINE_TX_ID;
    PFGA3010.SEL_MWB( WK_MWB, WK_TFJ201 );

    WK_DKJODTM                  := NULL;
    IF WK_MWB.PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
        FOR WK_REC IN CUR_TFJ301( '3',
                                  WK_TFJ201.PIPELINE_TX_ID ) LOOP
            -- �ŐV�̏��
            WK_DKJODTM          := WK_REC.DKJODTM;
            WK_ETERMINAL_ID     := WK_REC.ETERMINAL_ID;
            WK_EDEPARTMENT_ID   := WK_REC.EDEPARTMENT_ID;
            IF WK_REC.DGYMDTM = IN_DGYMDTM THEN
                WK_MWB.PIPELINE_TX_ID := 0;
                WK_TFJ201_SKIP_CNT    := WK_TFJ201_SKIP_CNT + 1;
            END IF;
        END LOOP;
    ELSE
        PFGA3910.TRACE_LOG( 'E', 'MWB ���o�G���[  PIPELINE_TX_ID='
                                            || IN_PIPELINE_TX_ID );
    END IF;

    IF WK_MWB.PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
        WK_TFJ201.WAYBILL_TYPE      := WK_MWB.PIPELINE_REF_TYPE;
        WK_TFJ201.DGYMDTM           := IN_DGYMDTM;
        IF WK_DKJODTM IS NOT NULL THEN
            -- �v��ς݃f�[�^������P�[�X --> �ŐV�̌v���
            WK_TFJ201.ACCOUNTING_DATE   := WK_DKJODTM;
        ELSE
            -- �v��ς݂̃f�[�^���Ȃ��iISSUE��荞�݁j
            WK_TFJ201.ACCOUNTING_DATE   := IN_ACCOUNTING_DATE;
        END IF;
        WK_TFJ201.COMPANY_ID        := IN_COMPANY_ID;
        WK_TFJ201.IMPORT_EXPORT_IND := IN_IMPORT_EXPORT_IND;
        WK_TFJ201.TRANSPORT_MODE    := IN_TRANSPORT_MODE;
        WK_TFJ201.INVOICE_DATE      := NULL;
        WK_TFJ201.ORIGINAL_INVOICE_DATE    := NULL;
        WK_TFJ201.HWB_TX_ID         := NULL;
        WK_TFJ201.RECORD_IND        := 'AP';
        WK_TFJ201.INVOICE_NO        := NULL;
        WK_TFJ201.INVOICE_TX_ID     := NULL;
        IF WK_DKJODTM IS NOT NULL THEN
            -- �v��ς݃f�[�^������P�[�X --> �ŐV�̏��
            WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID     := WK_ETERMINAL_ID;
            WK_TFJ201.GL_GROUP                        := WK_EDEPARTMENT_ID;
        ELSE
            IF IN_IMPORT_EXPORT_IND = 'E' THEN
                -- Export
                WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := WK_MWB.ORIG_TERMINAL_ID;
                WK_TFJ201.GL_GROUP                    := WK_MWB.ORIG_DEPARTMENT_ID;
            ELSIF IN_IMPORT_EXPORT_IND = 'I' THEN
                -- Import
                WK_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := WK_MWB.DEST_TERMINAL_ID;
                WK_TFJ201.GL_GROUP                    := WK_MWB.DEST_DEPARTMENT_ID;
            END IF;
        END IF;

        -- �v��f�[�^�ς݂̃f�[�^���������A
        -- �f�[�^������ꍇ�ԃf�[�^�쐬
        -- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
        PFGA3010.CHECK_KEIJYOU_MEISAI( WK_MWB.PIPELINE_TX_STATUS,
                                       WK_TFJ201,
                                       WK_NGENNO,
                                       WK_ORIGINAL_KJODTM );

        -- �폜�f�[�^�ȊO�̏ꍇ
        IF WK_MWB.PIPELINE_TX_STATUS NOT IN ('VD','CAN') THEN
            -- MWB ���і��ׁA�ҏW
            PFGA3010.SET_TFJ301_MWB( WK_TFJ301,
                                     WK_MWB,
                                     WK_TFJ201,
                                     WK_NGENNO,
                                     WK_ORIGINAL_KJODTM );

            -- ���і��ׂ�V�K�쐬
            PFGA3010.INS_TFJ301( WK_TFJ301 );

            -- HWB/MWB ���і��׋��z�A�ҏW�o��
            PFGA3010.OUTPUT_TFJ303( WK_TFJ201, WK_TFJ301, WK_NGENNO );
        END IF;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF PFGA3010.WK_ERROR = 0 THEN
            PFGA3010.WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ202: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

END PFGA3011;