CREATE OR REPLACE PACKAGE PFGA3010 AS
--********************************************************************
--�y ���і��׍쐬 �z
--  �߯����
--  PFGA3010
--  �Ăяo���K�w
--  CRE_MEISAI_JISSEKI                    ���і��ׂ��쐬
--    +-- SEL_MWB                         MWB ���o
--    +-- SET_TFJ301_MWB                  MWB ���і��ׁA�ҏW
--    |     +-- SET_TFJ301_CODENAME       ���і��ׁA�R�[�h�E���̕ҏW
--    +-- SEL_HWB                         HWB ���o
--    +-- SET_TFJ301_HWB                  HWB ���і��ׁA�ҏW
--    |     +-- SET_TFJ301_CODENAME       ���і��ׁA�R�[�h�E���̕ҏW
--    +-- SEL_INV                         INVOICE ���o
--    |     +-- SET_TFJ301_CODENAME       ���і��ׁA�R�[�h�E���̕ҏW
--    +-- SET_TFJ301_INV                  INVOICE ���і��ׁA�ҏW
--    +-- CHECK_KEIJYOU_MEISAI            ���і��ׂ̌v��σf�[�^�̃`�F�b�N
--    |     +-- INS_TFJ301                ���і��ׂ�V�K�쐬
--    |     +-- INS_TFJ303                ���і��׋��z��V�K�쐬
--    +-- INS_TFJ301                      ���і��ׂ�V�K�쐬
--    +-- OUTPUT_TFJ303                   HWB/MWB ���і��׋��z�A�ҏW�o��
--    |     +-- OUTPUT_TFJ303_CHARGES     HWB/MWB ���і��׋��z�ACharges�ҏW�o��
--    |           +-- INS_TFJ303          ���і��׋��z��V�K�쐬
--    |           +-- SEL_TFM205          �������ڃ}�X�^����
--    |           +-- EDIT_TFJ303         HWB/MWB ���і��׋��z��ҏW
--    +-- OUTPUT_TFJ303_INV               INVOICE ���і��׋��z�A�ҏW�o��
--    |     +-- OUTPUT_TFJ303_CHARGES_INV INVOICE ���і��׋��z�ACharges�ҏW�o��
--    |           +-- INS_TFJ303          ���і��׋��z��V�K�쐬
--    |           +-- SEL_TFM205          �������ڃ}�X�^����
--    +-- OUTPUT_TFJ304                   HWB ����Invoice�A�ҏW�o��
--    |     +-- OUTPUT_TFJ304_IH          HWB ����Invoice�A�ҏW�o��(by IH)
--    |           +-- INS_TFJ303          ����Invoice��V�K�쐬
--    +-- OUTPUT_TFJ304_INV               INVOICE ����Invoice�A�ҏW�o��
--          +-- OUTPUT_TFJ304_IH          HWB ����Invoice�A�ҏW�o��(by IH)
--                +-- INS_TFJ303          ����Invoice��V�K�쐬
--********************************************************************

--************************************************
--�y ���і��׍쐬 �z�߯���ގd�l��
--     PFGA3010
--************************************************

    --  PIPELINE, SHIPMENT_HEADER, SHIPMENT_HEADER_EXTENSION ���o
    CURSOR CUR_HWB(
        KEY_PIPELINE_TX_ID     PIPELINE.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT
            P.PIPELINE_TX_STATUS,
            P.PIPELINE_REF_ID,
            P.PIPELINE_TX_ID,
            P.PIPELINE_TX_TYPE,
            P.PIPELINE_REF_TYPE,
            SH.TRANSPORT_MODE,
            SH.SERVICE_TYPE,
            SH.MOVEMENT_TYPE,
            SH.CUSTOMER_SHIPMENT_TYPE,
            SX.AGENT_TYPE,
            SH.DISPOSITION,                 -- Add 2004.07.26
            SH.FREE_HOUSE_IND,
            SX.LCL_CNSL_CARRIER_IND,        -- Add 2004.07.26
            P.PIPELINE_TX_DATE,
            P.TX_DATE_TZ_CODE,
            TO_DATE(TO_CHAR(P.PIPELINE_TX_DATE+ZONE.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                  'YYYY/MM/DD') AS ISSUE_DATE,
            SH.TRANSPORT_TERMS_CODE,
            SH.SALES_TERMS_CODE,
            SH.FREE_HOUSE_TERMS_CODE,
            SH.PLACE_OF_RECEIPT,
            SH.PLACE_OF_DELIVERY,
            P.PORT_ORIGIN,
            P.PORT_LOADING,
            P.PORT_UNLOADING,
            P.PORT_DEST,
            SX.FINAL_DESTINATION,
            SX.PORT_LOADING_LC_CODE,
            SX.PORT_UNLOADING_LC_CODE,
            P.PORT_CC,
            P.PORT_CC_IMPORT,
            P.ORIG_COMPANY_ID,
            P.ORIG_SUBSIDIARY_ID,
            P.ORIG_TERMINAL_ID,
            P.ORIG_DEPARTMENT_ID,
            P.ORIG_AREA_CODE,
            P.ORIG_REGION_CODE,
            P.ORIG_COUNTRY_CODE,
            P.ORIG_IATA_TC_CODE,
            P.ORIG_POLAR_REGION_A_CODE,
            P.ORIG_POLAR_REGION_B_CODE,
            P.DEST_COMPANY_ID,
            P.DEST_SUBSIDIARY_ID,
            P.DEST_TERMINAL_ID,
            P.DEST_DEPARTMENT_ID,
            P.DEST_AREA_CODE,
            P.DEST_REGION_CODE,
            P.DEST_COUNTRY_CODE,
            P.DEST_IATA_TC_CODE,
            P.DEST_POLAR_REGION_A_CODE,
            P.DEST_POLAR_REGION_B_CODE,
            P.NUM_PIECES,
            P.PACKAGING_FORM_CODE,
            P.CHARGEABLE_WEIGHT,
            P.WEIGHT_UOM_CODE,
            SH.TOTAL_ACTUAL_WEIGHT,
            SH.ACTUAL_WEIGHT_UOM_CODE,
            SH.TOTAL_VOLUME,
            SH.VOLUME_UOM_CODE,
            SH.TOTAL_VOLUME_WEIGHT,
            SH.VOLUME_WEIGHT_UOM_CODE,
            SH.FREIGHT_PPC_IND,
            SH.OTHER_PPC_IND,
            SX.DESTINATION_PPC_IND,
            SH.OC_CURRENCY_CODE,
            SH.LOCAL_CURRENCY_CODE,
            SH.DEST_CURRENCY_CODE,
            SX.INVOICE_CURRENCY_CODE,
            SH.DEST_EXCHANGE_RATE,
            SX.INVOICE_EXCHANGE_RATE,
            SH.PPD_FREIGHT_AMT,
            SH.PPD_OTHER_AMT,
            SH.PPD_VALUATION_AMT,
            SH.PPD_TAX_AMT,
            SH.PPD_DUE_AGENT_AMT,
            SH.PPD_DUE_CARRIER_AMT,
            SH.TOT_PPD_AMT,
            SH.COLL_FREIGHT_AMT,
            SH.COLL_OTHER_AMT,
            SH.COLL_VALUATION_AMT,
            SH.COLL_TAX_AMT,
            SH.COLL_DUE_AGENT_AMT,
            SH.COLL_DUE_CARRIER_AMT,
            SH.TOT_COLL_AMT,
            SH.OC_PPD_FREIGHT_AMT,
            SH.OC_PPD_OTHER_AMT,
            SH.OC_PPD_VALUATION_AMT,
            SH.OC_PPD_TAX_AMT,
            SH.OC_PPD_DUE_AGENT_AMT,
            SH.OC_PPD_DUE_CARRIER_AMT,
            SH.OC_TOT_PPD_AMT,
            SH.OC_COLL_FREIGHT_AMT,
            SH.OC_COLL_OTHER_AMT,
            SH.OC_COLL_VALUATION_AMT,
            SH.OC_COLL_TAX_AMT,
            SH.OC_COLL_DUE_AGENT_AMT,
            SH.OC_COLL_DUE_CARRIER_AMT,
            SH.OC_TOT_COLL_AMT,
            SH.NATURE_OF_GOODS,
            SH.SHIPPER_NAME,
            SH.SHIPPER_ADDRESS_NO,
            SH.SHIPPER_CONTACT_NO,
            SH.CNEE_NAME,
            SH.CNEE_ADDRESS_NO,
            SH.CNEE_CONTACT_NO,
            SH.NOTIFY_NAME,
            SH.NOTIFY_ADDRESS_NO,
            SH.NOTIFY_CONTACT_NO,
            SH.BILLTO_NAME,
            SH.BILLTO_ADDRESS_NO,
            SH.BILLTO_CONTACT_NO,
            SH.CONTROLLING_NAME,
            SH.CONTROLLING_ADDRESS_NO,
            SH.CONTROLLING_CONTACT_NO,
            SH.BILLTO2_NAME,
            SH.BILLTO2_ADDRESS_NO,
            SH.BILLTO2_CONTACT_NO,
            SX.PTYTOCNT_NAME,
            SX.PTYTOCNT_ADDRESS_NO,
            SX.PTYTOCNT_CONTACT_NO,
            SH.SETTLEMENT_AGENT_NAME,
            SH.SETTLEMENT_AGENT_ADDRESS_NO,
            SH.SETTLEMENT_AGENT_CONTACT_NO,
            SH.RECEIPT_LOCATION_CODE,
            SH.CFS_RECEIPT_LOCATION_NAME,
            SH.CFS_RECEIPT_ADDRESS_NO,
            SH.CFS_RECEIPT_CONTACT_NO,
            SH.CY_RECEIPT_LOCATION_NAME,
            SH.CY_RECEIPT_ADDRESS_NO,
            SH.CY_RECEIPT_CONTACT_NO,
            SH.LOCFREIGHT_NAME,
            SH.LOCFREIGHT_ADDRESS_NO,
            SH.LOCFREIGHT_CONTACT_NO,
            SH.DEST_BROKER_NAME,
            SH.DEST_BROKER_ADDRESS_NO,
            SH.DEST_BROKER_CONTACT_NO,
            SX.IMPORT_BILLTO_NAME_CC,
            SX.IMPORT_BILLTO_ADDRESS_NO_CC,
            SX.IMPORT_BILLTO_CONTACT_NO_CC,
            SH.IMPORT_SALESMAN_ID,
            SH.EXPORT_SALESMAN_ID,
            TO_DATE(TO_CHAR(SH.ISSUE_DATE_TO_PRINT+ZONE.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                  'YYYY/MM/DD') AS ISSUE_DATE_TO_PRINT,
            SH.OBD_DATE_TO_PRINT,
            -- 2004.10.02
            SH.MPR_PORT_ORIGIN1,
            SH.MPR_PORT_DEST1,
            SH.MPR_RATE1,
            SH.MPR_CURRENCY_CODE1,
            SH.MPR_AMT1,
            SH.MPR_AMT1_PREPAID,
            SH.MPR_AMT1_COLLECT,
            SH.MPR_EXCHANGE_RATE1,
            SH.MPR_RATE_PROFILE_NAME1,
            -- 2005.05.15
            SH.MPR_PORT_ORIGIN2,
            SH.MPR_PORT_DEST2,
            SH.MPR_RATE2,
            SH.MPR_CURRENCY_CODE2,
            SH.MPR_AMT2,
            SH.MPR_AMT2_PREPAID,
            SH.MPR_AMT2_COLLECT,
            SH.MPR_EXCHANGE_RATE2,
            SH.MPR_RATE_PROFILE_NAME2,
            SH.MPR_PORT_ORIGIN3,
            SH.MPR_PORT_DEST3,
            SH.MPR_RATE3,
            SH.MPR_CURRENCY_CODE3,
            SH.MPR_AMT3,
            SH.MPR_AMT3_PREPAID,
            SH.MPR_AMT3_COLLECT,
            SH.MPR_EXCHANGE_RATE3,
            SH.MPR_RATE_PROFILE_NAME3,
            SH.MANIFEST_DESCRIPTION,
            SH.CUSTOMS_DECLARATION,
            SH.COMMCODE_RECORD_ID
        FROM PIPELINE                   P,
             SHIPMENT_HEADER            SH,
             SHIPMENT_HEADER_EXTENSION  SX,
             TIME_ZONE                  ZONE
        WHERE P.PIPELINE_TX_ID    = SH.PIPELINE_TX_ID
          AND P.PIPELINE_TX_TYPE  = 'SH'
          AND P.PIPELINE_TX_ID    = SX.PIPELINE_TX_ID
          AND P.PIPELINE_TX_ID    = KEY_PIPELINE_TX_ID
          AND ZONE.TIME_ZONE_CODE = P.TX_DATE_TZ_CODE;

    --  PIPELINE, INVOICE_HEADER ���o
    CURSOR CUR_INV(
        KEY_PIPELINE_TX_ID     PIPELINE.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT
            P.PIPELINE_TX_STATUS,
            P.PIPELINE_REF_ID,                             -- INVOICE_NO
            P.PIPELINE_TX_ID,
            P.PIPELINE_TX_TYPE,
            P.PIPELINE_REF_TYPE,
            P.PIPELINE_TX_DATE,
            P.TX_DATE_TZ_CODE,
            TO_DATE(TO_CHAR(P.PIPELINE_TX_DATE+ZONE.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                  'YYYY/MM/DD') AS ISSUE_DATE,
            P.PORT_ORIGIN,
            P.PORT_LOADING,
            P.PORT_UNLOADING,
            P.PORT_DEST,
            P.PORT_CC PORT_CC_EXPORT,
            P.PORT_CC_IMPORT,
            P.ORIG_COMPANY_ID,
            P.ORIG_SUBSIDIARY_ID,
            P.ORIG_TERMINAL_ID,
            P.ORIG_DEPARTMENT_ID,
            P.ORIG_AREA_CODE,
            P.ORIG_REGION_CODE,
            P.ORIG_COUNTRY_CODE,
            P.ORIG_IATA_TC_CODE,
            P.ORIG_POLAR_REGION_A_CODE,
            P.ORIG_POLAR_REGION_B_CODE,
            P.DEST_COMPANY_ID,
            P.DEST_SUBSIDIARY_ID,
            P.DEST_TERMINAL_ID,
            P.DEST_DEPARTMENT_ID,
            P.DEST_AREA_CODE,
            P.DEST_REGION_CODE,
            P.DEST_COUNTRY_CODE,
            P.DEST_IATA_TC_CODE,
            P.DEST_POLAR_REGION_A_CODE,
            P.DEST_POLAR_REGION_B_CODE,
            P.NUM_PIECES,
            P.PACKAGING_FORM_CODE,
            P.CHARGEABLE_WEIGHT,
            P.WEIGHT_UOM_CODE CHARGEABLE_WEIGHT_UOM_CODE,
            IH.BILLTO_NAME,
            IH.BILLTO_ADDRESS_NO,
            IH.BILLTO_CONTACT_NO,
            IH.INVOICE_CURRENCY_CODE,
            IH.OC_CURRENCY_CODE,
            IH.ACCTG_INTERFACE_STATUS,
            IH.TRANSPORT_MODE,
            IH.UAS_GL_DATE,
            IH.UAS_GL_DATE_TZ_CODE,
            -- 2005.12.16
            IH.MISC_WAYBILL_TYPE,
            IH.MISC_WAYBILL_ISSUE_DATE,
            IH.MISC_WB_ISSUE_DATE_TZ_CODE,
            IH.MISC_WAYBILL_NO,
            IH.MISC_CARRIER_CODE,
            IH.MISC_NUM_PIECES,
            IH.MISC_PACKAGING_FORM_CODE,
            IH.MISC_GROSS_WEIGHT,
            IH.MISC_GROSS_WEIGHT_UOM_CODE,
            IH.MISC_MEASUREMENT,
            IH.MISC_MEASUREMENT_UOM_CODE,
            IH.MISC_CHARGEABLE_WEIGHT,
            IH.MISC_CHG_WEIGHT_UOM_CODE,
            IH.MISC_DESCRIPTION,
            IH.MISC_SHIPPER_NAME,
            IH.MISC_SHIPPER_ADDRESS_NO,
            IH.MISC_SHIPPER_CONTACT_NO,
            IH.MISC_CONSIGNEE_NAME,
            IH.MISC_CONSIGNEE_ADDRESS_NO,
            IH.MISC_CONSIGNEE_CONTACT_NO
        FROM PIPELINE        P,
             INVOICE_HEADER  IH,
             TIME_ZONE       ZONE
        WHERE P.PIPELINE_TX_ID   = IH.PIPELINE_TX_ID
          AND P.PIPELINE_TX_TYPE = 'IN'
          AND P.PIPELINE_TX_ID   = KEY_PIPELINE_TX_ID
          AND ZONE.TIME_ZONE_CODE   = P.TX_DATE_TZ_CODE;


    --  PIPELINE, MWB_HEADER, MWB_HEADER_EXTENSION ���o
    CURSOR CUR_MWB(
        KEY_PIPELINE_TX_ID     PIPELINE.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT
            P.PIPELINE_TX_STATUS,
            P.PIPELINE_REF_ID,
            P.PIPELINE_TX_ID,
            P.PIPELINE_TX_TYPE,
            P.PIPELINE_REF_TYPE,
            MH.TRANSPORT_MODE,
            MH.SERVICE_TYPE,
            MH.MOVEMENT_TYPE,
            MH.CUSTOMER_SHIPMENT_TYPE,
            P.PIPELINE_TX_DATE,
            P.TX_DATE_TZ_CODE,
            TO_DATE(TO_CHAR(P.PIPELINE_TX_DATE+ZONE.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                  'YYYY/MM/DD') AS ISSUE_DATE,
            MX.LCL_CNSL_CARRIER as LCL_CNSL_CARRIER_IND,    -- Add 2004.07.26
            MH.PLACE_OF_RECEIPT_NAME,
            MH.PLACE_OF_DELIVERY_NAME,
            MH.PLACE_OF_RECEIPT_CODE,
            MH.PLACE_OF_DELIVERY_CODE,
            P.PORT_ORIGIN,
            P.PORT_LOADING,
            P.PORT_UNLOADING,
            P.PORT_DEST,
            MX.FINAL_DESTINATION,
            P.PORT_CC,
            P.PORT_CC_IMPORT,
            P.ORIG_COMPANY_ID,
            P.ORIG_SUBSIDIARY_ID,
            P.ORIG_TERMINAL_ID,
            P.ORIG_DEPARTMENT_ID,
            P.ORIG_AREA_CODE,
            P.ORIG_REGION_CODE,
            P.ORIG_COUNTRY_CODE,
            P.ORIG_IATA_TC_CODE,
            P.ORIG_POLAR_REGION_A_CODE,
            P.ORIG_POLAR_REGION_B_CODE,
            P.DEST_COMPANY_ID,
            P.DEST_SUBSIDIARY_ID,
            P.DEST_TERMINAL_ID,
            P.DEST_DEPARTMENT_ID,
            P.DEST_AREA_CODE,
            P.DEST_REGION_CODE,
            P.DEST_COUNTRY_CODE,
            P.DEST_IATA_TC_CODE,
            P.DEST_POLAR_REGION_A_CODE,
            P.DEST_POLAR_REGION_B_CODE,
            P.NUM_PIECES,
            P.PACKAGING_FORM_CODE,
            P.CHARGEABLE_WEIGHT,
            P.WEIGHT_UOM_CODE,
            MH.GROSS_WEIGHT,
            MH.GROSS_WEIGHT_UOM_CODE,
            MH.VOLUME,
            MH.VOLUME_UOM_CODE,
            MH.VOLUME_WEIGHT,
            MH.VOLUME_WEIGHT_UOM_CODE,
            MH.FREIGHT_PPC_IND,
            MH.OTHER_PPC_IND,
            MH.LOCAL_CURRENCY_CODE,
            MH.DEST_CURRENCY_CODE,
            MH.DEST_EXCHANGE_RATE,
            MH.PPD_FREIGHT_AMT,
            MH.PPD_OTHER_AMT,
            MH.PPD_VALUATION_AMT,
            MH.PPD_TAX_AMT,
            MH.PPD_DUE_AGENT_AMT,
            MH.PPD_DUE_CARRIER_AMT,
            MH.TOT_PPD_AMT,
            MH.COLL_FREIGHT_AMT,
            MH.COLL_OTHER_AMT,
            MH.COLL_VALUATION_AMT,
            MH.COLL_TAX_AMT,
            MH.COLL_DUE_AGENT_AMT,
            MH.COLL_DUE_CARRIER_AMT,
            MH.TOT_COLL_AMT,
            MH.OC_PPD_FREIGHT_AMT,
            MH.OC_PPD_OTHER_AMT,
            MH.OC_PPD_VALUATION_AMT,
            MH.OC_PPD_TAX_AMT,
            MH.OC_PPD_DUE_AGENT_AMT,
            MH.OC_PPD_DUE_CARRIER_AMT,
            MH.OC_TOT_PPD_AMT,
            MH.OC_COLL_FREIGHT_AMT,
            MH.OC_COLL_OTHER_AMT,
            MH.OC_COLL_VALUATION_AMT,
            MH.OC_COLL_TAX_AMT,
            MH.OC_COLL_DUE_AGENT_AMT,
            MH.OC_COLL_DUE_CARRIER_AMT,
            MH.OC_TOT_COLL_AMT,
            MH.NATURE_OF_GOODS,
            MH.SHIPPER_NAME,
            MH.SHIPPER_ADDRESS_NO,
            MH.SHIPPER_CONTACT_NO,
            MH.CNEE_NAME,
            MH.CNEE_ADDRESS_NO,
            MH.CNEE_CONTACT_NO,
            MH.NOTIFY_NAME,
            MH.NOTIFY_ADDRESS_NO,
            MH.NOTIFY_CONTACT_NO,
            MH.BILLTO_NAME,
            MH.BILLTO_ADDRESS_NO,
            MH.BILLTO_CONTACT_NO,
            MH.PAYTO_NAME PTYTOCNT_NAME,
            MH.PAYTO_ADDRESS_NO PTYTOCNT_ADDRESS_NO,
            MH.PAYTO_CONTACT_NO PTYTOCNT_CONTACT_NO,
            MH.LOCFREIGHT_NAME,
            MH.LOCFREIGHT_ADDRESS_NO,
            MH.LOCFREIGHT_CONTACT_NO,
            MH.DEST_BROKER_NAME,
            MH.DEST_BROKER_ADDRESS_NO,
            MH.DEST_BROKER_CONTACT_NO,
            MH.ORIG_AGENT_ID,
            MH.ORIG_AGENT_ADDRESS_NO,
            MH.ORIG_AGENT_CONTACT_NO,
            MH.ORIG_AGENT_NAME,
            MH.DEST_AGENT_ID,
            MH.DEST_AGENT_ADDRESS_NO,
            MH.DEST_AGENT_CONTACT_NO,
            MH.DEST_AGENT_NAME,
            MH.IMPORT_SALESPERSON_ID,
            MH.EXPORT_SALESPERSON_ID,
            TO_DATE(TO_CHAR(MH.ISSUE_DATE_TO_PRINT+ZONE.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                  'YYYY/MM/DD') AS ISSUE_DATE_TO_PRINT,
            MH.OBD_DATE_TO_PRINT,

            -- 2004.10.02
            MH.MPR_PORT_ORIGIN1,
            MH.MPR_PORT_DEST1,
            MH.MPR_RATE1,
            MH.MPR_CURRENCY_CODE1,
            MH.MPR_AMT1,
            MH.MPR_EXCHANGE_RATE1,
            MH.MPR_RATE_PROFILE_NAME1,
            -- 2005.05.15
            MH.MPR_PORT_ORIGIN2,
            MH.MPR_PORT_DEST2,
            MH.MPR_RATE2,
            MH.MPR_CURRENCY_CODE2,
            MH.MPR_AMT2,
            MH.MPR_EXCHANGE_RATE2,
            MH.MPR_RATE_PROFILE_NAME2,
            MH.MPR_PORT_ORIGIN3,
            MH.MPR_PORT_DEST3,
            MH.MPR_RATE3,
            MH.MPR_CURRENCY_CODE3,
            MH.MPR_AMT3,
            MH.MPR_EXCHANGE_RATE3,
            MH.MPR_RATE_PROFILE_NAME3,

            MH.COMMISSION_CURRENCY_CODE,                 -- 2004.12.05
            MH.COMMISSION_STD_PCT,
            MH.COMMISSION_STD_AMT,
            MH.COMMISSION_ADDTL_PCT,
            MH.COMMISSION_ADDTL_AMT,
            MH.COMMISSION_OVERRIDE_PCT,
            MH.COMMISSION_OVERRIDE_AMT,

            MH.BORROW_IND,                               -- 2004.12.05
            MH.BORROW_VENDOR_NAME,
            MH.BORROW_VENDOR_ADDRESS_NO,
            MH.BORROW_VENDOR_INVOICE_NO,
            -- 2005.05.15
            MH.TRV_MPR_RATE1,
            MH.TRV_MPR_CURRENCY_CODE1,
            MH.TRV_MPR_AMT1,
            MH.TRV_MPR_EXCHANGE_RATE1,
            MX.TRV_MPR_RATE_PROFILE_NAME1,
            MH.TRV_MPR_RATE2,
            MH.TRV_MPR_CURRENCY_CODE2,
            MH.TRV_MPR_AMT2,
            MH.TRV_MPR_EXCHANGE_RATE2,
            MX.TRV_MPR_RATE_PROFILE_NAME2,
            MH.TRV_MPR_RATE3,
            MH.TRV_MPR_CURRENCY_CODE3,
            MH.TRV_MPR_AMT3,
            MH.TRV_MPR_EXCHANGE_RATE3,
            MX.TRV_MPR_RATE_PROFILE_NAME3,
            MH.COMMCODE_RECORD_ID
        FROM PIPELINE              P,
             MWB_HEADER            MH,
             MWB_HEADER_EXTENSION  MX,
             TIME_ZONE             ZONE
        WHERE P.PIPELINE_TX_ID    = MH.PIPELINE_TX_ID
          AND P.PIPELINE_TX_TYPE  = 'CS'
          AND P.PIPELINE_TX_ID    = MX.PIPELINE_TX_ID
          AND P.PIPELINE_TX_ID    = KEY_PIPELINE_TX_ID
          AND ZONE.TIME_ZONE_CODE = P.TX_DATE_TZ_CODE;

    --�y ܰ��ϐ� �z
    -- JPAEX �ǉ�                                        2005.04.10
    C_EUPD_TNTCD            TFJ301.EUPD_TNTCD%TYPE := '!';

    -- �װ�����ϐ�
    WK_ERROR                NUMBER;

    -- ���͌������ėpܰ��ϐ�
    WK_TFJ201_IN_CNT        NUMBER;
    WK_TFJ201_NEW_CNT       NUMBER;
    WK_TFJ201_ADJ_CNT       NUMBER;
    WK_TFJ201_DEL_CNT       NUMBER;
    WK_MWB_IN_CNT           NUMBER;
    WK_HWB_IN_CNT           NUMBER;
    WK_INV_IN_CNT           NUMBER;
    WK_TFJ301_AKA_CNT       NUMBER;
    WK_TFJ301_KURO_CNT      NUMBER;
    WK_TFJ303_AKA_CNT       NUMBER;
    WK_TFJ303_KURO_CNT      NUMBER;
    WK_TFJ304_AKA_CNT       NUMBER;
    WK_TFJ304_KURO_CNT      NUMBER;
    WK_TFJ305_AKA_CNT       NUMBER;                  -- 2004.10.02
    WK_TFJ305_KURO_CNT      NUMBER;                  -- 2004.10.02


    --�y PROCEDURE / FUNCTION �z

    -- ���і��ׂ��쐬
    PROCEDURE CRE_MEISAI_JISSEKI(
        IN_DATE     IN DATE );                  -- �Ɩ����t(yyyymmdd)

    -- HWB ���o
    -- (PIPELINE, SHIPMENT_HEADER, SHIPMENT_HEADER_EXTENSION)
    PROCEDURE SEL_HWB(
        OUT_HWB       IN OUT     CUR_HWB%ROWTYPE,      -- HWB, INVOICE
        IN_TFJ201     IN         TFJ201%ROWTYPE );     -- UASIF

    -- ���і��ׁA�R�[�h�E���̕ҏW
    PROCEDURE SET_TFJ301_CODENAME(
        OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
        IN_TFJ201             IN         TFJ201%ROWTYPE );     -- UASIF )

    -- INVOICE ���o
    -- (PIPELINE, INVOICE_HEADER)
    PROCEDURE SEL_INV(
        OUT_INV       IN OUT     CUR_INV%ROWTYPE,      -- INVOICE
        IN_TFJ201     IN         TFJ201%ROWTYPE );     -- UASIF

    -- MWB ���o
    -- (PIPELINE, MWB_HEADER, MWB_HEADER_EXTENSION)
    PROCEDURE SEL_MWB(
        OUT_MWB       IN OUT     CUR_MWB%ROWTYPE,      -- MWB
        IN_TFJ201     IN         TFJ201%ROWTYPE );     -- UASIF

    -- ���і��ׂ̌v��σf�[�^�̃`�F�b�N
    PROCEDURE CHECK_KEIJYOU_MEISAI(
        IN_PIPELINE_TX_STATUS  IN     PIPELINE.PIPELINE_TX_STATUS%TYPE,
        IN_TFJ201              IN     TFJ201%ROWTYPE,       -- UASIF
        OUT_NGENNO             IN OUT TFJ301.NGENNO%TYPE,   -- ����ԍ�
        OUT_ORIGINAL_KJODTM    IN OUT TFJ301.ORIGINAL_KJODTM%TYPE );
                                                        -- �I���W�i���v���

    -- HWB ���і��ׁA�ҏW
    PROCEDURE SET_TFJ301_HWB(
        OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
        IN_HWB                IN         CUR_HWB%ROWTYPE,      -- HWB
        IN_TFJ201             IN         TFJ201%ROWTYPE,       -- UASIF
        IN_NGENNO             IN         TFJ301.NGENNO%TYPE,   -- ����ԍ�
        IN_ORIGINAL_KJODTM    IN         TFJ301.ORIGINAL_KJODTM%TYPE );
                                                        -- �I���W�i���v���

    -- INVOICE ���і��ׁA�ҏW
    PROCEDURE SET_TFJ301_INV(
        OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
        IN_INV                IN         CUR_INV%ROWTYPE,      -- INVOICE
        IN_TFJ201             IN         TFJ201%ROWTYPE );     -- UASIF )

    -- MWB ���і��ׁA�ҏW
    PROCEDURE SET_TFJ301_MWB(
        OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
        IN_MWB                IN         CUR_MWB%ROWTYPE,      -- MWB
        IN_TFJ201             IN         TFJ201%ROWTYPE,       -- UASIF
        IN_NGENNO             IN         TFJ301.NGENNO%TYPE,   -- ����ԍ�
        IN_ORIGINAL_KJODTM    IN         TFJ301.ORIGINAL_KJODTM%TYPE );
                                                        -- �I���W�i���v���

    -- UAS IF�f�[�^����LOCAL_INVOICE_AMT�擾           2004.10.17
    PROCEDURE GET_LOCAL_INVOICE_AMT(
        IN_PIPELINE_TX_ID      IN      TFJ201.PIPELINE_TX_ID%TYPE,
        OUT_LOCAL_INVOICE_AMT  IN OUT  TFJ201.LOCAL_INVOICE_AMT%TYPE );


    -- ���і��ׂ�V�K�쐬
    PROCEDURE INS_TFJ301(
        IN_TFJ301   IN  TFJ301%ROWTYPE );        -- ���і���

    -- HWB/MWB ���і��׋��z�A�ҏW�o��
    PROCEDURE OUTPUT_TFJ303(
        IN_TFJ201    IN         TFJ201%ROWTYPE,       -- UASIF
        IN_TFJ301    IN         TFJ301%ROWTYPE,       -- ���і���
        IN_NGENNO    IN         TFJ303.NGENNO%TYPE );

    -- HWB/MWB ���і��׋��z�ACharges�ҏW�o��
    PROCEDURE OUTPUT_TFJ303_CHARGES(
        IN_PIPELINE_TX_ID IN         PIPELINE_CHARGES.PIPELINE_TX_ID%TYPE,
        IN_TFJ201         IN         TFJ201%ROWTYPE,       -- UASIF
        IN_TFJ303         IN OUT     TFJ303%ROWTYPE );

    -- INVOICE ���і��׋��z�A�ҏW�o��
    PROCEDURE OUTPUT_TFJ303_INV(
        IN_TFJ201    IN         TFJ201%ROWTYPE,        -- UASIF
        IN_INV       IN         CUR_INV%ROWTYPE );     -- INVOICE

    -- HWB/MWB ���і��׋��z��ҏW
    PROCEDURE EDIT_TFJ303(
        IN_TFJ201        IN       TFJ201%ROWTYPE,       -- UASIF
        IN_PC_RECORD_ID  IN       PIPELINE_CHARGES.PC_RECORD_ID%TYPE,
        OUT_TFJ303       IN OUT   TFJ303%ROWTYPE );

    -- INVOICE ���і��׋��z�ACharges�ҏW�o��
    PROCEDURE OUTPUT_TFJ303_CHARGES_INV(
        IN_TFJ201    IN               TFJ201%ROWTYPE,       -- UASIF
        IN_INV       IN               CUR_INV%ROWTYPE,      -- INVOICE
        IN_TFJ303    IN OUT           TFJ303%ROWTYPE );

    -- �������ڃ}�X�^����
    PROCEDURE SEL_TFM205(
        IN_TFJ201      IN          TFJ201%ROWTYPE,                -- UASIF
        IN_CHARGE_CODE IN          TFM205.CHARGE_CODE%TYPE,
        OUT_TFM205     IN OUT      TFM205%ROWTYPE );

    -- ���і��׋��z��V�K�쐬
    PROCEDURE INS_TFJ303(
        IN_TFJ303   IN  TFJ303%ROWTYPE );         -- ���і��׋��z

    -- HWB ����Invoice�A�ҏW�o��
    PROCEDURE OUTPUT_TFJ304(
        IN_TFJ201    IN         TFJ201%ROWTYPE,       -- UASIF
        IN_NGENNO    IN         TFJ304.NGENNO%TYPE );

    -- INVOICE ����Invoice�A�ҏW�o��
    PROCEDURE OUTPUT_TFJ304_INV(
        IN_TFJ201    IN         TFJ201%ROWTYPE,        -- UASIF
        IN_INV       IN         CUR_INV%ROWTYPE );     -- INVOICE

    -- HWB ����Invoice�A�ҏW�o��(by Invoice Header)
    PROCEDURE OUTPUT_TFJ304_IH(
        IN_TFJ201    IN         TFJ201%ROWTYPE,        -- UASIF
        IN_TFJ304    IN OUT     TFJ304%ROWTYPE );     -- ����Invoice

    -- ����Invoice��V�K�쐬
    PROCEDURE INS_TFJ304(
        IN_TFJ304   IN  TFJ304%ROWTYPE );         -- ����Invoice

    -- ����Invoice���z�A�ҏW�o��            2004.10.02
    PROCEDURE OUTPUT_TFJ305(
        IN_TFJ201    IN               TFJ201%ROWTYPE,       -- UASIF
        IN_TFJ304    IN               TFJ304%ROWTYPE );

    -- ����Invoice���z��V�K�쐬            2004.10.02
    PROCEDURE INS_TFJ305(
        IN_TFJ305   IN  TFJ305%ROWTYPE );         -- ����Invoice���z

    -- ���s�폜�ҏW
    FUNCTION DEL_CRLF(
        IN_TEXT     IN  TFJ301.NATURE_OF_GOODS%TYPE )           -- TEXT
    RETURN TFJ301.NATURE_OF_GOODS%TYPE;

END PFGA3010;
CREATE OR REPLACE PACKAGE BODY PFGA3010 AS
--************************************************
--�y ���і��׍쐬 �z�߯���ޖ{�̕�
--     PFGA3010
--
-- UAS IF�f�[�^���A�w��̌v�������
-- �f�[�^�𒊏o���A���׍��ڂ�UFS DB����������
-- ���і��ׁE���і��׋��z�ɏo�͂���B

-- ����Invoice���z�̏o�͂�ǉ��B                     2004.10.02
-- TFJ301 �� Freight Rate�֘A���ڂ�ǉ��B            2004.10.02
-- MWB �̏ꍇ�ATFJ301 �� COMMISION�֘A���ڂ�ǉ��B   2004.10.02
--
-- MWB �̏ꍇ�ABorrow In/Out�֘A���ڂ�ǉ��B         2004.10.06
-- SUM_NUM_PIECES_HWB,SUM_NUM_PIECES_MWB ��OUT_CONTAINER_NUM��ǉ�   2004.10.06
-- ���ڂ̏ꍇ(PIPELINE_REF_TYPE='H'�܂���'M')�AManifest No�̑Ή�     2004.10.06
--
-- 2004.10.27
-- GUI_NUMBER��TFJ304�iInvoice_Head)�ɃZ�b�g
-- HWB, INV �̏ꍇ�APO_NO, COMMERCIAL_INV_NO �� TFJ301 �ɒǉ�        2004.12.12
-- 2005.01.24
-- AR�̎������AINVOICE_NO�̃Z�b�g�iTFJ301)
-- FWD���ЁE���Д��f��ύX 'KA'�F���� --> 'KA' or IS NULL
-- JPAEX�Ɠ��l���� �ǉ�                                              2005.04.10
-- 2005.04.17 JPEX��Global�̃\�[�X���ɗ͑�����B
--            ���̂��߁A���t�͍ŏ��ɕύX�������ɍ��킹��
-- 2005.04.18 Invoice���o��TFJ303����PIPELINE_RELATION�ɕύX
--            Debit/Credit�̍l���̂���
-- 2005.04.18 Direct Billing�̑Ή�-->TFJ304�ɍ��ڒǉ�
-- 2005.04.29 ROUTE�̑Ή�

-- 2005.12.16 Misc Invoice�Ή�
-- 2005.12.16 Rate Profile�Ή�

--************************************************

--================================================
-- ���і��ׂ��쐬
--================================================
PROCEDURE CRE_MEISAI_JISSEKI(
    IN_DATE     IN DATE )                 -- �Ɩ����t(yyyymmdd)
IS
    CURSOR CUR_TFJ201( KEY_DATE   DATE ) IS
        SELECT *
          FROM TFJ201
          WHERE DGYMDTM = KEY_DATE
          ORDER BY COMPANY_ID,
                   IMPORT_EXPORT_IND,
                   TRANSPORT_MODE,
                   ACCOUNTING_DATE,
                   PIPELINE_TX_ID,
                   INVOICE_TX_ID DESC;

    WK_PIPELINE_TX_ID     PIPELINE.PIPELINE_TX_ID%TYPE;
    WK_PIPELINE_TX_STATUS PIPELINE.PIPELINE_TX_STATUS%TYPE;

    WK_TFJ201             TFJ201%ROWTYPE;
    WK_HWB                CUR_HWB%ROWTYPE;
    WK_INV                CUR_INV%ROWTYPE;
    WK_MWB                CUR_MWB%ROWTYPE;
    WK_NGENNO             TFJ301.NGENNO%TYPE;
    WK_ORIGINAL_KJODTM    TFJ301.ORIGINAL_KJODTM%TYPE;
    WK_TFJ301             TFJ301%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'CRE_MEISAI_JISSEKI' );
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || IN_DATE );

    C_EUPD_TNTCD       := 'PFGA3010';
    WK_ERROR           := 0;

    -- �����������ėpܰ��ϐ�
    WK_TFJ201_IN_CNT   := 0;
    WK_TFJ201_NEW_CNT  := 0;
    WK_TFJ201_ADJ_CNT  := 0;
    WK_TFJ201_DEL_CNT  := 0;
    WK_MWB_IN_CNT      := 0;
    WK_HWB_IN_CNT      := 0;
    WK_INV_IN_CNT      := 0;
    WK_TFJ301_AKA_CNT  := 0;
    WK_TFJ301_KURO_CNT := 0;
    WK_TFJ303_AKA_CNT  := 0;
    WK_TFJ303_KURO_CNT := 0;
    WK_TFJ304_AKA_CNT  := 0;
    WK_TFJ304_KURO_CNT := 0;
    WK_TFJ305_AKA_CNT  := 0;                            -- 2004.10.02
    WK_TFJ305_KURO_CNT := 0;                            -- 2004.10.02

    WK_PIPELINE_TX_ID := 0;

    FOR WK_REC IN CUR_TFJ201( IN_DATE ) LOOP

        IF WK_PIPELINE_TX_ID <> WK_REC.PIPELINE_TX_ID THEN

            WK_TFJ201_IN_CNT := WK_TFJ201_IN_CNT + 1;
            WK_TFJ201        := WK_REC;

            IF WK_TFJ201.WAYBILL_TYPE = 'M'  OR
               WK_TFJ201.WAYBILL_TYPE = 'MD' THEN
                -- MWB ���o
                SEL_MWB( WK_MWB, WK_TFJ201 );
                WK_PIPELINE_TX_ID     := WK_MWB.PIPELINE_TX_ID;
                WK_PIPELINE_TX_STATUS := WK_MWB.PIPELINE_TX_STATUS;

                IF WK_PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
                    -- �v��f�[�^�ς݂̃f�[�^���������A
                    -- �f�[�^������ꍇ�ԃf�[�^�쐬
                    -- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
                    CHECK_KEIJYOU_MEISAI( WK_PIPELINE_TX_STATUS,
                                          WK_TFJ201,
                                          WK_NGENNO,
                                          WK_ORIGINAL_KJODTM );

                    -- �폜�f�[�^�ȊO�̏ꍇ
                    IF WK_PIPELINE_TX_STATUS NOT IN ('VD','CAN') THEN
                        -- MWB ���і��ׁA�ҏW
                        SET_TFJ301_MWB( WK_TFJ301,
                                        WK_MWB,
                                        WK_TFJ201,
                                        WK_NGENNO,
                                        WK_ORIGINAL_KJODTM );
                        -- ���і��ׂ�V�K�쐬
                        INS_TFJ301( WK_TFJ301 );

                        -- HWB/MWB ���і��׋��z�A�ҏW�o��
                        OUTPUT_TFJ303( WK_TFJ201, WK_TFJ301, WK_NGENNO );
                    END IF;
                END IF;
            ELSE
                IF WK_TFJ201.HWB_TX_ID <> 0 THEN
                    -- HWB ���o
                    SEL_HWB( WK_HWB, WK_TFJ201 );
                    WK_PIPELINE_TX_ID     := WK_HWB.PIPELINE_TX_ID;
                    WK_PIPELINE_TX_STATUS := WK_HWB.PIPELINE_TX_STATUS;

                    IF WK_PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
                        -- �v��f�[�^�ς݂̃f�[�^���������A
                        -- �f�[�^������ꍇ�ԃf�[�^�쐬
                        -- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
                        CHECK_KEIJYOU_MEISAI( WK_PIPELINE_TX_STATUS,
                                              WK_TFJ201,
                                              WK_NGENNO,
                                              WK_ORIGINAL_KJODTM );

                        -- �폜�f�[�^�ȊO�̏ꍇ
                        IF WK_PIPELINE_TX_STATUS NOT IN ('VD','CAN') THEN
                            -- HWB ���і��ׁA�ҏW
                            SET_TFJ301_HWB( WK_TFJ301,
                                            WK_HWB,
                                            WK_TFJ201,
                                            WK_NGENNO,
                                            WK_ORIGINAL_KJODTM );

                            -- ���і��ׂ�V�K�쐬
                            INS_TFJ301( WK_TFJ301 );

                            -- HWB/MWB ���і��׋��z�A�ҏW�o��
                            OUTPUT_TFJ303( WK_TFJ201, WK_TFJ301, WK_NGENNO );

                            -- HWB ����Invoice�A�ҏW�o��
                            OUTPUT_TFJ304( WK_TFJ201, WK_NGENNO );
                        END IF;
                    END IF;
                ELSE
                    -- INVOICE ���o
                    SEL_INV( WK_INV, WK_TFJ201 );
                    WK_PIPELINE_TX_ID     := WK_INV.PIPELINE_TX_ID;

                    IF WK_PIPELINE_TX_ID = WK_TFJ201.PIPELINE_TX_ID THEN
                        -- INVOICE ���і��ׁA�ҏW
                        SET_TFJ301_INV( WK_TFJ301,
                                        WK_INV,
                                        WK_TFJ201 );

                        -- ���і��ׂ�V�K�쐬
                        INS_TFJ301( WK_TFJ301 );

                        -- INVOICE ���і��׋��z�A�ҏW�o��
                        OUTPUT_TFJ303_INV( WK_TFJ201, WK_INV );

                        -- INVOICE ����Invoice�A�ҏW�o��
                        OUTPUT_TFJ304_INV( WK_TFJ201, WK_INV );
                    END IF;
                END IF;
            END IF;
        END IF;

    END LOOP;

    PFGA3910.TRACE_LOG( 'I', 'UASIF    ���͌���   = ' || WK_TFJ201_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �V�K����   = ' || WK_TFJ201_NEW_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �C������   = ' || WK_TFJ201_ADJ_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF    �폜����   = ' || WK_TFJ201_DEL_CNT );
    PFGA3910.TRACE_LOG( 'I', 'MWB      ���͌���   = ' || WK_MWB_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'HWB      ���͌���   = ' || WK_HWB_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', 'INVOICE  ���͌���   = ' || WK_INV_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� �ԏo�͌��� = ' || WK_TFJ301_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���і��� ���o�͌��� = ' || WK_TFJ301_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z �ԏo�͌��� = ' || WK_TFJ303_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '���׋��z ���o�͌��� = ' || WK_TFJ303_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', '����Inv  �ԏo�͌��� = ' || WK_TFJ304_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', '����Inv  ���o�͌��� = ' || WK_TFJ304_KURO_CNT );
    PFGA3910.TRACE_LOG( 'I', 'Inv���z  �ԏo�͌��� = ' || WK_TFJ305_AKA_CNT );
    PFGA3910.TRACE_LOG( 'I', 'Inv���z  ���o�͌��� = ' || WK_TFJ305_KURO_CNT );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ201: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_LOG( 'E', '�G���[�f�[�^'
                         || ' RECORD_IND = ' || WK_TFJ201.RECORD_IND
                         || ' RECORD_ID = '  || WK_TFJ201.RECORD_ID );
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- HWB ���o
-- (PIPELINE, SHIPMENT_HEADER, SHIPMENT_HEADER_EXTENSION)
--================================================
PROCEDURE SEL_HWB(
    OUT_HWB       IN OUT     CUR_HWB%ROWTYPE,      -- HWB
    IN_TFJ201     IN         TFJ201%ROWTYPE )      -- UASIF
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SEL_HWB' );

    OUT_HWB.PIPELINE_TX_ID := 0;

    FOR WK_REC IN CUR_HWB( IN_TFJ201.PIPELINE_TX_ID ) LOOP
        OUT_HWB       := WK_REC;
        WK_HWB_IN_CNT := WK_HWB_IN_CNT + 1;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','HWB: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- INVOICE ���o
-- (PIPELINE, INVOICE_HEADER)
--================================================
PROCEDURE SEL_INV(
    OUT_INV       IN OUT     CUR_INV%ROWTYPE,      -- INVOICE
    IN_TFJ201     IN         TFJ201%ROWTYPE )      -- UASIF
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SEL_INV' );

    OUT_INV.PIPELINE_TX_ID := 0;

    FOR WK_REC IN CUR_INV( IN_TFJ201.PIPELINE_TX_ID ) LOOP
        OUT_INV       := WK_REC;
        WK_INV_IN_CNT := WK_INV_IN_CNT + 1;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','INVOICE: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- MWB ���o
-- (PIPELINE, MWB_HEADER, MWB_HEADER_EXTENSION)
--================================================
PROCEDURE SEL_MWB(
    OUT_MWB       IN OUT     CUR_MWB%ROWTYPE,      -- MWB
    IN_TFJ201     IN         TFJ201%ROWTYPE )      -- UASIF
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SEL_MWB' );

    OUT_MWB.PIPELINE_TX_ID := 0;

    FOR WK_REC IN CUR_MWB( IN_TFJ201.PIPELINE_TX_ID ) LOOP
        OUT_MWB       := WK_REC;
        WK_MWB_IN_CNT := WK_MWB_IN_CNT + 1;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','MWB: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ���і��ׂ̌v��σf�[�^�̃`�F�b�N
--
-- �v��f�[�^�ς݂̃f�[�^���������A�f�[�^������ꍇ
-- �ԃf�[�^�쐬
-- �܂��A���f�[�^�쐬�̏ꍇ�̐���ԍ����擾
--================================================
PROCEDURE CHECK_KEIJYOU_MEISAI(
    IN_PIPELINE_TX_STATUS  IN     PIPELINE.PIPELINE_TX_STATUS%TYPE,
    IN_TFJ201              IN     TFJ201%ROWTYPE,       -- UASIF
    OUT_NGENNO             IN OUT TFJ301.NGENNO%TYPE,   -- ����ԍ�
    OUT_ORIGINAL_KJODTM    IN OUT TFJ301.ORIGINAL_KJODTM%TYPE )
                                                        -- �I���W�i���v���
IS
    -- ���і��ג��o�J�[�\��
    -- 2004.10.04 �ŐV�敪����MAX����ɕύX
    -- Global
    CURSOR CUR_TFJ301( KEY_EDATKBN         IN TFJ301.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ301.PIPELINE_TX_ID%TYPE ) IS
        SELECT *
          FROM TFJ301
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
--          AND ESISNKBN        = '1';
            AND NGENNO          = ( SELECT MAX(B.NGENNO)
                                     FROM  TFJ301 B
                                    WHERE  B.EDATKBN        = KEY_EDATKBN
                                      AND  B.PIPELINE_TX_ID = KEY_PIPELINE_TX_ID);

    -- ���і��׋��z���o�J�[�\��
    CURSOR CUR_TFJ303( KEY_EDATKBN         IN TFJ303.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ303.PIPELINE_TX_ID%TYPE,
                       KEY_NGENNO          IN TFJ303.NGENNO%TYPE ) IS
        SELECT *
          FROM TFJ303
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
            AND NGENNO          = KEY_NGENNO;

    -- ����Invoice���o�J�[�\��
    CURSOR CUR_TFJ304( KEY_EDATKBN         IN TFJ304.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ304.PIPELINE_TX_ID%TYPE,
                       KEY_NGENNO          IN TFJ304.NGENNO%TYPE ) IS
        SELECT *
          FROM TFJ304
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
            AND NGENNO          = KEY_NGENNO;

    -- ����Invoice���z���o�J�[�\��
    CURSOR CUR_TFJ305( KEY_EDATKBN         IN TFJ305.EDATKBN%TYPE,
                       KEY_PIPELINE_TX_ID  IN TFJ305.PIPELINE_TX_ID%TYPE,
                       KEY_NGENNO          IN TFJ305.NGENNO%TYPE ) IS
        SELECT *
          FROM TFJ305
          WHERE EDATKBN         = KEY_EDATKBN
            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
            AND NGENNO          = KEY_NGENNO;

    WK_EDATKBN         TFJ301.EDATKBN%TYPE;
    WK_TFJ301          TFJ301%ROWTYPE;
    WK_TFJ303          TFJ303%ROWTYPE;
    WK_TFJ304          TFJ304%ROWTYPE;
    WK_TFJ305          TFJ305%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'CHECK_KEIJYOU_MEISAI' );

    WK_TFJ301           := NULL;
    OUT_NGENNO          := 0;
    OUT_ORIGINAL_KJODTM := NULL;

    IF IN_TFJ201.WAYBILL_TYPE = 'M'  OR
       IN_TFJ201.WAYBILL_TYPE = 'MD' THEN
        -- MWB�̎��i�d����j
        WK_EDATKBN         := '3';
    ELSE
        -- HWB_TX_ID��0�ȊO�̎��iSHIPMENT�P�ʁj
        WK_EDATKBN         := '1';
    END IF;

    -- �ŐV�敪���X�V����
    FOR WK_REC IN CUR_TFJ301( WK_EDATKBN,
                              IN_TFJ201.PIPELINE_TX_ID ) LOOP
        WK_TFJ301           := WK_REC;
        OUT_NGENNO          := WK_REC.NGENNO;
        OUT_ORIGINAL_KJODTM := WK_TFJ301.ORIGINAL_KJODTM;

        -- �ŐV�敪�X�V
        UPDATE TFJ301
              SET EUPDDTM    = TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),
                  DHNEDTM    = SYSDATE,
--                  EUPD_OFCCD = '!',
--                  EUPD_TNTCD = '!',
                  ESISNKBN   = '0'
              WHERE EDATKBN        = WK_REC.EDATKBN
                AND PIPELINE_TX_ID = WK_REC.PIPELINE_TX_ID
                AND DGYMDTM        = WK_REC.DGYMDTM
                AND NGENNO         = WK_REC.NGENNO;
    END LOOP;

    -- �v��σf�[�^������ꍇ�A
    IF OUT_NGENNO > 0 THEN
        -- �폜�ް��ȊO�ō��ް��̏ꍇ�A�ԃf�[�^�쐬
        IF WK_TFJ301.EDELKBN = '0' AND WK_TFJ301.NAKKBN = 1 THEN
            WK_TFJ301.ETRKDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
            WK_TFJ301.EUPDDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
            WK_TFJ301.DHNEDTM    := SYSDATE;
            WK_TFJ301.EUPD_OFCCD := '!';
            WK_TFJ301.EUPD_TNTCD := C_EUPD_TNTCD;

            WK_TFJ301.DGYMDTM  := IN_TFJ201.DGYMDTM;          -- �Ɩ����t
            WK_TFJ301.DKJODTM  := IN_TFJ201.ACCOUNTING_DATE;  -- �v�����
            WK_TFJ301.NGENNO   := OUT_NGENNO + 1;             -- ����ԍ�
            WK_TFJ301.NAKKBN   := -1;                         -- ��
            WK_TFJ301.EOPE_KBN := '1';                  -- �f�[�^�����敪�F�C��

            -- �폜�ް��̏ꍇ�A���̐ԃf�[�^�͍ŐV�f�[�^�Ƃ���
            IF IN_PIPELINE_TX_STATUS IN ('VD','CAN') THEN
                WK_TFJ301.ESISNKBN := '1';
                WK_TFJ301.EDELKBN  := '1';
                WK_TFJ301.PIPELINE_TX_STATUS  := IN_PIPELINE_TX_STATUS;  -- 2005.06.10 Add
                WK_TFJ201_DEL_CNT  := WK_TFJ201_DEL_CNT + 1;
            ELSE
                WK_TFJ301.ESISNKBN := '0';
                WK_TFJ301.EDELKBN  := '0';
                WK_TFJ201_ADJ_CNT  := WK_TFJ201_ADJ_CNT + 1;
            END IF;

            -- ���і��ׂ��쐬�i�ԁj
            INS_TFJ301( WK_TFJ301 );

            -- ���і��׋��z���o
            FOR WK_REC3 IN CUR_TFJ303( WK_EDATKBN,
                                       IN_TFJ201.PIPELINE_TX_ID,
                                       OUT_NGENNO ) LOOP
                WK_TFJ303            := WK_REC3;
                WK_TFJ303.ETRKDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ303.EUPDDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ303.DHNEDTM    := SYSDATE;
                WK_TFJ303.EUPD_OFCCD := '!';
                WK_TFJ303.EUPD_TNTCD := C_EUPD_TNTCD;

                WK_TFJ303.DGYMDTM  := IN_TFJ201.DGYMDTM;          -- �Ɩ����t
                WK_TFJ303.NGENNO   := OUT_NGENNO + 1;             -- ����ԍ�
                WK_TFJ303.NAKKBN   := -1;                         -- ��
                WK_TFJ303.EOPE_KBN := '1';              -- �f�[�^�����敪�F�C��

                -- �폜�ް��̏ꍇ�A���̐ԃf�[�^�͍ŐV�f�[�^�Ƃ���
                IF IN_PIPELINE_TX_STATUS IN ('VD','CAN') THEN
                    WK_TFJ303.EDELKBN  := '1';
                ELSE
                    WK_TFJ303.EDELKBN  := '0';
                END IF;

                -- ���і��׋��z�i�ԁj���쐬
                INS_TFJ303( WK_TFJ303 );
            END LOOP;

            -- ����Invoice���o
            FOR WK_REC4 IN CUR_TFJ304( WK_EDATKBN,
                                       IN_TFJ201.PIPELINE_TX_ID,
                                       OUT_NGENNO ) LOOP
                WK_TFJ304            := WK_REC4;
                WK_TFJ304.ETRKDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ304.EUPDDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ304.DHNEDTM    := SYSDATE;
                WK_TFJ304.EUPD_OFCCD := '!';
                WK_TFJ304.EUPD_TNTCD := C_EUPD_TNTCD;

                WK_TFJ304.DGYMDTM  := IN_TFJ201.DGYMDTM;          -- �Ɩ����t
                WK_TFJ304.NGENNO   := OUT_NGENNO + 1;             -- ����ԍ�
                WK_TFJ304.NAKKBN   := -1;                         -- ��
                WK_TFJ304.EOPE_KBN := '1';              -- �f�[�^�����敪�F�C��

                -- �폜�ް��̏ꍇ�A���̐ԃf�[�^�͍ŐV�f�[�^�Ƃ���
                IF IN_PIPELINE_TX_STATUS IN ('VD','CAN') THEN
                    WK_TFJ304.EDELKBN  := '1';
                ELSE
                    WK_TFJ304.EDELKBN  := '0';
                END IF;

                -- ����Invoice�i�ԁj���쐬
                INS_TFJ304( WK_TFJ304 );
            END LOOP;

            -- ����Invoice���z���o
            FOR WK_REC5 IN CUR_TFJ305( WK_EDATKBN,
                                       IN_TFJ201.PIPELINE_TX_ID,
                                       OUT_NGENNO ) LOOP
                WK_TFJ305            := WK_REC5;
                WK_TFJ305.ETRKDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ305.EUPDDTM    := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
                WK_TFJ305.DHNEDTM    := SYSDATE;
                WK_TFJ305.EUPD_OFCCD := '!';
                WK_TFJ305.EUPD_TNTCD := C_EUPD_TNTCD;

                WK_TFJ305.DGYMDTM  := IN_TFJ201.DGYMDTM;          -- �Ɩ����t
                WK_TFJ305.NGENNO   := OUT_NGENNO + 1;             -- ����ԍ�
                WK_TFJ305.NAKKBN   := -1;                         -- ��
                WK_TFJ305.EOPE_KBN := '1';              -- �f�[�^�����敪�F�C��

                -- �폜�ް��̏ꍇ�A���̐ԃf�[�^�͍ŐV�f�[�^�Ƃ���
                IF IN_PIPELINE_TX_STATUS IN ('VD','CAN') THEN
                    WK_TFJ305.EDELKBN  := '1';
                ELSE
                    WK_TFJ305.EDELKBN  := '0';
                END IF;

                -- ����Invoice���z�i�ԁj���쐬
                INS_TFJ305( WK_TFJ305 );
            END LOOP;

            OUT_NGENNO         := OUT_NGENNO + 1;             -- ����ԍ��X�V

        END IF;
    ELSE
        WK_TFJ201_NEW_CNT := WK_TFJ201_NEW_CNT + 1;
    END IF;

    OUT_NGENNO :=OUT_NGENNO + 1;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- HWB ���і��ׁA�ҏW
--================================================
PROCEDURE SET_TFJ301_HWB(
    OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
    IN_HWB                IN         CUR_HWB%ROWTYPE,      -- HWB
    IN_TFJ201             IN         TFJ201%ROWTYPE,       -- UASIF
    IN_NGENNO             IN         TFJ301.NGENNO%TYPE,   -- ����ԍ�
    IN_ORIGINAL_KJODTM    IN         TFJ301.ORIGINAL_KJODTM%TYPE )
                                                        -- �I���W�i���v���
IS
    WK_PIPELINE_REF_ID     PIPELINE.PIPELINE_REF_ID%TYPE;
    WK_DATE                DATE;
    WK_PIPELINE_TX_ID      PIPELINE.PIPELINE_TX_ID%TYPE;

    WK_CONTAINER_NUM        SHIPMENT_DETAIL.CONTAINER_NUM%TYPE;   -- 2004.10.06
    WK_CONTAINER_TYPE       SHIPMENT_DETAIL.CONTAINER_TYPE%TYPE;  -- 2004.10.06
    WK_CONTAINER_20FT       SHIPMENT_DETAIL.NUM_PIECES%TYPE;
    WK_CONTAINER_40FT       SHIPMENT_DETAIL.NUM_PIECES%TYPE;
    WK_CONTAINER_ETC        SHIPMENT_DETAIL.NUM_PIECES%TYPE;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    DMY_PARENT_PARTNER_ID   PARTNER.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_NAME         PARTNER.PARTNER_NAME%TYPE;
    WK_LL_PARTNER_NAME      PARTNER.LL_PARTNER_NAME%TYPE;
    DMY_PARTNER_SHORT_NAME  PARTNER.PARTNER_SHORT_NAME%TYPE;
    WK_INDUSTRY_CODE        PARTNER.CUSTOMER_INDUSTRY_CODE%TYPE; -- add 2005.04.10
    WK_INDUSTRY_NAME        CODE_DETAIL.CD_DESCRIPTION%TYPE;     -- add 2005.04.10

    WK_ADDRESS              ADDRESS%ROWTYPE;
    WK_CONTACT              CONTACT%ROWTYPE;

    WK_PORT_NAME            PORT.PORT_NAME%TYPE;

    WK_COUNTRY_CODE         COUNTRY.COUNTRY_CODE%TYPE;
    WK_IATA_CONFERENCE_CODE COUNTRY.IATA_CONFERENCE_CODE%TYPE;

    WK_CONSOL_SERVICE_TYPE  CONSOL.CONSOL_SERVICE_TYPE%TYPE;
    WK_CONSOL_CODE          CONSOL.CONSOL_CODE%TYPE;             -- add 2005.04.10

    WK_CARRIER_TYPE         CARRIER.CARRIER_TYPE%TYPE;
    WK_CARRIER_NAME         CARRIER.CARRIER_NAME%TYPE;
    WK_DEPARTURE_DATE       CARRIER_SEGMENT.ATD%TYPE;
    WK_ARRIVAL_DATE         CARRIER_SEGMENT.ATA%TYPE;
    WK_CARRIER_CODE         CARRIER_SEGMENT.CARRIER_CODE%TYPE;
    WK_FLIGHT_VOYAGE        CARRIER_SEGMENT.FLIGHT_VOYAGE%TYPE;
    WK_VESSEL_NAME          CARRIER_SEGMENT.VESSEL_NAME%TYPE;

    WK_RATE_CLASS_CODE      SHIPMENT_DETAIL.RATE_CLASS_CODE%TYPE;
    WK_RATE_AMT             SHIPMENT_DETAIL.RATE_AMT%TYPE;
    WK_TOTAL_RATE_AMT       SHIPMENT_DETAIL.TOTAL_RATE_AMT%TYPE;
    WK_DESCRIPTION          SHIPMENT_DETAIL.DESCRIPTION%TYPE;        -- 2005.05.15
    WK_CC_RECORD_ID         SHIPMENT_DETAIL.COMMCODE_RECORD_ID%TYPE; -- 2005.05.15

    WK_MANIFEST_NO          MANIFEST_HEADER.MANIFEST_NO%TYPE;    -- 2004.10.06

    -- JPAEX �ǉ�                                        2005.04.10
    WK_PIPELINE_TX_STATUS  PIPELINE.PIPELINE_TX_STATUS%TYPE;
    WK_PORT_ORIGIN         PIPELINE.PORT_ORIGIN%TYPE;
    WK_PORT_LOADING        PIPELINE.PORT_LOADING%TYPE;
    WK_PORT_UNLOADING      PIPELINE.PORT_UNLOADING%TYPE;
    WK_PORT_DEST           PIPELINE.PORT_DEST%TYPE;
    WK_REF_NUM             REFERENCE_NUMBERS.REF_NUM%TYPE;

    -- ROUTE��� �ǉ�                                    2005.04.29
    WK_ETD                   ROUTE.DEPARTURE_DATE%TYPE;
    WK_ETA                   ROUTE.ARRIVAL_DATE%TYPE;
    WK_ATD                   ROUTE.DEPARTURE_DATE%TYPE;
    WK_ATA                   ROUTE.ARRIVAL_DATE%TYPE;
    WK_ROUTE1_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE1_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE1_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE1_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE1_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE1_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE2_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE2_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE2_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE2_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE2_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE2_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE3_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE3_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE3_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE3_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE3_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE3_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE4_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE4_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE4_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE4_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE4_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE4_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE5_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE5_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE5_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE5_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE5_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE5_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;

    -- 2005.05.15 COMMODITY_CODE(SCR No)
    WK_COMMODITY_CODE        COMMODITY_CODES.COMMODITY_CODE%TYPE;
    WK_COMMODITY_DESCRIPTION COMMODITY_CODES.COMMODITY_DESCRIPTION%TYPE;
    WK_COMMODITY_TYPE        COMMODITY_CODES.COMMODITY_TYPE%TYPE;

    -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
    WK_WT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_M3_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_RT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_WT_RND          NUMBER;
    WK_M3_RND          NUMBER;
    WK_RT_RND          NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SET_TFJ301_HWB' );

    OUT_TFJ301                         := NULL;
        -- ����
    OUT_TFJ301.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.DHNEDTM                 := SYSDATE;
    OUT_TFJ301.EUPD_OFCCD              := '!';
    OUT_TFJ301.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    OUT_TFJ301.EDATKBN                 := '1';
    OUT_TFJ301.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    OUT_TFJ301.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    OUT_TFJ301.NGENNO                  := IN_NGENNO;
    -- �R���g���[��
    OUT_TFJ301.ESISNKBN                := '1';
    OUT_TFJ301.NAKKBN                  := 1;
    OUT_TFJ301.EDELKBN                 := '0';
    OUT_TFJ301.ESKY_KBN                := '0';
    IF IN_NGENNO = 1 THEN
        OUT_TFJ301.EOPE_KBN            := '0';      -- �V�K
    ELSE
        OUT_TFJ301.EOPE_KBN            := '1';      -- �C��
    END IF;
    OUT_TFJ301.ECOMPANY_ID             := IN_TFJ201.COMPANY_ID;
    OUT_TFJ301.EIM_EX_IND              := IN_TFJ201.IMPORT_EXPORT_IND;
    OUT_TFJ301.ETRANS_MODE             := IN_TFJ201.TRANSPORT_MODE;
    -- ���t
    OUT_TFJ301.DKJODTM                 := IN_TFJ201.ACCOUNTING_DATE;
    -- 2005.06.19 PFGA3011 ISSUE�捞�̏ꍇ�AORIGINAL_KJODTM��NULL�ɂ���B
    -- IF IN_NGENNO > 1 THEN
    --     OUT_TFJ301.ORIGINAL_KJODTM     := IN_ORIGINAL_KJODTM;
    -- ELSE
    --     OUT_TFJ301.ORIGINAL_KJODTM     := IN_TFJ201.ACCOUNTING_DATE;
    -- END IF;
    IF IN_NGENNO = 1 THEN
        IF OUT_TFJ301.EUPD_TNTCD = 'PFGA3010' THEN
            OUT_TFJ301.ORIGINAL_KJODTM := IN_TFJ201.ACCOUNTING_DATE;
        ELSE
            OUT_TFJ301.ORIGINAL_KJODTM := NULL;
        END IF;
    ELSE
        IF IN_ORIGINAL_KJODTM IS NULL AND
           OUT_TFJ301.EUPD_TNTCD = 'PFGA3010' THEN
            OUT_TFJ301.ORIGINAL_KJODTM := IN_TFJ201.ACCOUNTING_DATE;
        ELSE
            OUT_TFJ301.ORIGINAL_KJODTM := IN_ORIGINAL_KJODTM;
        END IF;
    END IF;
    OUT_TFJ301.INVOICE_DATE            := IN_TFJ201.INVOICE_DATE;
    OUT_TFJ301.ORIGINAL_INVOICE_DATE   := IN_TFJ201.ORIGINAL_INVOICE_DATE;

    -- ���t�E�ԍ�
    IF IN_HWB.PIPELINE_REF_TYPE = 'HM' THEN
        OUT_TFJ301.HMWB_NO             := IN_HWB.PIPELINE_REF_ID;
        OUT_TFJ301.HMWB_TX_ID          := IN_HWB.PIPELINE_TX_ID;
    ELSIF IN_HWB.PIPELINE_REF_TYPE = 'HR' THEN
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.PIPELINE_TX_ID,
                                         'SH',
                                         'SH',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
        OUT_TFJ301.HMWB_NO             := WK_PIPELINE_REF_ID;
        OUT_TFJ301.HMWB_TX_ID          := WK_PIPELINE_TX_ID;
    ELSE
        OUT_TFJ301.HMWB_NO             := NULL;
        OUT_TFJ301.HMWB_TX_ID          := NULL;
    END IF;

    IF IN_HWB.PIPELINE_REF_TYPE = 'H' OR
       IN_HWB.PIPELINE_REF_TYPE = 'HM' THEN
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.PIPELINE_TX_ID,
                                         'SH',
                                         'CO',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
        OUT_TFJ301.CONSOL_DATE         := WK_DATE;
        OUT_TFJ301.CONSOL_NO           := WK_PIPELINE_REF_ID;
        OUT_TFJ301.CONSOL_TX_ID        := WK_PIPELINE_TX_ID;

        -- Manifest No�̑Ή�
        PFGA3950.SEL_MANIFEST_HEADER( OUT_TFJ301.CONSOL_TX_ID,
                                      'M',
                                      WK_MANIFEST_NO );
        OUT_TFJ301.MANIFEST_NO         := WK_MANIFEST_NO;

        -- 2005.09.01 MY Domestic Consol�Ή�
        PFGA3950.SEL_DC_RELATIONS( OUT_TFJ301.PIPELINE_TX_ID,
                                   'SH',
                                   'CO',
                                   WK_PIPELINE_REF_ID,
                                   WK_DATE,
                                   WK_PIPELINE_TX_ID );
        OUT_TFJ301.DC_CONSOL_DATE     := WK_DATE;
        OUT_TFJ301.DC_CONSOL_NO       := WK_PIPELINE_REF_ID;
        OUT_TFJ301.DC_CONSOL_TX_ID    := WK_PIPELINE_TX_ID;
        IF OUT_TFJ301.DC_CONSOL_TX_ID <> 0 THEN
            PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.DC_CONSOL_TX_ID,
                                             'CO',
                                             'CS',
                                             WK_PIPELINE_REF_ID,
                                             WK_DATE,
                                             WK_PIPELINE_TX_ID );
            OUT_TFJ301.DC_MWB_ISSUE_DATE := WK_DATE;
            OUT_TFJ301.DC_MWB_NO         := WK_PIPELINE_REF_ID;
            OUT_TFJ301.DC_MWB_TX_ID      := WK_PIPELINE_TX_ID;
        END IF;
    ELSIF IN_HWB.PIPELINE_REF_TYPE = 'HR' THEN
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.HMWB_TX_ID,
                                         'SH',
                                         'CO',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
        OUT_TFJ301.CONSOL_DATE         := WK_DATE;
        OUT_TFJ301.CONSOL_NO           := WK_PIPELINE_REF_ID;
        OUT_TFJ301.CONSOL_TX_ID        := WK_PIPELINE_TX_ID;
    ELSE
        OUT_TFJ301.CONSOL_DATE         := NULL;
        OUT_TFJ301.CONSOL_NO           := NULL;
        OUT_TFJ301.CONSOL_TX_ID        := NULL;
    END IF;

    IF IN_HWB.PIPELINE_REF_TYPE = 'H' OR
       IN_HWB.PIPELINE_REF_TYPE = 'HM' OR
       IN_HWB.PIPELINE_REF_TYPE = 'HR' THEN
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.CONSOL_TX_ID,
                                         'CO',
                                         'CS',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
    ELSE
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.PIPELINE_TX_ID,
                                         'SH',
                                         'CS',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
    END IF;
    OUT_TFJ301.MWB_ISSUE_DATE          := WK_DATE;
    OUT_TFJ301.MWB_NO                  := WK_PIPELINE_REF_ID;
    OUT_TFJ301.MWB_TX_ID               := WK_PIPELINE_TX_ID;

    OUT_TFJ301.ISSUE_DATE              := IN_HWB.ISSUE_DATE;
    OUT_TFJ301.HWB_NO                  := IN_HWB.PIPELINE_REF_ID;
    OUT_TFJ301.HWB_TX_ID               := IN_HWB.PIPELINE_TX_ID;

    -- 2005.01.24 AP��INVOICE_NO�iVENDOR_REF_NO�j�͂S�O��
    IF IN_TFJ201.RECORD_IND = 'AR' THEN
        OUT_TFJ301.INVOICE_NO          := IN_TFJ201.INVOICE_NO;
        OUT_TFJ301.INVOICE_TX_ID       := IN_TFJ201.INVOICE_TX_ID;
    ELSE
        OUT_TFJ301.INVOICE_NO          := NULL;
        OUT_TFJ301.INVOICE_TX_ID       := NULL;
    END IF;

    -- 2005.06.19 MY JOB_NO�Ή�
    IF OUT_TFJ301.EIM_EX_IND = 'E' THEN
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'SH',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNE',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    ELSE
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'SH',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNI',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    END IF;
    OUT_TFJ301.JOB_NO                  := WK_PIPELINE_REF_ID;
    OUT_TFJ301.JOB_TX_ID               := WK_PIPELINE_TX_ID;
--
    OUT_TFJ301.ISSUE_DATE_TO_PRINT     := IN_HWB.ISSUE_DATE_TO_PRINT;
    OUT_TFJ301.OBD_DATE_TO_PRINT       := IN_HWB.OBD_DATE_TO_PRINT;

    PFGA3950.GET_CARRIER_TYPE( OUT_TFJ301.MWB_TX_ID,
                               WK_CARRIER_TYPE,
                               WK_CARRIER_NAME,
                               WK_DEPARTURE_DATE,
                               WK_ARRIVAL_DATE,
                               WK_CARRIER_CODE,
                               WK_FLIGHT_VOYAGE,
                               WK_VESSEL_NAME );
-- 2005.04.29 ROUTE�̑Ή�
    PFGA3950.GET_ROUTE( OUT_TFJ301.MWB_TX_ID,
                               WK_ETD,
                               WK_ETA,
                               WK_ATD,
                               WK_ATA,
                               WK_ROUTE1_TYPE,
                               WK_ROUTE1_PORT_LOADING,
                               WK_ROUTE1_PORT_UNLOADING,
                               WK_ROUTE1_CARRIER_CODE,
                               WK_ROUTE1_FLIGHT_VOYAGE,
                               WK_ROUTE1_VESSEL_NAME,
                               WK_ROUTE2_TYPE,
                               WK_ROUTE2_PORT_LOADING,
                               WK_ROUTE2_PORT_UNLOADING,
                               WK_ROUTE2_CARRIER_CODE,
                               WK_ROUTE2_FLIGHT_VOYAGE,
                               WK_ROUTE2_VESSEL_NAME,
                               WK_ROUTE3_TYPE,
                               WK_ROUTE3_PORT_LOADING,
                               WK_ROUTE3_PORT_UNLOADING,
                               WK_ROUTE3_CARRIER_CODE,
                               WK_ROUTE3_FLIGHT_VOYAGE,
                               WK_ROUTE3_VESSEL_NAME,
                               WK_ROUTE4_TYPE,
                               WK_ROUTE4_PORT_LOADING,
                               WK_ROUTE4_PORT_UNLOADING,
                               WK_ROUTE4_CARRIER_CODE,
                               WK_ROUTE4_FLIGHT_VOYAGE,
                               WK_ROUTE4_VESSEL_NAME,
                               WK_ROUTE5_TYPE,
                               WK_ROUTE5_PORT_LOADING ,
                               WK_ROUTE5_PORT_UNLOADING,
                               WK_ROUTE5_CARRIER_CODE,
                               WK_ROUTE5_FLIGHT_VOYAGE,
                               WK_ROUTE5_VESSEL_NAME);

    IF WK_DEPARTURE_DATE IS NULL THEN
        IF WK_ATD IS NOT NULL THEN
            OUT_TFJ301.DEPARTURE_DATE  := TO_DATE(TO_CHAR(WK_ATD,'YYYY/MM/DD'),'YYYY/MM/DD');
        ELSE
            OUT_TFJ301.DEPARTURE_DATE  := TO_DATE(TO_CHAR(WK_ETD,'YYYY/MM/DD'),'YYYY/MM/DD');
        END IF;
    ELSE
        OUT_TFJ301.DEPARTURE_DATE      := WK_DEPARTURE_DATE;
    END IF;
    IF WK_ARRIVAL_DATE IS NULL OR
       WK_ARRIVAL_DATE < TO_DATE('2004/01/01','YYYY/MM/DD') THEN
        IF WK_ATA IS NOT NULL THEN
            OUT_TFJ301.ARRIVAL_DATE    := TO_DATE(TO_CHAR(WK_ATA,'YYYY/MM/DD'),'YYYY/MM/DD');
        ELSE
            OUT_TFJ301.ARRIVAL_DATE    := TO_DATE(TO_CHAR(WK_ETA,'YYYY/MM/DD'),'YYYY/MM/DD');
        END IF;
    ELSE
        OUT_TFJ301.ARRIVAL_DATE        := WK_ARRIVAL_DATE;
    END IF;
--
    OUT_TFJ301.PIPELINE_TX_TYPE        := IN_HWB.PIPELINE_TX_TYPE;
    OUT_TFJ301.PIPELINE_REF_TYPE       := IN_HWB.PIPELINE_REF_TYPE;
    OUT_TFJ301.PIPELINE_TX_STATUS      := IN_HWB.PIPELINE_TX_STATUS;
    OUT_TFJ301.TRANSPORT_MODE          := IN_HWB.TRANSPORT_MODE;
    OUT_TFJ301.SERVICE_TYPE            := IN_HWB.SERVICE_TYPE;
    OUT_TFJ301.MOVEMENT_TYPE           := IN_HWB.MOVEMENT_TYPE;
    OUT_TFJ301.CUSTOMER_SHIPMENT_TYPE  := IN_HWB.CUSTOMER_SHIPMENT_TYPE;

    -- AGENT_TYPE    'KA':KWE Agent,  'NK':Non KWE,  'OTH':Other
    OUT_TFJ301.AGENT_TYPE              := IN_HWB.AGENT_TYPE;

    -- CONSOL_SERVICE_TYPE
    IF IN_HWB.PIPELINE_REF_TYPE in ('H','HM') THEN
        PFGA3950.GET_CONSOL_SERVICE_TYPE( OUT_TFJ301.CONSOL_TX_ID,
                                          WK_CONSOL_SERVICE_TYPE,
                                          WK_CONSOL_CODE );
        OUT_TFJ301.CONSOL_SERVICE_TYPE := WK_CONSOL_SERVICE_TYPE;

        -- JPAEX �ǉ�                                        2005.04.10
        OUT_TFJ301.CONSOL_CODE         := WK_CONSOL_CODE;
    END IF;

    OUT_TFJ301.DISPOSITION             := IN_HWB.DISPOSITION;

    OUT_TFJ301.CARRIER_CODE            := WK_CARRIER_CODE;
    OUT_TFJ301.CARRIER_NAME            := WK_CARRIER_NAME;
    OUT_TFJ301.FLIGHT_VOYAGE           := WK_FLIGHT_VOYAGE;
    OUT_TFJ301.VESSEL_NAME             := WK_VESSEL_NAME;

    -- CARRIER_TYPE  'A':AIR,    'O':VOCC,    'N':NVOCC
    OUT_TFJ301.CARRIER_TYPE            := WK_CARRIER_TYPE;

-- 2005.04.29 ROUTE�̑Ή�
    OUT_TFJ301.ETD                     := WK_ETD;
    OUT_TFJ301.ETA                     := WK_ETA;
    OUT_TFJ301.ATD                     := WK_ATD;
    OUT_TFJ301.ATA                     := WK_ATA;
    OUT_TFJ301.ROUTE1_TYPE             := WK_ROUTE1_TYPE;
    OUT_TFJ301.ROUTE1_PORT_LOADING     := WK_ROUTE1_PORT_LOADING;
    OUT_TFJ301.ROUTE1_PORT_UNLOADING   := WK_ROUTE1_PORT_UNLOADING;
    OUT_TFJ301.ROUTE1_CARRIER_CODE     := WK_ROUTE1_CARRIER_CODE;
    OUT_TFJ301.ROUTE1_FLIGHT_VOYAGE    := WK_ROUTE1_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE1_VESSEL_NAME      := WK_ROUTE1_VESSEL_NAME;
    OUT_TFJ301.ROUTE2_TYPE             := WK_ROUTE2_TYPE;
    OUT_TFJ301.ROUTE2_PORT_LOADING     := WK_ROUTE2_PORT_LOADING;
    OUT_TFJ301.ROUTE2_PORT_UNLOADING   := WK_ROUTE2_PORT_UNLOADING;
    OUT_TFJ301.ROUTE2_CARRIER_CODE     := WK_ROUTE2_CARRIER_CODE;
    OUT_TFJ301.ROUTE2_FLIGHT_VOYAGE    := WK_ROUTE2_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE2_VESSEL_NAME      := WK_ROUTE2_VESSEL_NAME;
    OUT_TFJ301.ROUTE3_TYPE             := WK_ROUTE3_TYPE;
    OUT_TFJ301.ROUTE3_PORT_LOADING     := WK_ROUTE3_PORT_LOADING;
    OUT_TFJ301.ROUTE3_PORT_UNLOADING   := WK_ROUTE3_PORT_UNLOADING;
    OUT_TFJ301.ROUTE3_CARRIER_CODE     := WK_ROUTE3_CARRIER_CODE;
    OUT_TFJ301.ROUTE3_FLIGHT_VOYAGE    := WK_ROUTE3_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE3_VESSEL_NAME      := WK_ROUTE3_VESSEL_NAME;
    OUT_TFJ301.ROUTE4_TYPE             := WK_ROUTE4_TYPE;
    OUT_TFJ301.ROUTE4_PORT_LOADING     := WK_ROUTE4_PORT_LOADING;
    OUT_TFJ301.ROUTE4_PORT_UNLOADING   := WK_ROUTE4_PORT_UNLOADING;
    OUT_TFJ301.ROUTE4_CARRIER_CODE     := WK_ROUTE4_CARRIER_CODE;
    OUT_TFJ301.ROUTE4_FLIGHT_VOYAGE    := WK_ROUTE4_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE4_VESSEL_NAME      := WK_ROUTE4_VESSEL_NAME;
    OUT_TFJ301.ROUTE5_TYPE             := WK_ROUTE5_TYPE;
    OUT_TFJ301.ROUTE5_PORT_LOADING     := WK_ROUTE5_PORT_LOADING;
    OUT_TFJ301.ROUTE5_PORT_UNLOADING   := WK_ROUTE5_PORT_UNLOADING;
    OUT_TFJ301.ROUTE5_CARRIER_CODE     := WK_ROUTE5_CARRIER_CODE;
    OUT_TFJ301.ROUTE5_FLIGHT_VOYAGE    := WK_ROUTE5_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE5_VESSEL_NAME      := WK_ROUTE5_VESSEL_NAME;

    --  Add 2004.08.15 FWD���ЁE���Д��f
    --  Upd 2005.01.24 Direct�̏ꍇ�A'KA' Or IS NULL�F����
    IF OUT_TFJ301.EIM_EX_IND = 'I' THEN
        IF ( OUT_TFJ301.ETRANS_MODE       = 'A'  AND   -- Air
             OUT_TFJ301.PIPELINE_REF_TYPE = 'HD' AND     -- Direct
             OUT_TFJ301.AGENT_TYPE        = 'KA' )       -- KWE Agent
        OR ( OUT_TFJ301.ETRANS_MODE       = 'A'  AND   -- Air
             OUT_TFJ301.PIPELINE_REF_TYPE = 'HD' AND     -- Direct
             OUT_TFJ301.AGENT_TYPE        IS NULL )      -- KWE Agent
        OR ( OUT_TFJ301.ETRANS_MODE       = 'A'  AND   -- Air
             OUT_TFJ301.PIPELINE_REF_TYPE in ('H','HM','HR') ) -- House
        OR ( OUT_TFJ301.ETRANS_MODE       = 'O'  AND   -- Ocean
             OUT_TFJ301.PIPELINE_REF_TYPE = 'HD' AND     -- Direct
             OUT_TFJ301.CARRIER_TYPE      = 'O' )        -- VOCC
        OR ( OUT_TFJ301.ETRANS_MODE       = 'O'  AND   -- Ocean
             OUT_TFJ301.PIPELINE_REF_TYPE = 'H'  )       -- House
        THEN
            OUT_TFJ301.EFWD_JTKBN      := '1';  -- ����("1")
        ELSE
            OUT_TFJ301.EFWD_JTKBN      := '0';  -- ����("0")
        END IF;
    ELSE
        OUT_TFJ301.EFWD_JTKBN          := '1';  -- ����("1")
    END IF;

    --  Add 2004.07.26 �ʊ֎��ЁE���Д��f
    IF OUT_TFJ301.EIM_EX_IND = 'I' THEN
        IF OUT_TFJ301.DISPOSITION = 'CUS' THEN
            OUT_TFJ301.ETKN_JTKBN      := '1';  --  'CUS':KWE Clearance --> ����("1")
        ELSIF OUT_TFJ301.DISPOSITION = 'OF' THEN
            OUT_TFJ301.ETKN_JTKBN      := '2';  --  'OF' :On-Forwarding --> �]��("2")
        ELSIF OUT_TFJ301.DISPOSITION = 'T' THEN
            OUT_TFJ301.ETKN_JTKBN      := '2';  --  'T'  :Transhipment  --> �]��("2")
        ELSIF OUT_TFJ301.DISPOSITION = 'TO' THEN
            OUT_TFJ301.ETKN_JTKBN      := '0';  --  'TO' :Turnover      --> ����("0")
        ELSE
            OUT_TFJ301.ETKN_JTKBN      := '!';
            PFGA3910.TRACE_LOG( 'E', 'DISPOSITION = '
                                     || OUT_TFJ301.DISPOSITION );
        END IF;
    ELSE
        OUT_TFJ301.ETKN_JTKBN          := '9';
    END IF;

--
    OUT_TFJ301.FREE_HOUSE_IND          := TRIM(IN_HWB.FREE_HOUSE_IND);
    OUT_TFJ301.LCL_CNSL_CARRIER_IND    := TRIM(IN_HWB.LCL_CNSL_CARRIER_IND);
--
    OUT_TFJ301.PIPELINE_TX_DATE        := IN_HWB.PIPELINE_TX_DATE;
    OUT_TFJ301.TX_DATE_TZ_CODE         := IN_HWB.TX_DATE_TZ_CODE;
--
    OUT_TFJ301.TRANSPORT_TERMS_CODE    := IN_HWB.TRANSPORT_TERMS_CODE;
    OUT_TFJ301.SALES_TERMS_CODE        := IN_HWB.SALES_TERMS_CODE;
    OUT_TFJ301.FREE_HOUSE_TERMS_CODE   := IN_HWB.FREE_HOUSE_TERMS_CODE;
--
    OUT_TFJ301.IMPORT_SALESMAN_ID      := IN_HWB.IMPORT_SALESMAN_ID;
    OUT_TFJ301.EXPORT_SALESMAN_ID      := IN_HWB.EXPORT_SALESMAN_ID;
--
    -- PORT �ݒ�
    IF OUT_TFJ301.ETRANS_MODE = 'A' THEN      -- AIR
        OUT_TFJ301.PORT_ORIGIN         := IN_HWB.PORT_ORIGIN;
        OUT_TFJ301.PORT_LOADING        := IN_HWB.PORT_LOADING;
        OUT_TFJ301.PORT_UNLOADING      := IN_HWB.PORT_UNLOADING;
        OUT_TFJ301.PORT_DEST           := IN_HWB.PORT_DEST;
    ELSE                                        -- OCEAN
        OUT_TFJ301.PLACE_OF_RECEIPT  := SUBSTR(IN_HWB.PLACE_OF_RECEIPT,1,5);
        OUT_TFJ301.PLACE_OF_DELIVERY := SUBSTR(IN_HWB.PLACE_OF_DELIVERY,1,5);
        OUT_TFJ301.PORT_ORIGIN         := IN_HWB.PORT_ORIGIN;
        IF IN_HWB.PORT_LOADING_LC_CODE IS NOT NULL THEN
            OUT_TFJ301.PORT_LOADING    := IN_HWB.PORT_LOADING_LC_CODE;                -- OCEAN
        ELSE
            OUT_TFJ301.PORT_LOADING    := IN_HWB.PORT_LOADING;
        END IF;
        IF IN_HWB.PORT_UNLOADING_LC_CODE IS NOT NULL THEN
            OUT_TFJ301.PORT_UNLOADING  := IN_HWB.PORT_UNLOADING_LC_CODE;              -- OCEAN
        ELSE
            OUT_TFJ301.PORT_UNLOADING  := IN_HWB.PORT_UNLOADING;
        END IF;
        OUT_TFJ301.PORT_DEST           := IN_HWB.PORT_DEST;
        IF OUT_TFJ301.PLACE_OF_RECEIPT IS NULL THEN
            OUT_TFJ301.PLACE_OF_RECEIPT        := OUT_TFJ301.PORT_ORIGIN;
        END IF;
        IF OUT_TFJ301.PLACE_OF_DELIVERY IS NULL THEN
            OUT_TFJ301.PLACE_OF_DELIVERY       := OUT_TFJ301.PORT_DEST;
        END IF;
        -- PORT ����
        PFGA3950.SEL_PORT( OUT_TFJ301.PLACE_OF_RECEIPT, WK_PORT_NAME );
        OUT_TFJ301.PLACE_OF_RECEIPT_NAME   := WK_PORT_NAME;
        PFGA3950.SEL_PORT( OUT_TFJ301.PLACE_OF_DELIVERY, WK_PORT_NAME );
        OUT_TFJ301.PLACE_OF_DELIVERY_NAME  := WK_PORT_NAME;
    END IF;

    -- PORT ����
    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_ORIGIN, WK_PORT_NAME );
    OUT_TFJ301.PORT_ORIGIN_NAME        := WK_PORT_NAME;

    IF OUT_TFJ301.PORT_LOADING = OUT_TFJ301.PORT_ORIGIN THEN
        OUT_TFJ301.PORT_LOADING_NAME   := OUT_TFJ301.PORT_ORIGIN_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_LOADING, WK_PORT_NAME );
        OUT_TFJ301.PORT_LOADING_NAME   := WK_PORT_NAME;
    END IF;

    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_UNLOADING, WK_PORT_NAME );
    OUT_TFJ301.PORT_UNLOADING_NAME     := WK_PORT_NAME;

    IF OUT_TFJ301.PORT_DEST = OUT_TFJ301.PORT_UNLOADING THEN
        OUT_TFJ301.PORT_DEST_NAME   := OUT_TFJ301.PORT_UNLOADING_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_DEST, WK_PORT_NAME );
        OUT_TFJ301.PORT_DEST_NAME   := WK_PORT_NAME;
    END IF;

    OUT_TFJ301.FINAL_DESTINATION       := IN_HWB.FINAL_DESTINATION;
    OUT_TFJ301.PORT_CC_EXPORT          := IN_HWB.PORT_CC;
    OUT_TFJ301.PORT_CC_IMPORT          := IN_HWB.PORT_CC_IMPORT;
--
    OUT_TFJ301.ORIG_COMPANY_ID         := IN_HWB.ORIG_COMPANY_ID;
    OUT_TFJ301.ORIG_SUBSIDIARY_ID      := IN_HWB.ORIG_SUBSIDIARY_ID;
    OUT_TFJ301.ORIG_TERMINAL_ID        := IN_HWB.ORIG_TERMINAL_ID;
    OUT_TFJ301.ORIG_DEPARTMENT_ID      := IN_HWB.ORIG_DEPARTMENT_ID;
    OUT_TFJ301.ORIG_AREA_CODE          := IN_HWB.ORIG_AREA_CODE;
    OUT_TFJ301.ORIG_REGION_CODE        := IN_HWB.ORIG_REGION_CODE;
    OUT_TFJ301.ORIG_COUNTRY_CODE       := IN_HWB.ORIG_COUNTRY_CODE;
    OUT_TFJ301.ORIG_IATA_TC_CODE       := IN_HWB.ORIG_IATA_TC_CODE;
    IF OUT_TFJ301.ORIG_COUNTRY_CODE IS NULL OR
       OUT_TFJ301.ORIG_IATA_TC_CODE IS NULL THEN
        -- PORT's COUNTRY ����
        PFGA3950.SEL_PORT_COUNTRY( OUT_TFJ301.PORT_ORIGIN,
                          WK_COUNTRY_CODE,
                          WK_IATA_CONFERENCE_CODE );
        IF OUT_TFJ301.ORIG_COUNTRY_CODE IS NULL THEN
            OUT_TFJ301.ORIG_COUNTRY_CODE := WK_COUNTRY_CODE;
        END IF;
        IF OUT_TFJ301.ORIG_IATA_TC_CODE IS NULL THEN
            OUT_TFJ301.ORIG_IATA_TC_CODE := WK_IATA_CONFERENCE_CODE;
        END IF;
    END IF;
    OUT_TFJ301.ORIG_POLAR_REGION_A_CODE
                                       := IN_HWB.ORIG_POLAR_REGION_A_CODE;
    OUT_TFJ301.ORIG_POLAR_REGION_B_CODE
                                       := IN_HWB.ORIG_POLAR_REGION_B_CODE;
--
    OUT_TFJ301.DEST_COMPANY_ID         := IN_HWB.DEST_COMPANY_ID;
    OUT_TFJ301.DEST_SUBSIDIARY_ID      := IN_HWB.DEST_SUBSIDIARY_ID;
    OUT_TFJ301.DEST_TERMINAL_ID        := IN_HWB.DEST_TERMINAL_ID;
    OUT_TFJ301.DEST_DEPARTMENT_ID      := IN_HWB.DEST_DEPARTMENT_ID;
    OUT_TFJ301.DEST_AREA_CODE          := IN_HWB.DEST_AREA_CODE;
    OUT_TFJ301.DEST_REGION_CODE        := IN_HWB.DEST_REGION_CODE;

    OUT_TFJ301.DEST_COUNTRY_CODE       := IN_HWB.DEST_COUNTRY_CODE;
    OUT_TFJ301.DEST_IATA_TC_CODE       := IN_HWB.DEST_IATA_TC_CODE;
    IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL OR
       OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
        -- PORT's COUNTRY ����
        PFGA3950.SEL_PORT_COUNTRY( OUT_TFJ301.PORT_DEST,
                          WK_COUNTRY_CODE,
                          WK_IATA_CONFERENCE_CODE );
        IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL THEN
            OUT_TFJ301.DEST_COUNTRY_CODE := WK_COUNTRY_CODE;
        END IF;
        IF OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
            OUT_TFJ301.DEST_IATA_TC_CODE := WK_IATA_CONFERENCE_CODE;
        END IF;
    END IF;

    OUT_TFJ301.DEST_POLAR_REGION_A_CODE
                                       := IN_HWB.DEST_POLAR_REGION_A_CODE;
    OUT_TFJ301.DEST_POLAR_REGION_B_CODE
                                       := IN_HWB.DEST_POLAR_REGION_B_CODE;
--
    OUT_TFJ301.NATURE_OF_GOODS         := DEL_CRLF( IN_HWB.NATURE_OF_GOODS );
    OUT_TFJ301.MANIFEST_DESCRIPTION    := DEL_CRLF( IN_HWB.MANIFEST_DESCRIPTION );
--
    OUT_TFJ301.NUM_PIECES              := IN_HWB.NUM_PIECES;
    OUT_TFJ301.NUM_PIECES_UOM_CODE     := IN_HWB.PACKAGING_FORM_CODE;
    OUT_TFJ301.CHARGEABLE_WEIGHT       := IN_HWB.CHARGEABLE_WEIGHT;
    OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE
                                       := IN_HWB.WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_ACTUAL_WEIGHT     := IN_HWB.TOTAL_ACTUAL_WEIGHT;
    OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE  := IN_HWB.ACTUAL_WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_VOLUME            := IN_HWB.TOTAL_VOLUME;
    OUT_TFJ301.VOLUME_UOM_CODE         := IN_HWB.VOLUME_UOM_CODE;
    OUT_TFJ301.TOTAL_VOLUME_WEIGHT     := IN_HWB.TOTAL_VOLUME_WEIGHT;
    OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE  := IN_HWB.VOLUME_WEIGHT_UOM_CODE;
--
    WK_CONTAINER_NUM                   := NULL;
    WK_CONTAINER_TYPE                  := NULL;
    WK_CONTAINER_20FT                  := 0;
    WK_CONTAINER_40FT                  := 0;
    WK_CONTAINER_ETC                   := 0;
    -- SERVICE_TYPE��FCL�̎�
    IF IN_HWB.SERVICE_TYPE = 'FCL' THEN
        -- CONTAINER_TYPE���Ƃ̏W�v
        PFGA3950.SUM_NUM_PIECES_HWB( IN_HWB.PIPELINE_TX_ID,
                                     WK_CONTAINER_NUM,           --  2004.10.06
                                     WK_CONTAINER_TYPE,          --  2004.10.06
                                     WK_CONTAINER_20FT,
                                     WK_CONTAINER_40FT,
                                     WK_CONTAINER_ETC );
    END IF;
    OUT_TFJ301.CONTAINER_NUM           := WK_CONTAINER_NUM;
    OUT_TFJ301.CONTAINER_TYPE          := WK_CONTAINER_TYPE;
    OUT_TFJ301.CONTAINER_20FT          := WK_CONTAINER_20FT;
    OUT_TFJ301.CONTAINER_40FT          := WK_CONTAINER_40FT;
    OUT_TFJ301.CONTAINER_ETC           := WK_CONTAINER_ETC;
--
    OUT_TFJ301.FREIGHT_PPC_IND         := TRIM(IN_HWB.FREIGHT_PPC_IND);
    OUT_TFJ301.OTHER_PPC_IND           := TRIM(IN_HWB.OTHER_PPC_IND);
    OUT_TFJ301.DEST_PPC_IND            := TRIM(IN_HWB.DESTINATION_PPC_IND);
--
    OUT_TFJ301.OC_CURRENCY_CODE        := IN_HWB.OC_CURRENCY_CODE;
    OUT_TFJ301.ORIG_CURRENCY_CODE      := IN_HWB.LOCAL_CURRENCY_CODE;
    OUT_TFJ301.DEST_CURRENCY_CODE      := IN_HWB.DEST_CURRENCY_CODE;
    OUT_TFJ301.INVOICE_CURRENCY_CODE   := IN_HWB.INVOICE_CURRENCY_CODE;
--
    OUT_TFJ301.DEST_EXCHANGE_RATE      := IN_HWB.DEST_EXCHANGE_RATE;
    OUT_TFJ301.INVOICE_EXCHANGE_RATE   := IN_HWB.INVOICE_EXCHANGE_RATE;
--
    OUT_TFJ301.PPD_FREIGHT_AMT         := NVL(IN_HWB.PPD_FREIGHT_AMT,0);
    OUT_TFJ301.PPD_OTHER_AMT           := NVL(IN_HWB.PPD_OTHER_AMT,0);
    OUT_TFJ301.PPD_VALUATION_AMT       := NVL(IN_HWB.PPD_VALUATION_AMT,0);
    OUT_TFJ301.PPD_TAX_AMT             := NVL(IN_HWB.PPD_TAX_AMT,0);
    OUT_TFJ301.PPD_DUE_AGENT_AMT       := NVL(IN_HWB.PPD_DUE_AGENT_AMT,0);
    OUT_TFJ301.PPD_DUE_CARRIER_AMT     := NVL(IN_HWB.PPD_DUE_CARRIER_AMT,0);
    OUT_TFJ301.TOT_PPD_AMT             := NVL(IN_HWB.TOT_PPD_AMT,0);
    OUT_TFJ301.COLL_FREIGHT_AMT        := NVL(IN_HWB.COLL_FREIGHT_AMT,0);
    OUT_TFJ301.COLL_OTHER_AMT          := NVL(IN_HWB.COLL_OTHER_AMT,0);
    OUT_TFJ301.COLL_VALUATION_AMT      := NVL(IN_HWB.COLL_VALUATION_AMT,0);
    OUT_TFJ301.COLL_TAX_AMT            := NVL(IN_HWB.COLL_TAX_AMT,0);
    OUT_TFJ301.COLL_DUE_AGENT_AMT      := NVL(IN_HWB.COLL_DUE_AGENT_AMT,0);
    OUT_TFJ301.COLL_DUE_CARRIER_AMT    := NVL(IN_HWB.COLL_DUE_CARRIER_AMT,0);
    OUT_TFJ301.TOT_COLL_AMT            := NVL(IN_HWB.TOT_COLL_AMT,0);
--
    OUT_TFJ301.OC_PPD_FREIGHT_AMT      := NVL(IN_HWB.OC_PPD_FREIGHT_AMT,0);
    OUT_TFJ301.OC_PPD_OTHER_AMT        := NVL(IN_HWB.OC_PPD_OTHER_AMT,0);
    OUT_TFJ301.OC_PPD_VALUATION_AMT    := NVL(IN_HWB.OC_PPD_VALUATION_AMT,0);
    OUT_TFJ301.OC_PPD_TAX_AMT          := NVL(IN_HWB.OC_PPD_TAX_AMT,0);
    OUT_TFJ301.OC_PPD_DUE_AGENT_AMT    := NVL(IN_HWB.OC_PPD_DUE_AGENT_AMT,0);
    OUT_TFJ301.OC_PPD_DUE_CARRIER_AMT  := NVL(IN_HWB.OC_PPD_DUE_CARRIER_AMT,0);
    OUT_TFJ301.OC_TOT_PPD_AMT          := NVL(IN_HWB.OC_TOT_PPD_AMT,0);
    OUT_TFJ301.OC_COLL_FREIGHT_AMT     := NVL(IN_HWB.OC_COLL_FREIGHT_AMT,0);
    OUT_TFJ301.OC_COLL_OTHER_AMT       := NVL(IN_HWB.OC_COLL_OTHER_AMT,0);
    OUT_TFJ301.OC_COLL_VALUATION_AMT   := NVL(IN_HWB.OC_COLL_VALUATION_AMT,0);
    OUT_TFJ301.OC_COLL_TAX_AMT         := NVL(IN_HWB.OC_COLL_TAX_AMT,0);
    OUT_TFJ301.OC_COLL_DUE_AGENT_AMT   := NVL(IN_HWB.OC_COLL_DUE_AGENT_AMT,0);
    OUT_TFJ301.OC_COLL_DUE_CARRIER_AMT := NVL(IN_HWB.OC_COLL_DUE_CARRIER_AMT,0);
    OUT_TFJ301.OC_TOT_COLL_AMT         := NVL(IN_HWB.OC_TOT_COLL_AMT,0);
--
    -- Shipper
    PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                             'S',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.SHIPPER_ID              := WK_PARTNER_ID;
    OUT_TFJ301.SHIPPER_NAME            := IN_HWB.SHIPPER_NAME;

    PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_ID,
                          DMY_PARENT_PARTNER_ID,
                          WK_PARTNER_NAME,
                          WK_LL_PARTNER_NAME,
                          DMY_PARTNER_SHORT_NAME,
                          WK_INDUSTRY_CODE,
                          WK_INDUSTRY_NAME );
    OUT_TFJ301.LL_SHIPPER_NAME         := WK_LL_PARTNER_NAME;
    OUT_TFJ301.SHIPPER_PARENT_ID       := WK_PARENT_PARTNER_ID;
    OUT_TFJ301.SHIPPER_GROUP_ID        := WK_PARTNER_GROUP_CODE;
    -- JPAEX �ǉ�                                        2005.04.10
    OUT_TFJ301.SHIPPER_INDUSTRY_CODE   := WK_INDUSTRY_CODE;
    OUT_TFJ301.SHIPPER_INDUSTRY_NAME   := WK_INDUSTRY_NAME;

    IF OUT_TFJ301.SHIPPER_PARENT_ID IS NULL OR
       OUT_TFJ301.SHIPPER_PARENT_ID = '!'   THEN
        OUT_TFJ301.SHIPPER_PARENT_NAME     := NULL;
        OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := NULL;
    ELSE
        PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_PARENT_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.SHIPPER_PARENT_NAME     := WK_PARTNER_NAME;
        OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := WK_LL_PARTNER_NAME;
    END IF;
    OUT_TFJ301.SHIPPER_ADDRESS_NO      := IN_HWB.SHIPPER_ADDRESS_NO;

    PFGA3950.SEL_ADDRESS( OUT_TFJ301.SHIPPER_ADDRESS_NO, WK_ADDRESS );
    OUT_TFJ301.SHIPPER_ADDRESS1        := WK_ADDRESS.ADDRESS_1;
    OUT_TFJ301.SHIPPER_ADDRESS2        := WK_ADDRESS.ADDRESS_2;
    OUT_TFJ301.SHIPPER_ADDRESS3        := WK_ADDRESS.ADDRESS_3;
    OUT_TFJ301.SHIPPER_ADDRESS4        := WK_ADDRESS.ADDRESS_4;
    OUT_TFJ301.SHIPPER_ADDRESS5        := WK_ADDRESS.ADDRESS_5;
    OUT_TFJ301.LL_SHIPPER_ADDRESS1     := WK_ADDRESS.LL_ADDRESS_1;
    OUT_TFJ301.LL_SHIPPER_ADDRESS2     := WK_ADDRESS.LL_ADDRESS_2;
    OUT_TFJ301.LL_SHIPPER_ADDRESS3     := WK_ADDRESS.LL_ADDRESS_3;
    OUT_TFJ301.LL_SHIPPER_ADDRESS4     := WK_ADDRESS.LL_ADDRESS_4;
    OUT_TFJ301.LL_SHIPPER_ADDRESS5     := WK_ADDRESS.LL_ADDRESS_5;
    OUT_TFJ301.SHIPPER_CITY_NAME       := WK_ADDRESS.CITY_NAME;
    OUT_TFJ301.LL_SHIPPER_CITY_NAME    := WK_ADDRESS.LL_CITY_NAME;
    OUT_TFJ301.SHIPPER_REGION_CODE     := WK_ADDRESS.REGION_CODE;
    OUT_TFJ301.SHIPPER_POSTAL_CODE     := WK_ADDRESS.POSTAL_CODE;
    OUT_TFJ301.SHIPPER_COUNTRY_CODE    := WK_ADDRESS.COUNTRY_CODE;
    OUT_TFJ301.SHIPPER_CONTACT_NO      := IN_HWB.SHIPPER_CONTACT_NO;
    -- JPAEX �ǉ�                                        2005.04.10
    OUT_TFJ301.SHIPPER_REGION_NAME     := WK_ADDRESS.REGION_NAME;

    IF OUT_TFJ301.SHIPPER_CONTACT_NO IS NOT NULL THEN
        PFGA3950.SEL_CONTACT( OUT_TFJ301.SHIPPER_CONTACT_NO, WK_CONTACT );
        OUT_TFJ301.SHIPPER_CONTACT_NAME    := WK_CONTACT.LAST_NAME;
        OUT_TFJ301.LL_SHIPPER_CONTACT_NAME := WK_CONTACT.LL_NAME;
        OUT_TFJ301.SHIPPER_CONTACT_PHONE   := WK_CONTACT.PHONE_NO;
        OUT_TFJ301.SHIPPER_CONTACT_FAX     := WK_CONTACT.FAX_NO;
        OUT_TFJ301.SHIPPER_CONTACT_EMAIL   := WK_CONTACT.EMAIL_ID;
    END IF;
--
    -- Consignee
    PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                             'C',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.CNEE_ID                 := WK_PARTNER_ID;
    OUT_TFJ301.CNEE_NAME               := IN_HWB.CNEE_NAME;

    PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_ID,
                          DMY_PARENT_PARTNER_ID,
                          WK_PARTNER_NAME,
                          WK_LL_PARTNER_NAME,
                          DMY_PARTNER_SHORT_NAME,
                          WK_INDUSTRY_CODE,
                          WK_INDUSTRY_NAME );
    OUT_TFJ301.LL_CNEE_NAME            := WK_LL_PARTNER_NAME;
    OUT_TFJ301.CNEE_PARENT_ID          := WK_PARENT_PARTNER_ID;
    OUT_TFJ301.CNEE_GROUP_ID           := WK_PARTNER_GROUP_CODE;

    IF OUT_TFJ301.CNEE_PARENT_ID IS NULL OR
       OUT_TFJ301.CNEE_PARENT_ID = '!'   THEN
        OUT_TFJ301.CNEE_PARENT_NAME     := NULL;
        OUT_TFJ301.LL_CNEE_PARENT_NAME  := NULL;
    ELSE
        PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_PARENT_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.CNEE_PARENT_NAME     := WK_PARTNER_NAME;
        OUT_TFJ301.LL_CNEE_PARENT_NAME  := WK_LL_PARTNER_NAME;
    END IF;
    OUT_TFJ301.CNEE_ADDRESS_NO         := IN_HWB.CNEE_ADDRESS_NO;

    PFGA3950.SEL_ADDRESS( OUT_TFJ301.CNEE_ADDRESS_NO, WK_ADDRESS );
    OUT_TFJ301.CNEE_ADDRESS1           := WK_ADDRESS.ADDRESS_1;
    OUT_TFJ301.CNEE_ADDRESS2           := WK_ADDRESS.ADDRESS_2;
    OUT_TFJ301.CNEE_ADDRESS3           := WK_ADDRESS.ADDRESS_3;
    OUT_TFJ301.CNEE_ADDRESS4           := WK_ADDRESS.ADDRESS_4;
    OUT_TFJ301.CNEE_ADDRESS5           := WK_ADDRESS.ADDRESS_5;
    OUT_TFJ301.LL_CNEE_ADDRESS1        := WK_ADDRESS.LL_ADDRESS_1;
    OUT_TFJ301.LL_CNEE_ADDRESS2        := WK_ADDRESS.LL_ADDRESS_2;
    OUT_TFJ301.LL_CNEE_ADDRESS3        := WK_ADDRESS.LL_ADDRESS_3;
    OUT_TFJ301.LL_CNEE_ADDRESS4        := WK_ADDRESS.LL_ADDRESS_4;
    OUT_TFJ301.LL_CNEE_ADDRESS5        := WK_ADDRESS.LL_ADDRESS_5;
    OUT_TFJ301.CNEE_CITY_NAME          := WK_ADDRESS.CITY_NAME;
    OUT_TFJ301.LL_CNEE_CITY_NAME       := WK_ADDRESS.LL_CITY_NAME;
    OUT_TFJ301.CNEE_REGION_CODE        := WK_ADDRESS.REGION_CODE;
    OUT_TFJ301.CNEE_POSTAL_CODE        := WK_ADDRESS.POSTAL_CODE;
    OUT_TFJ301.CNEE_COUNTRY_CODE       := WK_ADDRESS.COUNTRY_CODE;
    OUT_TFJ301.CNEE_CONTACT_NO         := IN_HWB.CNEE_CONTACT_NO;

    IF OUT_TFJ301.CNEE_CONTACT_NO IS NOT NULL THEN
        PFGA3950.SEL_CONTACT( OUT_TFJ301.CNEE_CONTACT_NO, WK_CONTACT );
        OUT_TFJ301.CNEE_CONTACT_NAME       := WK_CONTACT.LAST_NAME;
        OUT_TFJ301.LL_CNEE_CONTACT_NAME    := WK_CONTACT.LL_NAME;
        OUT_TFJ301.CNEE_CONTACT_PHONE      := WK_CONTACT.PHONE_NO;
        OUT_TFJ301.CNEE_CONTACT_FAX        := WK_CONTACT.FAX_NO;
        OUT_TFJ301.CNEE_CONTACT_EMAIL      := WK_CONTACT.EMAIL_ID;
    END IF;
--
    -- Notify
    IF IN_HWB.NOTIFY_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'NO',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.NOTIFY_ID           := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.NOTIFY_ID           := '!';
    END IF;
    OUT_TFJ301.NOTIFY_NAME             := IN_HWB.NOTIFY_NAME;
    OUT_TFJ301.NOTIFY_ADDRESS_NO       := IN_HWB.NOTIFY_ADDRESS_NO;
    OUT_TFJ301.NOTIFY_CONTACT_NO       := IN_HWB.NOTIFY_CONTACT_NO;
--
    -- Bill To
    IF IN_HWB.BILLTO_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'BT',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.BILLTO_ID           := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.BILLTO_ID           := '!';
    END IF;
    OUT_TFJ301.BILLTO_NAME             := IN_HWB.BILLTO_NAME;
    OUT_TFJ301.BILLTO_ADDRESS_NO       := IN_HWB.BILLTO_ADDRESS_NO;
    OUT_TFJ301.BILLTO_CONTACT_NO       := IN_HWB.BILLTO_CONTACT_NO;
--
    -- Contorolling Party
    IF IN_HWB.CONTROLLING_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'N',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.CONTROLLING_ID      := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.CONTROLLING_ID      := '!';
    END IF;
    OUT_TFJ301.CONTROLLING_NAME        := IN_HWB.CONTROLLING_NAME;
    OUT_TFJ301.CONTROLLING_ADDRESS_NO  := IN_HWB.CONTROLLING_ADDRESS_NO;
    OUT_TFJ301.CONTROLLING_CONTACT_NO  := IN_HWB.CONTROLLING_CONTACT_NO;
--
    -- Other Bill To
    IF IN_HWB.BILLTO2_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'BT2',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.BILLTO2_ID          := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.BILLTO2_ID          := '!';
    END IF;
    OUT_TFJ301.BILLTO2_NAME            := IN_HWB.BILLTO2_NAME;
    OUT_TFJ301.BILLTO2_ADDRESS_NO      := IN_HWB.BILLTO2_ADDRESS_NO;
    OUT_TFJ301.BILLTO2_CONTACT_NO      := IN_HWB.BILLTO2_CONTACT_NO;
--
    -- Party To Contact
    IF IN_HWB.PTYTOCNT_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'PC',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.PTYTOCNT_ID         := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.PTYTOCNT_ID         := '!';
    END IF;
    OUT_TFJ301.PTYTOCNT_NAME           := IN_HWB.PTYTOCNT_NAME;
    OUT_TFJ301.PTYTOCNT_ADDRESS_NO     := IN_HWB.PTYTOCNT_ADDRESS_NO;
    OUT_TFJ301.PTYTOCNT_CONTACT_NO     := IN_HWB.PTYTOCNT_CONTACT_NO;
--
    -- Settlement Agent
    IF IN_HWB.SETTLEMENT_AGENT_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'A',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.SETTLEMENT_AGENT_ID := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.SETTLEMENT_AGENT_ID := '!';
    END IF;
    OUT_TFJ301.SETTLEMENT_AGENT_NAME   := IN_HWB.SETTLEMENT_AGENT_NAME;
    OUT_TFJ301.SETTLEMENT_AGENT_ADDRESS_NO
                        := IN_HWB.SETTLEMENT_AGENT_ADDRESS_NO;
    OUT_TFJ301.SETTLEMENT_AGENT_CONTACT_NO
                        := IN_HWB.SETTLEMENT_AGENT_CONTACT_NO;
--  CY/CYS
    OUT_TFJ301.RECEIPT_LOCATION_CODE   := IN_HWB.RECEIPT_LOCATION_CODE;
    -- CFS
    IF IN_HWB.CFS_RECEIPT_LOCATION_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'CFS',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.CFS_RECEIPT_ID      := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.CFS_RECEIPT_ID      := '!';
    END IF;
    OUT_TFJ301.CFS_RECEIPT_LOCATION_NAME
                        := IN_HWB.CFS_RECEIPT_LOCATION_NAME;
    OUT_TFJ301.CFS_RECEIPT_ADDRESS_NO  := IN_HWB.CFS_RECEIPT_ADDRESS_NO;
    OUT_TFJ301.CFS_RECEIPT_CONTACT_NO  := IN_HWB.CFS_RECEIPT_CONTACT_NO;
    -- CY
    IF IN_HWB.CY_RECEIPT_LOCATION_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'CY',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.CY_RECEIPT_ID       := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.CY_RECEIPT_ID       := '!';
    END IF;
    OUT_TFJ301.CY_RECEIPT_LOCATION_NAME
                        := IN_HWB.CY_RECEIPT_LOCATION_NAME;
    OUT_TFJ301.CY_RECEIPT_ADDRESS_NO   := IN_HWB.CY_RECEIPT_ADDRESS_NO;
    OUT_TFJ301.CY_RECEIPT_CONTACT_NO   := IN_HWB.CY_RECEIPT_CONTACT_NO;
--
    -- Location of Freight
    IF IN_HWB.LOCFREIGHT_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'LOF',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.LOCFREIGHT_ID       := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.LOCFREIGHT_ID       := '!';
    END IF;
    OUT_TFJ301.LOCFREIGHT_NAME         := IN_HWB.LOCFREIGHT_NAME;
    OUT_TFJ301.LOCFREIGHT_ADDRESS_NO   := IN_HWB.LOCFREIGHT_ADDRESS_NO;
    OUT_TFJ301.LOCFREIGHT_CONTACT_NO   := IN_HWB.LOCFREIGHT_CONTACT_NO;
--
    -- Destantion Broker
    IF IN_HWB.DEST_BROKER_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'B',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.DEST_BROKER_ID      := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.DEST_BROKER_ID      := '!';
    END IF;
    OUT_TFJ301.DEST_BROKER_NAME        := IN_HWB.DEST_BROKER_NAME;
    OUT_TFJ301.DEST_BROKER_ADDRESS_NO  := IN_HWB.DEST_BROKER_ADDRESS_NO;
    OUT_TFJ301.DEST_BROKER_CONTACT_NO  := IN_HWB.DEST_BROKER_CONTACT_NO;
--
    -- Import Bill To
    IF IN_HWB.IMPORT_BILLTO_NAME_CC IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_HWB.PIPELINE_TX_ID,
                                 'BTI',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.IMPORT_BILLTO_ID    := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.IMPORT_BILLTO_ID    := '!';
    END IF;
    OUT_TFJ301.IMPORT_BILLTO_NAME      := IN_HWB.IMPORT_BILLTO_NAME_CC;
    OUT_TFJ301.IMPORT_BILLTO_ADDRESS_NO
                        := IN_HWB.IMPORT_BILLTO_ADDRESS_NO_CC;
    OUT_TFJ301.IMPORT_BILLTO_CONTACT_NO
                        := IN_HWB.IMPORT_BILLTO_CONTACT_NO_CC;

    OUT_TFJ301.CUSTOMS_DECLARATION     := IN_HWB.CUSTOMS_DECLARATION;  -- 2005.05.15
    IF IN_HWB.COMMCODE_RECORD_ID IS NOT NULL THEN
        -- COMMODITY_CODE ���� 2005.05.15
        PFGA3950.SEL_COMMODITY_CODE( IN_HWB.COMMCODE_RECORD_ID,
                                     WK_COMMODITY_CODE,
                                     WK_COMMODITY_DESCRIPTION,
                                     WK_COMMODITY_TYPE );
        OUT_TFJ301.COMMODITY_CODE        := WK_COMMODITY_CODE;
        OUT_TFJ301.COMMODITY_DESCRIPTION := WK_COMMODITY_DESCRIPTION;
        OUT_TFJ301.COMMODITY_TYPE        := WK_COMMODITY_TYPE;
    END IF;

    -- Freight Rate                             2004.10.02
    OUT_TFJ301.MPR_PORT_ORIGIN          := IN_HWB.MPR_PORT_ORIGIN1;
    OUT_TFJ301.MPR_PORT_DEST            := IN_HWB.MPR_PORT_DEST1;
    OUT_TFJ301.MPR_RATE                 := IN_HWB.MPR_RATE1;
    OUT_TFJ301.MPR_CURRENCY_CODE        := IN_HWB.MPR_CURRENCY_CODE1;
    OUT_TFJ301.MPR_AMT                  := IN_HWB.MPR_AMT1;
    OUT_TFJ301.MPR_AMT_PREPAID          := IN_HWB.MPR_AMT1_PREPAID;
    OUT_TFJ301.MPR_AMT_COLLECT          := IN_HWB.MPR_AMT1_COLLECT;
    OUT_TFJ301.MPR_EXCHANGE_RATE        := IN_HWB.MPR_EXCHANGE_RATE1;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME    := IN_HWB.MPR_RATE_PROFILE_NAME1;
    -- Freight Rate                             2005.05.15
    OUT_TFJ301.MPR_PORT_ORIGIN2         := IN_HWB.MPR_PORT_ORIGIN2;
    OUT_TFJ301.MPR_PORT_DEST2           := IN_HWB.MPR_PORT_DEST2;
    OUT_TFJ301.MPR_RATE2                := IN_HWB.MPR_RATE2;
    OUT_TFJ301.MPR_CURRENCY_CODE2       := IN_HWB.MPR_CURRENCY_CODE2;
    OUT_TFJ301.MPR_AMT2                 := IN_HWB.MPR_AMT2;
    OUT_TFJ301.MPR_AMT2_PREPAID         := IN_HWB.MPR_AMT2_PREPAID;
    OUT_TFJ301.MPR_AMT2_COLLECT         := IN_HWB.MPR_AMT2_COLLECT;
    OUT_TFJ301.MPR_EXCHANGE_RATE2       := IN_HWB.MPR_EXCHANGE_RATE2;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME2   := IN_HWB.MPR_RATE_PROFILE_NAME2;
    OUT_TFJ301.MPR_PORT_ORIGIN3         := IN_HWB.MPR_PORT_ORIGIN3;
    OUT_TFJ301.MPR_PORT_DEST3           := IN_HWB.MPR_PORT_DEST3;
    OUT_TFJ301.MPR_RATE3                := IN_HWB.MPR_RATE3;
    OUT_TFJ301.MPR_CURRENCY_CODE3       := IN_HWB.MPR_CURRENCY_CODE3;
    OUT_TFJ301.MPR_AMT3                 := IN_HWB.MPR_AMT3;
    OUT_TFJ301.MPR_AMT3_PREPAID         := IN_HWB.MPR_AMT3_PREPAID;
    OUT_TFJ301.MPR_AMT3_COLLECT         := IN_HWB.MPR_AMT3_COLLECT;
    OUT_TFJ301.MPR_EXCHANGE_RATE3       := IN_HWB.MPR_EXCHANGE_RATE3;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME3   := IN_HWB.MPR_RATE_PROFILE_NAME3;

    IF OUT_TFJ301.ETRANS_MODE  = 'A'  THEN   -- Air
        -- SHIPMENT_DETAIL ����
        PFGA3950.SEL_SHIPMENT_DETAIL( IN_HWB.PIPELINE_TX_ID,
                                      WK_RATE_CLASS_CODE,
                                      WK_RATE_AMT,
                                      WK_TOTAL_RATE_AMT,
                                      WK_DESCRIPTION,
                                      WK_CC_RECORD_ID );
        -- Global Detail���MPR_RATE���㏑��
        IF WK_RATE_AMT IS NOT NULL  AND
           WK_RATE_AMT <> 0         THEN
            OUT_TFJ301.MPR_RATE         := WK_RATE_AMT;
        END IF;
        OUT_TFJ301.RATE_CLASS_CODE      := WK_RATE_CLASS_CODE;
        OUT_TFJ301.DETAIL_MPR_RATE      := WK_RATE_AMT;
        OUT_TFJ301.DETAIL_MPR_AMT       := WK_TOTAL_RATE_AMT;
        OUT_TFJ301.DETAIL_DESCRIPTION   := WK_DESCRIPTION;
        IF WK_CC_RECORD_ID IS NOT NULL THEN
            -- COMMODITY_CODE ���� 2005.05.15
            PFGA3950.SEL_COMMODITY_CODE( WK_CC_RECORD_ID,
                                         WK_COMMODITY_CODE,
                                         WK_COMMODITY_DESCRIPTION,
                                         WK_COMMODITY_TYPE );
            OUT_TFJ301.DETAIL_COMMODITY_CODE        := WK_COMMODITY_CODE;
            OUT_TFJ301.DETAIL_COMMODITY_DESCRIPTION := WK_COMMODITY_DESCRIPTION;
            OUT_TFJ301.DETAIL_COMMODITY_TYPE        := WK_COMMODITY_TYPE;
        END IF;
    END IF;

    -- UAS IF�f�[�^����TAX_AMT(LOCAL_INVOICE_AMT)�擾    2004.10.17
    GET_LOCAL_INVOICE_AMT( IN_TFJ201.PIPELINE_TX_ID,
                           OUT_TFJ301.TAX_AMT );

    -- REFERENCE_NUMBERS�擾                             2004.12.12
    PFGA3950.SEL_REFERENCE_NUMBERS( IN_HWB.PIPELINE_TX_ID,
                                    'PO',
                                    OUT_TFJ301.PO_NO );
    PFGA3950.SEL_REFERENCE_NUMBERS( IN_HWB.PIPELINE_TX_ID,
                                    'CI',
                                    OUT_TFJ301.COMMERCIAL_INV_NO );

    -- 2005.04.10
    IF IN_TFJ201.IMPORT_EXPORT_IND = 'E' THEN
        PFGA3950.SEL_MULTISEGMENT_STATUS( IN_HWB.PIPELINE_TX_ID,
                                          IN_HWB.ORIG_TERMINAL_ID,
                                          OUT_TFJ301.EXPORT_TX_STATUS );
        OUT_TFJ301.IMPORT_TX_STATUS := NULL;
    ELSIF IN_TFJ201.IMPORT_EXPORT_IND = 'I' THEN
        PFGA3950.SEL_MULTISEGMENT_STATUS( IN_HWB.PIPELINE_TX_ID,
                                          IN_HWB.DEST_TERMINAL_ID,
                                          OUT_TFJ301.IMPORT_TX_STATUS );
        OUT_TFJ301.EXPORT_TX_STATUS := NULL;
    ELSE
        OUT_TFJ301.EXPORT_TX_STATUS := NULL;
        OUT_TFJ301.IMPORT_TX_STATUS := NULL;
    END IF;

    -- JPAEX �ǉ�                                        2005.04.10
    PFGA3950.SEL_PIPELINE( OUT_TFJ301.MWB_TX_ID,
                           'CS',
                           WK_PIPELINE_REF_ID,
                           WK_DATE,
                           WK_PIPELINE_TX_STATUS,
                           WK_PORT_ORIGIN,
                           WK_PORT_LOADING,
                           WK_PORT_UNLOADING,
                           WK_PORT_DEST );
    OUT_TFJ301.MWB_PORT_ORIGIN     := WK_PORT_ORIGIN;
    OUT_TFJ301.MWB_PORT_LOADING    := WK_PORT_LOADING;
    OUT_TFJ301.MWB_PORT_UNLOADING  := WK_PORT_UNLOADING;
    OUT_TFJ301.MWB_PORT_DEST       := WK_PORT_DEST;

    -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
    WK_WT_UOM_CODE := 'KG';
    WK_M3_UOM_CODE := 'CBM';
    WK_RT_UOM_CODE := 'CBM';
    WK_WT_RND := 1;
    WK_M3_RND := 3;
    WK_RT_RND := 3;

    IF OUT_TFJ301.ETRANS_MODE  = 'A'  THEN   -- Air
        OUT_TFJ301.ACTUAL_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_ACTUAL_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.CHARGEABLE_WEIGHT_KG := ROUND(OUT_TFJ301.CHARGEABLE_WEIGHT   * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.VOLUME_CBM           := ROUND(OUT_TFJ301.TOTAL_VOLUME        * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_UOM_CODE,WK_M3_UOM_CODE)
                                                 ,WK_M3_RND);
        OUT_TFJ301.VOLUME_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_VOLUME_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
    ELSE
        OUT_TFJ301.ACTUAL_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_ACTUAL_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.CHARGEABLE_WEIGHT_KG := ROUND(OUT_TFJ301.CHARGEABLE_WEIGHT   * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,WK_RT_UOM_CODE)
                                                 ,WK_RT_RND);
        OUT_TFJ301.VOLUME_CBM           := ROUND(OUT_TFJ301.TOTAL_VOLUME        * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_UOM_CODE,WK_M3_UOM_CODE)
                                                 ,WK_M3_RND);
        OUT_TFJ301.VOLUME_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_VOLUME_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE,WK_RT_UOM_CODE)
                                                 ,WK_RT_RND);
    END IF;

    -- ���і��ׁA�R�[�h�E���̕ҏW
    SET_TFJ301_CODENAME( OUT_TFJ301, IN_TFJ201 );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ���і��ׁA�R�[�h�E���̕ҏW
--================================================
PROCEDURE SET_TFJ301_CODENAME(
    OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
    IN_TFJ201             IN         TFJ201%ROWTYPE )      -- UASIF )
IS
    WK_PARTNER_ROLE         PARTNER_RELATIONSHIPS.PARTNER_ROLE%TYPE;
    WK_EMPLOYEE_NO          PARTNER_RELATIONSHIPS.EMPLOYEE_NO%TYPE;

    WK_EMPLOYEE_NAME        EMPLOYEE.EMPLOYEE_NAME%TYPE;
    WK_LL_EMPLOYEE_NAME     EMPLOYEE.LL_EMPLOYEE_NAME%TYPE;

    WK_OFFICE_NAME          OFFICES.OFFICE_NAME%TYPE;
    WK_LL_OFFICE_NAME       OFFICES.LL_OFFICE_NAME%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SET_TFJ301_CODENAME' );

    OUT_TFJ301.ETERMINAL_ID        := NVL(IN_TFJ201.SALES_RESPONSIBLE_OFFICE_ID,'!');
    OUT_TFJ301.EDEPARTMENT_ID      := NVL(IN_TFJ201.GL_GROUP,'!');

    IF OUT_TFJ301.EIM_EX_IND  = 'E' THEN
        WK_PARTNER_ROLE                := 'S';
        OUT_TFJ301.EHBI_TNTCD          := OUT_TFJ301.EXPORT_SALESMAN_ID;
        IF OUT_TFJ301.SHIPPER_PARENT_ID IS NULL OR
           OUT_TFJ301.SHIPPER_PARENT_ID = '!'   THEN
            OUT_TFJ301.EOYA_ECNORCD    := OUT_TFJ301.SHIPPER_ID;
            OUT_TFJ301.EOYA_ECNORNM    := OUT_TFJ301.SHIPPER_NAME;
            OUT_TFJ301.JOYA_ECNORNM    := OUT_TFJ301.LL_SHIPPER_NAME;
        ELSE
            OUT_TFJ301.EOYA_ECNORCD    := OUT_TFJ301.SHIPPER_PARENT_ID;
            OUT_TFJ301.EOYA_ECNORNM    := OUT_TFJ301.SHIPPER_PARENT_NAME;
            OUT_TFJ301.JOYA_ECNORNM    := OUT_TFJ301.LL_SHIPPER_PARENT_NAME;
        END IF;
        OUT_TFJ301.ECNORCD             := OUT_TFJ301.SHIPPER_ID;
        OUT_TFJ301.ECNORNM             := OUT_TFJ301.SHIPPER_NAME;
        OUT_TFJ301.JCNORNM             := OUT_TFJ301.LL_SHIPPER_NAME;
    ELSE
        WK_PARTNER_ROLE                := 'C';
        OUT_TFJ301.EHBI_TNTCD          := OUT_TFJ301.IMPORT_SALESMAN_ID;
        IF OUT_TFJ301.CNEE_PARENT_ID IS NULL OR
           OUT_TFJ301.CNEE_PARENT_ID = '!'   THEN
            OUT_TFJ301.EOYA_ECNORCD    := OUT_TFJ301.CNEE_ID;
            OUT_TFJ301.EOYA_ECNORNM    := OUT_TFJ301.CNEE_NAME;
            OUT_TFJ301.JOYA_ECNORNM    := OUT_TFJ301.LL_CNEE_NAME;
        ELSE
            OUT_TFJ301.EOYA_ECNORCD    := OUT_TFJ301.CNEE_PARENT_ID;
            OUT_TFJ301.EOYA_ECNORNM    := OUT_TFJ301.CNEE_PARENT_NAME;
            OUT_TFJ301.JOYA_ECNORNM    := OUT_TFJ301.LL_CNEE_PARENT_NAME;
        END IF;
        OUT_TFJ301.ECNORCD             := OUT_TFJ301.CNEE_ID;
        OUT_TFJ301.ECNORNM             := OUT_TFJ301.CNEE_NAME;
        OUT_TFJ301.JCNORNM             := OUT_TFJ301.LL_CNEE_NAME;
    END IF;

    -- OFFICES ����
    PFGA3950.SEL_OFFICES( OUT_TFJ301.ECOMPANY_ID,
                          OUT_TFJ301.ETERMINAL_ID,
                          OUT_TFJ301.EDEPARTMENT_ID,
                          WK_OFFICE_NAME,
                          WK_LL_OFFICE_NAME );
    OUT_TFJ301.ETERMNM                 := WK_OFFICE_NAME;
    OUT_TFJ301.JTERMNM                 := WK_LL_OFFICE_NAME;
    OUT_TFJ301.EDEPARTNM               := NULL;
    OUT_TFJ301.JDEPARTNM               := NULL;

    IF OUT_TFJ301.EHBI_TNTCD IS NULL THEN
        -- Partner Relationship's Employee �擾
        PFGA3950.SEL_PR_EMPLOYEE( OUT_TFJ301.ECOMPANY_ID,
                                  OUT_TFJ301.ECNORCD,
                                  WK_PARTNER_ROLE,
                                  OUT_TFJ301.ETRANS_MODE,
                                  OUT_TFJ301.EIM_EX_IND,
                                  WK_EMPLOYEE_NO );
        OUT_TFJ301.EHBI_TNTCD          := WK_EMPLOYEE_NO;
    END IF;

    IF OUT_TFJ301.EHBI_TNTCD IS NOT NULL THEN
        -- EMPLOYEE �擾
        PFGA3950.SEL_EMPLOYEE( OUT_TFJ301.EHBI_TNTCD,
                               WK_EMPLOYEE_NAME,
                               WK_LL_EMPLOYEE_NAME );
        OUT_TFJ301.ETNTNM              := WK_EMPLOYEE_NAME;
        OUT_TFJ301.JTNTNM              := WK_LL_EMPLOYEE_NAME;
    ELSE
        OUT_TFJ301.EHBI_TNTCD          := '!';
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- INVOICE ���і��ׁA�ҏW
--================================================
PROCEDURE SET_TFJ301_INV(
    OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
    IN_INV                IN         CUR_INV%ROWTYPE,      -- INVOICE
    IN_TFJ201             IN         TFJ201%ROWTYPE )      -- UASIF )
IS
    WK_PIPELINE_REF_ID     PIPELINE.PIPELINE_REF_ID%TYPE;
    WK_DATE                DATE;
    WK_PIPELINE_TX_ID      PIPELINE.PIPELINE_TX_ID%TYPE;
    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    DMY_PARENT_PARTNER_ID   PARTNER.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_NAME         PARTNER.PARTNER_NAME%TYPE;
    WK_LL_PARTNER_NAME      PARTNER.LL_PARTNER_NAME%TYPE;
    DMY_PARTNER_SHORT_NAME  PARTNER.PARTNER_SHORT_NAME%TYPE;
    WK_INDUSTRY_CODE        PARTNER.CUSTOMER_INDUSTRY_CODE%TYPE; -- add 2005.04.10
    WK_INDUSTRY_NAME        CODE_DETAIL.CD_DESCRIPTION%TYPE;     -- add 2005.04.10

    WK_ADDRESS              ADDRESS%ROWTYPE;
    WK_CONTACT              CONTACT%ROWTYPE;

    WK_PORT_NAME            PORT.PORT_NAME%TYPE;

    WK_COUNTRY_CODE         COUNTRY.COUNTRY_CODE%TYPE;
    WK_IATA_CONFERENCE_CODE COUNTRY.IATA_CONFERENCE_CODE%TYPE;

    -- 2005.12.16 �R�[�h�E���̕ҏW
    WK_PARTNER_ROLE         PARTNER_RELATIONSHIPS.PARTNER_ROLE%TYPE;
    WK_EMPLOYEE_NO          PARTNER_RELATIONSHIPS.EMPLOYEE_NO%TYPE;
    WK_EMPLOYEE_NAME        EMPLOYEE.EMPLOYEE_NAME%TYPE;
    WK_LL_EMPLOYEE_NAME     EMPLOYEE.LL_EMPLOYEE_NAME%TYPE;
    WK_OFFICE_NAME          OFFICES.OFFICE_NAME%TYPE;
    WK_LL_OFFICE_NAME       OFFICES.LL_OFFICE_NAME%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SET_TFJ301_INV' );

    OUT_TFJ301                         := NULL;
        -- ����
    OUT_TFJ301.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.DHNEDTM                 := SYSDATE;
    OUT_TFJ301.EUPD_OFCCD              := '!';
    OUT_TFJ301.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    OUT_TFJ301.EDATKBN                 := '8';
    OUT_TFJ301.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    OUT_TFJ301.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    OUT_TFJ301.NGENNO                  := 1;
    -- �R���g���[��
    OUT_TFJ301.ESISNKBN                := '1';
    OUT_TFJ301.NAKKBN                  := 1;
    OUT_TFJ301.EDELKBN                 := '0';
    OUT_TFJ301.ESKY_KBN                := '1';
    OUT_TFJ301.EOPE_KBN                := '0';      -- �V�K

    --  Add 2004.07.26 FWD���ЁE���Д��f
    OUT_TFJ301.EFWD_JTKBN              := '0';  --  ����("0")
    --  Add 2004.07.26 �ʊ֎��ЁE����
    OUT_TFJ301.ETKN_JTKBN              := '9';

    OUT_TFJ301.ECOMPANY_ID             := IN_TFJ201.COMPANY_ID;
    OUT_TFJ301.EIM_EX_IND              := IN_TFJ201.IMPORT_EXPORT_IND;
    OUT_TFJ301.ETRANS_MODE             := IN_TFJ201.TRANSPORT_MODE;
    -- ���t
    OUT_TFJ301.DKJODTM                 := IN_TFJ201.ACCOUNTING_DATE;
    OUT_TFJ301.ORIGINAL_KJODTM         := IN_TFJ201.ACCOUNTING_DATE;
    OUT_TFJ301.INVOICE_DATE            := IN_TFJ201.INVOICE_DATE;
    OUT_TFJ301.ORIGINAL_INVOICE_DATE   := IN_TFJ201.ORIGINAL_INVOICE_DATE;
    OUT_TFJ301.MWB_ISSUE_DATE          := NULL;
    OUT_TFJ301.ISSUE_DATE              := IN_INV.ISSUE_DATE;
    OUT_TFJ301.CONSOL_DATE             := NULL;

    -- �ԍ�
    OUT_TFJ301.MWB_NO                  := NULL;
    OUT_TFJ301.HWB_NO                  := IN_INV.MISC_WAYBILL_NO;                         -- 2005.12.16 MISC
    OUT_TFJ301.CONSOL_NO               := NULL;
    OUT_TFJ301.INVOICE_NO              := IN_INV.PIPELINE_REF_ID;
    OUT_TFJ301.MWB_TX_ID               := NULL;
    OUT_TFJ301.HWB_TX_ID               := NULL;
    OUT_TFJ301.CONSOL_TX_ID            := NULL;
    OUT_TFJ301.INVOICE_TX_ID           := IN_TFJ201.INVOICE_TX_ID;

    -- 2005.06.19 MY JOB_NO�Ή�
    IF OUT_TFJ301.EIM_EX_IND = 'E' THEN
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'IN',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNE',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    ELSE
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'IN',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNI',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    END IF;
    OUT_TFJ301.JOB_NO                  := WK_PIPELINE_REF_ID;
    OUT_TFJ301.JOB_TX_ID               := WK_PIPELINE_TX_ID;
--
    OUT_TFJ301.PIPELINE_TX_TYPE        := IN_INV.PIPELINE_TX_TYPE;
    OUT_TFJ301.PIPELINE_REF_TYPE       := IN_INV.PIPELINE_REF_TYPE;
    OUT_TFJ301.PIPELINE_TX_STATUS      := IN_INV.PIPELINE_TX_STATUS;
    OUT_TFJ301.TRANSPORT_MODE          := IN_INV.TRANSPORT_MODE;
--    OUT_TFJ301.SERVICE_TYPE            := IN_INV.SERVICE_TYPE;
--    OUT_TFJ301.MOVEMENT_TYPE           := IN_INV.MOVEMENT_TYPE;
--    OUT_TFJ301.CUSTOMER_SHIPMENT_TYPE  := IN_INV.CUSTOMER_SHIPMENT_TYPE;
--    OUT_TFJ301.AGENT_TYPE              := IN_INV.AGENT_TYPE;
--
--    OUT_TFJ301.FREE_HOUSE_IND          := IN_INV.FREE_HOUSE_IND;
--
    OUT_TFJ301.PIPELINE_TX_DATE        := IN_INV.PIPELINE_TX_DATE;
    OUT_TFJ301.TX_DATE_TZ_CODE         := IN_INV.TX_DATE_TZ_CODE;
--
--    OUT_TFJ301.TRANSPORT_TERMS_CODE    := IN_INV.TRANSPORT_TERMS_CODE;
--    OUT_TFJ301.SALES_TERMS_CODE        := IN_INV.SALES_TERMS_CODE;
--    OUT_TFJ301.FREE_HOUSE_TERMS_CODE   := IN_INV.FREE_HOUSE_TERMS_CODE;
    OUT_TFJ301.CARRIER_CODE            := IN_INV.MISC_CARRIER_CODE;                       -- 2005.12.16 MISC
--
--    OUT_TFJ301.PLACE_OF_RECEIPT        := IN_INV.PLACE_OF_RECEIPT;
--    OUT_TFJ301.PLACE_OF_DELIVERY       := IN_INV.PLACE_OF_DELIVERY;

    -- PORT ����
    OUT_TFJ301.PORT_ORIGIN             := IN_INV.PORT_ORIGIN;
    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_ORIGIN, WK_PORT_NAME );
    OUT_TFJ301.PORT_ORIGIN_NAME        := WK_PORT_NAME;

    OUT_TFJ301.PORT_LOADING            := IN_INV.PORT_LOADING;
    IF OUT_TFJ301.PORT_LOADING = OUT_TFJ301.PORT_ORIGIN THEN
        OUT_TFJ301.PORT_LOADING_NAME   := OUT_TFJ301.PORT_ORIGIN_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_LOADING, WK_PORT_NAME );
        OUT_TFJ301.PORT_LOADING_NAME   := WK_PORT_NAME;
    END IF;

    OUT_TFJ301.PORT_UNLOADING          := IN_INV.PORT_UNLOADING;
    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_UNLOADING, WK_PORT_NAME );
    OUT_TFJ301.PORT_UNLOADING_NAME     := WK_PORT_NAME;

    OUT_TFJ301.PORT_DEST               := IN_INV.PORT_DEST;
    IF OUT_TFJ301.PORT_DEST = OUT_TFJ301.PORT_UNLOADING THEN
        OUT_TFJ301.PORT_DEST_NAME   := OUT_TFJ301.PORT_UNLOADING_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_DEST, WK_PORT_NAME );
        OUT_TFJ301.PORT_DEST_NAME   := WK_PORT_NAME;
    END IF;

--    OUT_TFJ301.FINAL_DESTINATION       := IN_INV.FINAL_DESTINATION;
    OUT_TFJ301.PORT_CC_EXPORT          := IN_INV.PORT_CC_EXPORT;
    OUT_TFJ301.PORT_CC_IMPORT          := IN_INV.PORT_CC_IMPORT;
--
    OUT_TFJ301.ORIG_COMPANY_ID         := IN_INV.ORIG_COMPANY_ID;
    OUT_TFJ301.ORIG_SUBSIDIARY_ID      := IN_INV.ORIG_SUBSIDIARY_ID;
    OUT_TFJ301.ORIG_TERMINAL_ID        := IN_INV.ORIG_TERMINAL_ID;
    OUT_TFJ301.ORIG_DEPARTMENT_ID      := IN_INV.ORIG_DEPARTMENT_ID;
    OUT_TFJ301.ORIG_AREA_CODE          := IN_INV.ORIG_AREA_CODE;
    OUT_TFJ301.ORIG_REGION_CODE        := IN_INV.ORIG_REGION_CODE;
    OUT_TFJ301.ORIG_COUNTRY_CODE       := IN_INV.ORIG_COUNTRY_CODE;
    OUT_TFJ301.ORIG_IATA_TC_CODE       := IN_INV.ORIG_IATA_TC_CODE;
    OUT_TFJ301.ORIG_POLAR_REGION_A_CODE
                                       := IN_INV.ORIG_POLAR_REGION_A_CODE;
    OUT_TFJ301.ORIG_POLAR_REGION_B_CODE
                                       := IN_INV.ORIG_POLAR_REGION_B_CODE;
    OUT_TFJ301.DEST_COMPANY_ID         := IN_INV.DEST_COMPANY_ID;
    OUT_TFJ301.DEST_SUBSIDIARY_ID      := IN_INV.DEST_SUBSIDIARY_ID;
    OUT_TFJ301.DEST_TERMINAL_ID        := IN_INV.DEST_TERMINAL_ID;
    OUT_TFJ301.DEST_DEPARTMENT_ID      := IN_INV.DEST_DEPARTMENT_ID;
    OUT_TFJ301.DEST_AREA_CODE          := IN_INV.DEST_AREA_CODE;
    OUT_TFJ301.DEST_REGION_CODE        := IN_INV.DEST_REGION_CODE;

    OUT_TFJ301.DEST_COUNTRY_CODE       := IN_INV.DEST_COUNTRY_CODE;
    OUT_TFJ301.DEST_IATA_TC_CODE       := IN_INV.DEST_IATA_TC_CODE;
    IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL OR
       OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
        -- PORT's COUNTRY ����
        PFGA3950.SEL_PORT_COUNTRY( OUT_TFJ301.PORT_DEST,
                          WK_COUNTRY_CODE,
                          WK_IATA_CONFERENCE_CODE );
        IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL THEN
            OUT_TFJ301.DEST_COUNTRY_CODE := WK_COUNTRY_CODE;
        END IF;
        IF OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
            OUT_TFJ301.DEST_IATA_TC_CODE := WK_IATA_CONFERENCE_CODE;
        END IF;
    END IF;

    OUT_TFJ301.DEST_POLAR_REGION_A_CODE
                                       := IN_INV.DEST_POLAR_REGION_A_CODE;
    OUT_TFJ301.DEST_POLAR_REGION_B_CODE
                                       := IN_INV.DEST_POLAR_REGION_B_CODE;
--
    OUT_TFJ301.NATURE_OF_GOODS         := NULL;
--
    -- MISC Invoice�Ή� 2005.12.16
    OUT_TFJ301.NUM_PIECES              := NVL(IN_INV.MISC_NUM_PIECES,0);
    OUT_TFJ301.NUM_PIECES_UOM_CODE     := IN_INV.MISC_PACKAGING_FORM_CODE;
    OUT_TFJ301.CHARGEABLE_WEIGHT       := NVL(IN_INV.MISC_CHARGEABLE_WEIGHT,0);
    OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE
                                       := IN_INV.MISC_CHG_WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_ACTUAL_WEIGHT     := NVL(IN_INV.MISC_GROSS_WEIGHT,0);
    OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE  := IN_INV.MISC_GROSS_WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_VOLUME            := 0;
    OUT_TFJ301.VOLUME_UOM_CODE         := NULL;
    OUT_TFJ301.TOTAL_VOLUME_WEIGHT     := 0;
    OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE  := NULL;
--
    OUT_TFJ301.CONTAINER_20FT          := 0;
    OUT_TFJ301.CONTAINER_40FT          := 0;
    OUT_TFJ301.CONTAINER_ETC           := 0;
--
--    OUT_TFJ301.FREIGHT_PPC_IND         := IN_INV.FREIGHT_PPC_IND;
--    OUT_TFJ301.OTHER_PPC_IND           := IN_INV.OTHER_PPC_IND;
--    OUT_TFJ301.DEST_PPC_IND            := IN_INV.DESTINATION_PPC_IND;
--
    OUT_TFJ301.OC_CURRENCY_CODE        := IN_INV.OC_CURRENCY_CODE;
--    OUT_TFJ301.ORIG_CURRENCY_CODE      := IN_INV.LOCAL_CURRENCY_CODE;
--    OUT_TFJ301.DEST_CURRENCY_CODE      := IN_INV.DEST_CURRENCY_CODE;
    OUT_TFJ301.INVOICE_CURRENCY_CODE   := IN_INV.INVOICE_CURRENCY_CODE;
--
--    OUT_TFJ301.DEST_EXCHANGE_RATE      := IN_INV.DEST_EXCHANGE_RATE;
--    OUT_TFJ301.INVOICE_EXCHANGE_RATE   := IN_INV.INVOICE_EXCHANGE_RATE;
--
    OUT_TFJ301.PPD_FREIGHT_AMT         := 0;
    OUT_TFJ301.PPD_OTHER_AMT           := 0;
    OUT_TFJ301.PPD_VALUATION_AMT       := 0;
    OUT_TFJ301.PPD_TAX_AMT             := 0;
    OUT_TFJ301.PPD_DUE_AGENT_AMT       := 0;
    OUT_TFJ301.PPD_DUE_CARRIER_AMT     := 0;
    OUT_TFJ301.TOT_PPD_AMT             := 0;
    OUT_TFJ301.COLL_FREIGHT_AMT        := 0;
    OUT_TFJ301.COLL_OTHER_AMT          := 0;
    OUT_TFJ301.COLL_VALUATION_AMT      := 0;
    OUT_TFJ301.COLL_TAX_AMT            := 0;
    OUT_TFJ301.COLL_DUE_AGENT_AMT      := 0;
    OUT_TFJ301.COLL_DUE_CARRIER_AMT    := 0;
    OUT_TFJ301.TOT_COLL_AMT            := 0;
--
    OUT_TFJ301.OC_PPD_FREIGHT_AMT      := 0;
    OUT_TFJ301.OC_PPD_OTHER_AMT        := 0;
    OUT_TFJ301.OC_PPD_VALUATION_AMT    := 0;
    OUT_TFJ301.OC_PPD_TAX_AMT          := 0;
    OUT_TFJ301.OC_PPD_DUE_AGENT_AMT    := 0;
    OUT_TFJ301.OC_PPD_DUE_CARRIER_AMT  := 0;
    OUT_TFJ301.OC_TOT_PPD_AMT          := 0;
    OUT_TFJ301.OC_COLL_FREIGHT_AMT     := 0;
    OUT_TFJ301.OC_COLL_OTHER_AMT       := 0;
    OUT_TFJ301.OC_COLL_VALUATION_AMT   := 0;
    OUT_TFJ301.OC_COLL_TAX_AMT         := 0;
    OUT_TFJ301.OC_COLL_DUE_AGENT_AMT   := 0;
    OUT_TFJ301.OC_COLL_DUE_CARRIER_AMT := 0;
    OUT_TFJ301.OC_TOT_COLL_AMT         := 0;
--
-- 2005.12.16 Misc Invoice�Ή�
    -- Shipper
    PFGA3950.SEL_PARTNER_ID( IN_INV.PIPELINE_TX_ID,
                             'S',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.SHIPPER_ID              := WK_PARTNER_ID;
    OUT_TFJ301.SHIPPER_NAME            := IN_INV.MISC_SHIPPER_NAME;

    IF OUT_TFJ301.SHIPPER_ID <> '!' THEN
        PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.LL_SHIPPER_NAME         := WK_LL_PARTNER_NAME;
        OUT_TFJ301.SHIPPER_PARENT_ID       := WK_PARENT_PARTNER_ID;
        OUT_TFJ301.SHIPPER_GROUP_ID        := WK_PARTNER_GROUP_CODE;
        -- JPAEX �ǉ�                                        2005.04.10
        OUT_TFJ301.SHIPPER_INDUSTRY_CODE   := WK_INDUSTRY_CODE;
        OUT_TFJ301.SHIPPER_INDUSTRY_NAME   := WK_INDUSTRY_NAME;

        IF OUT_TFJ301.SHIPPER_PARENT_ID IS NULL OR
           OUT_TFJ301.SHIPPER_PARENT_ID = '!'   THEN
            OUT_TFJ301.SHIPPER_PARENT_NAME     := NULL;
            OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := NULL;
        ELSE
            PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_PARENT_ID,
                                  DMY_PARENT_PARTNER_ID,
                                  WK_PARTNER_NAME,
                                  WK_LL_PARTNER_NAME,
                                  DMY_PARTNER_SHORT_NAME,
                                  WK_INDUSTRY_CODE,
                                  WK_INDUSTRY_NAME );
            OUT_TFJ301.SHIPPER_PARENT_NAME     := WK_PARTNER_NAME;
            OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := WK_LL_PARTNER_NAME;
        END IF;
        OUT_TFJ301.SHIPPER_ADDRESS_NO      := IN_INV.MISC_SHIPPER_ADDRESS_NO;

        PFGA3950.SEL_ADDRESS( OUT_TFJ301.SHIPPER_ADDRESS_NO, WK_ADDRESS );
        OUT_TFJ301.SHIPPER_ADDRESS1        := WK_ADDRESS.ADDRESS_1;
        OUT_TFJ301.SHIPPER_ADDRESS2        := WK_ADDRESS.ADDRESS_2;
        OUT_TFJ301.SHIPPER_ADDRESS3        := WK_ADDRESS.ADDRESS_3;
        OUT_TFJ301.SHIPPER_ADDRESS4        := WK_ADDRESS.ADDRESS_4;
        OUT_TFJ301.SHIPPER_ADDRESS5        := WK_ADDRESS.ADDRESS_5;
        OUT_TFJ301.LL_SHIPPER_ADDRESS1     := WK_ADDRESS.LL_ADDRESS_1;
        OUT_TFJ301.LL_SHIPPER_ADDRESS2     := WK_ADDRESS.LL_ADDRESS_2;
        OUT_TFJ301.LL_SHIPPER_ADDRESS3     := WK_ADDRESS.LL_ADDRESS_3;
        OUT_TFJ301.LL_SHIPPER_ADDRESS4     := WK_ADDRESS.LL_ADDRESS_4;
        OUT_TFJ301.LL_SHIPPER_ADDRESS5     := WK_ADDRESS.LL_ADDRESS_5;
        OUT_TFJ301.SHIPPER_CITY_NAME       := WK_ADDRESS.CITY_NAME;
        OUT_TFJ301.LL_SHIPPER_CITY_NAME    := WK_ADDRESS.LL_CITY_NAME;
        OUT_TFJ301.SHIPPER_REGION_CODE     := WK_ADDRESS.REGION_CODE;
        OUT_TFJ301.SHIPPER_POSTAL_CODE     := WK_ADDRESS.POSTAL_CODE;
        OUT_TFJ301.SHIPPER_COUNTRY_CODE    := WK_ADDRESS.COUNTRY_CODE;
        OUT_TFJ301.SHIPPER_CONTACT_NO      := IN_INV.MISC_SHIPPER_CONTACT_NO;
        -- JPAEX �ǉ�                                        2005.04.10
        OUT_TFJ301.SHIPPER_REGION_NAME     := WK_ADDRESS.REGION_NAME;

        IF OUT_TFJ301.SHIPPER_CONTACT_NO IS NOT NULL THEN
            PFGA3950.SEL_CONTACT( OUT_TFJ301.SHIPPER_CONTACT_NO, WK_CONTACT );
            OUT_TFJ301.SHIPPER_CONTACT_NAME    := WK_CONTACT.LAST_NAME;
            OUT_TFJ301.LL_SHIPPER_CONTACT_NAME := WK_CONTACT.LL_NAME;
            OUT_TFJ301.SHIPPER_CONTACT_PHONE   := WK_CONTACT.PHONE_NO;
            OUT_TFJ301.SHIPPER_CONTACT_FAX     := WK_CONTACT.FAX_NO;
            OUT_TFJ301.SHIPPER_CONTACT_EMAIL   := WK_CONTACT.EMAIL_ID;
        END IF;
    END IF;
--
    -- Consignee
    PFGA3950.SEL_PARTNER_ID( IN_INV.PIPELINE_TX_ID,
                             'C',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.CNEE_ID                 := WK_PARTNER_ID;
    OUT_TFJ301.CNEE_NAME               := IN_INV.MISC_CONSIGNEE_NAME;

    IF OUT_TFJ301.CNEE_ID <> '!' THEN
        PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.LL_CNEE_NAME            := WK_LL_PARTNER_NAME;
        OUT_TFJ301.CNEE_PARENT_ID          := WK_PARENT_PARTNER_ID;
        OUT_TFJ301.CNEE_GROUP_ID           := WK_PARTNER_GROUP_CODE;

        IF OUT_TFJ301.CNEE_PARENT_ID IS NULL OR
           OUT_TFJ301.CNEE_PARENT_ID = '!'   THEN
            OUT_TFJ301.CNEE_PARENT_NAME     := NULL;
            OUT_TFJ301.LL_CNEE_PARENT_NAME  := NULL;
        ELSE
            PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_PARENT_ID,
                                  DMY_PARENT_PARTNER_ID,
                                  WK_PARTNER_NAME,
                                  WK_LL_PARTNER_NAME,
                                  DMY_PARTNER_SHORT_NAME,
                                  WK_INDUSTRY_CODE,
                                  WK_INDUSTRY_NAME );
            OUT_TFJ301.CNEE_PARENT_NAME     := WK_PARTNER_NAME;
            OUT_TFJ301.LL_CNEE_PARENT_NAME  := WK_LL_PARTNER_NAME;
        END IF;
        OUT_TFJ301.CNEE_ADDRESS_NO         := IN_INV.MISC_CONSIGNEE_ADDRESS_NO;

        PFGA3950.SEL_ADDRESS( OUT_TFJ301.CNEE_ADDRESS_NO, WK_ADDRESS );
        OUT_TFJ301.CNEE_ADDRESS1           := WK_ADDRESS.ADDRESS_1;
        OUT_TFJ301.CNEE_ADDRESS2           := WK_ADDRESS.ADDRESS_2;
        OUT_TFJ301.CNEE_ADDRESS3           := WK_ADDRESS.ADDRESS_3;
        OUT_TFJ301.CNEE_ADDRESS4           := WK_ADDRESS.ADDRESS_4;
        OUT_TFJ301.CNEE_ADDRESS5           := WK_ADDRESS.ADDRESS_5;
        OUT_TFJ301.LL_CNEE_ADDRESS1        := WK_ADDRESS.LL_ADDRESS_1;
        OUT_TFJ301.LL_CNEE_ADDRESS2        := WK_ADDRESS.LL_ADDRESS_2;
        OUT_TFJ301.LL_CNEE_ADDRESS3        := WK_ADDRESS.LL_ADDRESS_3;
        OUT_TFJ301.LL_CNEE_ADDRESS4        := WK_ADDRESS.LL_ADDRESS_4;
        OUT_TFJ301.LL_CNEE_ADDRESS5        := WK_ADDRESS.LL_ADDRESS_5;
        OUT_TFJ301.CNEE_CITY_NAME          := WK_ADDRESS.CITY_NAME;
        OUT_TFJ301.LL_CNEE_CITY_NAME       := WK_ADDRESS.LL_CITY_NAME;
        OUT_TFJ301.CNEE_REGION_CODE        := WK_ADDRESS.REGION_CODE;
        OUT_TFJ301.CNEE_POSTAL_CODE        := WK_ADDRESS.POSTAL_CODE;
        OUT_TFJ301.CNEE_COUNTRY_CODE       := WK_ADDRESS.COUNTRY_CODE;
        OUT_TFJ301.CNEE_CONTACT_NO         := IN_INV.MISC_CONSIGNEE_CONTACT_NO;

        IF OUT_TFJ301.CNEE_CONTACT_NO IS NOT NULL THEN
            PFGA3950.SEL_CONTACT( OUT_TFJ301.CNEE_CONTACT_NO, WK_CONTACT );
            OUT_TFJ301.CNEE_CONTACT_NAME       := WK_CONTACT.LAST_NAME;
            OUT_TFJ301.LL_CNEE_CONTACT_NAME    := WK_CONTACT.LL_NAME;
            OUT_TFJ301.CNEE_CONTACT_PHONE      := WK_CONTACT.PHONE_NO;
            OUT_TFJ301.CNEE_CONTACT_FAX        := WK_CONTACT.FAX_NO;
            OUT_TFJ301.CNEE_CONTACT_EMAIL      := WK_CONTACT.EMAIL_ID;
        END IF;
    END IF;
--
    -- Bill To
    PFGA3950.SEL_PARTNER_ID( IN_INV.PIPELINE_TX_ID,
                             'BT',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.BILLTO_ID               := WK_PARTNER_ID;
    OUT_TFJ301.BILLTO_NAME             := IN_INV.BILLTO_NAME;
    OUT_TFJ301.BILLTO_ADDRESS_NO       := IN_INV.BILLTO_ADDRESS_NO;
    OUT_TFJ301.BILLTO_CONTACT_NO       := IN_INV.BILLTO_CONTACT_NO;

	-- �׎�iBILL_TO�j
    PFGA3950.SEL_PARTNER( OUT_TFJ301.BILLTO_ID,
                          DMY_PARENT_PARTNER_ID,
                          WK_PARTNER_NAME,
                          WK_LL_PARTNER_NAME,
                          DMY_PARTNER_SHORT_NAME,
                          WK_INDUSTRY_CODE,
                          WK_INDUSTRY_NAME );
    OUT_TFJ301.ECNORCD                 := OUT_TFJ301.BILLTO_ID;
    OUT_TFJ301.ECNORNM                 := OUT_TFJ301.BILLTO_NAME;
    OUT_TFJ301.JCNORNM                 := WK_LL_PARTNER_NAME;
    IF WK_PARENT_PARTNER_ID IS NULL OR
       WK_PARENT_PARTNER_ID = '!'   THEN
        OUT_TFJ301.EOYA_ECNORCD        := OUT_TFJ301.ECNORCD;
        OUT_TFJ301.EOYA_ECNORNM        := OUT_TFJ301.ECNORNM;
        OUT_TFJ301.JOYA_ECNORNM        := OUT_TFJ301.JCNORNM;
    ELSE
        OUT_TFJ301.EOYA_ECNORCD        := WK_PARENT_PARTNER_ID;
        PFGA3950.SEL_PARTNER( OUT_TFJ301.EOYA_ECNORCD,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.EOYA_ECNORNM        := WK_PARTNER_NAME;
        OUT_TFJ301.JOYA_ECNORNM        := WK_LL_PARTNER_NAME;
    END IF;

    --  �̔��ӏ�
    OUT_TFJ301.ETERMINAL_ID        := NVL(IN_TFJ201.SALES_RESPONSIBLE_OFFICE_ID,'!');
    OUT_TFJ301.EDEPARTMENT_ID      := NVL(IN_TFJ201.GL_GROUP,'!');

    -- OFFICES ����
    PFGA3950.SEL_OFFICES( OUT_TFJ301.ECOMPANY_ID,
                          OUT_TFJ301.ETERMINAL_ID,
                          OUT_TFJ301.EDEPARTMENT_ID,
                          WK_OFFICE_NAME,
                          WK_LL_OFFICE_NAME );
    OUT_TFJ301.ETERMNM                 := WK_OFFICE_NAME;
    OUT_TFJ301.JTERMNM                 := WK_LL_OFFICE_NAME;
    OUT_TFJ301.EDEPARTNM               := NULL;
    OUT_TFJ301.JDEPARTNM               := NULL;

    -- �S����
    IF OUT_TFJ301.EIM_EX_IND  = 'E' THEN
        WK_PARTNER_ROLE                := 'S';
    ELSE
        WK_PARTNER_ROLE                := 'C';
    END IF;
    -- Partner Relationship's Employee �擾
    PFGA3950.SEL_PR_EMPLOYEE( OUT_TFJ301.ECOMPANY_ID,
                              OUT_TFJ301.ECNORCD,
                              WK_PARTNER_ROLE,
                              OUT_TFJ301.ETRANS_MODE,
                              OUT_TFJ301.EIM_EX_IND,
                              WK_EMPLOYEE_NO );
    OUT_TFJ301.EHBI_TNTCD          := WK_EMPLOYEE_NO;

    IF OUT_TFJ301.EHBI_TNTCD IS NOT NULL THEN
        -- EMPLOYEE �擾
        PFGA3950.SEL_EMPLOYEE( OUT_TFJ301.EHBI_TNTCD,
                               WK_EMPLOYEE_NAME,
                               WK_LL_EMPLOYEE_NAME );
        OUT_TFJ301.ETNTNM              := WK_EMPLOYEE_NAME;
        OUT_TFJ301.JTNTNM              := WK_LL_EMPLOYEE_NAME;
    ELSE
        OUT_TFJ301.EHBI_TNTCD          := '!';
    END IF;

    -- REFERENCE_NUMBERS�擾                             2004.12.12
    PFGA3950.SEL_REFERENCE_NUMBERS( IN_TFJ201.PIPELINE_TX_ID,
                                    'PO',
                                    OUT_TFJ301.PO_NO );
    PFGA3950.SEL_REFERENCE_NUMBERS( IN_TFJ201.PIPELINE_TX_ID,
                                    'CI',
                                    OUT_TFJ301.COMMERCIAL_INV_NO );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- MWB ���і��ׁA�ҏW
--================================================
PROCEDURE SET_TFJ301_MWB(
    OUT_TFJ301            IN OUT     TFJ301%ROWTYPE,       -- ���і���
    IN_MWB                IN         CUR_MWB%ROWTYPE,      -- MWB
    IN_TFJ201             IN         TFJ201%ROWTYPE,       -- UASIF
    IN_NGENNO             IN         TFJ301.NGENNO%TYPE,   -- ����ԍ�
    IN_ORIGINAL_KJODTM    IN         TFJ301.ORIGINAL_KJODTM%TYPE )
                                                        -- �I���W�i���v���
IS
    WK_PIPELINE_REF_ID     PIPELINE.PIPELINE_REF_ID%TYPE;
    WK_DATE                DATE;
    WK_PIPELINE_TX_ID      PIPELINE.PIPELINE_TX_ID%TYPE;

    WK_CONTAINER_NUM        MWB_DETAIL.CONTAINER_NUM%TYPE;       -- 2004.10.06
    WK_CONTAINER_TYPE       MWB_DETAIL.CONTAINER_TYPE%TYPE;      -- 2004.10.06
    WK_CONTAINER_20FT       MWB_DETAIL.NUM_PIECES%TYPE;
    WK_CONTAINER_40FT       MWB_DETAIL.NUM_PIECES%TYPE;
    WK_CONTAINER_ETC        MWB_DETAIL.NUM_PIECES%TYPE;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    DMY_PARENT_PARTNER_ID   PARTNER.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_NAME         PARTNER.PARTNER_NAME%TYPE;
    WK_LL_PARTNER_NAME      PARTNER.LL_PARTNER_NAME%TYPE;
    DMY_PARTNER_SHORT_NAME  PARTNER.PARTNER_SHORT_NAME%TYPE;
    WK_INDUSTRY_CODE        PARTNER.CUSTOMER_INDUSTRY_CODE%TYPE; -- add 2005.04.10
    WK_INDUSTRY_NAME        CODE_DETAIL.CD_DESCRIPTION%TYPE;     -- add 2005.04.10

    WK_ADDRESS              ADDRESS%ROWTYPE;
    WK_CONTACT              CONTACT%ROWTYPE;

    WK_PORT_NAME            PORT.PORT_NAME%TYPE;

    WK_COUNTRY_CODE         COUNTRY.COUNTRY_CODE%TYPE;
    WK_IATA_CONFERENCE_CODE COUNTRY.IATA_CONFERENCE_CODE%TYPE;

    WK_CONSOL_SERVICE_TYPE  CONSOL.CONSOL_SERVICE_TYPE%TYPE;
    WK_CONSOL_CODE          CONSOL.CONSOL_CODE%TYPE;             -- add 2005.04.10

    WK_CARRIER_TYPE         CARRIER.CARRIER_TYPE%TYPE;
    WK_CARRIER_NAME         CARRIER.CARRIER_NAME%TYPE;
    WK_DEPARTURE_DATE       CARRIER_SEGMENT.ATD%TYPE;
    WK_ARRIVAL_DATE         CARRIER_SEGMENT.ATA%TYPE;
    WK_CARRIER_CODE         CARRIER_SEGMENT.CARRIER_CODE%TYPE;
    WK_FLIGHT_VOYAGE        CARRIER_SEGMENT.FLIGHT_VOYAGE%TYPE;
    WK_VESSEL_NAME          CARRIER_SEGMENT.VESSEL_NAME%TYPE;

    WK_MANIFEST_NO          MANIFEST_HEADER.MANIFEST_NO%TYPE;    -- 2004.10.06

    -- ROUTE��� �ǉ�                                    2005.04.29
    WK_ETD                   ROUTE.DEPARTURE_DATE%TYPE;
    WK_ETA                   ROUTE.ARRIVAL_DATE%TYPE;
    WK_ATD                   ROUTE.DEPARTURE_DATE%TYPE;
    WK_ATA                   ROUTE.ARRIVAL_DATE%TYPE;
    WK_ROUTE1_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE1_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE1_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE1_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE1_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE1_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE2_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE2_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE2_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE2_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE2_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE2_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE3_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE3_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE3_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE3_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE3_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE3_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE4_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE4_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE4_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE4_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE4_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE4_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;
    WK_ROUTE5_TYPE           ROUTE.ROUTE_TYPE%TYPE;
    WK_ROUTE5_PORT_LOADING   ROUTE.PORT_LOADING%TYPE;
    WK_ROUTE5_PORT_UNLOADING ROUTE.PORT_UNLOADING%TYPE;
    WK_ROUTE5_CARRIER_CODE   ROUTE.CARRIER_CODE%TYPE;
    WK_ROUTE5_FLIGHT_VOYAGE  ROUTE.FLIGHT_VOYAGE%TYPE;
    WK_ROUTE5_VESSEL_NAME    ROUTE.VESSEL_NAME%TYPE;

    -- 2005.05.15 COMMODITY_CODE(SCR No)
    WK_COMMODITY_CODE        COMMODITY_CODES.COMMODITY_CODE%TYPE;
    WK_COMMODITY_DESCRIPTION COMMODITY_CODES.COMMODITY_DESCRIPTION%TYPE;
    WK_COMMODITY_TYPE        COMMODITY_CODES.COMMODITY_TYPE%TYPE;

    -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
    WK_WT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_M3_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_RT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_WT_RND          NUMBER;
    WK_M3_RND          NUMBER;
    WK_RT_RND          NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SET_TFJ301_MWB' );

    OUT_TFJ301                         := NULL;
        -- ����
    OUT_TFJ301.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    OUT_TFJ301.DHNEDTM                 := SYSDATE;
    OUT_TFJ301.EUPD_OFCCD              := '!';
    OUT_TFJ301.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    OUT_TFJ301.EDATKBN                 := '3';
    OUT_TFJ301.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    OUT_TFJ301.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    OUT_TFJ301.NGENNO                  := IN_NGENNO;
    -- �R���g���[��
    OUT_TFJ301.ESISNKBN                := '1';
    OUT_TFJ301.NAKKBN                  := 1;
    OUT_TFJ301.EDELKBN                 := '0';
    OUT_TFJ301.ESKY_KBN                := '0';
    IF IN_NGENNO = 1 THEN
        OUT_TFJ301.EOPE_KBN            := '0';      -- �V�K
    ELSE
        OUT_TFJ301.EOPE_KBN            := '1';      -- �C��
    END IF;

    --  Add 2004.08.15 FWD���ЁE���Д��f
    IF IN_TFJ201.IMPORT_EXPORT_IND = 'I' THEN
        IF IN_MWB.PIPELINE_REF_TYPE = 'M' THEN
            OUT_TFJ301.EFWD_JTKBN      := '1';  --  'M' :Consol --> ����("1")
        ELSIF IN_MWB.PIPELINE_REF_TYPE = 'MD' THEN
            OUT_TFJ301.EFWD_JTKBN      := '0';  --  'MD':Direct --> ����("0")
        ELSE
            OUT_TFJ301.EFWD_JTKBN      := '!';
            PFGA3910.TRACE_LOG( 'E', 'PIPELINE_REF_TYPE = '
                                 || IN_MWB.PIPELINE_REF_TYPE );
        END IF;
    ELSE
        OUT_TFJ301.EFWD_JTKBN          := '1';  -- ����("1")
    END IF;

    --  Add 2004.07.26 �ʊ֎��ЁE����
    OUT_TFJ301.ETKN_JTKBN              := '9';

    OUT_TFJ301.ECOMPANY_ID             := IN_TFJ201.COMPANY_ID;
    OUT_TFJ301.EIM_EX_IND              := IN_TFJ201.IMPORT_EXPORT_IND;
    OUT_TFJ301.ETRANS_MODE             := IN_TFJ201.TRANSPORT_MODE;
    -- ���t
    OUT_TFJ301.DKJODTM                 := IN_TFJ201.ACCOUNTING_DATE;
    IF IN_NGENNO > 1 THEN
        OUT_TFJ301.ORIGINAL_KJODTM     := IN_ORIGINAL_KJODTM;
    ELSE
        OUT_TFJ301.ORIGINAL_KJODTM     := IN_TFJ201.ACCOUNTING_DATE;
    END IF;
    OUT_TFJ301.INVOICE_DATE            := IN_TFJ201.INVOICE_DATE;
    OUT_TFJ301.ORIGINAL_INVOICE_DATE   := IN_TFJ201.ORIGINAL_INVOICE_DATE;

    -- ���t�E�ԍ�
    IF IN_MWB.PIPELINE_REF_TYPE = 'M' THEN
        PFGA3950.SEL_PIPELINE_RELATIONS( OUT_TFJ301.PIPELINE_TX_ID,
                                         'CS',
                                         'CO',
                                         WK_PIPELINE_REF_ID,
                                         WK_DATE,
                                         WK_PIPELINE_TX_ID );
        OUT_TFJ301.CONSOL_DATE         := WK_DATE;
        OUT_TFJ301.CONSOL_NO           := WK_PIPELINE_REF_ID;
        OUT_TFJ301.CONSOL_TX_ID        := WK_PIPELINE_TX_ID;

        -- Manifest No�̑Ή�
        PFGA3950.SEL_MANIFEST_HEADER( OUT_TFJ301.CONSOL_TX_ID,
                                      'M',
                                      WK_MANIFEST_NO );
        OUT_TFJ301.MANIFEST_NO         := WK_MANIFEST_NO;
    ELSE
        OUT_TFJ301.CONSOL_DATE         := NULL;
        OUT_TFJ301.CONSOL_NO           := NULL;
        OUT_TFJ301.CONSOL_TX_ID        := NULL;
    END IF;

    OUT_TFJ301.MWB_ISSUE_DATE          := IN_MWB.ISSUE_DATE;
    OUT_TFJ301.MWB_NO                  := IN_MWB.PIPELINE_REF_ID;
    OUT_TFJ301.MWB_TX_ID               := IN_MWB.PIPELINE_TX_ID;

    OUT_TFJ301.HMWB_NO                 := NULL;
    OUT_TFJ301.HMWB_TX_ID              := NULL;

    OUT_TFJ301.ISSUE_DATE              := NULL;
    OUT_TFJ301.HWB_NO                  := NULL;
    OUT_TFJ301.HWB_TX_ID               := NULL;

    OUT_TFJ301.INVOICE_NO              := NULL;
    OUT_TFJ301.INVOICE_TX_ID           := NULL;

    -- 2005.06.19 MY JOB_NO�Ή�
    IF OUT_TFJ301.EIM_EX_IND = 'E' THEN
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'CS',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNE',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    ELSE
        PFGA3950.SEL_JOB_NO( OUT_TFJ301.PIPELINE_TX_ID,
                                         'CS',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNI',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
    END IF;
    OUT_TFJ301.JOB_NO                  := WK_PIPELINE_REF_ID;
    OUT_TFJ301.JOB_TX_ID               := WK_PIPELINE_TX_ID;
--
    OUT_TFJ301.ISSUE_DATE_TO_PRINT     := IN_MWB.ISSUE_DATE_TO_PRINT;
    OUT_TFJ301.OBD_DATE_TO_PRINT       := IN_MWB.OBD_DATE_TO_PRINT;

    PFGA3950.GET_CARRIER_TYPE( OUT_TFJ301.MWB_TX_ID,
                               WK_CARRIER_TYPE,
                               WK_CARRIER_NAME,
                               WK_DEPARTURE_DATE,
                               WK_ARRIVAL_DATE,
                               WK_CARRIER_CODE,
                               WK_FLIGHT_VOYAGE,
                               WK_VESSEL_NAME );
-- 2005.04.29 ROUTE�̑Ή�
    PFGA3950.GET_ROUTE( OUT_TFJ301.MWB_TX_ID,
                               WK_ETD,
                               WK_ETA,
                               WK_ATD,
                               WK_ATA,
                               WK_ROUTE1_TYPE,
                               WK_ROUTE1_PORT_LOADING,
                               WK_ROUTE1_PORT_UNLOADING,
                               WK_ROUTE1_CARRIER_CODE,
                               WK_ROUTE1_FLIGHT_VOYAGE,
                               WK_ROUTE1_VESSEL_NAME,
                               WK_ROUTE2_TYPE,
                               WK_ROUTE2_PORT_LOADING,
                               WK_ROUTE2_PORT_UNLOADING,
                               WK_ROUTE2_CARRIER_CODE,
                               WK_ROUTE2_FLIGHT_VOYAGE,
                               WK_ROUTE2_VESSEL_NAME,
                               WK_ROUTE3_TYPE,
                               WK_ROUTE3_PORT_LOADING,
                               WK_ROUTE3_PORT_UNLOADING,
                               WK_ROUTE3_CARRIER_CODE,
                               WK_ROUTE3_FLIGHT_VOYAGE,
                               WK_ROUTE3_VESSEL_NAME,
                               WK_ROUTE4_TYPE,
                               WK_ROUTE4_PORT_LOADING,
                               WK_ROUTE4_PORT_UNLOADING,
                               WK_ROUTE4_CARRIER_CODE,
                               WK_ROUTE4_FLIGHT_VOYAGE,
                               WK_ROUTE4_VESSEL_NAME,
                               WK_ROUTE5_TYPE,
                               WK_ROUTE5_PORT_LOADING ,
                               WK_ROUTE5_PORT_UNLOADING,
                               WK_ROUTE5_CARRIER_CODE,
                               WK_ROUTE5_FLIGHT_VOYAGE,
                               WK_ROUTE5_VESSEL_NAME);

    IF WK_DEPARTURE_DATE IS NULL THEN
        IF WK_ATD IS NOT NULL THEN
            OUT_TFJ301.DEPARTURE_DATE  := TO_DATE(TO_CHAR(WK_ATD,'YYYY/MM/DD'),'YYYY/MM/DD');
        ELSE
            OUT_TFJ301.DEPARTURE_DATE  := TO_DATE(TO_CHAR(WK_ETD,'YYYY/MM/DD'),'YYYY/MM/DD');
        END IF;
    ELSE
        OUT_TFJ301.DEPARTURE_DATE      := WK_DEPARTURE_DATE;
    END IF;
    IF WK_ARRIVAL_DATE IS NULL OR
       WK_ARRIVAL_DATE < TO_DATE('2004/01/01','YYYY/MM/DD') THEN
        IF WK_ATA IS NOT NULL THEN
            OUT_TFJ301.ARRIVAL_DATE    := TO_DATE(TO_CHAR(WK_ATA,'YYYY/MM/DD'),'YYYY/MM/DD');
        ELSE
            OUT_TFJ301.ARRIVAL_DATE    := TO_DATE(TO_CHAR(WK_ETA,'YYYY/MM/DD'),'YYYY/MM/DD');
        END IF;
    ELSE
        OUT_TFJ301.ARRIVAL_DATE        := WK_ARRIVAL_DATE;
    END IF;
--
    OUT_TFJ301.PIPELINE_TX_TYPE        := IN_MWB.PIPELINE_TX_TYPE;
    OUT_TFJ301.PIPELINE_REF_TYPE       := IN_MWB.PIPELINE_REF_TYPE;
    OUT_TFJ301.PIPELINE_TX_STATUS      := IN_MWB.PIPELINE_TX_STATUS;
    OUT_TFJ301.TRANSPORT_MODE          := IN_MWB.TRANSPORT_MODE;
    OUT_TFJ301.SERVICE_TYPE            := IN_MWB.SERVICE_TYPE;
    OUT_TFJ301.MOVEMENT_TYPE           := IN_MWB.MOVEMENT_TYPE;
    OUT_TFJ301.CUSTOMER_SHIPMENT_TYPE  := IN_MWB.CUSTOMER_SHIPMENT_TYPE;
--    OUT_TFJ301.AGENT_TYPE              := ;

    -- CONSOL_SERVICE_TYPE
    IF IN_MWB.PIPELINE_REF_TYPE = 'M' THEN
        PFGA3950.GET_CONSOL_SERVICE_TYPE( OUT_TFJ301.CONSOL_TX_ID,
                                          WK_CONSOL_SERVICE_TYPE,
                                          WK_CONSOL_CODE );
        OUT_TFJ301.CONSOL_SERVICE_TYPE := WK_CONSOL_SERVICE_TYPE;

        -- JPAEX �ǉ�                                        2005.04.10
        OUT_TFJ301.CONSOL_CODE         := WK_CONSOL_CODE;
    END IF;

    OUT_TFJ301.DISPOSITION             := NULL;
--
    OUT_TFJ301.CARRIER_CODE            := WK_CARRIER_CODE;
    OUT_TFJ301.CARRIER_NAME            := WK_CARRIER_NAME;
    OUT_TFJ301.FLIGHT_VOYAGE           := WK_FLIGHT_VOYAGE;
    OUT_TFJ301.VESSEL_NAME             := WK_VESSEL_NAME;

    -- CARRIER_TYPE  'A':AIR,    'O':VOCC,    'N':NVOCC
    OUT_TFJ301.CARRIER_TYPE            := WK_CARRIER_TYPE;
--
-- 2005.04.29 ROUTE�̑Ή�
    OUT_TFJ301.ETD                     := WK_ETD;
    OUT_TFJ301.ETA                     := WK_ETA;
    OUT_TFJ301.ATD                     := WK_ATD;
    OUT_TFJ301.ATA                     := WK_ATA;
    OUT_TFJ301.ROUTE1_TYPE             := WK_ROUTE1_TYPE;
    OUT_TFJ301.ROUTE1_PORT_LOADING     := WK_ROUTE1_PORT_LOADING;
    OUT_TFJ301.ROUTE1_PORT_UNLOADING   := WK_ROUTE1_PORT_UNLOADING;
    OUT_TFJ301.ROUTE1_CARRIER_CODE     := WK_ROUTE1_CARRIER_CODE;
    OUT_TFJ301.ROUTE1_FLIGHT_VOYAGE    := WK_ROUTE1_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE1_VESSEL_NAME      := WK_ROUTE1_VESSEL_NAME;
    OUT_TFJ301.ROUTE2_TYPE             := WK_ROUTE2_TYPE;
    OUT_TFJ301.ROUTE2_PORT_LOADING     := WK_ROUTE2_PORT_LOADING;
    OUT_TFJ301.ROUTE2_PORT_UNLOADING   := WK_ROUTE2_PORT_UNLOADING;
    OUT_TFJ301.ROUTE2_CARRIER_CODE     := WK_ROUTE2_CARRIER_CODE;
    OUT_TFJ301.ROUTE2_FLIGHT_VOYAGE    := WK_ROUTE2_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE2_VESSEL_NAME      := WK_ROUTE2_VESSEL_NAME;
    OUT_TFJ301.ROUTE3_TYPE             := WK_ROUTE3_TYPE;
    OUT_TFJ301.ROUTE3_PORT_LOADING     := WK_ROUTE3_PORT_LOADING;
    OUT_TFJ301.ROUTE3_PORT_UNLOADING   := WK_ROUTE3_PORT_UNLOADING;
    OUT_TFJ301.ROUTE3_CARRIER_CODE     := WK_ROUTE3_CARRIER_CODE;
    OUT_TFJ301.ROUTE3_FLIGHT_VOYAGE    := WK_ROUTE3_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE3_VESSEL_NAME      := WK_ROUTE3_VESSEL_NAME;
    OUT_TFJ301.ROUTE4_TYPE             := WK_ROUTE4_TYPE;
    OUT_TFJ301.ROUTE4_PORT_LOADING     := WK_ROUTE4_PORT_LOADING;
    OUT_TFJ301.ROUTE4_PORT_UNLOADING   := WK_ROUTE4_PORT_UNLOADING;
    OUT_TFJ301.ROUTE4_CARRIER_CODE     := WK_ROUTE4_CARRIER_CODE;
    OUT_TFJ301.ROUTE4_FLIGHT_VOYAGE    := WK_ROUTE4_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE4_VESSEL_NAME      := WK_ROUTE4_VESSEL_NAME;
    OUT_TFJ301.ROUTE5_TYPE             := WK_ROUTE5_TYPE;
    OUT_TFJ301.ROUTE5_PORT_LOADING     := WK_ROUTE5_PORT_LOADING;
    OUT_TFJ301.ROUTE5_PORT_UNLOADING   := WK_ROUTE5_PORT_UNLOADING;
    OUT_TFJ301.ROUTE5_CARRIER_CODE     := WK_ROUTE5_CARRIER_CODE;
    OUT_TFJ301.ROUTE5_FLIGHT_VOYAGE    := WK_ROUTE5_FLIGHT_VOYAGE;
    OUT_TFJ301.ROUTE5_VESSEL_NAME      := WK_ROUTE5_VESSEL_NAME;

--    OUT_TFJ301.FREE_HOUSE_IND          := ;
    OUT_TFJ301.LCL_CNSL_CARRIER_IND    := TRIM(IN_MWB.LCL_CNSL_CARRIER_IND);
--
    OUT_TFJ301.PIPELINE_TX_DATE        := IN_MWB.PIPELINE_TX_DATE;
    OUT_TFJ301.TX_DATE_TZ_CODE         := IN_MWB.TX_DATE_TZ_CODE;
--
--    OUT_TFJ301.TRANSPORT_TERMS_CODE    := ;
--    OUT_TFJ301.SALES_TERMS_CODE        := ;
--    OUT_TFJ301.FREE_HOUSE_TERMS_CODE   := ;
--
    OUT_TFJ301.IMPORT_SALESMAN_ID      := IN_MWB.IMPORT_SALESPERSON_ID;
    OUT_TFJ301.EXPORT_SALESMAN_ID      := IN_MWB.EXPORT_SALESPERSON_ID;
--
    OUT_TFJ301.PLACE_OF_RECEIPT        := IN_MWB.PLACE_OF_RECEIPT_CODE;
    OUT_TFJ301.PLACE_OF_RECEIPT_NAME   := IN_MWB.PLACE_OF_RECEIPT_NAME;
    OUT_TFJ301.PLACE_OF_DELIVERY       := IN_MWB.PLACE_OF_DELIVERY_CODE;
    OUT_TFJ301.PLACE_OF_DELIVERY_NAME  := IN_MWB.PLACE_OF_DELIVERY_NAME;

    -- PORT ����
    OUT_TFJ301.PORT_ORIGIN             := IN_MWB.PORT_ORIGIN;
    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_ORIGIN, WK_PORT_NAME );
    OUT_TFJ301.PORT_ORIGIN_NAME        := WK_PORT_NAME;

    OUT_TFJ301.PORT_LOADING            := IN_MWB.PORT_LOADING;
    IF OUT_TFJ301.PORT_LOADING = OUT_TFJ301.PORT_ORIGIN THEN
        OUT_TFJ301.PORT_LOADING_NAME   := OUT_TFJ301.PORT_ORIGIN_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_LOADING, WK_PORT_NAME );
        OUT_TFJ301.PORT_LOADING_NAME   := WK_PORT_NAME;
    END IF;

    OUT_TFJ301.PORT_UNLOADING          := IN_MWB.PORT_UNLOADING;
    PFGA3950.SEL_PORT( OUT_TFJ301.PORT_UNLOADING, WK_PORT_NAME );
    OUT_TFJ301.PORT_UNLOADING_NAME     := WK_PORT_NAME;

    OUT_TFJ301.PORT_DEST               := IN_MWB.PORT_DEST;
    IF OUT_TFJ301.PORT_DEST = OUT_TFJ301.PORT_UNLOADING THEN
        OUT_TFJ301.PORT_DEST_NAME      := OUT_TFJ301.PORT_UNLOADING_NAME;
    ELSE
        PFGA3950.SEL_PORT( OUT_TFJ301.PORT_DEST, WK_PORT_NAME );
        OUT_TFJ301.PORT_DEST_NAME      := WK_PORT_NAME;
    END IF;

    IF OUT_TFJ301.ETRANS_MODE = 'O' THEN      -- OCEAN
        IF OUT_TFJ301.PLACE_OF_RECEIPT IS NULL THEN
            OUT_TFJ301.PLACE_OF_RECEIPT        := OUT_TFJ301.PORT_ORIGIN;
            OUT_TFJ301.PLACE_OF_RECEIPT_NAME   := OUT_TFJ301.PORT_ORIGIN_NAME;
        END IF;
        IF OUT_TFJ301.PLACE_OF_DELIVERY IS NULL THEN
            OUT_TFJ301.PLACE_OF_DELIVERY       := OUT_TFJ301.PORT_DEST;
            OUT_TFJ301.PLACE_OF_DELIVERY_NAME  := OUT_TFJ301.PORT_DEST_NAME;
        END IF;
    END IF;
    OUT_TFJ301.FINAL_DESTINATION       := IN_MWB.FINAL_DESTINATION;
    OUT_TFJ301.PORT_CC_EXPORT          := IN_MWB.PORT_CC;
    OUT_TFJ301.PORT_CC_IMPORT          := IN_MWB.PORT_CC_IMPORT;
--
    OUT_TFJ301.ORIG_COMPANY_ID         := IN_MWB.ORIG_COMPANY_ID;
    OUT_TFJ301.ORIG_SUBSIDIARY_ID      := IN_MWB.ORIG_SUBSIDIARY_ID;
    OUT_TFJ301.ORIG_TERMINAL_ID        := IN_MWB.ORIG_TERMINAL_ID;
    OUT_TFJ301.ORIG_DEPARTMENT_ID      := IN_MWB.ORIG_DEPARTMENT_ID;
    OUT_TFJ301.ORIG_AREA_CODE          := IN_MWB.ORIG_AREA_CODE;
    OUT_TFJ301.ORIG_REGION_CODE        := IN_MWB.ORIG_REGION_CODE;
    OUT_TFJ301.ORIG_COUNTRY_CODE       := IN_MWB.ORIG_COUNTRY_CODE;
    OUT_TFJ301.ORIG_IATA_TC_CODE       := IN_MWB.ORIG_IATA_TC_CODE;
    IF OUT_TFJ301.ORIG_COUNTRY_CODE IS NULL OR
       OUT_TFJ301.ORIG_IATA_TC_CODE IS NULL THEN
        -- PORT's COUNTRY ����
        PFGA3950.SEL_PORT_COUNTRY( OUT_TFJ301.PORT_ORIGIN,
                          WK_COUNTRY_CODE,
                          WK_IATA_CONFERENCE_CODE );
        IF OUT_TFJ301.ORIG_COUNTRY_CODE IS NULL THEN
            OUT_TFJ301.ORIG_COUNTRY_CODE := WK_COUNTRY_CODE;
        END IF;
        IF OUT_TFJ301.ORIG_IATA_TC_CODE IS NULL THEN
            OUT_TFJ301.ORIG_IATA_TC_CODE := WK_IATA_CONFERENCE_CODE;
        END IF;
    END IF;
    OUT_TFJ301.ORIG_POLAR_REGION_A_CODE
                                       := IN_MWB.ORIG_POLAR_REGION_A_CODE;
    OUT_TFJ301.ORIG_POLAR_REGION_B_CODE
                                       := IN_MWB.ORIG_POLAR_REGION_B_CODE;
--
    OUT_TFJ301.DEST_COMPANY_ID         := IN_MWB.DEST_COMPANY_ID;
    OUT_TFJ301.DEST_SUBSIDIARY_ID      := IN_MWB.DEST_SUBSIDIARY_ID;
    OUT_TFJ301.DEST_TERMINAL_ID        := IN_MWB.DEST_TERMINAL_ID;
    OUT_TFJ301.DEST_DEPARTMENT_ID      := IN_MWB.DEST_DEPARTMENT_ID;
    OUT_TFJ301.DEST_AREA_CODE          := IN_MWB.DEST_AREA_CODE;
    OUT_TFJ301.DEST_REGION_CODE        := IN_MWB.DEST_REGION_CODE;
    OUT_TFJ301.DEST_COUNTRY_CODE       := IN_MWB.DEST_COUNTRY_CODE;
    OUT_TFJ301.DEST_IATA_TC_CODE       := IN_MWB.DEST_IATA_TC_CODE;
    IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL OR
       OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
        -- PORT's COUNTRY ����
        PFGA3950.SEL_PORT_COUNTRY( OUT_TFJ301.PORT_DEST,
                                   WK_COUNTRY_CODE,
                                   WK_IATA_CONFERENCE_CODE );
        IF OUT_TFJ301.DEST_COUNTRY_CODE IS NULL THEN
            OUT_TFJ301.DEST_COUNTRY_CODE := WK_COUNTRY_CODE;
        END IF;
        IF OUT_TFJ301.DEST_IATA_TC_CODE IS NULL THEN
            OUT_TFJ301.DEST_IATA_TC_CODE := WK_IATA_CONFERENCE_CODE;
        END IF;
    END IF;
    OUT_TFJ301.DEST_POLAR_REGION_A_CODE
                                       := IN_MWB.DEST_POLAR_REGION_A_CODE;
    OUT_TFJ301.DEST_POLAR_REGION_B_CODE
                                       := IN_MWB.DEST_POLAR_REGION_B_CODE;
--
    OUT_TFJ301.NATURE_OF_GOODS         := DEL_CRLF( IN_MWB.NATURE_OF_GOODS );
--
    OUT_TFJ301.NUM_PIECES              := IN_MWB.NUM_PIECES;
    OUT_TFJ301.NUM_PIECES_UOM_CODE     := IN_MWB.PACKAGING_FORM_CODE;
    OUT_TFJ301.CHARGEABLE_WEIGHT       := IN_MWB.CHARGEABLE_WEIGHT;
    OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE
                                       := IN_MWB.WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_ACTUAL_WEIGHT     := IN_MWB.GROSS_WEIGHT;
    OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE  := IN_MWB.GROSS_WEIGHT_UOM_CODE;
    OUT_TFJ301.TOTAL_VOLUME            := IN_MWB.VOLUME;
    OUT_TFJ301.VOLUME_UOM_CODE         := IN_MWB.VOLUME_UOM_CODE;
    OUT_TFJ301.TOTAL_VOLUME_WEIGHT     := IN_MWB.VOLUME_WEIGHT;
    OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE  := IN_MWB.VOLUME_WEIGHT_UOM_CODE;
--
    WK_CONTAINER_NUM                   := NULL;
    WK_CONTAINER_TYPE                  := NULL;
    WK_CONTAINER_20FT                  := 0;
    WK_CONTAINER_40FT                  := 0;
    WK_CONTAINER_ETC                   := 0;
    -- SERVICE_TYPE��FCL�̎�
    IF IN_MWB.SERVICE_TYPE = 'FCL' THEN
        -- CONTAINER_TYPE���Ƃ̏W�v
        PFGA3950.SUM_NUM_PIECES_MWB( IN_MWB.PIPELINE_TX_ID,
                                     WK_CONTAINER_NUM,           --  2004.10.06
                                     WK_CONTAINER_TYPE,          --  2004.10.06
                                     WK_CONTAINER_20FT,
                                     WK_CONTAINER_40FT,
                                     WK_CONTAINER_ETC );
    END IF;
    OUT_TFJ301.CONTAINER_NUM           := WK_CONTAINER_NUM;
    OUT_TFJ301.CONTAINER_TYPE          := WK_CONTAINER_TYPE;
    OUT_TFJ301.CONTAINER_20FT          := WK_CONTAINER_20FT;
    OUT_TFJ301.CONTAINER_40FT          := WK_CONTAINER_40FT;
    OUT_TFJ301.CONTAINER_ETC           := WK_CONTAINER_ETC;
--
    OUT_TFJ301.FREIGHT_PPC_IND         := TRIM(IN_MWB.FREIGHT_PPC_IND);
    OUT_TFJ301.OTHER_PPC_IND           := TRIM(IN_MWB.OTHER_PPC_IND);
--    OUT_TFJ301.DEST_PPC_IND            := ;
--
--    OUT_TFJ301.OC_CURRENCY_CODE        := ;
    OUT_TFJ301.ORIG_CURRENCY_CODE      := IN_MWB.LOCAL_CURRENCY_CODE;
    OUT_TFJ301.DEST_CURRENCY_CODE      := IN_MWB.DEST_CURRENCY_CODE;
--    OUT_TFJ301.INVOICE_CURRENCY_CODE   := ;
--
    OUT_TFJ301.DEST_EXCHANGE_RATE      := IN_MWB.DEST_EXCHANGE_RATE;
--    OUT_TFJ301.INVOICE_EXCHANGE_RATE   := ;
--
    OUT_TFJ301.PPD_FREIGHT_AMT         := NVL(IN_MWB.PPD_FREIGHT_AMT,0);
    OUT_TFJ301.PPD_OTHER_AMT           := NVL(IN_MWB.PPD_OTHER_AMT,0);
    OUT_TFJ301.PPD_VALUATION_AMT       := NVL(IN_MWB.PPD_VALUATION_AMT,0);
    OUT_TFJ301.PPD_TAX_AMT             := NVL(IN_MWB.PPD_TAX_AMT,0);
    OUT_TFJ301.PPD_DUE_AGENT_AMT       := NVL(IN_MWB.PPD_DUE_AGENT_AMT,0);
    OUT_TFJ301.PPD_DUE_CARRIER_AMT     := NVL(IN_MWB.PPD_DUE_CARRIER_AMT,0);
    OUT_TFJ301.TOT_PPD_AMT             := NVL(IN_MWB.TOT_PPD_AMT,0);
    OUT_TFJ301.COLL_FREIGHT_AMT        := NVL(IN_MWB.COLL_FREIGHT_AMT,0);
    OUT_TFJ301.COLL_OTHER_AMT          := NVL(IN_MWB.COLL_OTHER_AMT,0);
    OUT_TFJ301.COLL_VALUATION_AMT      := NVL(IN_MWB.COLL_VALUATION_AMT,0);
    OUT_TFJ301.COLL_TAX_AMT            := NVL(IN_MWB.COLL_TAX_AMT,0);
    OUT_TFJ301.COLL_DUE_AGENT_AMT      := NVL(IN_MWB.COLL_DUE_AGENT_AMT,0);
    OUT_TFJ301.COLL_DUE_CARRIER_AMT    := NVL(IN_MWB.COLL_DUE_CARRIER_AMT,0);
    OUT_TFJ301.TOT_COLL_AMT            := NVL(IN_MWB.TOT_COLL_AMT,0);
--
    OUT_TFJ301.OC_PPD_FREIGHT_AMT      := NVL(IN_MWB.OC_PPD_FREIGHT_AMT,0);
    OUT_TFJ301.OC_PPD_OTHER_AMT        := NVL(IN_MWB.OC_PPD_OTHER_AMT,0);
    OUT_TFJ301.OC_PPD_VALUATION_AMT    := NVL(IN_MWB.OC_PPD_VALUATION_AMT,0);
    OUT_TFJ301.OC_PPD_TAX_AMT          := NVL(IN_MWB.OC_PPD_TAX_AMT,0);
    OUT_TFJ301.OC_PPD_DUE_AGENT_AMT    := NVL(IN_MWB.OC_PPD_DUE_AGENT_AMT,0);
    OUT_TFJ301.OC_PPD_DUE_CARRIER_AMT  := NVL(IN_MWB.OC_PPD_DUE_CARRIER_AMT,0);
    OUT_TFJ301.OC_TOT_PPD_AMT          := NVL(IN_MWB.OC_TOT_PPD_AMT,0);
    OUT_TFJ301.OC_COLL_FREIGHT_AMT     := NVL(IN_MWB.OC_COLL_FREIGHT_AMT,0);
    OUT_TFJ301.OC_COLL_OTHER_AMT       := NVL(IN_MWB.OC_COLL_OTHER_AMT,0);
    OUT_TFJ301.OC_COLL_VALUATION_AMT   := NVL(IN_MWB.OC_COLL_VALUATION_AMT,0);
    OUT_TFJ301.OC_COLL_TAX_AMT         := NVL(IN_MWB.OC_COLL_TAX_AMT,0);
    OUT_TFJ301.OC_COLL_DUE_AGENT_AMT   := NVL(IN_MWB.OC_COLL_DUE_AGENT_AMT,0);
    OUT_TFJ301.OC_COLL_DUE_CARRIER_AMT := NVL(IN_MWB.OC_COLL_DUE_CARRIER_AMT,0);
    OUT_TFJ301.OC_TOT_COLL_AMT         := NVL(IN_MWB.OC_TOT_COLL_AMT,0);
--
    -- Shipper
    PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                             'S',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.SHIPPER_ID              := WK_PARTNER_ID;
    OUT_TFJ301.SHIPPER_NAME            := IN_MWB.SHIPPER_NAME;

    PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_ID,
                          DMY_PARENT_PARTNER_ID,
                          WK_PARTNER_NAME,
                          WK_LL_PARTNER_NAME,
                          DMY_PARTNER_SHORT_NAME,
                          WK_INDUSTRY_CODE,
                          WK_INDUSTRY_NAME );
    OUT_TFJ301.LL_SHIPPER_NAME         := WK_LL_PARTNER_NAME;
    OUT_TFJ301.SHIPPER_PARENT_ID       := WK_PARENT_PARTNER_ID;
    OUT_TFJ301.SHIPPER_GROUP_ID        := WK_PARTNER_GROUP_CODE;
    -- JPAEX �ǉ�                                        2005.04.10
    OUT_TFJ301.SHIPPER_INDUSTRY_CODE   := WK_INDUSTRY_CODE;
    OUT_TFJ301.SHIPPER_INDUSTRY_NAME   := WK_INDUSTRY_NAME;

    IF OUT_TFJ301.SHIPPER_PARENT_ID IS NULL OR
       OUT_TFJ301.SHIPPER_PARENT_ID = '!'   THEN
        OUT_TFJ301.SHIPPER_PARENT_NAME     := NULL;
        OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := NULL;
    ELSE
        PFGA3950.SEL_PARTNER( OUT_TFJ301.SHIPPER_PARENT_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.SHIPPER_PARENT_NAME     := WK_PARTNER_NAME;
        OUT_TFJ301.LL_SHIPPER_PARENT_NAME  := WK_LL_PARTNER_NAME;
    END IF;
    OUT_TFJ301.SHIPPER_ADDRESS_NO      := IN_MWB.SHIPPER_ADDRESS_NO;

    PFGA3950.SEL_ADDRESS( OUT_TFJ301.SHIPPER_ADDRESS_NO, WK_ADDRESS );
    OUT_TFJ301.SHIPPER_ADDRESS1        := WK_ADDRESS.ADDRESS_1;
    OUT_TFJ301.SHIPPER_ADDRESS2        := WK_ADDRESS.ADDRESS_2;
    OUT_TFJ301.SHIPPER_ADDRESS3        := WK_ADDRESS.ADDRESS_3;
    OUT_TFJ301.SHIPPER_ADDRESS4        := WK_ADDRESS.ADDRESS_4;
    OUT_TFJ301.SHIPPER_ADDRESS5        := WK_ADDRESS.ADDRESS_5;
    OUT_TFJ301.LL_SHIPPER_ADDRESS1     := WK_ADDRESS.LL_ADDRESS_1;
    OUT_TFJ301.LL_SHIPPER_ADDRESS2     := WK_ADDRESS.LL_ADDRESS_2;
    OUT_TFJ301.LL_SHIPPER_ADDRESS3     := WK_ADDRESS.LL_ADDRESS_3;
    OUT_TFJ301.LL_SHIPPER_ADDRESS4     := WK_ADDRESS.LL_ADDRESS_4;
    OUT_TFJ301.LL_SHIPPER_ADDRESS5     := WK_ADDRESS.LL_ADDRESS_5;
    OUT_TFJ301.SHIPPER_CITY_NAME       := WK_ADDRESS.CITY_NAME;
    OUT_TFJ301.LL_SHIPPER_CITY_NAME    := WK_ADDRESS.LL_CITY_NAME;
    OUT_TFJ301.SHIPPER_REGION_CODE     := WK_ADDRESS.REGION_CODE;
    OUT_TFJ301.SHIPPER_POSTAL_CODE     := WK_ADDRESS.POSTAL_CODE;
    OUT_TFJ301.SHIPPER_COUNTRY_CODE    := WK_ADDRESS.COUNTRY_CODE;
    OUT_TFJ301.SHIPPER_CONTACT_NO      := IN_MWB.SHIPPER_CONTACT_NO;
    -- JPAEX �ǉ�                                        2005.04.10
    OUT_TFJ301.SHIPPER_REGION_NAME     := WK_ADDRESS.REGION_NAME;

-- 2005.04.17 Master��CONTACT�͕K�v�Ȃ�
--    IF OUT_TFJ301.SHIPPER_CONTACT_NO IS NOT NULL THEN
--        PFGA3950.SEL_CONTACT( OUT_TFJ301.SHIPPER_CONTACT_NO, WK_CONTACT );
--        OUT_TFJ301.SHIPPER_CONTACT_NAME    := WK_CONTACT.LAST_NAME;
--        OUT_TFJ301.LL_SHIPPER_CONTACT_NAME := WK_CONTACT.LL_NAME;
--        OUT_TFJ301.SHIPPER_CONTACT_PHONE   := WK_CONTACT.PHONE_NO;
--        OUT_TFJ301.SHIPPER_CONTACT_FAX     := WK_CONTACT.FAX_NO;
--        OUT_TFJ301.SHIPPER_CONTACT_EMAIL   := WK_CONTACT.EMAIL_ID;
--    END IF;
--
    -- Consignee
    PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                             'C',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ301.CNEE_ID                 := WK_PARTNER_ID;
    OUT_TFJ301.CNEE_NAME               := IN_MWB.CNEE_NAME;

    PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_ID,
                          DMY_PARENT_PARTNER_ID,
                          WK_PARTNER_NAME,
                          WK_LL_PARTNER_NAME,
                          DMY_PARTNER_SHORT_NAME,
                          WK_INDUSTRY_CODE,
                          WK_INDUSTRY_NAME );
    OUT_TFJ301.LL_CNEE_NAME            := WK_LL_PARTNER_NAME;
    OUT_TFJ301.CNEE_PARENT_ID          := WK_PARENT_PARTNER_ID;
    OUT_TFJ301.CNEE_GROUP_ID           := WK_PARTNER_GROUP_CODE;

    IF OUT_TFJ301.CNEE_PARENT_ID IS NULL OR
       OUT_TFJ301.CNEE_PARENT_ID = '!'   THEN
        OUT_TFJ301.CNEE_PARENT_NAME     := NULL;
        OUT_TFJ301.LL_CNEE_PARENT_NAME  := NULL;
    ELSE
        PFGA3950.SEL_PARTNER( OUT_TFJ301.CNEE_PARENT_ID,
                              DMY_PARENT_PARTNER_ID,
                              WK_PARTNER_NAME,
                              WK_LL_PARTNER_NAME,
                              DMY_PARTNER_SHORT_NAME,
                              WK_INDUSTRY_CODE,
                              WK_INDUSTRY_NAME );
        OUT_TFJ301.CNEE_PARENT_NAME     := WK_PARTNER_NAME;
        OUT_TFJ301.LL_CNEE_PARENT_NAME  := WK_LL_PARTNER_NAME;
    END IF;
    OUT_TFJ301.CNEE_ADDRESS_NO         := IN_MWB.CNEE_ADDRESS_NO;

    PFGA3950.SEL_ADDRESS( OUT_TFJ301.CNEE_ADDRESS_NO, WK_ADDRESS );
    OUT_TFJ301.CNEE_ADDRESS1           := WK_ADDRESS.ADDRESS_1;
    OUT_TFJ301.CNEE_ADDRESS2           := WK_ADDRESS.ADDRESS_2;
    OUT_TFJ301.CNEE_ADDRESS3           := WK_ADDRESS.ADDRESS_3;
    OUT_TFJ301.CNEE_ADDRESS4           := WK_ADDRESS.ADDRESS_4;
    OUT_TFJ301.CNEE_ADDRESS5           := WK_ADDRESS.ADDRESS_5;
    OUT_TFJ301.LL_CNEE_ADDRESS1        := WK_ADDRESS.LL_ADDRESS_1;
    OUT_TFJ301.LL_CNEE_ADDRESS2        := WK_ADDRESS.LL_ADDRESS_2;
    OUT_TFJ301.LL_CNEE_ADDRESS3        := WK_ADDRESS.LL_ADDRESS_3;
    OUT_TFJ301.LL_CNEE_ADDRESS4        := WK_ADDRESS.LL_ADDRESS_4;
    OUT_TFJ301.LL_CNEE_ADDRESS5        := WK_ADDRESS.LL_ADDRESS_5;
    OUT_TFJ301.CNEE_CITY_NAME          := WK_ADDRESS.CITY_NAME;
    OUT_TFJ301.LL_CNEE_CITY_NAME       := WK_ADDRESS.LL_CITY_NAME;
    OUT_TFJ301.CNEE_REGION_CODE        := WK_ADDRESS.REGION_CODE;
    OUT_TFJ301.CNEE_POSTAL_CODE        := WK_ADDRESS.POSTAL_CODE;
    OUT_TFJ301.CNEE_COUNTRY_CODE       := WK_ADDRESS.COUNTRY_CODE;
    OUT_TFJ301.CNEE_CONTACT_NO         := IN_MWB.CNEE_CONTACT_NO;

-- 2005.04.17 Master��CONTACT�͕K�v�Ȃ�
--    IF OUT_TFJ301.CNEE_CONTACT_NO IS NOT NULL THEN
--        PFGA3950.SEL_CONTACT( OUT_TFJ301.CNEE_CONTACT_NO, WK_CONTACT );
--        OUT_TFJ301.CNEE_CONTACT_NAME       := WK_CONTACT.LAST_NAME;
--        OUT_TFJ301.LL_CNEE_CONTACT_NAME    := WK_CONTACT.LL_NAME;
--        OUT_TFJ301.CNEE_CONTACT_PHONE      := WK_CONTACT.PHONE_NO;
--        OUT_TFJ301.CNEE_CONTACT_FAX        := WK_CONTACT.FAX_NO;
--        OUT_TFJ301.CNEE_CONTACT_EMAIL      := WK_CONTACT.EMAIL_ID;
--    END IF;
--
    -- Notify
    IF IN_MWB.NOTIFY_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                                 'NO',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.NOTIFY_ID           := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.NOTIFY_ID           := '!';
    END IF;
    OUT_TFJ301.NOTIFY_NAME             := IN_MWB.NOTIFY_NAME;
    OUT_TFJ301.NOTIFY_ADDRESS_NO       := IN_MWB.NOTIFY_ADDRESS_NO;
    OUT_TFJ301.NOTIFY_CONTACT_NO       := IN_MWB.NOTIFY_CONTACT_NO;
--
    -- Bill To
    IF IN_MWB.BILLTO_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                                 'BT',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.BILLTO_ID           := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.BILLTO_ID           := '!';
    END IF;
    OUT_TFJ301.BILLTO_NAME             := IN_MWB.BILLTO_NAME;
    OUT_TFJ301.BILLTO_ADDRESS_NO       := IN_MWB.BILLTO_ADDRESS_NO;
    OUT_TFJ301.BILLTO_CONTACT_NO       := IN_MWB.BILLTO_CONTACT_NO;
--
    -- Collect Charge Payable To
    IF IN_MWB.PTYTOCNT_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                                 'PT',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.PTYTOCNT_ID         := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.PTYTOCNT_ID         := '!';
    END IF;
    OUT_TFJ301.PTYTOCNT_NAME           := IN_MWB.PTYTOCNT_NAME;
    OUT_TFJ301.PTYTOCNT_ADDRESS_NO     := IN_MWB.PTYTOCNT_ADDRESS_NO;
    OUT_TFJ301.PTYTOCNT_CONTACT_NO     := IN_MWB.PTYTOCNT_CONTACT_NO;
--
    -- Location of Freight
    IF IN_MWB.LOCFREIGHT_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                                 'LOF',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.LOCFREIGHT_ID       := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.LOCFREIGHT_ID       := '!';
    END IF;
    OUT_TFJ301.LOCFREIGHT_NAME         := IN_MWB.LOCFREIGHT_NAME;
    OUT_TFJ301.LOCFREIGHT_ADDRESS_NO   := IN_MWB.LOCFREIGHT_ADDRESS_NO;
    OUT_TFJ301.LOCFREIGHT_CONTACT_NO   := IN_MWB.LOCFREIGHT_CONTACT_NO;
--
    -- Destantion Broker
    IF IN_MWB.DEST_BROKER_NAME IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_ID( IN_MWB.PIPELINE_TX_ID,
                                 'B',
                                 WK_PARTNER_ID,
                                 WK_PARENT_PARTNER_ID,
                                 WK_PARTNER_GROUP_CODE );
        OUT_TFJ301.DEST_BROKER_ID      := WK_PARTNER_ID;
    ELSE
        OUT_TFJ301.DEST_BROKER_ID      := '!';
    END IF;
    OUT_TFJ301.DEST_BROKER_NAME        := IN_MWB.DEST_BROKER_NAME;
    OUT_TFJ301.DEST_BROKER_ADDRESS_NO  := IN_MWB.DEST_BROKER_ADDRESS_NO;
    OUT_TFJ301.DEST_BROKER_CONTACT_NO  := IN_MWB.DEST_BROKER_CONTACT_NO;
--
    -- MWB Orign Agent
    OUT_TFJ301.ORIG_AGENT_ID           := IN_MWB.ORIG_AGENT_ID;
    OUT_TFJ301.ORIG_AGENT_NAME         := IN_MWB.ORIG_AGENT_NAME;
    OUT_TFJ301.ORIG_AGENT_ADDRESS_NO   := IN_MWB.ORIG_AGENT_ADDRESS_NO;
    OUT_TFJ301.ORIG_AGENT_CONTACT_NO   := IN_MWB.ORIG_AGENT_CONTACT_NO;
    -- MWB Dest Agent
    OUT_TFJ301.DEST_AGENT_ID           := IN_MWB.DEST_AGENT_ID;
    OUT_TFJ301.DEST_AGENT_NAME         := IN_MWB.DEST_AGENT_NAME;
    OUT_TFJ301.DEST_AGENT_ADDRESS_NO   := IN_MWB.DEST_AGENT_ADDRESS_NO;
    OUT_TFJ301.DEST_AGENT_CONTACT_NO   := IN_MWB.DEST_AGENT_CONTACT_NO;

    IF IN_MWB.COMMCODE_RECORD_ID IS NOT NULL THEN
        -- COMMODITY_CODE ���� 2005.05.15
        PFGA3950.SEL_COMMODITY_CODE( IN_MWB.COMMCODE_RECORD_ID,
                                     WK_COMMODITY_CODE,
                                     WK_COMMODITY_DESCRIPTION,
                                     WK_COMMODITY_TYPE );
        OUT_TFJ301.COMMODITY_CODE        := WK_COMMODITY_CODE;
        OUT_TFJ301.COMMODITY_DESCRIPTION := WK_COMMODITY_DESCRIPTION;
        OUT_TFJ301.COMMODITY_TYPE        := WK_COMMODITY_TYPE;
    END IF;

    -- Freight Rate                             2004.10.02
    OUT_TFJ301.MPR_PORT_ORIGIN          := IN_MWB.MPR_PORT_ORIGIN1;
    OUT_TFJ301.MPR_PORT_DEST            := IN_MWB.MPR_PORT_DEST1;
    OUT_TFJ301.MPR_RATE                 := IN_MWB.MPR_RATE1;
    OUT_TFJ301.MPR_CURRENCY_CODE        := IN_MWB.MPR_CURRENCY_CODE1;
    OUT_TFJ301.MPR_AMT                  := IN_MWB.MPR_AMT1;
    OUT_TFJ301.MPR_EXCHANGE_RATE        := IN_MWB.MPR_EXCHANGE_RATE1;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME    := IN_MWB.MPR_RATE_PROFILE_NAME1;
    -- Freight Rate                             2005.05.15
    OUT_TFJ301.MPR_PORT_ORIGIN2         := IN_MWB.MPR_PORT_ORIGIN2;
    OUT_TFJ301.MPR_PORT_DEST2           := IN_MWB.MPR_PORT_DEST2;
    OUT_TFJ301.MPR_RATE2                := IN_MWB.MPR_RATE2;
    OUT_TFJ301.MPR_CURRENCY_CODE2       := IN_MWB.MPR_CURRENCY_CODE2;
    OUT_TFJ301.MPR_AMT2                 := IN_MWB.MPR_AMT2;
    OUT_TFJ301.MPR_EXCHANGE_RATE2       := IN_MWB.MPR_EXCHANGE_RATE2;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME2   := IN_MWB.MPR_RATE_PROFILE_NAME2;
    OUT_TFJ301.MPR_PORT_ORIGIN3         := IN_MWB.MPR_PORT_ORIGIN3;
    OUT_TFJ301.MPR_PORT_DEST3           := IN_MWB.MPR_PORT_DEST3;
    OUT_TFJ301.MPR_RATE3                := IN_MWB.MPR_RATE3;
    OUT_TFJ301.MPR_CURRENCY_CODE3       := IN_MWB.MPR_CURRENCY_CODE3;
    OUT_TFJ301.MPR_AMT3                 := IN_MWB.MPR_AMT3;
    OUT_TFJ301.MPR_EXCHANGE_RATE3       := IN_MWB.MPR_EXCHANGE_RATE3;
    OUT_TFJ301.MPR_RATE_PROFILE_NAME3   := IN_MWB.MPR_RATE_PROFILE_NAME3;
--    OUT_TFJ301.RATE_CLASS_CODE

    -- IATA Freight Rate                        2005.05.15
    OUT_TFJ301.TRV_MPR_RATE               := IN_MWB.TRV_MPR_RATE1;
    OUT_TFJ301.TRV_MPR_CURRENCY_CODE      := IN_MWB.TRV_MPR_CURRENCY_CODE1;
    OUT_TFJ301.TRV_MPR_AMT                := IN_MWB.TRV_MPR_AMT1;
    OUT_TFJ301.TRV_MPR_EXCHANGE_RATE      := IN_MWB.TRV_MPR_EXCHANGE_RATE1;
    OUT_TFJ301.TRV_MPR_RATE_PROFILE_NAME  := IN_MWB.TRV_MPR_RATE_PROFILE_NAME1;
    OUT_TFJ301.TRV_MPR_RATE2              := IN_MWB.TRV_MPR_RATE2;
    OUT_TFJ301.TRV_MPR_CURRENCY_CODE2     := IN_MWB.TRV_MPR_CURRENCY_CODE2;
    OUT_TFJ301.TRV_MPR_AMT2               := IN_MWB.TRV_MPR_AMT2;
    OUT_TFJ301.TRV_MPR_EXCHANGE_RATE2     := IN_MWB.TRV_MPR_EXCHANGE_RATE2;
    OUT_TFJ301.TRV_MPR_RATE_PROFILE_NAME2 := IN_MWB.TRV_MPR_RATE_PROFILE_NAME2;
    OUT_TFJ301.TRV_MPR_RATE3              := IN_MWB.TRV_MPR_RATE3;
    OUT_TFJ301.TRV_MPR_CURRENCY_CODE3     := IN_MWB.TRV_MPR_CURRENCY_CODE3;
    OUT_TFJ301.TRV_MPR_AMT3               := IN_MWB.TRV_MPR_AMT3;
    OUT_TFJ301.TRV_MPR_EXCHANGE_RATE3     := IN_MWB.TRV_MPR_EXCHANGE_RATE3;
    OUT_TFJ301.TRV_MPR_RATE_PROFILE_NAME3 := IN_MWB.TRV_MPR_RATE_PROFILE_NAME3;

    -- COMMISION                                2004.10.02
    OUT_TFJ301.COMMISSION_CURRENCY_CODE := IN_MWB.COMMISSION_CURRENCY_CODE;
    OUT_TFJ301.COMMISSION_STD_PCT       := IN_MWB.COMMISSION_STD_PCT;
    OUT_TFJ301.COMMISSION_STD_AMT       := IN_MWB.COMMISSION_STD_AMT;
    OUT_TFJ301.COMMISSION_ADDTL_PCT     := IN_MWB.COMMISSION_ADDTL_PCT;
    OUT_TFJ301.COMMISSION_ADDTL_AMT     := IN_MWB.COMMISSION_ADDTL_AMT;
    OUT_TFJ301.COMMISSION_OVERRIDE_PCT  := IN_MWB.COMMISSION_OVERRIDE_PCT;
    OUT_TFJ301.COMMISSION_OVERRIDE_AMT  := IN_MWB.COMMISSION_OVERRIDE_AMT;


    -- Borrow In/Out�̑Ή�                      2004.10.07
    OUT_TFJ301.BORROW_IND               := TRIM(IN_MWB.BORROW_IND);
    OUT_TFJ301.BORROW_VENDOR_NAME       := IN_MWB.BORROW_VENDOR_NAME;
    OUT_TFJ301.BORROW_VENDOR_ADDRESS_NO := IN_MWB.BORROW_VENDOR_ADDRESS_NO;
    OUT_TFJ301.BORROW_VENDOR_INVOICE_NO := IN_MWB.BORROW_VENDOR_INVOICE_NO;
--
    -- UAS IF�f�[�^����TAX_AMT(LOCAL_INVOICE_AMT)�擾    2004.10.17
    GET_LOCAL_INVOICE_AMT( IN_TFJ201.PIPELINE_TX_ID,
                           OUT_TFJ301.TAX_AMT );

    -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
    WK_WT_UOM_CODE := 'KG';
    WK_M3_UOM_CODE := 'CBM';
    WK_RT_UOM_CODE := 'CBM';
    WK_WT_RND := 1;
    WK_M3_RND := 3;
    WK_RT_RND := 3;

    IF OUT_TFJ301.ETRANS_MODE  = 'A'  THEN   -- Air
        OUT_TFJ301.ACTUAL_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_ACTUAL_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.CHARGEABLE_WEIGHT_KG := ROUND(OUT_TFJ301.CHARGEABLE_WEIGHT   * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.VOLUME_CBM           := ROUND(OUT_TFJ301.TOTAL_VOLUME        * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_UOM_CODE,WK_M3_UOM_CODE)
                                                 ,WK_M3_RND);
        OUT_TFJ301.VOLUME_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_VOLUME_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
    ELSE
        OUT_TFJ301.ACTUAL_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_ACTUAL_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.ACTUAL_WEIGHT_UOM_CODE,WK_WT_UOM_CODE)
                                                 ,WK_WT_RND);
        OUT_TFJ301.CHARGEABLE_WEIGHT_KG := ROUND(OUT_TFJ301.CHARGEABLE_WEIGHT   * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,WK_RT_UOM_CODE)
                                                 ,WK_RT_RND);
        OUT_TFJ301.VOLUME_CBM           := ROUND(OUT_TFJ301.TOTAL_VOLUME        * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_UOM_CODE,WK_M3_UOM_CODE)
                                                 ,WK_M3_RND);
        OUT_TFJ301.VOLUME_WEIGHT_KG     := ROUND(OUT_TFJ301.TOTAL_VOLUME_WEIGHT * PFGA3950.SEL_UOM_CONVERSION
                                                (OUT_TFJ301.VOLUME_WEIGHT_UOM_CODE,WK_RT_UOM_CODE)
                                                 ,WK_RT_RND);
    END IF;

    -- ���і��ׁA�R�[�h�E���̕ҏW
    SET_TFJ301_CODENAME( OUT_TFJ301, IN_TFJ201 );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- UAS IF�f�[�^����LOCAL_INVOICE_AMT�擾 2004.10.17
--================================================
PROCEDURE GET_LOCAL_INVOICE_AMT(
    IN_PIPELINE_TX_ID      IN      TFJ201.PIPELINE_TX_ID%TYPE,
    OUT_LOCAL_INVOICE_AMT  IN OUT  TFJ201.LOCAL_INVOICE_AMT%TYPE )
IS
    CURSOR CUR_TFJ201( KEY_PIPELINE_TX_ID   TFJ201.PIPELINE_TX_ID%TYPE ) IS
      SELECT SUM(LOCAL_INVOICE_AMT) AS TAX_AMT
      FROM TFJ201
      WHERE PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
        AND LINE_TYPE      = 'TAX'
      GROUP BY PIPELINE_TX_ID;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'GET_LOCAL_INVOICE_AMT' );

    OUT_LOCAL_INVOICE_AMT := 0;
    FOR WK_REC IN CUR_TFJ201( IN_PIPELINE_TX_ID ) LOOP
        OUT_LOCAL_INVOICE_AMT := WK_REC.TAX_AMT;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ201: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ���і��ׂ�V�K�쐬
--================================================
PROCEDURE INS_TFJ301(
    IN_TFJ301   IN  TFJ301%ROWTYPE )         -- ���і���
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'INS_TFJ301' );

    INSERT INTO TFJ301(
        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
        -- �j�d�x
        EDATKBN,
        PIPELINE_TX_ID,
        DGYMDTM,
        NGENNO,
        -- �R���g���[��
        ESISNKBN,
        NAKKBN,
        EDELKBN,
        ESKY_KBN,
        EOPE_KBN,
        EFWD_JTKBN,
        ETKN_JTKBN,
        ECOMPANY_ID,
        EIM_EX_IND,
        ETRANS_MODE,
        -- ���t
        DKJODTM,
        ORIGINAL_KJODTM,
        INVOICE_DATE,
        ORIGINAL_INVOICE_DATE,
        MWB_ISSUE_DATE,
        ISSUE_DATE,
        CONSOL_DATE,
        ISSUE_DATE_TO_PRINT,
        OBD_DATE_TO_PRINT,
        DEPARTURE_DATE,
        ARRIVAL_DATE,
        -- �ԍ�
        MWB_NO,
        HWB_NO,
        CONSOL_NO,
        INVOICE_NO,
        MWB_TX_ID,
        HWB_TX_ID,
        CONSOL_TX_ID,
        INVOICE_TX_ID,
--
        ETERMINAL_ID,
        EDEPARTMENT_ID,
        EOYA_ECNORCD,
        ECNORCD,
        EHBI_TNTCD,
        -- ����
        EOYA_ECNORNM,
        JOYA_ECNORNM,
        ECNORNM,
        JCNORNM,
        ETERMNM,
        JTERMNM,
        EDEPARTNM,
        JDEPARTNM,
        ETNTNM,
        JTNTNM,
--
        PIPELINE_TX_TYPE,
        PIPELINE_REF_TYPE,
        PIPELINE_TX_STATUS,
        TRANSPORT_MODE,
        SERVICE_TYPE,
        MOVEMENT_TYPE,
        CUSTOMER_SHIPMENT_TYPE,
        AGENT_TYPE,
        CONSOL_SERVICE_TYPE,
        DISPOSITION,
--
        CARRIER_CODE,
        CARRIER_NAME,
        FLIGHT_VOYAGE,
        VESSEL_NAME,
        CARRIER_TYPE,
--
        FREE_HOUSE_IND,
        LCL_CNSL_CARRIER_IND,
--
        PIPELINE_TX_DATE,
        TX_DATE_TZ_CODE,
--
        TRANSPORT_TERMS_CODE,
        SALES_TERMS_CODE,
        FREE_HOUSE_TERMS_CODE,
--
        IMPORT_SALESMAN_ID,
        EXPORT_SALESMAN_ID,
--
        PLACE_OF_RECEIPT,
        PLACE_OF_RECEIPT_NAME,
        PLACE_OF_DELIVERY,
        PLACE_OF_DELIVERY_NAME,
        PORT_ORIGIN,
        PORT_ORIGIN_NAME,
        PORT_LOADING,
        PORT_LOADING_NAME,
        PORT_UNLOADING,
        PORT_UNLOADING_NAME,
        PORT_DEST,
        PORT_DEST_NAME,
        FINAL_DESTINATION,
        PORT_CC_EXPORT,
        PORT_CC_IMPORT,
--
        ORIG_COMPANY_ID,
        ORIG_SUBSIDIARY_ID,
        ORIG_TERMINAL_ID,
        ORIG_DEPARTMENT_ID,
        ORIG_AREA_CODE,
        ORIG_REGION_CODE,
        ORIG_COUNTRY_CODE,
        ORIG_IATA_TC_CODE,
        ORIG_POLAR_REGION_A_CODE,
        ORIG_POLAR_REGION_B_CODE,
        DEST_COMPANY_ID,
        DEST_SUBSIDIARY_ID,
        DEST_TERMINAL_ID,
        DEST_DEPARTMENT_ID,
        DEST_AREA_CODE,
        DEST_REGION_CODE,
        DEST_COUNTRY_CODE,
        DEST_IATA_TC_CODE,
        DEST_POLAR_REGION_A_CODE,
        DEST_POLAR_REGION_B_CODE,
--
        NATURE_OF_GOODS,
--
        NUM_PIECES,
        NUM_PIECES_UOM_CODE,
        CHARGEABLE_WEIGHT,
        CHARGEABLE_WEIGHT_UOM_CODE,
        TOTAL_ACTUAL_WEIGHT,
        ACTUAL_WEIGHT_UOM_CODE,
        TOTAL_VOLUME,
        VOLUME_UOM_CODE,
        TOTAL_VOLUME_WEIGHT,
        VOLUME_WEIGHT_UOM_CODE,
--
        CONTAINER_20FT,
        CONTAINER_40FT,
        CONTAINER_ETC,
--
        FREIGHT_PPC_IND,
        OTHER_PPC_IND,
        DEST_PPC_IND,
--
        OC_CURRENCY_CODE,
        ORIG_CURRENCY_CODE,
        DEST_CURRENCY_CODE,
        INVOICE_CURRENCY_CODE,
--
        DEST_EXCHANGE_RATE,
        INVOICE_EXCHANGE_RATE,
--
        PPD_FREIGHT_AMT,
        PPD_OTHER_AMT,
        PPD_VALUATION_AMT,
        PPD_TAX_AMT,
        PPD_DUE_AGENT_AMT,
        PPD_DUE_CARRIER_AMT,
        TOT_PPD_AMT,
        COLL_FREIGHT_AMT,
        COLL_OTHER_AMT,
        COLL_VALUATION_AMT,
        COLL_TAX_AMT,
        COLL_DUE_AGENT_AMT,
        COLL_DUE_CARRIER_AMT,
        TOT_COLL_AMT,
--
        OC_PPD_FREIGHT_AMT,
        OC_PPD_OTHER_AMT,
        OC_PPD_VALUATION_AMT,
        OC_PPD_TAX_AMT,
        OC_PPD_DUE_AGENT_AMT,
        OC_PPD_DUE_CARRIER_AMT,
        OC_TOT_PPD_AMT,
        OC_COLL_FREIGHT_AMT,
        OC_COLL_OTHER_AMT,
        OC_COLL_VALUATION_AMT,
        OC_COLL_TAX_AMT,
        OC_COLL_DUE_AGENT_AMT,
        OC_COLL_DUE_CARRIER_AMT,
        OC_TOT_COLL_AMT,
--
        -- Shipper
        SHIPPER_ID,
        SHIPPER_NAME,
        LL_SHIPPER_NAME,
        SHIPPER_PARENT_ID,
        SHIPPER_GROUP_ID,
        SHIPPER_PARENT_NAME,
        LL_SHIPPER_PARENT_NAME,
        SHIPPER_ADDRESS_NO,
        SHIPPER_ADDRESS1,
        SHIPPER_ADDRESS2,
        SHIPPER_ADDRESS3,
        SHIPPER_ADDRESS4,
        SHIPPER_ADDRESS5,
        LL_SHIPPER_ADDRESS1,
        LL_SHIPPER_ADDRESS2,
        LL_SHIPPER_ADDRESS3,
        LL_SHIPPER_ADDRESS4,
        LL_SHIPPER_ADDRESS5,
        SHIPPER_CITY_NAME,
        LL_SHIPPER_CITY_NAME,
        SHIPPER_REGION_CODE,
        SHIPPER_POSTAL_CODE,
        SHIPPER_COUNTRY_CODE,
        SHIPPER_CONTACT_NO,
        SHIPPER_CONTACT_NAME,
        LL_SHIPPER_CONTACT_NAME,
        SHIPPER_CONTACT_PHONE,
        SHIPPER_CONTACT_FAX,
        SHIPPER_CONTACT_EMAIL,
--
        -- Consignee
        CNEE_ID,
        CNEE_NAME,
        LL_CNEE_NAME,
        CNEE_PARENT_ID,
        CNEE_GROUP_ID,
        CNEE_PARENT_NAME,
        LL_CNEE_PARENT_NAME,
        CNEE_ADDRESS_NO,
        CNEE_ADDRESS1,
        CNEE_ADDRESS2,
        CNEE_ADDRESS3,
        CNEE_ADDRESS4,
        CNEE_ADDRESS5,
        LL_CNEE_ADDRESS1,
        LL_CNEE_ADDRESS2,
        LL_CNEE_ADDRESS3,
        LL_CNEE_ADDRESS4,
        LL_CNEE_ADDRESS5,
        CNEE_CITY_NAME,
        LL_CNEE_CITY_NAME,
        CNEE_REGION_CODE,
        CNEE_POSTAL_CODE,
        CNEE_COUNTRY_CODE,
        CNEE_CONTACT_NO,
        CNEE_CONTACT_NAME,
        LL_CNEE_CONTACT_NAME,
        CNEE_CONTACT_PHONE,
        CNEE_CONTACT_FAX,
        CNEE_CONTACT_EMAIL,
--
        -- Notify
        NOTIFY_ID,
        NOTIFY_NAME,
        NOTIFY_ADDRESS_NO,
        NOTIFY_CONTACT_NO,
--
        -- BILLTO
        BILLTO_ID,
        BILLTO_NAME,
        BILLTO_ADDRESS_NO,
        BILLTO_CONTACT_NO,
--
        CONTROLLING_ID,
        CONTROLLING_NAME,
        CONTROLLING_ADDRESS_NO,
        CONTROLLING_CONTACT_NO,
        BILLTO2_ID,
        BILLTO2_NAME,
        BILLTO2_ADDRESS_NO,
        BILLTO2_CONTACT_NO,
        PTYTOCNT_ID,
        PTYTOCNT_NAME,
        PTYTOCNT_ADDRESS_NO,
        PTYTOCNT_CONTACT_NO,
        SETTLEMENT_AGENT_ID,
        SETTLEMENT_AGENT_NAME,
        SETTLEMENT_AGENT_ADDRESS_NO,
        SETTLEMENT_AGENT_CONTACT_NO,
        RECEIPT_LOCATION_CODE,
        CFS_RECEIPT_ID,
        CFS_RECEIPT_LOCATION_NAME,
        CFS_RECEIPT_ADDRESS_NO,
        CFS_RECEIPT_CONTACT_NO,
        CY_RECEIPT_ID,
        CY_RECEIPT_LOCATION_NAME,
        CY_RECEIPT_ADDRESS_NO,
        CY_RECEIPT_CONTACT_NO,
        LOCFREIGHT_ID,
        LOCFREIGHT_NAME,
        LOCFREIGHT_ADDRESS_NO,
        LOCFREIGHT_CONTACT_NO,
        DEST_BROKER_ID,
        DEST_BROKER_NAME,
        DEST_BROKER_ADDRESS_NO,
        DEST_BROKER_CONTACT_NO,
        IMPORT_BILLTO_ID,
        IMPORT_BILLTO_NAME,
        IMPORT_BILLTO_ADDRESS_NO,
        IMPORT_BILLTO_CONTACT_NO,
--
        ORIG_AGENT_ID,
        ORIG_AGENT_NAME,
        ORIG_AGENT_ADDRESS_NO,
        ORIG_AGENT_CONTACT_NO,
        DEST_AGENT_ID,
        DEST_AGENT_NAME,
        DEST_AGENT_ADDRESS_NO,
        DEST_AGENT_CONTACT_NO,

        -- Freight Rate                              2004.10.02
        MPR_PORT_ORIGIN,
        MPR_PORT_DEST,
        MPR_RATE,
        MPR_CURRENCY_CODE,
        MPR_AMT,
        MPR_AMT_PREPAID,
        MPR_AMT_COLLECT,
        MPR_EXCHANGE_RATE,
        MPR_RATE_PROFILE_NAME,
        RATE_CLASS_CODE,

        -- COMMISION                                2004.10.02
        COMMISSION_CURRENCY_CODE,
        COMMISSION_STD_PCT,
        COMMISSION_STD_AMT,
        COMMISSION_ADDTL_PCT,
        COMMISSION_ADDTL_AMT,
        COMMISSION_OVERRIDE_PCT,
        COMMISSION_OVERRIDE_AMT,

        -- BORROW / CONTAINER / MANIFEST            2004.10.06
        BORROW_IND,
        BORROW_VENDOR_NAME,
        BORROW_VENDOR_ADDRESS_NO,
        BORROW_VENDOR_INVOICE_NO,
        CONTAINER_NUM,
        CONTAINER_TYPE,
        MANIFEST_NO,

        TAX_AMT,                                    -- 2004.10.17

        PO_NO,                                      -- 2004.12.12
        COMMERCIAL_INV_NO,
-- Add 2005.04.10
        EXPORT_TX_STATUS,
        IMPORT_TX_STATUS,
        -- JPAEX �ǉ�
        CONSOL_CODE,
        SS_CODE1,
        SS_CODE2,
        SS_CODE3,
        SS_CODE4,
        SS_CODE5,
        SS_CODE6,
        MWB_PORT_ORIGIN,
        MWB_PORT_LOADING,
        MWB_PORT_UNLOADING,
        MWB_PORT_DEST,
        SHIPPING_SEGMENT,
        GOODS_CATEGORY,
        PROJECT_CODE,
        SHIPPER_INDUSTRY_CODE,
        SHIPPER_INDUSTRY_NAME,
        SHIPPER_REGION_NAME,
        FRT_SALES_AMT,
        FOT_SALES_AMT,
        CCO_SALES_AMT,
        CHG_SALES_AMT,
        FRT_COST_AMT,
        FOT_COST_AMT,
        AGT_COST_AMT,
        CHG_COST_AMT,
        -- JPAEX �ǉ��iCarrier Waybill:M�̂݁j
        HAWB_CNT,
        HAWB_AGWT,
        HAWB_CGWT,
        HAWB_M3,
        HAWB_VWT,
        HAWB_PCS,
        -- 2005.04.29 ROUTE�̑Ή�
        ETD,
        ETA,
        ATD,
        ATA,
        ROUTE1_TYPE,
        ROUTE1_PORT_LOADING,
        ROUTE1_PORT_UNLOADING,
        ROUTE1_CARRIER_CODE,
        ROUTE1_FLIGHT_VOYAGE,
        ROUTE1_VESSEL_NAME,
        ROUTE2_TYPE,
        ROUTE2_PORT_LOADING,
        ROUTE2_PORT_UNLOADING,
        ROUTE2_CARRIER_CODE,
        ROUTE2_FLIGHT_VOYAGE,
        ROUTE2_VESSEL_NAME,
        ROUTE3_TYPE,
        ROUTE3_PORT_LOADING,
        ROUTE3_PORT_UNLOADING,
        ROUTE3_CARRIER_CODE,
        ROUTE3_FLIGHT_VOYAGE,
        ROUTE3_VESSEL_NAME,
        ROUTE4_TYPE,
        ROUTE4_PORT_LOADING,
        ROUTE4_PORT_UNLOADING,
        ROUTE4_CARRIER_CODE,
        ROUTE4_FLIGHT_VOYAGE,
        ROUTE4_VESSEL_NAME,
        ROUTE5_TYPE,
        ROUTE5_PORT_LOADING,
        ROUTE5_PORT_UNLOADING,
        ROUTE5_CARRIER_CODE,
        ROUTE5_FLIGHT_VOYAGE,
        ROUTE5_VESSEL_NAME,
        -- 2005.05.15 V1.2.03 ACR / IATA Tarrif / Commodity Code�̑Ή�
        HMWB_NO,
        HMWB_TX_ID,
        MANIFEST_DESCRIPTION,
        CUSTOMS_DECLARATION,
        -- Commodity Code(SCR No)
        COMMODITY_CODE,
        COMMODITY_DESCRIPTION,
        COMMODITY_TYPE,
        -- SHIPMENT_DETAIL
        DETAIL_DESCRIPTION,
        DETAIL_MPR_RATE,
        DETAIL_MPR_AMT,
        DETAIL_COMMODITY_CODE,
        DETAIL_COMMODITY_DESCRIPTION,
        DETAIL_COMMODITY_TYPE,
        -- MPR �ǉ�
        MPR_PORT_ORIGIN2,
        MPR_PORT_DEST2,
        MPR_RATE2,
        MPR_CURRENCY_CODE2,
        MPR_AMT2,
        MPR_AMT2_PREPAID,
        MPR_AMT2_COLLECT,
        MPR_EXCHANGE_RATE2,
        MPR_RATE_PROFILE_NAME2,
        MPR_PORT_ORIGIN3,
        MPR_PORT_DEST3,
        MPR_RATE3,
        MPR_CURRENCY_CODE3,
        MPR_AMT3,
        MPR_AMT3_PREPAID,
        MPR_AMT3_COLLECT,
        MPR_EXCHANGE_RATE3,
        MPR_RATE_PROFILE_NAME3,
        -- IATA RATE (Travel)
        TRV_MPR_RATE,
        TRV_MPR_CURRENCY_CODE,
        TRV_MPR_AMT,
        TRV_MPR_EXCHANGE_RATE,
        TRV_MPR_RATE_PROFILE_NAME,
        TRV_MPR_RATE2,
        TRV_MPR_CURRENCY_CODE2,
        TRV_MPR_AMT2,
        TRV_MPR_EXCHANGE_RATE2,
        TRV_MPR_RATE_PROFILE_NAME2,
        TRV_MPR_RATE3,
        TRV_MPR_CURRENCY_CODE3,
        TRV_MPR_AMT3,
        TRV_MPR_EXCHANGE_RATE3,
        TRV_MPR_RATE_PROFILE_NAME3,
        -- 2005.06.19 MY JOB_NO�Ή�
        JOB_NO,
        JOB_TX_ID,
        -- 2005.09.01 MY Domestic Consol�Ή�
        DC_MWB_ISSUE_DATE,
        DC_CONSOL_DATE,
        DC_MWB_NO,
        DC_MWB_TX_ID,
        DC_CONSOL_NO,
        DC_CONSOL_TX_ID,
        -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
        CHARGEABLE_WEIGHT_KG,
        ACTUAL_WEIGHT_KG,
        VOLUME_CBM,
        VOLUME_WEIGHT_KG )
      VALUES(
        -- ����
        IN_TFJ301.ETRKDTM,
        IN_TFJ301.EUPDDTM,
        IN_TFJ301.DHNEDTM,
        IN_TFJ301.EUPD_OFCCD,
        IN_TFJ301.EUPD_TNTCD,
        -- �j�d�x
        IN_TFJ301.EDATKBN,
        IN_TFJ301.PIPELINE_TX_ID,
        IN_TFJ301.DGYMDTM,
        IN_TFJ301.NGENNO,
        -- �R���g���[��
        IN_TFJ301.ESISNKBN,
        IN_TFJ301.NAKKBN,
        IN_TFJ301.EDELKBN,
        IN_TFJ301.ESKY_KBN,
        IN_TFJ301.EOPE_KBN,
        IN_TFJ301.EFWD_JTKBN,
        IN_TFJ301.ETKN_JTKBN,
        IN_TFJ301.ECOMPANY_ID,
        IN_TFJ301.EIM_EX_IND,
        IN_TFJ301.ETRANS_MODE,
        -- ���t
        IN_TFJ301.DKJODTM,
        IN_TFJ301.ORIGINAL_KJODTM,
        IN_TFJ301.INVOICE_DATE,
        IN_TFJ301.ORIGINAL_INVOICE_DATE,
        IN_TFJ301.MWB_ISSUE_DATE,
        IN_TFJ301.ISSUE_DATE,
        IN_TFJ301.CONSOL_DATE,
        IN_TFJ301.ISSUE_DATE_TO_PRINT,
        IN_TFJ301.OBD_DATE_TO_PRINT,
        IN_TFJ301.DEPARTURE_DATE,
        IN_TFJ301.ARRIVAL_DATE,
        -- �ԍ�
        IN_TFJ301.MWB_NO,
        IN_TFJ301.HWB_NO,
        IN_TFJ301.CONSOL_NO,
        IN_TFJ301.INVOICE_NO,
        IN_TFJ301.MWB_TX_ID,
        IN_TFJ301.HWB_TX_ID,
        IN_TFJ301.CONSOL_TX_ID,
        IN_TFJ301.INVOICE_TX_ID,
--
        IN_TFJ301.ETERMINAL_ID,
        IN_TFJ301.EDEPARTMENT_ID,
        IN_TFJ301.EOYA_ECNORCD,
        IN_TFJ301.ECNORCD,
        IN_TFJ301.EHBI_TNTCD,
        -- ����
        IN_TFJ301.EOYA_ECNORNM,
        IN_TFJ301.JOYA_ECNORNM,
        IN_TFJ301.ECNORNM,
        IN_TFJ301.JCNORNM,
        IN_TFJ301.ETERMNM,
        IN_TFJ301.JTERMNM,
        IN_TFJ301.EDEPARTNM,
        IN_TFJ301.JDEPARTNM,
        IN_TFJ301.ETNTNM,
        IN_TFJ301.JTNTNM,
--
        IN_TFJ301.PIPELINE_TX_TYPE,
        IN_TFJ301.PIPELINE_REF_TYPE,
        IN_TFJ301.PIPELINE_TX_STATUS,
        IN_TFJ301.TRANSPORT_MODE,
        IN_TFJ301.SERVICE_TYPE,
        IN_TFJ301.MOVEMENT_TYPE,
        IN_TFJ301.CUSTOMER_SHIPMENT_TYPE,
        IN_TFJ301.AGENT_TYPE,
        IN_TFJ301.CONSOL_SERVICE_TYPE,
        IN_TFJ301.DISPOSITION,
--
        IN_TFJ301.CARRIER_CODE,
        IN_TFJ301.CARRIER_NAME,
        IN_TFJ301.FLIGHT_VOYAGE,
        IN_TFJ301.VESSEL_NAME,
        IN_TFJ301.CARRIER_TYPE,
--
        IN_TFJ301.FREE_HOUSE_IND,
        IN_TFJ301.LCL_CNSL_CARRIER_IND,
--
        IN_TFJ301.PIPELINE_TX_DATE,
        IN_TFJ301.TX_DATE_TZ_CODE,
--
        IN_TFJ301.TRANSPORT_TERMS_CODE,
        IN_TFJ301.SALES_TERMS_CODE,
        IN_TFJ301.FREE_HOUSE_TERMS_CODE,
--
        IN_TFJ301.IMPORT_SALESMAN_ID,
        IN_TFJ301.EXPORT_SALESMAN_ID,
--
        IN_TFJ301.PLACE_OF_RECEIPT,
        IN_TFJ301.PLACE_OF_RECEIPT_NAME,
        IN_TFJ301.PLACE_OF_DELIVERY,
        IN_TFJ301.PLACE_OF_DELIVERY_NAME,
        IN_TFJ301.PORT_ORIGIN,
        IN_TFJ301.PORT_ORIGIN_NAME,
        IN_TFJ301.PORT_LOADING,
        IN_TFJ301.PORT_LOADING_NAME,
        IN_TFJ301.PORT_UNLOADING,
        IN_TFJ301.PORT_UNLOADING_NAME,
        IN_TFJ301.PORT_DEST,
        IN_TFJ301.PORT_DEST_NAME,
        IN_TFJ301.FINAL_DESTINATION,
        IN_TFJ301.PORT_CC_EXPORT,
        IN_TFJ301.PORT_CC_IMPORT,
--
        IN_TFJ301.ORIG_COMPANY_ID,
        IN_TFJ301.ORIG_SUBSIDIARY_ID,
        IN_TFJ301.ORIG_TERMINAL_ID,
        IN_TFJ301.ORIG_DEPARTMENT_ID,
        IN_TFJ301.ORIG_AREA_CODE,
        IN_TFJ301.ORIG_REGION_CODE,
        IN_TFJ301.ORIG_COUNTRY_CODE,
        IN_TFJ301.ORIG_IATA_TC_CODE,
        IN_TFJ301.ORIG_POLAR_REGION_A_CODE,
        IN_TFJ301.ORIG_POLAR_REGION_B_CODE,
        IN_TFJ301.DEST_COMPANY_ID,
        IN_TFJ301.DEST_SUBSIDIARY_ID,
        IN_TFJ301.DEST_TERMINAL_ID,
        IN_TFJ301.DEST_DEPARTMENT_ID,
        IN_TFJ301.DEST_AREA_CODE,
        IN_TFJ301.DEST_REGION_CODE,
        IN_TFJ301.DEST_COUNTRY_CODE,
        IN_TFJ301.DEST_IATA_TC_CODE,
        IN_TFJ301.DEST_POLAR_REGION_A_CODE,
        IN_TFJ301.DEST_POLAR_REGION_B_CODE,
--
        IN_TFJ301.NATURE_OF_GOODS,
--
        IN_TFJ301.NUM_PIECES,
        IN_TFJ301.NUM_PIECES_UOM_CODE,
        IN_TFJ301.CHARGEABLE_WEIGHT,
        IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
        IN_TFJ301.TOTAL_ACTUAL_WEIGHT,
        IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
        IN_TFJ301.TOTAL_VOLUME,
        IN_TFJ301.VOLUME_UOM_CODE,
        IN_TFJ301.TOTAL_VOLUME_WEIGHT,
        IN_TFJ301.VOLUME_WEIGHT_UOM_CODE,
--
        IN_TFJ301.CONTAINER_20FT,
        IN_TFJ301.CONTAINER_40FT,
        IN_TFJ301.CONTAINER_ETC,
--
        IN_TFJ301.FREIGHT_PPC_IND,
        IN_TFJ301.OTHER_PPC_IND,
        IN_TFJ301.DEST_PPC_IND,
--
        IN_TFJ301.OC_CURRENCY_CODE,
        IN_TFJ301.ORIG_CURRENCY_CODE,
        IN_TFJ301.DEST_CURRENCY_CODE,
        IN_TFJ301.INVOICE_CURRENCY_CODE,
--
        IN_TFJ301.DEST_EXCHANGE_RATE,
        IN_TFJ301.INVOICE_EXCHANGE_RATE,
--
        IN_TFJ301.PPD_FREIGHT_AMT,
        IN_TFJ301.PPD_OTHER_AMT,
        IN_TFJ301.PPD_VALUATION_AMT,
        IN_TFJ301.PPD_TAX_AMT,
        IN_TFJ301.PPD_DUE_AGENT_AMT,
        IN_TFJ301.PPD_DUE_CARRIER_AMT,
        IN_TFJ301.TOT_PPD_AMT,
        IN_TFJ301.COLL_FREIGHT_AMT,
        IN_TFJ301.COLL_OTHER_AMT,
        IN_TFJ301.COLL_VALUATION_AMT,
        IN_TFJ301.COLL_TAX_AMT,
        IN_TFJ301.COLL_DUE_AGENT_AMT,
        IN_TFJ301.COLL_DUE_CARRIER_AMT,
        IN_TFJ301.TOT_COLL_AMT,
--
        IN_TFJ301.OC_PPD_FREIGHT_AMT,
        IN_TFJ301.OC_PPD_OTHER_AMT,
        IN_TFJ301.OC_PPD_VALUATION_AMT,
        IN_TFJ301.OC_PPD_TAX_AMT,
        IN_TFJ301.OC_PPD_DUE_AGENT_AMT,
        IN_TFJ301.OC_PPD_DUE_CARRIER_AMT,
        IN_TFJ301.OC_TOT_PPD_AMT,
        IN_TFJ301.OC_COLL_FREIGHT_AMT,
        IN_TFJ301.OC_COLL_OTHER_AMT,
        IN_TFJ301.OC_COLL_VALUATION_AMT,
        IN_TFJ301.OC_COLL_TAX_AMT,
        IN_TFJ301.OC_COLL_DUE_AGENT_AMT,
        IN_TFJ301.OC_COLL_DUE_CARRIER_AMT,
        IN_TFJ301.OC_TOT_COLL_AMT,
--
        -- Shipper
        IN_TFJ301.SHIPPER_ID,
        IN_TFJ301.SHIPPER_NAME,
        IN_TFJ301.LL_SHIPPER_NAME,
        IN_TFJ301.SHIPPER_PARENT_ID,
        IN_TFJ301.SHIPPER_GROUP_ID,
        IN_TFJ301.SHIPPER_PARENT_NAME,
        IN_TFJ301.LL_SHIPPER_PARENT_NAME,
        IN_TFJ301.SHIPPER_ADDRESS_NO,
        IN_TFJ301.SHIPPER_ADDRESS1,
        IN_TFJ301.SHIPPER_ADDRESS2,
        IN_TFJ301.SHIPPER_ADDRESS3,
        IN_TFJ301.SHIPPER_ADDRESS4,
        IN_TFJ301.SHIPPER_ADDRESS5,
        IN_TFJ301.LL_SHIPPER_ADDRESS1,
        IN_TFJ301.LL_SHIPPER_ADDRESS2,
        IN_TFJ301.LL_SHIPPER_ADDRESS3,
        IN_TFJ301.LL_SHIPPER_ADDRESS4,
        IN_TFJ301.LL_SHIPPER_ADDRESS5,
        IN_TFJ301.SHIPPER_CITY_NAME,
        IN_TFJ301.LL_SHIPPER_CITY_NAME,
        IN_TFJ301.SHIPPER_REGION_CODE,
        IN_TFJ301.SHIPPER_POSTAL_CODE,
        IN_TFJ301.SHIPPER_COUNTRY_CODE,
        IN_TFJ301.SHIPPER_CONTACT_NO,
        IN_TFJ301.SHIPPER_CONTACT_NAME,
        IN_TFJ301.LL_SHIPPER_CONTACT_NAME,
        IN_TFJ301.SHIPPER_CONTACT_PHONE,
        IN_TFJ301.SHIPPER_CONTACT_FAX,
        IN_TFJ301.SHIPPER_CONTACT_EMAIL,
--
        -- Consignee
        IN_TFJ301.CNEE_ID,
        IN_TFJ301.CNEE_NAME,
        IN_TFJ301.LL_CNEE_NAME,
        IN_TFJ301.CNEE_PARENT_ID,
        IN_TFJ301.CNEE_GROUP_ID,
        IN_TFJ301.CNEE_PARENT_NAME,
        IN_TFJ301.LL_CNEE_PARENT_NAME,
        IN_TFJ301.CNEE_ADDRESS_NO,
        IN_TFJ301.CNEE_ADDRESS1,
        IN_TFJ301.CNEE_ADDRESS2,
        IN_TFJ301.CNEE_ADDRESS3,
        IN_TFJ301.CNEE_ADDRESS4,
        IN_TFJ301.CNEE_ADDRESS5,
        IN_TFJ301.LL_CNEE_ADDRESS1,
        IN_TFJ301.LL_CNEE_ADDRESS2,
        IN_TFJ301.LL_CNEE_ADDRESS3,
        IN_TFJ301.LL_CNEE_ADDRESS4,
        IN_TFJ301.LL_CNEE_ADDRESS5,
        IN_TFJ301.CNEE_CITY_NAME,
        IN_TFJ301.LL_CNEE_CITY_NAME,
        IN_TFJ301.CNEE_REGION_CODE,
        IN_TFJ301.CNEE_POSTAL_CODE,
        IN_TFJ301.CNEE_COUNTRY_CODE,
        IN_TFJ301.CNEE_CONTACT_NO,
        IN_TFJ301.CNEE_CONTACT_NAME,
        IN_TFJ301.LL_CNEE_CONTACT_NAME,
        IN_TFJ301.CNEE_CONTACT_PHONE,
        IN_TFJ301.CNEE_CONTACT_FAX,
        IN_TFJ301.CNEE_CONTACT_EMAIL,
--
        -- Notify
        IN_TFJ301.NOTIFY_ID,
        IN_TFJ301.NOTIFY_NAME,
        IN_TFJ301.NOTIFY_ADDRESS_NO,
        IN_TFJ301.NOTIFY_CONTACT_NO,
--
        -- BILLTO
        IN_TFJ301.BILLTO_ID,
        IN_TFJ301.BILLTO_NAME,
        IN_TFJ301.BILLTO_ADDRESS_NO,
        IN_TFJ301.BILLTO_CONTACT_NO,
--
        IN_TFJ301.CONTROLLING_ID,
        IN_TFJ301.CONTROLLING_NAME,
        IN_TFJ301.CONTROLLING_ADDRESS_NO,
        IN_TFJ301.CONTROLLING_CONTACT_NO,
        IN_TFJ301.BILLTO2_ID,
        IN_TFJ301.BILLTO2_NAME,
        IN_TFJ301.BILLTO2_ADDRESS_NO,
        IN_TFJ301.BILLTO2_CONTACT_NO,
        IN_TFJ301.PTYTOCNT_ID,
        IN_TFJ301.PTYTOCNT_NAME,
        IN_TFJ301.PTYTOCNT_ADDRESS_NO,
        IN_TFJ301.PTYTOCNT_CONTACT_NO,
        IN_TFJ301.SETTLEMENT_AGENT_ID,
        IN_TFJ301.SETTLEMENT_AGENT_NAME,
        IN_TFJ301.SETTLEMENT_AGENT_ADDRESS_NO,
        IN_TFJ301.SETTLEMENT_AGENT_CONTACT_NO,
        IN_TFJ301.RECEIPT_LOCATION_CODE,
        IN_TFJ301.CFS_RECEIPT_ID,
        IN_TFJ301.CFS_RECEIPT_LOCATION_NAME,
        IN_TFJ301.CFS_RECEIPT_ADDRESS_NO,
        IN_TFJ301.CFS_RECEIPT_CONTACT_NO,
        IN_TFJ301.CY_RECEIPT_ID,
        IN_TFJ301.CY_RECEIPT_LOCATION_NAME,
        IN_TFJ301.CY_RECEIPT_ADDRESS_NO,
        IN_TFJ301.CY_RECEIPT_CONTACT_NO,
        IN_TFJ301.LOCFREIGHT_ID,
        IN_TFJ301.LOCFREIGHT_NAME,
        IN_TFJ301.LOCFREIGHT_ADDRESS_NO,
        IN_TFJ301.LOCFREIGHT_CONTACT_NO,
        IN_TFJ301.DEST_BROKER_ID,
        IN_TFJ301.DEST_BROKER_NAME,
        IN_TFJ301.DEST_BROKER_ADDRESS_NO,
        IN_TFJ301.DEST_BROKER_CONTACT_NO,
        IN_TFJ301.IMPORT_BILLTO_ID,
        IN_TFJ301.IMPORT_BILLTO_NAME,
        IN_TFJ301.IMPORT_BILLTO_ADDRESS_NO,
        IN_TFJ301.IMPORT_BILLTO_CONTACT_NO,
--
        IN_TFJ301.ORIG_AGENT_ID,
        IN_TFJ301.ORIG_AGENT_NAME,
        IN_TFJ301.ORIG_AGENT_ADDRESS_NO,
        IN_TFJ301.ORIG_AGENT_CONTACT_NO,
        IN_TFJ301.DEST_AGENT_ID,
        IN_TFJ301.DEST_AGENT_NAME,
        IN_TFJ301.DEST_AGENT_ADDRESS_NO,
        IN_TFJ301.DEST_AGENT_CONTACT_NO,

        -- Freight Rate                              2004.10.02
        IN_TFJ301.MPR_PORT_ORIGIN,
        IN_TFJ301.MPR_PORT_DEST,
        IN_TFJ301.MPR_RATE,
        IN_TFJ301.MPR_CURRENCY_CODE,
        IN_TFJ301.MPR_AMT,
        IN_TFJ301.MPR_AMT_PREPAID,
        IN_TFJ301.MPR_AMT_COLLECT,
        IN_TFJ301.MPR_EXCHANGE_RATE,
        IN_TFJ301.MPR_RATE_PROFILE_NAME,
        IN_TFJ301.RATE_CLASS_CODE,

         -- COMMISION                                2004.10.02
        IN_TFJ301.COMMISSION_CURRENCY_CODE,
        IN_TFJ301.COMMISSION_STD_PCT,
        IN_TFJ301.COMMISSION_STD_AMT,
        IN_TFJ301.COMMISSION_ADDTL_PCT,
        IN_TFJ301.COMMISSION_ADDTL_AMT,
        IN_TFJ301.COMMISSION_OVERRIDE_PCT,
        IN_TFJ301.COMMISSION_OVERRIDE_AMT,

        -- BORROW / CONTAINER / MANIFEST            2004.10.06
        IN_TFJ301.BORROW_IND,
        IN_TFJ301.BORROW_VENDOR_NAME,
        IN_TFJ301.BORROW_VENDOR_ADDRESS_NO,
        IN_TFJ301.BORROW_VENDOR_INVOICE_NO,
        IN_TFJ301.CONTAINER_NUM,
        IN_TFJ301.CONTAINER_TYPE,
        IN_TFJ301.MANIFEST_NO,

        IN_TFJ301.TAX_AMT,                          -- 2004.10.17

        IN_TFJ301.PO_NO,                            -- 2004.12.12
        IN_TFJ301.COMMERCIAL_INV_NO,
-- Add 2005.04.10
        IN_TFJ301.EXPORT_TX_STATUS,
        IN_TFJ301.IMPORT_TX_STATUS,
        -- JPAEX �ǉ�
        IN_TFJ301.CONSOL_CODE,
        IN_TFJ301.SS_CODE1,
        IN_TFJ301.SS_CODE2,
        IN_TFJ301.SS_CODE3,
        IN_TFJ301.SS_CODE4,
        IN_TFJ301.SS_CODE5,
        IN_TFJ301.SS_CODE6,
        IN_TFJ301.MWB_PORT_ORIGIN,
        IN_TFJ301.MWB_PORT_LOADING,
        IN_TFJ301.MWB_PORT_UNLOADING,
        IN_TFJ301.MWB_PORT_DEST,
        IN_TFJ301.SHIPPING_SEGMENT,
        IN_TFJ301.GOODS_CATEGORY,
        IN_TFJ301.PROJECT_CODE,
        IN_TFJ301.SHIPPER_INDUSTRY_CODE,
        IN_TFJ301.SHIPPER_INDUSTRY_NAME,
        IN_TFJ301.SHIPPER_REGION_NAME,
        IN_TFJ301.FRT_SALES_AMT,
        IN_TFJ301.FOT_SALES_AMT,
        IN_TFJ301.CCO_SALES_AMT,
        IN_TFJ301.CHG_SALES_AMT,
        IN_TFJ301.FRT_COST_AMT,
        IN_TFJ301.FOT_COST_AMT,
        IN_TFJ301.AGT_COST_AMT,
        IN_TFJ301.CHG_COST_AMT,
        -- JPAEX �ǉ��iCarrier Waybill:M�̂݁j
        IN_TFJ301.HAWB_CNT,
        IN_TFJ301.HAWB_AGWT,
        IN_TFJ301.HAWB_CGWT,
        IN_TFJ301.HAWB_M3,
        IN_TFJ301.HAWB_VWT,
        IN_TFJ301.HAWB_PCS,
        -- 2005.04.29 ROUTE�̑Ή�
        IN_TFJ301.ETD,
        IN_TFJ301.ETA,
        IN_TFJ301.ATD,
        IN_TFJ301.ATA,
        IN_TFJ301.ROUTE1_TYPE,
        IN_TFJ301.ROUTE1_PORT_LOADING,
        IN_TFJ301.ROUTE1_PORT_UNLOADING,
        IN_TFJ301.ROUTE1_CARRIER_CODE,
        IN_TFJ301.ROUTE1_FLIGHT_VOYAGE,
        IN_TFJ301.ROUTE1_VESSEL_NAME,
        IN_TFJ301.ROUTE2_TYPE,
        IN_TFJ301.ROUTE2_PORT_LOADING,
        IN_TFJ301.ROUTE2_PORT_UNLOADING,
        IN_TFJ301.ROUTE2_CARRIER_CODE,
        IN_TFJ301.ROUTE2_FLIGHT_VOYAGE,
        IN_TFJ301.ROUTE2_VESSEL_NAME,
        IN_TFJ301.ROUTE3_TYPE,
        IN_TFJ301.ROUTE3_PORT_LOADING,
        IN_TFJ301.ROUTE3_PORT_UNLOADING,
        IN_TFJ301.ROUTE3_CARRIER_CODE,
        IN_TFJ301.ROUTE3_FLIGHT_VOYAGE,
        IN_TFJ301.ROUTE3_VESSEL_NAME,
        IN_TFJ301.ROUTE4_TYPE,
        IN_TFJ301.ROUTE4_PORT_LOADING,
        IN_TFJ301.ROUTE4_PORT_UNLOADING,
        IN_TFJ301.ROUTE4_CARRIER_CODE,
        IN_TFJ301.ROUTE4_FLIGHT_VOYAGE,
        IN_TFJ301.ROUTE4_VESSEL_NAME,
        IN_TFJ301.ROUTE5_TYPE,
        IN_TFJ301.ROUTE5_PORT_LOADING,
        IN_TFJ301.ROUTE5_PORT_UNLOADING,
        IN_TFJ301.ROUTE5_CARRIER_CODE,
        IN_TFJ301.ROUTE5_FLIGHT_VOYAGE,
        IN_TFJ301.ROUTE5_VESSEL_NAME,

        -- 2005.05.15 V1.2.03 ACR / IATA Tarrif / Commodity Code�̑Ή�
        IN_TFJ301.HMWB_NO,
        IN_TFJ301.HMWB_TX_ID,
        IN_TFJ301.MANIFEST_DESCRIPTION,
        IN_TFJ301.CUSTOMS_DECLARATION,
        -- Commodity Code(SCR No)
        IN_TFJ301.COMMODITY_CODE,
        IN_TFJ301.COMMODITY_DESCRIPTION,
        IN_TFJ301.COMMODITY_TYPE,
        -- SHIPMENT_DETAIL
        IN_TFJ301.DETAIL_DESCRIPTION,
        IN_TFJ301.DETAIL_MPR_RATE,
        IN_TFJ301.DETAIL_MPR_AMT,
        IN_TFJ301.DETAIL_COMMODITY_CODE,
        IN_TFJ301.DETAIL_COMMODITY_DESCRIPTION,
        IN_TFJ301.DETAIL_COMMODITY_TYPE,
        -- MPR �ǉ�
        IN_TFJ301.MPR_PORT_ORIGIN2,
        IN_TFJ301.MPR_PORT_DEST2,
        IN_TFJ301.MPR_RATE2,
        IN_TFJ301.MPR_CURRENCY_CODE2,
        IN_TFJ301.MPR_AMT2,
        IN_TFJ301.MPR_AMT2_PREPAID,
        IN_TFJ301.MPR_AMT2_COLLECT,
        IN_TFJ301.MPR_EXCHANGE_RATE2,
        IN_TFJ301.MPR_RATE_PROFILE_NAME2,
        IN_TFJ301.MPR_PORT_ORIGIN3,
        IN_TFJ301.MPR_PORT_DEST3,
        IN_TFJ301.MPR_RATE3,
        IN_TFJ301.MPR_CURRENCY_CODE3,
        IN_TFJ301.MPR_AMT3,
        IN_TFJ301.MPR_AMT3_PREPAID,
        IN_TFJ301.MPR_AMT3_COLLECT,
        IN_TFJ301.MPR_EXCHANGE_RATE3,
        IN_TFJ301.MPR_RATE_PROFILE_NAME3,
        -- IATA RATE (Travel)
        IN_TFJ301.TRV_MPR_RATE,
        IN_TFJ301.TRV_MPR_CURRENCY_CODE,
        IN_TFJ301.TRV_MPR_AMT,
        IN_TFJ301.TRV_MPR_EXCHANGE_RATE,
        IN_TFJ301.TRV_MPR_RATE_PROFILE_NAME,
        IN_TFJ301.TRV_MPR_RATE2,
        IN_TFJ301.TRV_MPR_CURRENCY_CODE2,
        IN_TFJ301.TRV_MPR_AMT2,
        IN_TFJ301.TRV_MPR_EXCHANGE_RATE2,
        IN_TFJ301.TRV_MPR_RATE_PROFILE_NAME2,
        IN_TFJ301.TRV_MPR_RATE3,
        IN_TFJ301.TRV_MPR_CURRENCY_CODE3,
        IN_TFJ301.TRV_MPR_AMT3,
        IN_TFJ301.TRV_MPR_EXCHANGE_RATE3,
        IN_TFJ301.TRV_MPR_RATE_PROFILE_NAME3,
        -- 2005.06.19 MY JOB_NO�Ή�
        IN_TFJ301.JOB_NO,
        IN_TFJ301.JOB_TX_ID,
        -- 2005.09.01 MY Domestic Consol�Ή�
        IN_TFJ301.DC_MWB_ISSUE_DATE,
        IN_TFJ301.DC_CONSOL_DATE,
        IN_TFJ301.DC_MWB_NO,
        IN_TFJ301.DC_MWB_TX_ID,
        IN_TFJ301.DC_CONSOL_NO,
        IN_TFJ301.DC_CONSOL_TX_ID,
        -- 2005.10.14 ���ʂ�UOM_CONVERSION�Ή�
        IN_TFJ301.CHARGEABLE_WEIGHT_KG,
        IN_TFJ301.ACTUAL_WEIGHT_KG,
        IN_TFJ301.VOLUME_CBM,
        IN_TFJ301.VOLUME_WEIGHT_KG );

    IF IN_TFJ301.NAKKBN = 1 THEN
        WK_TFJ301_KURO_CNT := WK_TFJ301_KURO_CNT + 1;
    ELSE
        WK_TFJ301_AKA_CNT := WK_TFJ301_AKA_CNT + 1;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- HWB/MWB ���і��׋��z�A�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ303(
    IN_TFJ201    IN         TFJ201%ROWTYPE,       -- UASIF
    IN_TFJ301    IN         TFJ301%ROWTYPE,       -- ���і���
    IN_NGENNO    IN         TFJ303.NGENNO%TYPE )
IS
    WK_TFJ303             TFJ303%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ303' );

    WK_TFJ303 := NULL;

    -- ����
    WK_TFJ303.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ303.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ303.DHNEDTM                 := SYSDATE;
    WK_TFJ303.EUPD_OFCCD              := '!';
    WK_TFJ303.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    IF IN_TFJ201.WAYBILL_TYPE = 'M'  OR
       IN_TFJ201.WAYBILL_TYPE = 'MD' THEN
        -- MWB�̎��i�d����j
        WK_TFJ303.EDATKBN             := '3';
        WK_TFJ303.ESKY_KBN            := '0';
    ELSE
        -- HWB_TX_ID��0�ȊO�̎��iSHIPMENT�P�ʁj�AHWB_TX_ID���Z�b�g�A�����敪'0'
        WK_TFJ303.EDATKBN         := '1';
        WK_TFJ303.ESKY_KBN        := '0';
    END IF;

    WK_TFJ303.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    WK_TFJ303.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    WK_TFJ303.NGENNO                  := IN_NGENNO;
    -- Global:PIPELINE_TX_TYPE��KEY�̈ꕔ
    WK_TFJ303.PIPELINE_TX_TYPE        := IN_TFJ301.PIPELINE_TX_TYPE;      -- H:'SH'  /  M:'CS'

    -- �R���g���[��
    WK_TFJ303.NAKKBN                  := 1;
    WK_TFJ303.EDELKBN                 := '0';
    IF IN_NGENNO = 1 THEN
        WK_TFJ303.EOPE_KBN            := '0';       -- �V�K
    ELSE
        WK_TFJ303.EOPE_KBN            := '1';       -- �C��
    END IF;

    -- ���і��׋��z�i���j�ACharges�ҏW�o��
    OUTPUT_TFJ303_CHARGES( IN_TFJ201.PIPELINE_TX_ID, IN_TFJ201, WK_TFJ303 );

    -- 2004.08.02 Add
    IF IN_TFJ301.PIPELINE_REF_TYPE = 'M' THEN
        -- Global:PIPELINE_TX_TYPE��KEY�̈ꕔ
        WK_TFJ303.PIPELINE_TX_TYPE        := 'CO';                       -- M:'CO'  ���ӁDMaster�̏ꍇ'CS'��'CO'

        -- ���і��׋��z�i���j�ACharges�ҏW�o�� (
        OUTPUT_TFJ303_CHARGES( IN_TFJ301.CONSOL_TX_ID, IN_TFJ201, WK_TFJ303 );
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- HWB/MWB ���і��׋��z�ACharges�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ303_CHARGES(
    IN_PIPELINE_TX_ID IN               PIPELINE_CHARGES.PIPELINE_TX_ID%TYPE,
    IN_TFJ201         IN               TFJ201%ROWTYPE,       -- UASIF
    IN_TFJ303         IN OUT           TFJ303%ROWTYPE )
IS
    CURSOR CUR_PIPELINE_CHARGES(
        KEY_PIPELINE_TX_ID       PIPELINE_CHARGES.PIPELINE_TX_ID%TYPE,
        KEY_IMPORT_EXPORT_IND    PIPELINE_CHARGES.IMPORT_EXPORT_IND%TYPE
    ) IS
        SELECT *
        FROM PIPELINE_CHARGES
        WHERE PIPELINE_TX_ID    = KEY_PIPELINE_TX_ID
          AND IMPORT_EXPORT_IND = KEY_IMPORT_EXPORT_IND
          AND (INVOICE_CHARGE_AMT <> 0 OR COST_AMT <> 0)
        ORDER BY CHARGE_CODE,
                 PPC_IND,
                 INVOICE_WB_CURRENCY_CODE,
                 INVOICE_CURRENCY_CODE,
                 NVL(COST_CURRENCY_CODE,OC_CURRENCY_CODE),
                 NVL(VENDOR_PARTNER_ID,'!'),
                 PC_RECORD_ID DESC;

    WK_PC_RECORD_ID   PIPELINE_CHARGES.PC_RECORD_ID%TYPE;
    WK_CHARGE_CODE    PIPELINE_CHARGES.CHARGE_CODE%TYPE   := '#';
    WK_PPC_IND        PIPELINE_CHARGES.PPC_IND%TYPE       := '#';
    WK_TFM205         TFM205%ROWTYPE;
    WK_NAKKBN         TFJ301.NAKKBN%TYPE;
    -- 2005.10.23 TFJ303��PK��PC_RECORD_ID��ǉ�
    -- INVOICE_WB_CURRENCY_CODE�AINVOICE_CURRENCY_CODE�ACOST_CURRENCY_CODE�AVENDOR_PARTNER_ID
    -- �������������Z
    WK_INVOICE_WB_CURRENCY_CODE    PIPELINE_CHARGES.INVOICE_WB_CURRENCY_CODE%TYPE   := '#';
    WK_INVOICE_CURRENCY_CODE       PIPELINE_CHARGES.INVOICE_CURRENCY_CODE%TYPE      := '#';
    WK_COST_CURRENCY_CODE          PIPELINE_CHARGES.COST_CURRENCY_CODE%TYPE         := '#';
    WK_VENDOR_PARTNER_ID           PIPELINE_CHARGES.VENDOR_PARTNER_ID%TYPE          := '#';

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ303_CHARGES' );

    FOR WK_REC IN CUR_PIPELINE_CHARGES( IN_PIPELINE_TX_ID,
                                        IN_TFJ201.IMPORT_EXPORT_IND ) LOOP

        -- 2005.10.23 TFJ303��PK��PC_RECORD_ID��ǉ�
        -- INVOICE_WB_CURRENCY_CODE�AINVOICE_CURRENCY_CODE�ACOST_CURRENCY_CODE�AVENDOR_PARTNER_ID
        -- �������������Z
        IF WK_REC.CHARGE_CODE                <> WK_CHARGE_CODE              OR
           WK_REC.PPC_IND                    <> WK_PPC_IND                  OR
           WK_REC.INVOICE_WB_CURRENCY_CODE   <> WK_INVOICE_WB_CURRENCY_CODE OR
           WK_REC.INVOICE_CURRENCY_CODE      <> WK_INVOICE_CURRENCY_CODE    OR
           NVL(WK_REC.COST_CURRENCY_CODE,WK_REC.OC_CURRENCY_CODE)
                                             <> WK_COST_CURRENCY_CODE       OR
           NVL(WK_REC.VENDOR_PARTNER_ID,'!') <> WK_VENDOR_PARTNER_ID        THEN
            IF WK_CHARGE_CODE <> '#' THEN
                IF IN_TFJ303.INVOICE_CHARGE_AMT <> 0 OR
                   IN_TFJ303.COST_AMT           <> 0 THEN
                    -- ���і��׋��z��ҏW
                    EDIT_TFJ303( IN_TFJ201, WK_PC_RECORD_ID, IN_TFJ303 );
                    -- ���і��׋��z���쐬
                    INS_TFJ303( IN_TFJ303 );
                END IF;
            END IF;

            -- �������ڃ}�X�^����
            SEL_TFM205( IN_TFJ201, WK_REC.CHARGE_CODE, WK_TFM205 );
            IN_TFJ303.CHARGE_CODE         := WK_REC.CHARGE_CODE;

            IN_TFJ303.CHARGE_DESCRIPTION  := WK_REC.APPEND_CHARGE_DESCRIPTION;
            IN_TFJ303.CHARGE_STATUS       := WK_REC.CHARGE_STATUS;
            IN_TFJ303.PPC_IND             := TRIM(WK_REC.PPC_IND);
            -- 2005.10.23 TFJ303��PK��PC_RECORD_ID��ǉ�
            IN_TFJ303.PC_RECORD_ID        := WK_REC.PC_RECORD_ID;
            IN_TFJ303.IMPORT_EXPORT_IND   := TRIM(WK_REC.IMPORT_EXPORT_IND);
            IN_TFJ303.CATEGORY_CODE       := WK_REC.CATEGORY_CODE;
            IF WK_TFM205.CHARGE_CODE IS NOT NULL THEN
                IN_TFJ303.NKMK_ITI              := WK_TFM205.NKMK_ITI;
                IN_TFJ303.EPRT_TAG              := WK_TFM205.EURI_PRT_TAG1;
                IN_TFJ303.SUMMARY_CATEGORY_CODE := WK_TFM205.ESUMGASNID;
                IN_TFJ303.ACCTG_CATEGORY_CODE   := WK_TFM205.ESYUGOID;
                IN_TFJ303.ASSOC_TX_TYPE         := WK_TFM205.EHSI_KYOKMNKBN;
            ELSE
                IN_TFJ303.NKMK_ITI              := 0;
                IN_TFJ303.EPRT_TAG              := '!';
                IN_TFJ303.SUMMARY_CATEGORY_CODE := NULL;
                IN_TFJ303.ACCTG_CATEGORY_CODE   := NULL;
                IN_TFJ303.ASSOC_TX_TYPE         := NULL;
            END IF;
--
            IN_TFJ303.INVOICE_NO          := NULL;
            IN_TFJ303.INVOICE_TX_ID       := NULL;
            IN_TFJ303.BILLTO_ID           := NULL;
            IN_TFJ303.RECORD_IND          := NULL;
--
            IN_TFJ303.INVOICE_WB_AMT      := 0;
            IN_TFJ303.INVOICE_WB_CURRENCY_CODE
                                      := WK_REC.INVOICE_WB_CURRENCY_CODE;
            IN_TFJ303.INVOICE_WB_EXCHANGE_RATE
                                      := WK_REC.INVOICE_WB_EXCHANGE_RATE;
--
            IN_TFJ303.INVOICE_CHARGE_AMT  := 0;
            IN_TFJ303.INVOICE_CURRENCY_CODE
                                      := WK_REC.INVOICE_CURRENCY_CODE;
            IN_TFJ303.INVOICE_EXCHANGE_RATE
                                      := WK_REC.INVOICE_EXCHANGE_RATE;
--
            IN_TFJ303.OC_INVOICE_CHARGE_AMT := 0;
            IN_TFJ303.OC_CURRENCY_CODE    := WK_REC.OC_CURRENCY_CODE;
--
            IN_TFJ303.VENDOR_NAME         := WK_REC.VENDOR_NAME;
            IN_TFJ303.VENDOR_PARTNER_ID   := WK_REC.VENDOR_PARTNER_ID;
            IN_TFJ303.VENDOR_ADDRESS_NO   := WK_REC.VENDOR_ADDRESS_NO;
            IN_TFJ303.VENDOR_REF_NO       := WK_REC.VENDOR_REF_NO;
--
            IN_TFJ303.COST_AMT            := 0;
            IN_TFJ303.COST_CURRENCY_CODE  := NVL(WK_REC.COST_CURRENCY_CODE,WK_REC.OC_CURRENCY_CODE);
            IF WK_REC.COST_CURRENCY_CODE IS NULL THEN
                IN_TFJ303.COST_EXCHANGE_RATE  := 1;
            ELSE
                IN_TFJ303.COST_EXCHANGE_RATE  := WK_REC.COST_EXCHANGE_RATE;
            END IF;
            IN_TFJ303.OC_COST_AMT         := 0;
--
            IN_TFJ303.CREATED_FROM        := WK_REC.CREATED_FROM;
            IN_TFJ303.UAS_CNF_DATE        := IN_TFJ201.DGYMDTM;
            IN_TFJ303.UAS_GL_DATE         := WK_REC.UAS_GL_DATE;
            IN_TFJ303.UAS_GL_DATE_TZ_CODE := WK_REC.UAS_GL_DATE_TZ_CODE;
            -- 2005.12.16 Rate Profile�Ή�
            IN_TFJ303.PCP_RECORD_ID       := WK_REC.PCP_RECORD_ID;
            IN_TFJ303.RATE                := WK_REC.RATE;
            IN_TFJ303.RATE_UOM            := WK_REC.RATE_UOM;
            IF SUBSTR(IN_TFJ303.CHARGE_CODE,-2,2) = 'RV' OR
               SUBSTR(IN_TFJ303.CHARGE_CODE,-2,2) = 'AD' THEN
                IN_TFJ303.PRINT_IND       := TRIM(WK_REC.PRINT_IND);
            ELSE
                IN_TFJ303.PRINT_IND       := NULL;
            END IF;
            IF WK_REC.COST_AMT <> 0 THEN
                IN_TFJ303.ACCRUAL_COST_IND := TRIM(WK_REC.ACCRUAL_COST_IND);
            ELSE
                IN_TFJ303.ACCRUAL_COST_IND := NULL;
            END IF;

            WK_PC_RECORD_ID := 0;                                       -- �����l=0
            WK_CHARGE_CODE  := WK_REC.CHARGE_CODE;
            WK_PPC_IND      := TRIM(WK_REC.PPC_IND);
            WK_INVOICE_WB_CURRENCY_CODE   := WK_REC.INVOICE_WB_CURRENCY_CODE;
            WK_INVOICE_CURRENCY_CODE      := WK_REC.INVOICE_CURRENCY_CODE;
            WK_COST_CURRENCY_CODE         := NVL(WK_REC.COST_CURRENCY_CODE,WK_REC.OC_CURRENCY_CODE);
            WK_VENDOR_PARTNER_ID          := NVL(WK_REC.VENDOR_PARTNER_ID,'!');
        END IF;

        -- 2004/07/18 �C�� PC_RECORD_ID��INVOICE_CHARGE_AMT��Zero�ȊO�̎��Z�b�g
        IF WK_PC_RECORD_ID = 0 AND
           NVL(WK_REC.INVOICE_CHARGE_AMT,0) <> 0 THEN
            WK_PC_RECORD_ID := WK_REC.PC_RECORD_ID;
        END IF;
        -- COMMITION�͋��z���}�C�i�X 2005.05.15
        IF WK_TFM205.EGASNID = 'COM' THEN
            WK_NAKKBN := -1;
        ELSE
            WK_NAKKBN := 1;
        END IF;
        IN_TFJ303.INVOICE_WB_AMT         := IN_TFJ303.INVOICE_WB_AMT
                                         + NVL(WK_REC.INVOICE_WB_AMT,0)        * WK_NAKKBN;
        IN_TFJ303.INVOICE_CHARGE_AMT     := IN_TFJ303.INVOICE_CHARGE_AMT
                                         + NVL(WK_REC.INVOICE_CHARGE_AMT,0)    * WK_NAKKBN;
        IN_TFJ303.OC_INVOICE_CHARGE_AMT  := IN_TFJ303.OC_INVOICE_CHARGE_AMT
                                         + NVL(WK_REC.OC_INVOICE_CHARGE_AMT,0) * WK_NAKKBN;
        IN_TFJ303.COST_AMT               := IN_TFJ303.COST_AMT
                                         + NVL(WK_REC.COST_AMT,0)              * WK_NAKKBN;
        IN_TFJ303.OC_COST_AMT            := IN_TFJ303.OC_COST_AMT
                                         + NVL(WK_REC.OC_COST_AMT,0)           * WK_NAKKBN;
    END LOOP;

    IF WK_CHARGE_CODE <> '#' THEN
        IF IN_TFJ303.INVOICE_CHARGE_AMT <> 0 OR
           IN_TFJ303.COST_AMT           <> 0 THEN
            -- ���і��׋��z��ҏW
            EDIT_TFJ303( IN_TFJ201, WK_PC_RECORD_ID, IN_TFJ303 );
            -- ���і��׋��z���쐬
            INS_TFJ303( IN_TFJ303 );
        END IF;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','PIPELINE_CHARGES: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- HWB/MWB ���і��׋��z��ҏW
--================================================
PROCEDURE EDIT_TFJ303(
    IN_TFJ201        IN       TFJ201%ROWTYPE,       -- UASIF
    IN_PC_RECORD_ID  IN       PIPELINE_CHARGES.PC_RECORD_ID%TYPE,
    OUT_TFJ303       IN OUT   TFJ303%ROWTYPE )
IS
    CURSOR CUR_TFJ201_CHARGES(
        KEY_PIPELINE_TX_ID    TFJ201.PIPELINE_TX_ID%TYPE,
        KEY_CHARGE_CODE       TFJ201.CHARGE_CODE%TYPE
    ) IS
        SELECT VENDOR_NO
          FROM TFJ201
          WHERE RECORD_IND     = 'AP'
            AND PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
            AND PPC_IND        = 'C'
            AND CHARGE_CODE    = KEY_CHARGE_CODE
          ORDER BY RECORD_ID DESC;

    CURSOR CUR_TFJ201_AR(
        KEY_PIPELINE_TX_ID    TFJ201.PIPELINE_TX_ID%TYPE,
        KEY_CHARGE_CODE       TFJ201.CHARGE_CODE%TYPE,
        KEY_PPC_IND           TFJ201.PPC_IND%TYPE
    ) IS
        SELECT DGYMDTM, ACCOUNTING_DATE
          FROM TFJ201
          WHERE RECORD_IND     = 'AR'
            AND PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
            AND CHARGE_CODE    = KEY_CHARGE_CODE
            AND PPC_IND        = KEY_PPC_IND
          ORDER BY RECORD_ID DESC;

    -- 2005.11.07 Direct Collect�̑Ή�
    CURSOR CUR_TFJ201_AP(
        KEY_PIPELINE_TX_ID    TFJ201.PIPELINE_TX_ID%TYPE,
        KEY_CHARGE_CODE       TFJ201.CHARGE_CODE%TYPE,
        KEY_PPC_IND           TFJ201.PPC_IND%TYPE
    ) IS
        SELECT DGYMDTM, ACCOUNTING_DATE
          FROM TFJ201
          WHERE RECORD_IND     = 'AP'
            AND PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
            AND CHARGE_CODE    = KEY_CHARGE_CODE
            AND PPC_IND        = KEY_PPC_IND
          ORDER BY RECORD_ID DESC;

    -- 2004.08.08 ORDER BY��RECORD_IND��ǉ� AP�D��
    CURSOR CUR_TFJ201_AP_GL(
        KEY_PIPELINE_TX_ID    TFJ201.PIPELINE_TX_ID%TYPE,
        KEY_CHARGE_CODE       TFJ201.CHARGE_CODE%TYPE
    ) IS
        SELECT RECORD_IND, DGYMDTM, ACCOUNTING_DATE, VENDOR_NO
          FROM TFJ201
          WHERE RECORD_IND    in ('AP','GL')
            AND PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
            AND CHARGE_CODE    = KEY_CHARGE_CODE
          ORDER BY RECORD_IND,RECORD_ID DESC;

    -- 2005.10.23 AP_INTERFACE_LINES���VENDOR���擾
    CURSOR CUR_AP_LINES(
        KEY_PC_RECORD_ID       AP_INTERFACE_LINES.PC_RECORD_ID%TYPE
    ) IS
        SELECT ACCOUNTING_DATE, VENDOR_NUMBER
          FROM AP_INTERFACE_LINES
          WHERE INVD_RECORD_ID = KEY_PC_RECORD_ID;

    -- 2005.12.16 Rate Profile�Ή�
    CURSOR CUR_RP_CHARGE(
        KEY_PCP_RECORD_ID     PARTNER_CHARGE_PROFILE.PCP_RECORD_ID%TYPE
    ) IS
        SELECT PCP.CHARGE_RATEPROF_RECORD_ID as RP_RECORD_ID,
               PCP.CHARGE_CALCULATION_METHOD as CALCULATION_METHOD,PCP.TAXABLE_IND,
               RP.RATE_PROFILE_NAME,
               RP.DESCRIPTION
          FROM PARTNER_CHARGE_PROFILE PCP,RATE_PROFILE RP
          WHERE RP.RP_RECORD_ID(+) = PCP.CHARGE_RATEPROF_RECORD_ID
            AND PCP.PCP_RECORD_ID  = KEY_PCP_RECORD_ID;

    CURSOR CUR_RP_COST(
        KEY_PCP_RECORD_ID     PARTNER_CHARGE_PROFILE.PCP_RECORD_ID%TYPE
    ) IS
        SELECT PCP.COST_RATEPROF_RECORD_ID as RP_RECORD_ID,
               PCP.COST_CALCULATION_METHOD as CALCULATION_METHOD,PCP.TAXABLE_IND,
               RP.RATE_PROFILE_NAME,
               RP.DESCRIPTION
          FROM PARTNER_CHARGE_PROFILE PCP,RATE_PROFILE RP
          WHERE RP.RP_RECORD_ID(+) = PCP.COST_RATEPROF_RECORD_ID
            AND PCP.PCP_RECORD_ID  = KEY_PCP_RECORD_ID;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    DMY_PARENT_PARTNER_ID   PARTNER.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_NAME         PARTNER.PARTNER_NAME%TYPE;
    DMY_LL_PARTNER_NAME     PARTNER.LL_PARTNER_NAME%TYPE;
    DMY_PARTNER_SHORT_NAME  PARTNER.PARTNER_SHORT_NAME%TYPE;
    DMY_INDUSTRY_CODE       PARTNER.CUSTOMER_INDUSTRY_CODE%TYPE; -- add 2005.04.10
    DMY_INDUSTRY_NAME       CODE_DETAIL.CD_DESCRIPTION%TYPE;     -- add 2005.04.10
    WK_CHARGE_STATUS        TFJ303.CHARGE_STATUS%TYPE;           -- add 2005.12.16

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'EDIT_TFJ303' );

    -- HWB �̔����z�̏ꍇ�AINVOICE_NO�̃Z�b�g
    -- 2004/06/09 �����̒ǉ��FCHARGE_STATUS��'O'(Open)�ȊO
    IF OUT_TFJ303.EDATKBN = '1'           AND
       OUT_TFJ303.CHARGE_STATUS <> 'O'    AND
       OUT_TFJ303.INVOICE_CHARGE_AMT <> 0 AND
       IN_PC_RECORD_ID <> 0               THEN
        BEGIN
            SELECT PIPELINE_TX_ID, PIPELINE_REF_ID
              INTO OUT_TFJ303.INVOICE_TX_ID, OUT_TFJ303.INVOICE_NO
              FROM PIPELINE
              WHERE PIPELINE_TX_ID = (
                    SELECT MAX(ID.PIPELINE_TX_ID) as PIPELINE_TX_ID
                      FROM PIPELINE_CHARGES PC,INVOICE_DETAIL ID
                      WHERE PC.PC_RECORD_ID = ID.PIPECHG_RECORD_ID
                        AND PC.PC_RECORD_ID = IN_PC_RECORD_ID
                      GROUP BY ID.PIPECHG_RECORD_ID);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                PFGA3910.TRACE_LOG('I','INVOICE NO NOT FOUND PIPELINE_TX_ID=' || IN_TFJ201.PIPELINE_TX_ID ||
                                       ' HWB_NO=' || IN_TFJ201.HWB_NO ||
                                       ' PC_RECORD_ID=' || IN_PC_RECORD_ID);
            WHEN OTHERS THEN
                RAISE ;
        END ;
        IF OUT_TFJ303.INVOICE_TX_ID IS NOT NULL THEN
            -- BillTo Code�̎擾
            PFGA3950.SEL_PARTNER_ID( OUT_TFJ303.INVOICE_TX_ID,
                                     'BT',
                                     WK_PARTNER_ID,
                                     WK_PARENT_PARTNER_ID,
                                     WK_PARTNER_GROUP_CODE );
            OUT_TFJ303.BILLTO_ID  := WK_PARTNER_ID;
        END IF;
    END IF;

    -- MWB Collect�̃R�X�g�̏ꍇ�AVENDOR_PARTNER_ID��VENDOR_NAME�̃Z�b�g
    IF OUT_TFJ303.EDATKBN = '3'          AND
       IN_TFJ201.IMPORT_EXPORT_IND = 'E' AND
       OUT_TFJ303.PPC_IND = 'C'          AND
       OUT_TFJ303.COST_AMT <> 0          THEN
        FOR WK_REC IN CUR_TFJ201_CHARGES( IN_TFJ201.PIPELINE_TX_ID,
                                          OUT_TFJ303.CHARGE_CODE ) LOOP
            OUT_TFJ303.VENDOR_PARTNER_ID := WK_REC.VENDOR_NO;

            IF OUT_TFJ303.VENDOR_PARTNER_ID IS NOT NULL THEN
                PFGA3950.SEL_PARTNER( OUT_TFJ303.VENDOR_PARTNER_ID,
                                      DMY_PARENT_PARTNER_ID,
                                      WK_PARTNER_NAME,
                                      DMY_LL_PARTNER_NAME,
                                      DMY_PARTNER_SHORT_NAME,
                                      DMY_INDUSTRY_CODE,
                                      DMY_INDUSTRY_NAME );
                OUT_TFJ303.VENDOR_NAME   := WK_PARTNER_NAME;
            END IF;
            EXIT;
        END LOOP;
    END IF;

    -- HWB �̔���̏ꍇ�AACCOUNTING_DATE�̃Z�b�g
    -- CHARGE_STATUS='O'  :Open �܂�UAF�v�サ�Ă��Ȃ�
    -- CHARGE_STATUS='DNI':UAS Interface���Ȃ�Charge
    IF OUT_TFJ303.EDATKBN = '1'           AND
       OUT_TFJ303.CHARGE_STATUS <> 'O'    AND
       OUT_TFJ303.INVOICE_CHARGE_AMT <> 0 THEN
        -- 2005.11.07 Direct Collect�̑Ή�
        IF IN_TFJ201.WAYBILL_TYPE = 'HD' AND
           OUT_TFJ303.PPC_IND     = 'C'  THEN
            WK_CHARGE_STATUS := OUT_TFJ303.CHARGE_STATUS;
            OUT_TFJ303.CHARGE_STATUS := 'DNI';
            FOR WK_REC IN CUR_TFJ201_AP( IN_TFJ201.PIPELINE_TX_ID,
                                         OUT_TFJ303.CHARGE_CODE,
                                         OUT_TFJ303.PPC_IND) LOOP
                OUT_TFJ303.CHARGE_STATUS := WK_CHARGE_STATUS;
                OUT_TFJ303.UAS_CNF_DATE  := WK_REC.DGYMDTM;
                OUT_TFJ303.UAS_GL_DATE   := WK_REC.ACCOUNTING_DATE;
                EXIT;
            END LOOP;
        ELSE
            FOR WK_REC IN CUR_TFJ201_AR( IN_TFJ201.PIPELINE_TX_ID,
                                         OUT_TFJ303.CHARGE_CODE,
                                         OUT_TFJ303.PPC_IND) LOOP
                OUT_TFJ303.UAS_CNF_DATE  := WK_REC.DGYMDTM;
                OUT_TFJ303.UAS_GL_DATE   := WK_REC.ACCOUNTING_DATE;
                EXIT;
            END LOOP;
        END IF;
    END IF;
    -- HWB �̃R�X�g�̏ꍇ�ARECORD_IND,ACCOUNTING_DATE�̃Z�b�g
    IF OUT_TFJ303.EDATKBN = '1'          AND
       OUT_TFJ303.CHARGE_STATUS <> 'O'   AND
       OUT_TFJ303.CHARGE_STATUS <> 'DNI' AND
       OUT_TFJ303.COST_AMT <> 0          THEN
        FOR WK_REC IN CUR_TFJ201_AP_GL( IN_TFJ201.PIPELINE_TX_ID,
                                        OUT_TFJ303.CHARGE_CODE) LOOP
            OUT_TFJ303.RECORD_IND   := WK_REC.RECORD_IND;
            OUT_TFJ303.UAS_CNF_DATE := WK_REC.DGYMDTM;
            OUT_TFJ303.UAS_GL_DATE  := WK_REC.ACCOUNTING_DATE;
            IF OUT_TFJ303.RECORD_IND = 'AP' AND
               OUT_TFJ303.VENDOR_PARTNER_ID <> WK_REC.VENDOR_NO THEN
                OUT_TFJ303.VENDOR_PARTNER_ID := WK_REC.VENDOR_NO;
                PFGA3950.SEL_PARTNER( OUT_TFJ303.VENDOR_PARTNER_ID,
                                      DMY_PARENT_PARTNER_ID,
                                      WK_PARTNER_NAME,
                                      DMY_LL_PARTNER_NAME,
                                      DMY_PARTNER_SHORT_NAME,
                                      DMY_INDUSTRY_CODE,
                                      DMY_INDUSTRY_NAME );
                OUT_TFJ303.VENDOR_NAME   := WK_PARTNER_NAME;
            END IF;
            EXIT;
        END LOOP;
    END IF;
    -- 2004.08.06 Add
    -- MISC �̃R�X�g�̏ꍇ�ARECORD_IND�̃Z�b�g
    -- 2005.10.23 AP_INTERFACE_LINES���VENDOR���擾
    IF OUT_TFJ303.EDATKBN = '8' AND
       OUT_TFJ303.CHARGE_STATUS <> 'O' AND
       OUT_TFJ303.CHARGE_STATUS <> 'DNI' AND
       OUT_TFJ303.COST_AMT <> 0 THEN
        FOR WK_REC IN CUR_AP_LINES( OUT_TFJ303.PC_RECORD_ID) LOOP
            OUT_TFJ303.RECORD_IND   := 'AP';
            OUT_TFJ303.UAS_GL_DATE  := WK_REC.ACCOUNTING_DATE;
            IF OUT_TFJ303.VENDOR_PARTNER_ID <> WK_REC.VENDOR_NUMBER THEN
                OUT_TFJ303.VENDOR_PARTNER_ID := WK_REC.VENDOR_NUMBER;
                PFGA3950.SEL_PARTNER( OUT_TFJ303.VENDOR_PARTNER_ID,
                                      DMY_PARENT_PARTNER_ID,
                                      WK_PARTNER_NAME,
                                      DMY_LL_PARTNER_NAME,
                                      DMY_PARTNER_SHORT_NAME,
                                      DMY_INDUSTRY_CODE,
                                      DMY_INDUSTRY_NAME );
                OUT_TFJ303.VENDOR_NAME   := WK_PARTNER_NAME;
            END IF;
            EXIT;
        END LOOP;
    END IF;

    -- 2005.12.16 Rate Profile�Ή�
    IF (OUT_TFJ303.EDATKBN = '1' OR
        OUT_TFJ303.EDATKBN = '3') AND
       OUT_TFJ303.PCP_RECORD_ID IS NOT NULL THEN
        IF OUT_TFJ303.INVOICE_CHARGE_AMT <> 0 THEN
            FOR WK_REC IN CUR_RP_CHARGE( OUT_TFJ303.PCP_RECORD_ID) LOOP
                OUT_TFJ303.RP_RECORD_ID       := WK_REC.RP_RECORD_ID;
                OUT_TFJ303.CALCULATION_METHOD := WK_REC.CALCULATION_METHOD;
                OUT_TFJ303.RATE_PROFILE_NAME  := WK_REC.RATE_PROFILE_NAME;
                OUT_TFJ303.RATE_DESCRIPTION   := WK_REC.DESCRIPTION;
                OUT_TFJ303.TAXABLE_IND        := TRIM(WK_REC.TAXABLE_IND);
                EXIT;
            END LOOP;
        ELSE
            FOR WK_REC IN CUR_RP_COST( OUT_TFJ303.PCP_RECORD_ID) LOOP
                OUT_TFJ303.RP_RECORD_ID       := WK_REC.RP_RECORD_ID;
                OUT_TFJ303.CALCULATION_METHOD := WK_REC.CALCULATION_METHOD;
                OUT_TFJ303.RATE_PROFILE_NAME  := WK_REC.RATE_PROFILE_NAME;
                OUT_TFJ303.RATE_DESCRIPTION   := WK_REC.DESCRIPTION;
                OUT_TFJ303.TAXABLE_IND        := NULL;
                EXIT;
            END LOOP;
        END IF;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','PIPELINE_CHARGES: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- INVOICE ���і��׋��z�A�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ303_INV(
    IN_TFJ201    IN         TFJ201%ROWTYPE,        -- UASIF
    IN_INV       IN         CUR_INV%ROWTYPE )      -- INVOICE
IS
    WK_TFJ303             TFJ303%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ303_INV' );

    WK_TFJ303 := NULL;

        -- ����
    WK_TFJ303.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ303.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ303.DHNEDTM                 := SYSDATE;
    WK_TFJ303.EUPD_OFCCD              := '!';
    WK_TFJ303.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    -- HWB_TX_ID��0�̎��i���̑������j�AINVOICE_TX_ID���Z�b�g�A�����敪'1'
    WK_TFJ303.EDATKBN                 := '8';
    WK_TFJ303.ESKY_KBN                := '1';

    WK_TFJ303.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    WK_TFJ303.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    WK_TFJ303.NGENNO                  := 1;
    -- Global:PIPELINE_TX_TYPE��KEY�̈ꕔ
    WK_TFJ303.PIPELINE_TX_TYPE        := 'IN';

    -- �R���g���[��
    WK_TFJ303.NAKKBN                  := 1;
    WK_TFJ303.EDELKBN                 := '0';
    WK_TFJ303.EOPE_KBN                := '0';       -- �V�K

    -- ���і��׋��z�i���j�ACharges�ҏW�o��
    OUTPUT_TFJ303_CHARGES_INV( IN_TFJ201, IN_INV, WK_TFJ303 );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- INVOICE ���і��׋��z�ACharges�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ303_CHARGES_INV(
    IN_TFJ201    IN               TFJ201%ROWTYPE,       -- UASIF
    IN_INV       IN               CUR_INV%ROWTYPE,      -- INVOICE
    IN_TFJ303    IN OUT           TFJ303%ROWTYPE )
IS
    CURSOR CUR_INVOICE_DETAIL(
        KEY_PIPELINE_TX_ID    INVOICE_DETAIL.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT *
        FROM INVOICE_DETAIL
        WHERE PIPELINE_TX_ID = KEY_PIPELINE_TX_ID
        ORDER BY CHARGE_CODE,
                 COST_CURRENCY_CODE,
                 VENDOR_PARTNER_ID,
                 VENDOR_REF_NO,
                 INVD_RECORD_ID DESC;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    WK_CHARGE_CODE          INVOICE_DETAIL.CHARGE_CODE%TYPE        := '#';
    WK_COST_CURRENCY_CODE   INVOICE_DETAIL.COST_CURRENCY_CODE%TYPE := '#';
    WK_VENDOR_PARTNER_ID    INVOICE_DETAIL.VENDOR_PARTNER_ID%TYPE  := '#';
    WK_VENDOR_REF_NO        INVOICE_DETAIL.VENDOR_REF_NO%TYPE      := '#';
    WK_TFM205         TFM205%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ303_CHARGES_INV' );

    -- BillTo Code�̎擾
    PFGA3950.SEL_PARTNER_ID( IN_INV.PIPELINE_TX_ID,
                             'BT',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );

    FOR WK_REC IN CUR_INVOICE_DETAIL( IN_TFJ303.PIPELINE_TX_ID ) LOOP

        IF WK_REC.CHARGE_CODE                <> WK_CHARGE_CODE        OR
           NVL(WK_REC.COST_CURRENCY_CODE,IN_INV.OC_CURRENCY_CODE)
                                             <> WK_COST_CURRENCY_CODE OR
           NVL(WK_REC.VENDOR_PARTNER_ID,'!') <> WK_VENDOR_PARTNER_ID  OR
           NVL(WK_REC.VENDOR_REF_NO,'!')     <> WK_VENDOR_REF_NO      THEN
            IF WK_CHARGE_CODE <> '#' THEN
                -- ���і��׋��z��ҏW
                EDIT_TFJ303( IN_TFJ201, 0, IN_TFJ303 );
                -- ���і��׋��z���쐬
                INS_TFJ303( IN_TFJ303 );
            END IF;

            -- �������ڃ}�X�^����
            SEL_TFM205( IN_TFJ201, WK_REC.CHARGE_CODE, WK_TFM205 );
            IN_TFJ303.CHARGE_CODE         := WK_REC.CHARGE_CODE;

            IN_TFJ303.CHARGE_DESCRIPTION  := WK_REC.CHARGE_DESCRIPTION;
            IN_TFJ303.CHARGE_STATUS       := IN_INV.ACCTG_INTERFACE_STATUS;
            IF IN_TFJ201.IMPORT_EXPORT_IND = 'E' THEN
                IN_TFJ303.PPC_IND         := 'P';
            ELSE
                IN_TFJ303.PPC_IND         := 'C';
            END IF;
            -- 2005.07.11 TFJ303��PK��PC_RECORD_ID��ǉ�
            IN_TFJ303.PC_RECORD_ID        := WK_REC.INVD_RECORD_ID;
            IN_TFJ303.IMPORT_EXPORT_IND   := IN_TFJ201.IMPORT_EXPORT_IND;
            IN_TFJ303.CATEGORY_CODE       := NULL;
            IF WK_TFM205.CHARGE_CODE IS NOT NULL THEN
                IN_TFJ303.NKMK_ITI              := WK_TFM205.NKMK_ITI;
                IN_TFJ303.EPRT_TAG              := WK_TFM205.EURI_PRT_TAG1;
                IN_TFJ303.SUMMARY_CATEGORY_CODE := WK_TFM205.ESUMGASNID;
                IN_TFJ303.ACCTG_CATEGORY_CODE   := WK_TFM205.ESYUGOID;
                IN_TFJ303.ASSOC_TX_TYPE         := WK_TFM205.EHSI_KYOKMNKBN;
            ELSE
                IN_TFJ303.NKMK_ITI              := 0;
                IN_TFJ303.EPRT_TAG              := '!';
                IN_TFJ303.SUMMARY_CATEGORY_CODE := NULL;
                IN_TFJ303.ACCTG_CATEGORY_CODE   := NULL;
                IN_TFJ303.ASSOC_TX_TYPE         := NULL;
            END IF;
--
            IN_TFJ303.INVOICE_NO               := IN_INV.PIPELINE_REF_ID;
            IN_TFJ303.INVOICE_TX_ID            := IN_INV.PIPELINE_TX_ID;
            IN_TFJ303.BILLTO_ID                := WK_PARTNER_ID;
            IN_TFJ303.RECORD_IND               := NULL;
--
            IN_TFJ303.INVOICE_WB_AMT           := 0;
            IN_TFJ303.INVOICE_WB_CURRENCY_CODE := NULL;
            IN_TFJ303.INVOICE_WB_EXCHANGE_RATE := 0;
--
            IN_TFJ303.INVOICE_CHARGE_AMT     := 0;
            IN_TFJ303.INVOICE_CURRENCY_CODE  := IN_INV.INVOICE_CURRENCY_CODE;
            IN_TFJ303.INVOICE_EXCHANGE_RATE  := WK_REC.INVOICE_EXCHANGE_RATE;
--
            IN_TFJ303.OC_INVOICE_CHARGE_AMT  := 0;
            IN_TFJ303.OC_CURRENCY_CODE       := IN_INV.OC_CURRENCY_CODE;
--
            IN_TFJ303.VENDOR_NAME         := WK_REC.VENDOR_NAME;
            IN_TFJ303.VENDOR_PARTNER_ID   := WK_REC.VENDOR_PARTNER_ID;
            IN_TFJ303.VENDOR_ADDRESS_NO   := WK_REC.VENDOR_ADDRESS_NO;
            IN_TFJ303.VENDOR_REF_NO       := WK_REC.VENDOR_REF_NO;
--
            IN_TFJ303.COST_AMT            := 0;
            IN_TFJ303.COST_CURRENCY_CODE  := NVL(WK_REC.COST_CURRENCY_CODE,IN_INV.OC_CURRENCY_CODE);
            IN_TFJ303.COST_EXCHANGE_RATE  := WK_REC.COST_EXCHANGE_RATE;
            IN_TFJ303.OC_COST_AMT         := 0;
--
            IN_TFJ303.CREATED_FROM        := NULL;
            IN_TFJ303.UAS_CNF_DATE        := IN_TFJ201.DGYMDTM;
            IN_TFJ303.UAS_GL_DATE         := IN_INV.UAS_GL_DATE;
            IN_TFJ303.UAS_GL_DATE_TZ_CODE := IN_INV.UAS_GL_DATE_TZ_CODE;
            -- 2005.11.12 Rate Profile�Ή�
            IN_TFJ303.PCP_RECORD_ID       := NULL;
            IN_TFJ303.RP_RECORD_ID        := NULL;
            IN_TFJ303.CALCULATION_METHOD  := NULL;
            IN_TFJ303.RATE_PROFILE_NAME   := NULL;
            IN_TFJ303.RATE_DESCRIPTION    := NULL;
            IN_TFJ303.RATE                := NULL;
            IN_TFJ303.RATE_UOM            := NULL;
            IN_TFJ303.PRINT_IND           := NULL;
            IN_TFJ303.ACCRUAL_COST_IND    := NULL;
            IN_TFJ303.TAXABLE_IND         := NULL;

            WK_CHARGE_CODE                := WK_REC.CHARGE_CODE;
            WK_COST_CURRENCY_CODE         := NVL(WK_REC.COST_CURRENCY_CODE,IN_INV.OC_CURRENCY_CODE);
            WK_VENDOR_PARTNER_ID          := NVL(WK_REC.VENDOR_PARTNER_ID,'!');
            WK_VENDOR_REF_NO              := NVL(WK_REC.VENDOR_REF_NO,'!');
        END IF;

        IN_TFJ303.INVOICE_CHARGE_AMT      := IN_TFJ303.INVOICE_CHARGE_AMT
                                              + WK_REC.INVOICE_CHARGE_AMT;
        IN_TFJ303.OC_INVOICE_CHARGE_AMT   := IN_TFJ303.OC_INVOICE_CHARGE_AMT
                                              + WK_REC.OC_CHARGE_AMT;
        IN_TFJ303.COST_AMT                := IN_TFJ303.COST_AMT
                                              + WK_REC.ACTUAL_COST_AMT;
        IN_TFJ303.OC_COST_AMT             := IN_TFJ303.OC_COST_AMT
                                              + WK_REC.OC_COST_AMT;
    END LOOP;

    IF WK_CHARGE_CODE <> '#' THEN
        -- ���і��׋��z��ҏW
        EDIT_TFJ303( IN_TFJ201, 0, IN_TFJ303 );
        -- ���і��׋��z���쐬
        INS_TFJ303( IN_TFJ303 );
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','INVOICE_DETAIL: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �������ڃ}�X�^����
--================================================
PROCEDURE SEL_TFM205(
    IN_TFJ201      IN          TFJ201%ROWTYPE,                -- UASIF
    IN_CHARGE_CODE IN          TFM205.CHARGE_CODE%TYPE,
    OUT_TFM205     IN OUT      TFM205%ROWTYPE )
IS
    CURSOR CUR_TFM205(
        KEY_COMPANY_ID         TFM205.COMPANY_ID%TYPE,
        KEY_IMPORT_EXPORT_IND  TFM205.IMPORT_EXPORT_IND%TYPE,
        KEY_TRANSPORT_MODE     TFM205.TRANSPORT_MODE%TYPE,
        KEY_CHARGE_CODE        TFM205.CHARGE_CODE%TYPE
    ) IS
      SELECT *
      FROM TFM205
      WHERE COMPANY_ID        = KEY_COMPANY_ID
       AND  IMPORT_EXPORT_IND = KEY_IMPORT_EXPORT_IND
       AND  TRANSPORT_MODE    = KEY_TRANSPORT_MODE
       AND  CHARGE_CODE       = KEY_CHARGE_CODE
       AND  ESISNKBN = '1';

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'SEL_TFM205' );

    OUT_TFM205.CHARGE_CODE := NULL;
    FOR WK_REC IN CUR_TFM205( IN_TFJ201.COMPANY_ID,
                                        IN_TFJ201.IMPORT_EXPORT_IND,
                                        IN_TFJ201.TRANSPORT_MODE,
                                        IN_CHARGE_CODE) LOOP
        OUT_TFM205 := WK_REC;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFM205: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ���і��׋��z��V�K�쐬
--================================================
PROCEDURE INS_TFJ303(
    IN_TFJ303   IN  TFJ303%ROWTYPE )         -- ���і��׋��z
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'INS_TFJ303' );

    INSERT INTO TFJ303(
        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
        -- �j�d�x
        EDATKBN,
        PIPELINE_TX_ID,
        DGYMDTM,
        NGENNO,
        PIPELINE_TX_TYPE,
        CHARGE_CODE,
        PPC_IND,
        PC_RECORD_ID,                        -- 2005.10.23
        -- �R���g���[��
        NAKKBN,
        EDELKBN,
        ESKY_KBN,
        EOPE_KBN,
--
        CHARGE_DESCRIPTION,
        CHARGE_STATUS,
        IMPORT_EXPORT_IND,
        NKMK_ITI,
        EPRT_TAG,
        CATEGORY_CODE,
        SUMMARY_CATEGORY_CODE,
        ACCTG_CATEGORY_CODE,
        ASSOC_TX_TYPE,
--
        INVOICE_NO,
        INVOICE_TX_ID,
        BILLTO_ID,
        RECORD_IND,
--
        INVOICE_WB_AMT,
        INVOICE_WB_CURRENCY_CODE,
        INVOICE_WB_EXCHANGE_RATE,
--
        INVOICE_CHARGE_AMT,
        INVOICE_CURRENCY_CODE,
        INVOICE_EXCHANGE_RATE,
--
        OC_INVOICE_CHARGE_AMT,
        OC_CURRENCY_CODE,
--
        VENDOR_NAME,
        VENDOR_PARTNER_ID,
        VENDOR_ADDRESS_NO,
        VENDOR_REF_NO,
--
        COST_AMT,
        COST_CURRENCY_CODE,
        COST_EXCHANGE_RATE,
        OC_COST_AMT,
--
        CREATED_FROM,
        UAS_CNF_DATE,
        UAS_GL_DATE,
        UAS_GL_DATE_TZ_CODE,
-- 2005.12.16 Rate Profile�Ή�
        PCP_RECORD_ID,
        RP_RECORD_ID,
        CALCULATION_METHOD,
        RATE_PROFILE_NAME,
        RATE_DESCRIPTION,
        RATE,
        RATE_UOM,
        PRINT_IND,
        ACCRUAL_COST_IND,
        TAXABLE_IND )
      VALUES(
        -- ����
        IN_TFJ303.ETRKDTM,
        IN_TFJ303.EUPDDTM,
        IN_TFJ303.DHNEDTM,
        IN_TFJ303.EUPD_OFCCD,
        IN_TFJ303.EUPD_TNTCD,
        -- �j�d�x
        IN_TFJ303.EDATKBN,
        IN_TFJ303.PIPELINE_TX_ID,
        IN_TFJ303.DGYMDTM,
        IN_TFJ303.NGENNO,
        IN_TFJ303.PIPELINE_TX_TYPE,
        IN_TFJ303.CHARGE_CODE,
        IN_TFJ303.PPC_IND,
        IN_TFJ303.PC_RECORD_ID,                        -- 2005.10.23
        -- �R���g���[��
        IN_TFJ303.NAKKBN,
        IN_TFJ303.EDELKBN,
        IN_TFJ303.ESKY_KBN,
        IN_TFJ303.EOPE_KBN,
--
        IN_TFJ303.CHARGE_DESCRIPTION,
        IN_TFJ303.CHARGE_STATUS,
        IN_TFJ303.IMPORT_EXPORT_IND,
        IN_TFJ303.NKMK_ITI,
        IN_TFJ303.EPRT_TAG,
        IN_TFJ303.CATEGORY_CODE,
        IN_TFJ303.SUMMARY_CATEGORY_CODE,
        IN_TFJ303.ACCTG_CATEGORY_CODE,
        IN_TFJ303.ASSOC_TX_TYPE,
--
        IN_TFJ303.INVOICE_NO,
        IN_TFJ303.INVOICE_TX_ID,
        IN_TFJ303.BILLTO_ID,
        IN_TFJ303.RECORD_IND,
--
        IN_TFJ303.INVOICE_WB_AMT,
        IN_TFJ303.INVOICE_WB_CURRENCY_CODE,
        IN_TFJ303.INVOICE_WB_EXCHANGE_RATE,
--
        IN_TFJ303.INVOICE_CHARGE_AMT,
        IN_TFJ303.INVOICE_CURRENCY_CODE,
        IN_TFJ303.INVOICE_EXCHANGE_RATE,
--
        IN_TFJ303.OC_INVOICE_CHARGE_AMT,
        IN_TFJ303.OC_CURRENCY_CODE,
--
        IN_TFJ303.VENDOR_NAME,
        IN_TFJ303.VENDOR_PARTNER_ID,
        IN_TFJ303.VENDOR_ADDRESS_NO,
        IN_TFJ303.VENDOR_REF_NO,
--
        IN_TFJ303.COST_AMT,
        IN_TFJ303.COST_CURRENCY_CODE,
        IN_TFJ303.COST_EXCHANGE_RATE,
        IN_TFJ303.OC_COST_AMT,
--
        IN_TFJ303.CREATED_FROM,
        IN_TFJ303.UAS_CNF_DATE,
        IN_TFJ303.UAS_GL_DATE,
        IN_TFJ303.UAS_GL_DATE_TZ_CODE,
-- 2005.11.12 Rate Profile�Ή�
        IN_TFJ303.PCP_RECORD_ID,
        IN_TFJ303.RP_RECORD_ID,
        IN_TFJ303.CALCULATION_METHOD,
        IN_TFJ303.RATE_PROFILE_NAME,
        IN_TFJ303.RATE_DESCRIPTION,
        IN_TFJ303.RATE,
        IN_TFJ303.RATE_UOM,
        IN_TFJ303.PRINT_IND,
        IN_TFJ303.ACCRUAL_COST_IND,
        IN_TFJ303.TAXABLE_IND );

    IF IN_TFJ303.NAKKBN = 1 THEN
        WK_TFJ303_KURO_CNT := WK_TFJ303_KURO_CNT + 1;
    ELSE
        WK_TFJ303_AKA_CNT  := WK_TFJ303_AKA_CNT + 1;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ303: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- HWB ����Invoice�A�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ304(
    IN_TFJ201    IN         TFJ201%ROWTYPE,       -- UASIF
    IN_NGENNO    IN         TFJ304.NGENNO%TYPE )
IS
    -- 2005.04.18 Invoice���o��TFJ303����PIPELINE_RELATION�ɕύX
    -- ���і��׋��z���o�J�[�\��
--    CURSOR CUR_TFJ303( KEY_PIPELINE_TX_ID  IN TFJ303.PIPELINE_TX_ID%TYPE,
--                       KEY_DGYMDTM         IN TFJ303.DGYMDTM%TYPE,
--                       KEY_NGENNO          IN TFJ303.NGENNO%TYPE ) IS
--        SELECT INVOICE_TX_ID, INVOICE_NO
--          FROM TFJ303
--          WHERE EDATKBN         = '1'
--            AND PIPELINE_TX_ID  = KEY_PIPELINE_TX_ID
--            AND DGYMDTM         = KEY_DGYMDTM
--            AND NGENNO          = KEY_NGENNO
--            AND INVOICE_TX_ID IS NOT NULL
--            AND INVOICE_NO IS NOT NULL
--          GROUP BY INVOICE_TX_ID,INVOICE_NO;

   -- PIPELINE_RELATION���o�J�[�\��
   -- Invoice Close
   -- Do not Interface��Omit
   -- Void��Credit��Omit

    CURSOR CUR_INVOICE(
        KEY_PIPELINE_TX_ID    PIPELINE_RELATIONS.PIPELINE_TX_ID%TYPE,
        KEY_IMPORT_EXPORT_IND INVOICE_HEADER.IMPORT_EXPORT_IND%TYPE) IS
        SELECT PIPE.PIPELINE_TX_ID  as INVOICE_TX_ID,
               PIPE.PIPELINE_REF_ID as INVOICE_NO
          FROM PIPELINE_RELATIONS REL,
               PIPELINE           PIPE,
               INVOICE_HEADER     IH
        WHERE REL.PIPELINE_TX_ID       = KEY_PIPELINE_TX_ID
          AND REL.PIPELINE_TX_TYPE     = 'SH'
          AND REL.REL_PIPELINE_TX_TYPE = 'IN'
          AND PIPE.PIPELINE_TX_ID      = REL.REL_PIPELINE_TX_ID
          AND IH.PIPELINE_TX_ID        = PIPE.PIPELINE_TX_ID
          AND IH.IMPORT_EXPORT_IND     = KEY_IMPORT_EXPORT_IND
          AND PIPE.PIPELINE_TX_STATUS = 'C'
          AND (IH.ACCTG_INTERFACE_STATUS <> 'DNI' OR IH.ACCTG_INTERFACE_STATUS IS NULL)
          AND (IH.INVOICE_PROCESS_TYPE   <> 'VD'  OR IH.INVOICE_PROCESS_TYPE IS NULL);

    WK_TFJ304               TFJ304%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ304' );

    WK_TFJ304 := NULL;

    -- ����
    WK_TFJ304.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ304.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ304.DHNEDTM                 := SYSDATE;
    WK_TFJ304.EUPD_OFCCD              := '!';
    WK_TFJ304.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    -- HWB_TX_ID��0�ȊO�̎��iSHIPMENT�P�ʁj�AHWB_TX_ID���Z�b�g�A�����敪'0'
    WK_TFJ304.EDATKBN                 := '1';
    WK_TFJ304.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    WK_TFJ304.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    WK_TFJ304.NGENNO                  := IN_NGENNO;
    -- �R���g���[��
    WK_TFJ304.NAKKBN                  := 1;
    WK_TFJ304.EDELKBN                 := '0';
    WK_TFJ304.ESKY_KBN                := '0';
    IF IN_NGENNO = 1 THEN
        WK_TFJ304.EOPE_KBN            := '0';       -- �V�K
    ELSE
        WK_TFJ304.EOPE_KBN            := '1';       -- �C��
    END IF;

    -- PIPELINE_RELATIONS���o
    FOR WK_REC IN CUR_INVOICE( IN_TFJ201.PIPELINE_TX_ID,
                               IN_TFJ201.IMPORT_EXPORT_IND) LOOP
        WK_TFJ304.INVOICE_TX_ID       := WK_REC.INVOICE_TX_ID;
        WK_TFJ304.INVOICE_NO          := WK_REC.INVOICE_NO;

        -- HWB ����Invoice�A�ҏW�o��(by Invoice Header)
        OUTPUT_TFJ304_IH( IN_TFJ201, WK_TFJ304 );
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ304: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- INVOICE ����Invoice�A�ҏW�o��
--================================================
PROCEDURE OUTPUT_TFJ304_INV(
    IN_TFJ201    IN         TFJ201%ROWTYPE,        -- UASIF
    IN_INV       IN         CUR_INV%ROWTYPE )      -- INVOICE
IS
    WK_TFJ304               TFJ304%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ304_INV' );

    WK_TFJ304 := NULL;

        -- ����
    WK_TFJ304.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ304.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ304.DHNEDTM                 := SYSDATE;
    WK_TFJ304.EUPD_OFCCD              := '!';
    WK_TFJ304.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    -- HWB_TX_ID��0�̎��i���̑������j�AINVOICE_TX_ID���Z�b�g�A�����敪'1'
    WK_TFJ304.EDATKBN                 := '8';
    WK_TFJ304.PIPELINE_TX_ID          := IN_TFJ201.PIPELINE_TX_ID;
    WK_TFJ304.DGYMDTM                 := IN_TFJ201.DGYMDTM;
    WK_TFJ304.NGENNO                  := 1;
    WK_TFJ304.INVOICE_TX_ID           := IN_INV.PIPELINE_TX_ID;
    -- �R���g���[��
    WK_TFJ304.NAKKBN                  := 1;
    WK_TFJ304.EDELKBN                 := '0';
    WK_TFJ304.ESKY_KBN                := '1';
    WK_TFJ304.EOPE_KBN                := '0';       -- �V�K

    WK_TFJ304.INVOICE_NO              := IN_INV.PIPELINE_REF_ID;

    IF IN_TFJ201.IMPORT_EXPORT_IND = 'E' THEN
        WK_TFJ304.PPC_IND             := 'P';
    ELSE
        WK_TFJ304.PPC_IND             := 'C';
    END IF;

    -- HWB ����Invoice�A�ҏW�o��(by Invoice Header)
    OUTPUT_TFJ304_IH( IN_TFJ201, WK_TFJ304 );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- HWB ����Invoice�A�ҏW�o��(by Invoice Header)
--================================================
PROCEDURE OUTPUT_TFJ304_IH(
    IN_TFJ201    IN         TFJ201%ROWTYPE,       -- UASIF          2004.10.02
    IN_TFJ304    IN OUT     TFJ304%ROWTYPE )      -- ����Invoice
IS
    -- Invoice Header���o�J�[�\��
    CURSOR CUR_IH( KEY_PIPELINE_TX_ID   INVOICE_HEADER.PIPELINE_TX_ID%TYPE ) IS
        SELECT IH.*, ZONE.HOURS_FROM_GMT
          FROM INVOICE_HEADER IH,
               TIME_ZONE      ZONE
          WHERE IH.PIPELINE_TX_ID      = KEY_PIPELINE_TX_ID
            AND ZONE.TIME_ZONE_CODE(+) = IH.ACCTG_DATE_TZ_CODE;

    -- GUI_NUMBER���o�J�[�\��
    -- Global(TW)
    -- 2005.04.29 GUI_NO��KWETW_RA_INTERFACE_LINES�ɕύX
--    CURSOR CUR_TFJ201( KEY_INVOICE_TX_ID   TFJ201.INVOICE_TX_ID%TYPE ) IS
--      SELECT GUI_NUMBER, GUI_DATE
--      FROM TFJ201
--      WHERE RECORD_IND    = 'AR'
--        AND INVOICE_TX_ID = KEY_INVOICE_TX_ID
--        AND GUI_NUMBER IS NOT NULL
--      ORDER BY GUI_NUMBER DESC;

    -- 2005.12.16 GUI_NO�̃Z�b�g��PFGA3040ALTER�Ŏ��s
--    CURSOR CUR_GUI_NUMBER(
--        KEY_INVOICE_NO   KWETW_RA_INTERFACE_LINES.INTERFACE_LINE_ATTRIBUTE1%TYPE
--    ) IS
--        SELECT GUI_NUMBER,
--               GUI_DATE
--        FROM KWETW_RA_INTERFACE_LINES
--        WHERE INTERFACE_LINE_ATTRIBUTE1 = KEY_INVOICE_NO
--          AND GUI_ISSUE_FLAG = 'Y'
--        ORDER BY INTERFACE_LINE_ATTRIBUTE2;

    WK_PIPELINE_REF_ID     PIPELINE.PIPELINE_REF_ID%TYPE;
    WK_DATE                DATE;
    WK_PIPELINE_TX_STATUS  PIPELINE.PIPELINE_TX_STATUS%TYPE;
    WK_PIPELINE_TX_ID      PIPELINE.PIPELINE_TX_ID%TYPE;
    DMY_PORT_ORIGIN         PIPELINE.PORT_ORIGIN%TYPE;
    DMY_PORT_LOADING        PIPELINE.PORT_LOADING%TYPE;
    DMY_PORT_UNLOADING      PIPELINE.PORT_UNLOADING%TYPE;
    DMY_PORT_DEST           PIPELINE.PORT_DEST%TYPE;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

    WK_CUSTOMER_IND         PARTNER.CUSTOMER_IND%TYPE;
    WK_SHIPPER_IND          PARTNER.SHIPPER_IND%TYPE;
    WK_CNEE_IND             PARTNER.CNEE_IND%TYPE;
    WK_VENDOR_IND           PARTNER.VENDOR_IND%TYPE;
    WK_AGENT_IND            PARTNER.AGENT_IND%TYPE;

    WK_ADDRESS              ADDRESS%ROWTYPE;        -- 2005.04.18

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ304_IH' );

    -- Pipeline �擾 2004.10.10
    PFGA3950.SEL_PIPELINE( IN_TFJ304.INVOICE_TX_ID,
                             'IN',
                             WK_PIPELINE_REF_ID,
                             WK_DATE,
                             WK_PIPELINE_TX_STATUS,
                             DMY_PORT_ORIGIN,
                             DMY_PORT_LOADING,
                             DMY_PORT_UNLOADING,
                             DMY_PORT_DEST );
    IN_TFJ304.INVOICE_DATE        := WK_DATE;
    IN_TFJ304.PIPELINE_TX_STATUS  := WK_PIPELINE_TX_STATUS;

    -- BillTo Code�̎擾
    PFGA3950.SEL_PARTNER_ID( IN_TFJ304.INVOICE_TX_ID,
                             'BT',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    IN_TFJ304.BILLTO_ID               := WK_PARTNER_ID;
    -- 2005.04.18 Add
    IN_TFJ304.BILLTO_PARENT_ID       := WK_PARENT_PARTNER_ID;
    IN_TFJ304.BILLTO_GROUP_ID        := WK_PARTNER_GROUP_CODE;

    -- Partner Indication�擾               2004.10.03
    IF IN_TFJ304.BILLTO_ID IS NOT NULL THEN
        PFGA3950.SEL_PARTNER_INDICATION( IN_TFJ304.BILLTO_ID,
                                         WK_CUSTOMER_IND,
                                         WK_SHIPPER_IND,
                                         WK_CNEE_IND,
                                         WK_VENDOR_IND,
                                         WK_AGENT_IND );
    ELSE
        WK_CUSTOMER_IND := NULL;
        WK_SHIPPER_IND  := NULL;
        WK_CNEE_IND     := NULL;
        WK_VENDOR_IND   := NULL;
        WK_AGENT_IND    := NULL;
    END IF;
    IN_TFJ304.CUSTOMER_IND := WK_CUSTOMER_IND;
    IN_TFJ304.SHIPPER_IND  := WK_SHIPPER_IND;
    IN_TFJ304.CNEE_IND     := WK_CNEE_IND;
    IN_TFJ304.VENDOR_IND   := WK_VENDOR_IND;
    IN_TFJ304.AGENT_IND    := WK_AGENT_IND;

    -- Invoice Header���o
    FOR WK_REC IN CUR_IH( IN_TFJ304.INVOICE_TX_ID ) LOOP
        IN_TFJ304.IMPORT_EXPORT_IND      := TRIM(WK_REC.IMPORT_EXPORT_IND);
        IN_TFJ304.TRANSPORT_MODE         := WK_REC.TRANSPORT_MODE;
        -- 2005.06.19 MY JOB_NO�Ή�
        IF IN_TFJ304.IMPORT_EXPORT_IND = 'E' THEN
            PFGA3950.SEL_JOB_NO( IN_TFJ304.INVOICE_TX_ID,
                                         'IN',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNE',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
        ELSE
            PFGA3950.SEL_JOB_NO( IN_TFJ304.INVOICE_TX_ID,
                                         'IN',                     -- PIPELINE_TX_TYPE
                                         'JN',                     -- REL_PIPELINE_TX_TYPE
                                         'JNI',                    -- PIPELINE_REF_TYPE
                                         WK_PIPELINE_REF_ID,
                                         WK_PIPELINE_TX_ID );
        END IF;
        IN_TFJ304.JOB_NO              := WK_PIPELINE_REF_ID;
        IN_TFJ304.JOB_TX_ID           := WK_PIPELINE_TX_ID;

        IN_TFJ304.BILLTO_NAME         := WK_REC.BILLTO_NAME;
        IN_TFJ304.REMITTO_NAME        := WK_REC.REMITTO_NAME;

        IN_TFJ304.INVOICE_CURRENCY_CODE
                                      := WK_REC.INVOICE_CURRENCY_CODE;
        IN_TFJ304.INVOICE_AMT         := NVL(WK_REC.INVOICE_AMT,0);
        IN_TFJ304.TAXABLE_AMT         := NVL(WK_REC.TAXABLE_AMT,0);
        IN_TFJ304.NON_TAXABLE_AMT     := NVL(WK_REC.NON_TAXABLE_AMT,0);
        IN_TFJ304.TAX1_AMT            := NVL(WK_REC.TAX1_AMT,0);
        IN_TFJ304.TAX2_AMT            := NVL(WK_REC.TAX2_AMT,0);
        IN_TFJ304.TAX3_AMT            := NVL(WK_REC.TAX3_AMT,0);
        IN_TFJ304.TAX4_AMT            := NVL(WK_REC.TAX4_AMT,0);

        IN_TFJ304.OC_CURRENCY_CODE    := WK_REC.OC_CURRENCY_CODE;
        IN_TFJ304.OC_INVOICE_AMT      := NVL(WK_REC.OC_INVOICE_AMT,0);
        IN_TFJ304.OC_TAXABLE_AMT      := NVL(WK_REC.OC_TAXABLE_AMT,0);
        IN_TFJ304.OC_NON_TAXABLE_AMT  := NVL(WK_REC.OC_NON_TAXABLE_AMT,0);
        IN_TFJ304.OC_TAX1_AMT         := NVL(WK_REC.OC_TAX1_AMT,0);
        IN_TFJ304.OC_TAX2_AMT         := NVL(WK_REC.OC_TAX2_AMT,0);
        IN_TFJ304.OC_TAX3_AMT         := NVL(WK_REC.OC_TAX3_AMT,0);
        IN_TFJ304.OC_TAX4_AMT         := NVL(WK_REC.OC_TAX4_AMT,0);

        IN_TFJ304.TAX1_EXCHANGE_RATE  := NVL(WK_REC.TAX1_EXCHANGE_RATE,0);
        IN_TFJ304.TAX2_EXCHANGE_RATE  := NVL(WK_REC.TAX2_EXCHANGE_RATE,0);
        IN_TFJ304.TAX3_EXCHANGE_RATE  := NVL(WK_REC.TAX3_EXCHANGE_RATE,0);
        IN_TFJ304.TAX4_EXCHANGE_RATE  := NVL(WK_REC.TAX4_EXCHANGE_RATE,0);

        IN_TFJ304.TAX1_RATE           := NVL(WK_REC.TAX1_RATE,0);
        IN_TFJ304.TAX2_RATE           := NVL(WK_REC.TAX2_RATE,0);
        IN_TFJ304.TAX3_RATE           := NVL(WK_REC.TAX3_RATE,0);
        IN_TFJ304.TAX4_RATE           := NVL(WK_REC.TAX4_RATE,0);

        IN_TFJ304.UAS_GL_DATE         := WK_REC.UAS_GL_DATE;
        IN_TFJ304.UAS_GL_DATE_TZ_CODE := WK_REC.UAS_GL_DATE_TZ_CODE;

        IN_TFJ304.ACCTG_INTERFACE_STATUS := WK_REC.ACCTG_INTERFACE_STATUS;
        IN_TFJ304.ORIGINAL_INVOICE_DATE  := WK_REC.ORIGINAL_INVOICE_DATE;
        IF WK_REC.ACCTG_DATE_TZ_CODE IS NOT NULL THEN
            IN_TFJ304.ACCTG_CLOSE_DATE   := TO_DATE(TO_CHAR(WK_REC.ACCTG_CLOSE_DATE+WK_REC.HOURS_FROM_GMT/24,'YYYY/MM/DD'),
                                                    'YYYY/MM/DD');
        ELSE
            IN_TFJ304.ACCTG_CLOSE_DATE   := NULL;
        END IF;
        IN_TFJ304.GOVT_INVOICE_NO        := WK_REC.GOVT_INVOICE_NO;
        IN_TFJ304.REMARKS                := WK_REC.REMARKS;
        -- 2005.04.18 Add
        IN_TFJ304.INVOICE_PROCESS_TYPE   := WK_REC.INVOICE_PROCESS_TYPE;
        IN_TFJ304.BILLTO_ADDRESS_NO      := WK_REC.BILLTO_ADDRESS_NO;
        IN_TFJ304.BILLTO_CONTACT_NO      := WK_REC.BILLTO_CONTACT_NO;
        -- 2005.04.18 BILL_TO��ADDRESS���擾
        PFGA3950.SEL_ADDRESS( IN_TFJ304.BILLTO_ADDRESS_NO, WK_ADDRESS );
        IN_TFJ304.BILLTO_CITY_NAME       := WK_ADDRESS.CITY_NAME;
        IN_TFJ304.BILLTO_REGION_CODE     := WK_ADDRESS.REGION_CODE;
        IN_TFJ304.BILLTO_REGION_NAME     := WK_ADDRESS.REGION_NAME;
        IN_TFJ304.BILLTO_POSTAL_CODE     := WK_ADDRESS.POSTAL_CODE;
        IN_TFJ304.BILLTO_COUNTRY_CODE    := WK_ADDRESS.COUNTRY_CODE;

-- 2005.12.16 TW GUI_NO�̃Z�b�g��PFGA3040ALTER�Ŏ��s
--        IF IN_TFJ201.COMPANY_ID in ('590','591','592') THEN                 -- KWETW
--            -- GUI_NUMBER���o 2004.10.27
--            IN_TFJ304.GUI_NUMBER         := NULL;
--            IN_TFJ304.GUI_DATE           := NULL;
--            FOR WK_GUI_REC IN CUR_GUI_NUMBER( IN_TFJ304.INVOICE_NO ) LOOP
--                IN_TFJ304.GUI_NUMBER     := WK_GUI_REC.GUI_NUMBER;
--                IN_TFJ304.GUI_DATE       := WK_GUI_REC.GUI_DATE;
--                EXIT;
--            END LOOP;
--        END IF;

        -- ����Invoice��V�K�쐬
        INS_TFJ304( IN_TFJ304 );

       -- ����Invoice���z�A�ҏW�o��            2004.10.02
       OUTPUT_TFJ305( IN_TFJ201, IN_TFJ304 );

    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','Invoice Header: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- ����Invoice��V�K�쐬
--================================================
PROCEDURE INS_TFJ304(
    IN_TFJ304   IN  TFJ304%ROWTYPE )         -- ����Invoice
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'INS_TFJ304' );

    INSERT INTO TFJ304(
        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
        -- �j�d�x
        EDATKBN,
        PIPELINE_TX_ID,
        DGYMDTM,
        NGENNO,
        INVOICE_TX_ID,
        -- �R���g���[��
        NAKKBN,
        EDELKBN,
        ESKY_KBN,
        EOPE_KBN,
--
        INVOICE_NO,
        BILLTO_ID,
        BILLTO_NAME,
        REMITTO_NAME,
--
        INVOICE_CURRENCY_CODE,
        INVOICE_AMT,
        TAXABLE_AMT,
        NON_TAXABLE_AMT,
        TAX1_AMT,
        TAX2_AMT,
        TAX3_AMT,
        TAX4_AMT,
--
        OC_CURRENCY_CODE,
        OC_INVOICE_AMT,
        OC_TAXABLE_AMT,
        OC_NON_TAXABLE_AMT,
        OC_TAX1_AMT,
        OC_TAX2_AMT,
        OC_TAX3_AMT,
        OC_TAX4_AMT,
--
        TAX1_EXCHANGE_RATE,
        TAX2_EXCHANGE_RATE,
        TAX3_EXCHANGE_RATE,
        TAX4_EXCHANGE_RATE,
--
        TAX1_RATE,
        TAX2_RATE,
        TAX3_RATE,
        TAX4_RATE,
--
        UAS_GL_DATE,
        UAS_GL_DATE_TZ_CODE,
--
-- 2004.10.10
        CUSTOMER_IND,
        SHIPPER_IND,
        CNEE_IND,
        VENDOR_IND,
        AGENT_IND,
        PIPELINE_TX_STATUS,
        ACCTG_INTERFACE_STATUS,
        INVOICE_DATE,
        ORIGINAL_INVOICE_DATE,
        ACCTG_CLOSE_DATE,
        IMPORT_EXPORT_IND,
        TRANSPORT_MODE,
        PPC_IND,
        GOVT_INVOICE_NO,
        REMARKS,
-- 2004.10.27
        GUI_NUMBER,
        GUI_DATE,
-- 2005.04.18
        INVOICE_PROCESS_TYPE,
        BILLTO_PARENT_ID,
        BILLTO_GROUP_ID,
        BILLTO_ADDRESS_NO,
        BILLTO_CONTACT_NO,
        BILLTO_CITY_NAME,
        BILLTO_REGION_CODE,
        BILLTO_REGION_NAME,
        BILLTO_POSTAL_CODE,
        BILLTO_COUNTRY_CODE,
        -- 2005.06.19 MY JOB_NO�Ή�
        JOB_NO,
        JOB_TX_ID )
      VALUES(
        -- ����
        IN_TFJ304.ETRKDTM,
        IN_TFJ304.EUPDDTM,
        IN_TFJ304.DHNEDTM,
        IN_TFJ304.EUPD_OFCCD,
        IN_TFJ304.EUPD_TNTCD,
        -- �j�d�x
        IN_TFJ304.EDATKBN,
        IN_TFJ304.PIPELINE_TX_ID,
        IN_TFJ304.DGYMDTM,
        IN_TFJ304.NGENNO,
        IN_TFJ304.INVOICE_TX_ID,
        -- �R���g���[��
        IN_TFJ304.NAKKBN,
        IN_TFJ304.EDELKBN,
        IN_TFJ304.ESKY_KBN,
        IN_TFJ304.EOPE_KBN,
--
        IN_TFJ304.INVOICE_NO,
        IN_TFJ304.BILLTO_ID,
        IN_TFJ304.BILLTO_NAME,
        IN_TFJ304.REMITTO_NAME,
--
        IN_TFJ304.INVOICE_CURRENCY_CODE,
        IN_TFJ304.INVOICE_AMT,
        IN_TFJ304.TAXABLE_AMT,
        IN_TFJ304.NON_TAXABLE_AMT,
        IN_TFJ304.TAX1_AMT,
        IN_TFJ304.TAX2_AMT,
        IN_TFJ304.TAX3_AMT,
        IN_TFJ304.TAX4_AMT,
--
        IN_TFJ304.OC_CURRENCY_CODE,
        IN_TFJ304.OC_INVOICE_AMT,
        IN_TFJ304.OC_TAXABLE_AMT,
        IN_TFJ304.OC_NON_TAXABLE_AMT,
        IN_TFJ304.OC_TAX1_AMT,
        IN_TFJ304.OC_TAX2_AMT,
        IN_TFJ304.OC_TAX3_AMT,
        IN_TFJ304.OC_TAX4_AMT,
--
        IN_TFJ304.TAX1_EXCHANGE_RATE,
        IN_TFJ304.TAX2_EXCHANGE_RATE,
        IN_TFJ304.TAX3_EXCHANGE_RATE,
        IN_TFJ304.TAX4_EXCHANGE_RATE,
--
        IN_TFJ304.TAX1_RATE,
        IN_TFJ304.TAX2_RATE,
        IN_TFJ304.TAX3_RATE,
        IN_TFJ304.TAX4_RATE,
--
        IN_TFJ304.UAS_GL_DATE,
        IN_TFJ304.UAS_GL_DATE_TZ_CODE,
-- 2004.10.10
        IN_TFJ304.CUSTOMER_IND,
        IN_TFJ304.SHIPPER_IND,
        IN_TFJ304.CNEE_IND,
        IN_TFJ304.VENDOR_IND,
        IN_TFJ304.AGENT_IND,
        IN_TFJ304.PIPELINE_TX_STATUS,
        IN_TFJ304.ACCTG_INTERFACE_STATUS,
        IN_TFJ304.INVOICE_DATE,
        IN_TFJ304.ORIGINAL_INVOICE_DATE,
        IN_TFJ304.ACCTG_CLOSE_DATE,
        IN_TFJ304.IMPORT_EXPORT_IND,
        IN_TFJ304.TRANSPORT_MODE,
        IN_TFJ304.PPC_IND,
        IN_TFJ304.GOVT_INVOICE_NO,
        IN_TFJ304.REMARKS,
-- 2004.10.27
        IN_TFJ304.GUI_NUMBER,
        IN_TFJ304.GUI_DATE,
-- 2005.04.18
        IN_TFJ304.INVOICE_PROCESS_TYPE,
        IN_TFJ304.BILLTO_PARENT_ID,
        IN_TFJ304.BILLTO_GROUP_ID,
        IN_TFJ304.BILLTO_ADDRESS_NO,
        IN_TFJ304.BILLTO_CONTACT_NO,
        IN_TFJ304.BILLTO_CITY_NAME,
        IN_TFJ304.BILLTO_REGION_CODE,
        IN_TFJ304.BILLTO_REGION_NAME,
        IN_TFJ304.BILLTO_POSTAL_CODE,
        IN_TFJ304.BILLTO_COUNTRY_CODE,
        -- 2005.06.19 MY JOB_NO�Ή�
        IN_TFJ304.JOB_NO,
        IN_TFJ304.JOB_TX_ID );

    IF IN_TFJ304.NAKKBN = 1 THEN
        WK_TFJ304_KURO_CNT := WK_TFJ304_KURO_CNT + 1;
    ELSE
        WK_TFJ304_AKA_CNT  := WK_TFJ304_AKA_CNT + 1;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ304: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ����Invoice���z�A�ҏW�o��            2004.10.02
--================================================
PROCEDURE OUTPUT_TFJ305(
    IN_TFJ201    IN               TFJ201%ROWTYPE,       -- UASIF
    IN_TFJ304    IN               TFJ304%ROWTYPE )
IS
    -- 2005.04.18 PIPELINE_CHARGES����PPC_IND���擾
    -- 2005.11.12 Rate Profile�Ή�
    CURSOR CUR_INVOICE_DETAIL(
        KEY_PIPELINE_TX_ID    INVOICE_DETAIL.PIPELINE_TX_ID%TYPE
    ) IS
        SELECT ID.*, PC.PPC_IND, PC.CATEGORY_CODE,
                     PC.PCP_RECORD_ID as PC_PCP_RECORD_ID,
                     PC.RATE, PC.RATE_UOM
        FROM INVOICE_DETAIL ID,
             PIPELINE_CHARGES PC
        WHERE ID.PIPELINE_TX_ID   = KEY_PIPELINE_TX_ID
          AND PC.PC_RECORD_ID(+)  = ID.PIPECHG_RECORD_ID
        ORDER BY ID.CHARGE_CODE,
                 ID.INVD_RECORD_ID DESC;

    WK_CHARGE_CODE    INVOICE_DETAIL.CHARGE_CODE%TYPE   := '#';

    WK_TFM205         TFM205%ROWTYPE;
    WK_TFJ305         TFJ305%ROWTYPE;

    WK_PPC_IND        PIPELINE_CHARGES.PPC_IND%TYPE     := '#';

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'OUTPUT_TFJ305' );

    WK_TFJ305 := NULL;

        -- ����
    WK_TFJ305.ETRKDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ305.EUPDDTM                 := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
    WK_TFJ305.DHNEDTM                 := SYSDATE;
    WK_TFJ305.EUPD_OFCCD              := '!';
    WK_TFJ305.EUPD_TNTCD              := C_EUPD_TNTCD;
    -- �j�d�x
    -- HWB_TX_ID��0�̎��i���̑������j�AINVOICE_TX_ID���Z�b�g�A�����敪'1'
    WK_TFJ305.EDATKBN                 := IN_TFJ304.EDATKBN;
    WK_TFJ305.PIPELINE_TX_ID          := IN_TFJ304.PIPELINE_TX_ID;
    WK_TFJ305.DGYMDTM                 := IN_TFJ304.DGYMDTM;
    WK_TFJ305.NGENNO                  := IN_TFJ304.NGENNO;
    WK_TFJ305.INVOICE_TX_ID           := IN_TFJ304.INVOICE_TX_ID;
    -- �R���g���[��
    WK_TFJ305.NAKKBN                  := IN_TFJ304.NAKKBN;
    WK_TFJ305.EDELKBN                 := IN_TFJ304.EDELKBN;
    WK_TFJ305.ESKY_KBN                := IN_TFJ304.ESKY_KBN;
    WK_TFJ305.EOPE_KBN                := IN_TFJ304.EOPE_KBN;

    WK_TFJ305.INVOICE_NO              := IN_TFJ304.INVOICE_NO;
    WK_TFJ305.BILLTO_ID               := IN_TFJ304.BILLTO_ID;

    WK_TFJ305.INVOICE_CURRENCY_CODE   := IN_TFJ304.INVOICE_CURRENCY_CODE;
    WK_TFJ305.OC_CURRENCY_CODE        := IN_TFJ304.OC_CURRENCY_CODE;

    FOR WK_REC IN CUR_INVOICE_DETAIL( IN_TFJ304.INVOICE_TX_ID ) LOOP

        WK_PPC_IND  :=  TRIM(WK_REC.PPC_IND);
        IF WK_REC.CHARGE_CODE <> WK_CHARGE_CODE THEN
            IF WK_CHARGE_CODE <> '#' THEN
                IF WK_TFJ305.INVOICE_CHARGE_AMT <> 0 THEN
                    -- ����Invoice���z��V�K�쐬
                    INS_TFJ305( WK_TFJ305 );
                END IF;
            END IF;

            -- �������ڃ}�X�^����
            SEL_TFM205( IN_TFJ201, WK_REC.CHARGE_CODE, WK_TFM205 );
            WK_TFJ305.CHARGE_CODE         := WK_REC.CHARGE_CODE;

            WK_TFJ305.CHARGE_DESCRIPTION  := WK_REC.CHARGE_DESCRIPTION;
            WK_TFJ305.CATEGORY_CODE       := WK_REC.CATEGORY_CODE;
            IF WK_TFM205.CHARGE_CODE IS NOT NULL THEN
                WK_TFJ305.NKMK_ITI              := WK_TFM205.NKMK_ITI;
                WK_TFJ305.EPRT_TAG              := WK_TFM205.EURI_PRT_TAG1;
                WK_TFJ305.SUMMARY_CATEGORY_CODE := WK_TFM205.ESUMGASNID;
                WK_TFJ305.ACCTG_CATEGORY_CODE   := WK_TFM205.ESYUGOID;
            ELSE
                WK_TFJ305.NKMK_ITI              := 0;
                WK_TFJ305.EPRT_TAG              := '!';
                WK_TFJ305.SUMMARY_CATEGORY_CODE := NULL;
                WK_TFJ305.ACCTG_CATEGORY_CODE   := NULL;
            END IF;
--
            WK_TFJ305.INVOICE_CHARGE_AMT     := 0;
            WK_TFJ305.INVOICE_EXCHANGE_RATE  := WK_REC.INVOICE_EXCHANGE_RATE;
--
            WK_TFJ305.OC_INVOICE_CHARGE_AMT  := 0;
--
            WK_TFJ305.TAXABLE_IND            := TRIM(WK_REC.TAXABLE_IND);
            -- 2005.12.16 Rate Profile�Ή�
            WK_TFJ305.PCP_RECORD_ID          := WK_REC.PC_PCP_RECORD_ID;
            WK_TFJ305.RATE                   := WK_REC.RATE;
            WK_TFJ305.RATE_UOM               := WK_REC.RATE_UOM;

            WK_CHARGE_CODE := WK_REC.CHARGE_CODE;
        END IF;

        WK_TFJ305.INVOICE_CHARGE_AMT      := WK_TFJ305.INVOICE_CHARGE_AMT
                                              + WK_REC.INVOICE_CHARGE_AMT;
        WK_TFJ305.OC_INVOICE_CHARGE_AMT   := WK_TFJ305.OC_INVOICE_CHARGE_AMT
                                              + WK_REC.OC_CHARGE_AMT;
    END LOOP;

    IF WK_CHARGE_CODE <> '#' THEN
        IF WK_TFJ305.INVOICE_CHARGE_AMT <> 0 THEN
            -- ����Invoice���z��V�K�쐬
            INS_TFJ305( WK_TFJ305 );
        END IF;
    END IF;

    -- 2005.04.18 TFJ304��PPC_IND���X�V
    IF WK_PPC_IND <> '#' AND
       IN_TFJ304.EDATKBN = '1' THEN
        -- ����Invoice Head��PPC_IND���X�V
        UPDATE TFJ304
              SET PPC_IND    = WK_PPC_IND
              WHERE EDATKBN        = IN_TFJ304.EDATKBN
                AND PIPELINE_TX_ID = IN_TFJ304.PIPELINE_TX_ID
                AND DGYMDTM        = IN_TFJ304.DGYMDTM
                AND NGENNO         = IN_TFJ304.NGENNO
                AND INVOICE_TX_ID  = IN_TFJ304.INVOICE_TX_ID;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','INVOICE_DETAIL: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ����Invoice���z��V�K�쐬            2004.10.02
--================================================
PROCEDURE INS_TFJ305(
    IN_TFJ305   IN  TFJ305%ROWTYPE )         -- ����Invoice���z
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'INS_TFJ305' );

    INSERT INTO TFJ305(
        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
        -- �j�d�x
        EDATKBN,
        PIPELINE_TX_ID,
        DGYMDTM,
        NGENNO,
        INVOICE_TX_ID,
        CHARGE_CODE,
        -- �R���g���[��
        NAKKBN,
        EDELKBN,
        ESKY_KBN,
        EOPE_KBN,
--
        INVOICE_NO,
        BILLTO_ID,
--
        CHARGE_DESCRIPTION,
        NKMK_ITI,
        EPRT_TAG,
        CATEGORY_CODE,
        SUMMARY_CATEGORY_CODE,
        ACCTG_CATEGORY_CODE,
--
        INVOICE_CHARGE_AMT,
        INVOICE_CURRENCY_CODE,
        INVOICE_EXCHANGE_RATE,
--
        OC_INVOICE_CHARGE_AMT,
        OC_CURRENCY_CODE,
--
        TAXABLE_IND,
-- 2005.12.16 Rate Profile�Ή�
        PCP_RECORD_ID,
        RATE,
        RATE_UOM )
      VALUES(
        -- ����
        IN_TFJ305.ETRKDTM,
        IN_TFJ305.EUPDDTM,
        IN_TFJ305.DHNEDTM,
        IN_TFJ305.EUPD_OFCCD,
        IN_TFJ305.EUPD_TNTCD,
        -- �j�d�x
        IN_TFJ305.EDATKBN,
        IN_TFJ305.PIPELINE_TX_ID,
        IN_TFJ305.DGYMDTM,
        IN_TFJ305.NGENNO,
        IN_TFJ305.INVOICE_TX_ID,
        IN_TFJ305.CHARGE_CODE,
        -- �R���g���[��
        IN_TFJ305.NAKKBN,
        IN_TFJ305.EDELKBN,
        IN_TFJ305.ESKY_KBN,
        IN_TFJ305.EOPE_KBN,
--
        IN_TFJ305.INVOICE_NO,
        IN_TFJ305.BILLTO_ID,
--
        IN_TFJ305.CHARGE_DESCRIPTION,
        IN_TFJ305.NKMK_ITI,
        IN_TFJ305.EPRT_TAG,
        IN_TFJ305.CATEGORY_CODE,
        IN_TFJ305.SUMMARY_CATEGORY_CODE,
        IN_TFJ305.ACCTG_CATEGORY_CODE,
--
        IN_TFJ305.INVOICE_CHARGE_AMT,
        IN_TFJ305.INVOICE_CURRENCY_CODE,
        IN_TFJ305.INVOICE_EXCHANGE_RATE,
--
        IN_TFJ305.OC_INVOICE_CHARGE_AMT,
        IN_TFJ305.OC_CURRENCY_CODE,
--
        IN_TFJ305.TAXABLE_IND,
-- 2005.11.12 Rate Profile�Ή�
        IN_TFJ305.PCP_RECORD_ID,
        IN_TFJ305.RATE,
        IN_TFJ305.RATE_UOM );

    IF IN_TFJ305.NAKKBN = 1 THEN
        WK_TFJ305_KURO_CNT := WK_TFJ305_KURO_CNT + 1;
    ELSE
        WK_TFJ305_AKA_CNT  := WK_TFJ305_AKA_CNT + 1;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ305: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--================================================
-- ���s�폜�ҏW
--================================================
FUNCTION DEL_CRLF(
    IN_TEXT    IN      TFJ301.NATURE_OF_GOODS%TYPE )           -- TEXT
RETURN TFJ301.NATURE_OF_GOODS%TYPE
IS
    OUT_TEXT    TFJ301.NATURE_OF_GOODS%TYPE;                   -- OUT TEXT

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3010', 'DEL_CRLF' );

    IF IN_TEXT IS NULL THEN
        PFGA3910.TRACE_PROC_EXIT;
        RETURN IN_TEXT;
    END IF;

    OUT_TEXT := IN_TEXT;
    -- ���s���ނ𔼊p�X�y�[�X�ɒu������
    OUT_TEXT := REPLACE( OUT_TEXT, CHR(13), ' ' );

    -- Line Feed���ނ𔼊p�X�y�[�X�ɒu������
    OUT_TEXT := REPLACE( OUT_TEXT, CHR(10), ' ' );

    -- TAB���ނ𔼊p�X�y�[�X�ɒu������
    OUT_TEXT := REPLACE( OUT_TEXT, CHR(9), ' ' );

    PFGA3910.TRACE_PROC_EXIT;

    RETURN OUT_TEXT;


EXCEPTION
    WHEN OTHERS THEN
        PFGA3910.TRACE_LOG( 'E', 'DEL_CRLF() Error TEXT = ['
                               || IN_TEXT || ']' );
    PFGA3910.TRACE_PROC_EXIT;

    RETURN IN_TEXT;
END;

END PFGA3010;
