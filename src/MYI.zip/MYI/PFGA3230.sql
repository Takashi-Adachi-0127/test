CREATE OR REPLACE PACKAGE PFGA3230 AS
--**********************************************
--�y �ӏ��ʎ��v���э쐬 �z
--  �p�b�P�[�W
--  PFGA3230
--  �Ăяo���K�w
--  CRE_TFJ323                          �ӏ��ʎ��v���т̍쐬
--    +-- CHECK_OUT_TFJ323              �ӏ��ʎ��v���т̃`�F�b�N�Əo��
--          +-- KEY_CHECK               Key Break �`�F�b�N
--          +-- INS_TFJ323              �ӏ��ʎ��v���э쐬INSERT����
--**********************************************

--******************************************
--�y �ӏ��ʎ��v���э쐬 �z�p�b�P�[�W�d�l��
--             PFGA3230
--******************************************

    -- �ӏ��ʎ��v���сiTFJ323�j���z�z��
    TYPE TFJ323_rec_type IS RECORD (
        NHBI_KIN        TFJ323.NTAG1_HBI_KIN%TYPE,
        NCOST_KIN       TFJ323.NTAG1_COST_KIN%TYPE
    );
    TYPE TFJ323_tab_type IS TABLE OF TFJ323_rec_type
         INDEX BY BINARY_INTEGER ;
    C_KIN_MAX               NUMBER := 30;

    -- �װ�����ϐ�
    WK_ERROR                NUMBER;

    -- �ӏ��ʋ��z���сiTFJ321�j�̒��o�p�v�j�ϐ��J�E���^
    TFJ321_cnt              NUMBER ;

    -- �ӏ��ʕ��ʎ��сiTFJ322�j�̒��o�p�v�j�ϐ��J�E���^
    TFJ322_cnt              NUMBER ;

    -- �ӏ��ʎ��v���сiTFJ323�j�}���p�v�j�ϐ��J�E���^
    TFJ323_cnt              NUMBER ;


--==========================================
-- PROCEDURE / FUNCTION
--==========================================
    -- �ӏ��ʎ��v���т̍쐬
    PROCEDURE CRE_TFJ323(
        in_date             IN      DATE );

    -- �ӏ��ʎ��v���т̃`�F�b�N�Əo��
    FUNCTION CHECK_OUT_TFJ323(
        IN_TFJ321       IN     TFJ321%ROWTYPE,
        IN_TFJ322       IN     TFJ322%ROWTYPE,
        OUT_TFJ323      IN OUT TFJ323%ROWTYPE,
        OUT_NKIN_ARRAY  IN OUT TFJ323_tab_type )
        RETURN NUMBER;

    -- Key Break �`�F�b�N
    FUNCTION KEY_CHECK(
        IN_EIM_EX_IND1     IN TFJ323.EIM_EX_IND%TYPE,
        IN_ETRANS_MODE1    IN TFJ323.ETRANS_MODE%TYPE,
        IN_EWB_TYPE1       IN TFJ323.EWB_TYPE%TYPE,
        IN_DKJODTM1        IN TFJ323.DKJODTM%TYPE,
        IN_ECOMPANY_ID1    IN TFJ323.ECOMPANY_ID%TYPE,
        IN_ETERMINAL_ID1   IN TFJ323.ETERMINAL_ID%TYPE,
        IN_EDEPARTMENT_ID1 IN TFJ323.EDEPARTMENT_ID%TYPE,
        IN_EIM_EX_IND2     IN TFJ323.EIM_EX_IND%TYPE,
        IN_ETRANS_MODE2    IN TFJ323.ETRANS_MODE%TYPE,
        IN_EWB_TYPE2       IN TFJ323.EWB_TYPE%TYPE,
        IN_DKJODTM2        IN TFJ323.DKJODTM%TYPE,
        IN_ECOMPANY_ID2    IN TFJ323.ECOMPANY_ID%TYPE,
        IN_ETERMINAL_ID2   IN TFJ323.ETERMINAL_ID%TYPE,
        IN_EDEPARTMENT_ID2 IN TFJ323.EDEPARTMENT_ID%TYPE )
        RETURN NUMBER;

    -- �ӏ��ʎ��v���э쐬INSERT����
    PROCEDURE INS_TFJ323 (
        IN_TFJ323      IN  TFJ323%ROWTYPE,
        IN_NKIN_ARRAY  IN  TFJ323_tab_type );

END PFGA3230 ;
CREATE OR REPLACE PACKAGE BODY PFGA3230 AS
--******************************************
--�y �ӏ��ʎ��v���э쐬 �z�p�b�P�[�W�{�̕�
--             PFGA3230
--******************************************

--******************************************
--==========================================
-- �ӏ��ʎ��v���т̍쐬
-- �iTFJ321�ATFJ322����ATFJ323�ցj
--==========================================
PROCEDURE CRE_TFJ323(
    in_date             IN      DATE
) IS

    -- �ӏ��ʋ��z���т̒��o
    CURSOR CUR_TFJ321(
        wk_gyomdate     DATE
    ) IS
        SELECT  *
          FROM  TFJ321
         WHERE  DGYMDTM = wk_gyomdate
         ORDER  BY  DGYMDTM,
                    EIM_EX_IND,
                    ETRANS_MODE,
                    EWB_TYPE,
                    DKJODTM,
                    ECOMPANY_ID,
                    ETERMINAL_ID,
                    EDEPARTMENT_ID;

    -- �ӏ��ʕ��ʎ��т̒��o
    CURSOR CUR_TFJ322(
        wk_gyomdate     DATE
    ) IS
        SELECT  *
          FROM  TFJ322
         WHERE  DGYMDTM = wk_gyomdate
         ORDER  BY  DGYMDTM,
                    EIM_EX_IND,
                    ETRANS_MODE,
                    EWB_TYPE,
                    DKJODTM,
                    ECOMPANY_ID,
                    ETERMINAL_ID,
                    EDEPARTMENT_ID;

    REC_TFJ321          TFJ321%ROWTYPE ;
    REC_TFJ322          TFJ322%ROWTYPE ;
    REC_TFJ323          TFJ323%ROWTYPE ;
    NKIN_ARRAY          TFJ323_tab_type ;

    WK_RC               NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3230','CRE_TFJ323');
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || in_date );

    -- �ϐ��N���A
    TFJ321_cnt := 0 ;
    TFJ322_cnt := 0 ;
    TFJ323_cnt := 0 ;

    REC_TFJ321.ETRKDTM := '#';
    REC_TFJ322.ETRKDTM := '#';
    REC_TFJ323.ETRKDTM := '#';
    WK_RC := 3;

    -- �ӏ��ʋ��z����ð��ٵ����
    OPEN CUR_TFJ321( in_date ) ;
    -- �ӏ��ʕ��ʎ���ð��ٵ����
    OPEN CUR_TFJ322( in_date ) ;
    LOOP
        IF WK_RC = 1 OR WK_RC = 3 THEN
             -- �ӏ��ʋ��z����FETCH
             FETCH CUR_TFJ321 INTO REC_TFJ321 ;
             IF CUR_TFJ321%NOTFOUND THEN
                 REC_TFJ321.ETRKDTM := '#';
             ELSE
                 TFJ321_cnt  := TFJ321_cnt + 1 ;
             END IF;
        END IF;
        IF WK_RC = 2 OR WK_RC = 3 THEN
             -- �ӏ��ʕ��ʎ���FETCH
             FETCH CUR_TFJ322 INTO REC_TFJ322 ;
             IF CUR_TFJ322%NOTFOUND THEN
                 REC_TFJ322.ETRKDTM := '#';
             ELSE
                 TFJ322_cnt  := TFJ322_cnt + 1 ;
             END IF;
        END IF;

        -- �ӏ��ʎ��v���т̃`�F�b�N�Əo��
        WK_RC := CHECK_OUT_TFJ323( REC_TFJ321,
                                   REC_TFJ322,
                                   REC_TFJ323,
                                   NKIN_ARRAY );
        IF WK_RC = 0 THEN
            -- �I��
            EXIT;
        END IF;
        IF WK_RC = 1 OR WK_RC = 3 THEN
            -- �ӏ��ʋ��z���т��ҏW
            NKIN_ARRAY(REC_TFJ321.NKMK_ITI).NHBI_KIN
                    := REC_TFJ321.NHSI_HBI_KIN + REC_TFJ321.NSYSI_HBI_KIN;
            NKIN_ARRAY(REC_TFJ321.NKMK_ITI).NCOST_KIN
                    := REC_TFJ321.NHSI_COST_KIN + REC_TFJ321.NSYSI_COST_KIN;
        END IF;
        IF WK_RC = 2 OR WK_RC = 3 THEN
            -- �ӏ��ʕ��ʎ��т��ҏW
            REC_TFJ323.NCY_HONSU_GKI := REC_TFJ322.NHSI_CY_HONSU_GKI
                                      + REC_TFJ322.NSYSI_CY_HONSU_GKI;
            REC_TFJ323.NCY_CNT  := REC_TFJ322.NHSI_CY_CNT
                                 + REC_TFJ322.NSYSI_CY_CNT;
            REC_TFJ323.NCY_PCS  := REC_TFJ322.NHSI_CY_PCS
                                 + REC_TFJ322.NSYSI_CY_PCS;
            REC_TFJ323.NCY_WT   := REC_TFJ322.NHSI_CY_WT
                                 + REC_TFJ322.NSYSI_CY_WT;
            REC_TFJ323.NCY_M3   := REC_TFJ322.NHSI_CY_M3
                                 + REC_TFJ322.NSYSI_CY_M3;
            REC_TFJ323.NCY_RT   := REC_TFJ322.NHSI_CY_RT
                                 + REC_TFJ322.NSYSI_CY_RT;
            REC_TFJ323.NCFS_CNT := REC_TFJ322.NHSI_CFS_CNT
                                 + REC_TFJ322.NSYSI_CFS_CNT;
            REC_TFJ323.NCFS_PCS := REC_TFJ322.NHSI_CFS_PCS
                                 + REC_TFJ322.NSYSI_CFS_PCS;
            REC_TFJ323.NCFS_WT  := REC_TFJ322.NHSI_CFS_WT
                                 + REC_TFJ322.NSYSI_CFS_WT;
            REC_TFJ323.NCFS_M3  := REC_TFJ322.NHSI_CFS_M3
                                 + REC_TFJ322.NSYSI_CFS_M3;
            REC_TFJ323.NCFS_RT  := REC_TFJ322.NHSI_CFS_RT
                                 + REC_TFJ322.NSYSI_CFS_RT;
            REC_TFJ323.NCLD_CNT := REC_TFJ322.NHSI_CLD_CNT
                                 + REC_TFJ322.NSYSI_CLD_CNT;
            REC_TFJ323.NCLD_PCS := REC_TFJ322.NHSI_CLD_PCS
                                 + REC_TFJ322.NSYSI_CLD_PCS;
            REC_TFJ323.NCLD_WT  := REC_TFJ322.NHSI_CLD_WT
                                 + REC_TFJ322.NSYSI_CLD_WT;
            REC_TFJ323.NCLD_M3  := REC_TFJ322.NHSI_CLD_M3
                                 + REC_TFJ322.NSYSI_CLD_M3;
            REC_TFJ323.NCLD_RT  := REC_TFJ322.NHSI_CLD_RT
                                 + REC_TFJ322.NSYSI_CLD_RT;
            IF REC_TFJ322.EWT_TAG = 'FWD' THEN
                REC_TFJ323.NBL_CNT        := REC_TFJ322.NHSI_CNT
                                           + REC_TFJ322.NSYSI_CNT;
                REC_TFJ323.NBL_CRG_PCS    := REC_TFJ322.NHSI_CRG_PCS
                                           + REC_TFJ322.NSYSI_CRG_PCS;
                REC_TFJ323.NBL_CRG_ACTWT  := REC_TFJ322.NHSI_CRG_ACTWT
                                           + REC_TFJ322.NSYSI_CRG_ACTWT;
                REC_TFJ323.NBL_CRG_CHGWT  := REC_TFJ322.NHSI_CRG_CHGWT
                                           + REC_TFJ322.NSYSI_CRG_CHGWT;
                REC_TFJ323.NBL_CRG_M3     := REC_TFJ322.NHSI_CRG_M3
                                           + REC_TFJ322.NSYSI_CRG_M3;
                REC_TFJ323.NBL_20FT_HONSU := REC_TFJ322.NHSI_20FT_HONSU
                                           + REC_TFJ322.NSYSI_20FT_HONSU;
                REC_TFJ323.NBL_40FT_HONSU := REC_TFJ322.NHSI_40FT_HONSU
                                           + REC_TFJ322.NSYSI_40FT_HONSU;
                REC_TFJ323.NBL_ETC_HONSU  := REC_TFJ322.NHSI_ETC_HONSU
                                           + REC_TFJ322.NSYSI_ETC_HONSU;
            ELSIF REC_TFJ322.EWT_TAG = 'CLE' THEN
                REC_TFJ323.NTKN_CNT        := REC_TFJ322.NHSI_CNT
                                            + REC_TFJ322.NSYSI_CNT;
                REC_TFJ323.NTKN_CRG_PCS    := REC_TFJ322.NHSI_CRG_PCS
                                            + REC_TFJ322.NSYSI_CRG_PCS;
                REC_TFJ323.NTKN_CRG_ACTWT  := REC_TFJ322.NHSI_CRG_ACTWT
                                            + REC_TFJ322.NSYSI_CRG_ACTWT;
                REC_TFJ323.NTKN_CRG_CHGWT  := REC_TFJ322.NHSI_CRG_CHGWT
                                            + REC_TFJ322.NSYSI_CRG_CHGWT;
                REC_TFJ323.NTKN_CRG_M3     := REC_TFJ322.NHSI_CRG_M3
                                            + REC_TFJ322.NSYSI_CRG_M3;
                REC_TFJ323.NTKN_20FT_HONSU := REC_TFJ322.NHSI_20FT_HONSU
                                            + REC_TFJ322.NSYSI_20FT_HONSU;
                REC_TFJ323.NTKN_40FT_HONSU := REC_TFJ322.NHSI_40FT_HONSU
                                            + REC_TFJ322.NSYSI_40FT_HONSU;
                REC_TFJ323.NTKN_ETC_HONSU  := REC_TFJ322.NHSI_ETC_HONSU
                                            + REC_TFJ322.NSYSI_ETC_HONSU;
            END IF;
        END IF;
    END LOOP ;
    CLOSE CUR_TFJ322 ;
    CLOSE CUR_TFJ321 ;

    PFGA3910.TRACE_LOG('I','�ӏ��ʋ��z���� ���͌��� = ' || TFJ321_cnt);
    PFGA3910.TRACE_LOG('I','�ӏ��ʕ��ʎ��� ���͌��� = ' || TFJ322_cnt);
    PFGA3910.TRACE_LOG('I','�ӏ��ʎ��v���� �o�͌��� = ' || TFJ323_cnt);
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ321/TFJ322: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        IF CUR_TFJ321%ISOPEN THEN
            CLOSE CUR_TFJ321 ;
        END IF ;
        IF CUR_TFJ322%ISOPEN THEN
            CLOSE CUR_TFJ322 ;
        END IF ;
        RAISE ;
END ;


--================================================
-- �ӏ��ʎ��v���т̃`�F�b�N�Əo��
--================================================
FUNCTION CHECK_OUT_TFJ323(
    IN_TFJ321       IN     TFJ321%ROWTYPE,
    IN_TFJ322       IN     TFJ322%ROWTYPE,
    OUT_TFJ323      IN OUT TFJ323%ROWTYPE,
    OUT_NKIN_ARRAY  IN OUT TFJ323_tab_type )
    RETURN NUMBER
IS
    WK_RC0        NUMBER;
    WK_RC1        NUMBER;
    WK_RC2        NUMBER;
    WK_RC         NUMBER;
    WK_KEY_BREAK  BOOLEAN;
    i             NUMBER;

    WK_OFFICE_NAME      OFFICES.OFFICE_NAME%TYPE;
    WK_LL_OFFICE_NAME   OFFICES.LL_OFFICE_NAME%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3230','CHECK_OUT_TFJ323');

    IF IN_TFJ321.ETRKDTM <> '#' THEN
        IF IN_TFJ322.ETRKDTM <> '#' THEN
            WK_RC0 := KEY_CHECK( IN_TFJ321.EIM_EX_IND,
                                 IN_TFJ321.ETRANS_MODE,
                                 IN_TFJ321.EWB_TYPE,
                                 IN_TFJ321.DKJODTM,
                                 IN_TFJ321.ECOMPANY_ID,
                                 IN_TFJ321.ETERMINAL_ID,
                                 IN_TFJ321.EDEPARTMENT_ID,
                                 IN_TFJ322.EIM_EX_IND,
                                 IN_TFJ322.ETRANS_MODE,
                                 IN_TFJ322.EWB_TYPE,
                                 IN_TFJ322.DKJODTM,
                                 IN_TFJ322.ECOMPANY_ID,
                                 IN_TFJ322.ETERMINAL_ID,
                                 IN_TFJ322.EDEPARTMENT_ID );
            IF WK_RC0 < 0 THEN
                WK_RC := 1;
            ELSIF WK_RC0 > 0 THEN
                WK_RC := 2;
            ELSE
                WK_RC := 3;
            END IF;
        ELSE
            WK_RC := 1;
        END IF;
    ELSE
        IF IN_TFJ322.ETRKDTM <> '#' THEN
            WK_RC := 2;
        ELSE
            WK_RC := 0;
        END IF;
    END IF;
--  PFGA3910.TRACE_LOG( 'I', '   CHECK_OUT_TFJ323 WK_RC=' || WK_RC );

    WK_KEY_BREAK := FALSE;
    IF OUT_TFJ323.ETRKDTM <> '#' THEN
        IF WK_RC = 0 THEN
            WK_KEY_BREAK := TRUE;
        END IF;
        IF WK_RC = 1 THEN
            WK_RC1 := KEY_CHECK( IN_TFJ321.EIM_EX_IND,
                                 IN_TFJ321.ETRANS_MODE,
                                 IN_TFJ321.EWB_TYPE,
                                 IN_TFJ321.DKJODTM,
                                 IN_TFJ321.ECOMPANY_ID,
                                 IN_TFJ321.ETERMINAL_ID,
                                 IN_TFJ321.EDEPARTMENT_ID,
                                 OUT_TFJ323.EIM_EX_IND,
                                 OUT_TFJ323.ETRANS_MODE,
                                 OUT_TFJ323.EWB_TYPE,
                                 OUT_TFJ323.DKJODTM,
                                 OUT_TFJ323.ECOMPANY_ID,
                                 OUT_TFJ323.ETERMINAL_ID,
                                 OUT_TFJ323.EDEPARTMENT_ID );
            IF WK_RC1 <> 0 THEN
                WK_KEY_BREAK := TRUE;
            END IF;
        END IF;
        IF WK_RC = 2 OR WK_RC = 3 THEN
            WK_RC2 := KEY_CHECK( IN_TFJ322.EIM_EX_IND,
                                 IN_TFJ322.ETRANS_MODE,
                                 IN_TFJ322.EWB_TYPE,
                                 IN_TFJ322.DKJODTM,
                                 IN_TFJ322.ECOMPANY_ID,
                                 IN_TFJ322.ETERMINAL_ID,
                                 IN_TFJ322.EDEPARTMENT_ID,
                                 OUT_TFJ323.EIM_EX_IND,
                                 OUT_TFJ323.ETRANS_MODE,
                                 OUT_TFJ323.EWB_TYPE,
                                 OUT_TFJ323.DKJODTM,
                                 OUT_TFJ323.ECOMPANY_ID,
                                 OUT_TFJ323.ETERMINAL_ID,
                                 OUT_TFJ323.EDEPARTMENT_ID );
            IF WK_RC2 <> 0 THEN
                WK_KEY_BREAK := TRUE;
            END IF;
        END IF;
        IF WK_KEY_BREAK = TRUE THEN
--          PFGA3910.TRACE_LOG( 'I', '   CHECK_OUT_TFJ323 OUT_TFJ323' );
            -- �ӏ��ʎ��v���т̏o��
            INS_TFJ323( OUT_TFJ323, OUT_NKIN_ARRAY );
            OUT_TFJ323.ETRKDTM := '#';
        END IF;
    ELSE
        WK_KEY_BREAK := TRUE;
    END IF;

    IF WK_KEY_BREAK = TRUE THEN
        -- �ӏ��ʎ��v���т̏�����
        -- ����
        OUT_TFJ323.ETRKDTM     := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
        OUT_TFJ323.EUPDDTM     := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
        OUT_TFJ323.DHNEDTM     := SYSDATE;
        OUT_TFJ323.EUPD_OFCCD  := '!';
        OUT_TFJ323.EUPD_TNTCD  := '!';
        IF WK_RC = 1 THEN
            -- �j�d�x
            OUT_TFJ323.EIM_EX_IND     := IN_TFJ321.EIM_EX_IND;
            OUT_TFJ323.ETRANS_MODE    := IN_TFJ321.ETRANS_MODE;
            OUT_TFJ323.EWB_TYPE       := IN_TFJ321.EWB_TYPE;
            OUT_TFJ323.DKJODTM        := IN_TFJ321.DKJODTM;
            OUT_TFJ323.ECOMPANY_ID    := IN_TFJ321.ECOMPANY_ID;
            OUT_TFJ323.ETERMINAL_ID   := IN_TFJ321.ETERMINAL_ID;
            OUT_TFJ323.EDEPARTMENT_ID := IN_TFJ321.EDEPARTMENT_ID;
            OUT_TFJ323.DGYMDTM        := IN_TFJ321.DGYMDTM;

            -- ����
            PFGA3950.SEL_OFFICES( OUT_TFJ323.ECOMPANY_ID,
                                  OUT_TFJ323.ETERMINAL_ID,
                                  OUT_TFJ323.EDEPARTMENT_ID,
                                  WK_OFFICE_NAME,
                                  WK_LL_OFFICE_NAME );
            OUT_TFJ323.ETERMNM        := WK_OFFICE_NAME;
            OUT_TFJ323.JTERMNM        := WK_LL_OFFICE_NAME;
            OUT_TFJ323.EDEPARTNM      := NULL;
            OUT_TFJ323.JDEPARTNM      := NULL;
        END IF;
        IF WK_RC = 2 OR WK_RC = 3 THEN
            -- �j�d�x
            OUT_TFJ323.EIM_EX_IND     := IN_TFJ322.EIM_EX_IND;
            OUT_TFJ323.ETRANS_MODE    := IN_TFJ322.ETRANS_MODE;
            OUT_TFJ323.EWB_TYPE       := IN_TFJ322.EWB_TYPE;
            OUT_TFJ323.DKJODTM        := IN_TFJ322.DKJODTM;
            OUT_TFJ323.ECOMPANY_ID    := IN_TFJ322.ECOMPANY_ID;
            OUT_TFJ323.ETERMINAL_ID   := IN_TFJ322.ETERMINAL_ID;
            OUT_TFJ323.EDEPARTMENT_ID := IN_TFJ322.EDEPARTMENT_ID;
            OUT_TFJ323.DGYMDTM        := IN_TFJ322.DGYMDTM;
            -- ����
            OUT_TFJ323.ETERMNM        := IN_TFJ322.ETERMNM;
            OUT_TFJ323.JTERMNM        := IN_TFJ322.JTERMNM;
            OUT_TFJ323.EDEPARTNM      := IN_TFJ322.EDEPARTNM;
            OUT_TFJ323.JDEPARTNM      := IN_TFJ322.JDEPARTNM;
        END IF;

        -- ����
        OUT_TFJ323.NCY_HONSU_GKI    := 0;
        OUT_TFJ323.NCY_CNT          := 0;
        OUT_TFJ323.NCY_PCS          := 0;
        OUT_TFJ323.NCY_WT           := 0;
        OUT_TFJ323.NCY_M3           := 0;
        OUT_TFJ323.NCY_RT           := 0;
        OUT_TFJ323.NCFS_CNT         := 0;
        OUT_TFJ323.NCFS_PCS         := 0;
        OUT_TFJ323.NCFS_WT          := 0;
        OUT_TFJ323.NCFS_M3          := 0;
        OUT_TFJ323.NCFS_RT          := 0;
        OUT_TFJ323.NCLD_CNT         := 0;
        OUT_TFJ323.NCLD_PCS         := 0;
        OUT_TFJ323.NCLD_WT          := 0;
        OUT_TFJ323.NCLD_M3          := 0;
        OUT_TFJ323.NCLD_RT          := 0;
        OUT_TFJ323.NBL_CNT          := 0;
        OUT_TFJ323.NBL_CRG_PCS      := 0;
        OUT_TFJ323.NBL_CRG_ACTWT    := 0;
        OUT_TFJ323.NBL_CRG_CHGWT    := 0;
        OUT_TFJ323.NBL_CRG_M3       := 0;
        OUT_TFJ323.NBL_20FT_HONSU   := 0;
        OUT_TFJ323.NBL_40FT_HONSU   := 0;
        OUT_TFJ323.NBL_ETC_HONSU    := 0;
        OUT_TFJ323.NTKN_CNT         := 0;
        OUT_TFJ323.NTKN_CRG_PCS     := 0;
        OUT_TFJ323.NTKN_CRG_ACTWT   := 0;
        OUT_TFJ323.NTKN_CRG_CHGWT   := 0;
        OUT_TFJ323.NTKN_CRG_M3      := 0;
        OUT_TFJ323.NTKN_20FT_HONSU  := 0;
        OUT_TFJ323.NTKN_40FT_HONSU  := 0;
        OUT_TFJ323.NTKN_ETC_HONSU   := 0;

        -- �ӏ��ʎ��v���сiTFJ323�j���z�z��
        FOR i IN 1 .. C_KIN_MAX LOOP
            OUT_NKIN_ARRAY(i).NHBI_KIN  := 0;
            OUT_NKIN_ARRAY(i).NCOST_KIN := 0;
        END LOOP ;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

    RETURN WK_RC;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- Key Break �`�F�b�N
--================================================
FUNCTION KEY_CHECK(
    IN_EIM_EX_IND1     IN TFJ323.EIM_EX_IND%TYPE,
    IN_ETRANS_MODE1    IN TFJ323.ETRANS_MODE%TYPE,
    IN_EWB_TYPE1       IN TFJ323.EWB_TYPE%TYPE,
    IN_DKJODTM1        IN TFJ323.DKJODTM%TYPE,
    IN_ECOMPANY_ID1    IN TFJ323.ECOMPANY_ID%TYPE,
    IN_ETERMINAL_ID1   IN TFJ323.ETERMINAL_ID%TYPE,
    IN_EDEPARTMENT_ID1 IN TFJ323.EDEPARTMENT_ID%TYPE,
    IN_EIM_EX_IND2     IN TFJ323.EIM_EX_IND%TYPE,
    IN_ETRANS_MODE2    IN TFJ323.ETRANS_MODE%TYPE,
    IN_EWB_TYPE2       IN TFJ323.EWB_TYPE%TYPE,
    IN_DKJODTM2        IN TFJ323.DKJODTM%TYPE,
    IN_ECOMPANY_ID2    IN TFJ323.ECOMPANY_ID%TYPE,
    IN_ETERMINAL_ID2   IN TFJ323.ETERMINAL_ID%TYPE,
    IN_EDEPARTMENT_ID2 IN TFJ323.EDEPARTMENT_ID%TYPE )
    RETURN NUMBER
IS
    WK_RC         NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3230','KEY_CHECK');

    IF IN_EIM_EX_IND1 > IN_EIM_EX_IND2 THEN
        WK_RC := 1;
    ELSIF IN_EIM_EX_IND1 < IN_EIM_EX_IND2 THEN
        WK_RC := -1;
    ELSE
        IF IN_ETRANS_MODE1 > IN_ETRANS_MODE2 THEN
            WK_RC := 1;
        ELSIF IN_ETRANS_MODE1 < IN_ETRANS_MODE2 THEN
            WK_RC := -1;
        ELSE
            IF IN_EWB_TYPE1 > IN_EWB_TYPE2 THEN
                WK_RC := 1;
            ELSIF IN_EWB_TYPE1 < IN_EWB_TYPE2 THEN
                WK_RC := -1;
            ELSE
                IF IN_DKJODTM1 > IN_DKJODTM2 THEN
                    WK_RC := 1;
                ELSIF IN_DKJODTM1 < IN_DKJODTM2 THEN
                    WK_RC := -1;
                ELSE
                    IF IN_ECOMPANY_ID1 > IN_ECOMPANY_ID2 THEN
                        WK_RC := 1;
                    ELSIF IN_ECOMPANY_ID1 < IN_ECOMPANY_ID2 THEN
                        WK_RC := -1;
                    ELSE
                        IF IN_ETERMINAL_ID1 > IN_ETERMINAL_ID2 THEN
                            WK_RC := 1;
                        ELSIF IN_ETERMINAL_ID1 < IN_ETERMINAL_ID2 THEN
                            WK_RC := -1;
                        ELSE
                            IF IN_EDEPARTMENT_ID1 > IN_EDEPARTMENT_ID2 THEN
                                WK_RC := 1;
                            ELSIF IN_EDEPARTMENT_ID1 < IN_EDEPARTMENT_ID2 THEN
                                WK_RC := -1;
                            ELSE
                                WK_RC := 0;
                            END IF;
                        END IF;
                    END IF;
                END IF;
            END IF;
        END IF;
    END IF;

--  PFGA3910.TRACE_LOG( 'I', '   KEY_CHECK=' || WK_RC );

    PFGA3910.TRACE_PROC_EXIT;

    RETURN WK_RC;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- �ӏ��ʎ��v���э쐬INSERT����
-- �ӏ��ʎ��v����tð��ق��ް��Z�b�g�ς�
--==========================================
PROCEDURE INS_TFJ323 (
    IN_TFJ323      IN  TFJ323%ROWTYPE,
    IN_NKIN_ARRAY  IN  TFJ323_tab_type )
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA3230','INS_TFJ323');

    -- insert���s
    INSERT  INTO TFJ323 (
        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
        -- �j�d�x
        EIM_EX_IND,
        ETRANS_MODE,
        EWB_TYPE,
        DKJODTM,
        ECOMPANY_ID,
        ETERMINAL_ID,
        EDEPARTMENT_ID,
        DGYMDTM,
        -- ����
        ETERMNM,
        JTERMNM,
        EDEPARTNM,
        JDEPARTNM,
        -- ����
        NCY_HONSU_GKI,
        NCY_CNT,
        NCY_PCS,
        NCY_WT,
        NCY_M3,
        NCY_RT,
        NCFS_CNT,
        NCFS_PCS,
        NCFS_WT,
        NCFS_M3,
        NCFS_RT,
        NCLD_CNT,
        NCLD_PCS,
        NCLD_WT,
        NCLD_M3,
        NCLD_RT,
        NBL_CNT,
        NBL_CRG_PCS,
        NBL_CRG_ACTWT,
        NBL_CRG_CHGWT,
        NBL_CRG_M3,
        NBL_20FT_HONSU,
        NBL_40FT_HONSU,
        NBL_ETC_HONSU,
        NTKN_CNT,
        NTKN_CRG_PCS,
        NTKN_CRG_ACTWT,
        NTKN_CRG_CHGWT,
        NTKN_CRG_M3,
        NTKN_20FT_HONSU,
        NTKN_40FT_HONSU,
        NTKN_ETC_HONSU,
        -- ���z(���[TAG��)
        NTAG1_HBI_KIN,
        NTAG1_COST_KIN,
        NTAG2_HBI_KIN,
        NTAG2_COST_KIN,
        NTAG3_HBI_KIN,
        NTAG3_COST_KIN,
        NTAG4_HBI_KIN,
        NTAG4_COST_KIN,
        NTAG5_HBI_KIN,
        NTAG5_COST_KIN,
        NTAG6_HBI_KIN,
        NTAG6_COST_KIN,
        NTAG7_HBI_KIN,
        NTAG7_COST_KIN,
        NTAG8_HBI_KIN,
        NTAG8_COST_KIN,
        NTAG9_HBI_KIN,
        NTAG9_COST_KIN,
        NTAG10_HBI_KIN,
        NTAG10_COST_KIN,
        NTAG11_HBI_KIN,
        NTAG11_COST_KIN,
        NTAG12_HBI_KIN,
        NTAG12_COST_KIN,
        NTAG13_HBI_KIN,
        NTAG13_COST_KIN,
        NTAG14_HBI_KIN,
        NTAG14_COST_KIN,
        NTAG15_HBI_KIN,
        NTAG15_COST_KIN,
        NTAG16_HBI_KIN,
        NTAG16_COST_KIN,
        NTAG17_HBI_KIN,
        NTAG17_COST_KIN,
        NTAG18_HBI_KIN,
        NTAG18_COST_KIN,
        NTAG19_HBI_KIN,
        NTAG19_COST_KIN,
        NTAG20_HBI_KIN,
        NTAG20_COST_KIN,
        NTAG21_HBI_KIN,
        NTAG21_COST_KIN,
        NTAG22_HBI_KIN,
        NTAG22_COST_KIN,
        NTAG23_HBI_KIN,
        NTAG23_COST_KIN,
        NTAG24_HBI_KIN,
        NTAG24_COST_KIN,
        NTAG25_HBI_KIN,
        NTAG25_COST_KIN,
        NTAG26_HBI_KIN,
        NTAG26_COST_KIN,
        NTAG27_HBI_KIN,
        NTAG27_COST_KIN,
        NTAG28_HBI_KIN,
        NTAG28_COST_KIN,
        NTAG29_HBI_KIN,
        NTAG29_COST_KIN,
        NTAG30_HBI_KIN,
        NTAG30_COST_KIN )
    VALUES(
        -- ����
        TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),
        TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),
        SYSDATE,
        '!',
        '!',
        -- �j�d�x
        IN_TFJ323.EIM_EX_IND,
        IN_TFJ323.ETRANS_MODE,
        IN_TFJ323.EWB_TYPE,
        IN_TFJ323.DKJODTM,
        IN_TFJ323.ECOMPANY_ID,
        IN_TFJ323.ETERMINAL_ID,
        IN_TFJ323.EDEPARTMENT_ID,
        IN_TFJ323.DGYMDTM,
        -- ����
        IN_TFJ323.ETERMNM,
        IN_TFJ323.JTERMNM,
        IN_TFJ323.EDEPARTNM,
        IN_TFJ323.JDEPARTNM,
        -- ����
        IN_TFJ323.NCY_HONSU_GKI,
        IN_TFJ323.NCY_CNT,
        IN_TFJ323.NCY_PCS,
        IN_TFJ323.NCY_WT,
        IN_TFJ323.NCY_M3,
        IN_TFJ323.NCY_RT,
        IN_TFJ323.NCFS_CNT,
        IN_TFJ323.NCFS_PCS,
        IN_TFJ323.NCFS_WT,
        IN_TFJ323.NCFS_M3,
        IN_TFJ323.NCFS_RT,
        IN_TFJ323.NCLD_CNT,
        IN_TFJ323.NCLD_PCS,
        IN_TFJ323.NCLD_WT,
        IN_TFJ323.NCLD_M3,
        IN_TFJ323.NCLD_RT,
        IN_TFJ323.NBL_CNT,
        IN_TFJ323.NBL_CRG_PCS,
        IN_TFJ323.NBL_CRG_ACTWT,
        IN_TFJ323.NBL_CRG_CHGWT,
        IN_TFJ323.NBL_CRG_M3,
        IN_TFJ323.NBL_20FT_HONSU,
        IN_TFJ323.NBL_40FT_HONSU,
        IN_TFJ323.NBL_ETC_HONSU,
        IN_TFJ323.NTKN_CNT,
        IN_TFJ323.NTKN_CRG_PCS,
        IN_TFJ323.NTKN_CRG_ACTWT,
        IN_TFJ323.NTKN_CRG_CHGWT,
        IN_TFJ323.NTKN_CRG_M3,
        IN_TFJ323.NTKN_20FT_HONSU,
        IN_TFJ323.NTKN_40FT_HONSU,
        IN_TFJ323.NTKN_ETC_HONSU,
        -- ���z(���[TAG��)
        IN_NKIN_ARRAY(1).NHBI_KIN,
        IN_NKIN_ARRAY(1).NCOST_KIN,
        IN_NKIN_ARRAY(2).NHBI_KIN,
        IN_NKIN_ARRAY(2).NCOST_KIN,
        IN_NKIN_ARRAY(3).NHBI_KIN,
        IN_NKIN_ARRAY(3).NCOST_KIN,
        IN_NKIN_ARRAY(4).NHBI_KIN,
        IN_NKIN_ARRAY(4).NCOST_KIN,
        IN_NKIN_ARRAY(5).NHBI_KIN,
        IN_NKIN_ARRAY(5).NCOST_KIN,
        IN_NKIN_ARRAY(6).NHBI_KIN,
        IN_NKIN_ARRAY(6).NCOST_KIN,
        IN_NKIN_ARRAY(7).NHBI_KIN,
        IN_NKIN_ARRAY(7).NCOST_KIN,
        IN_NKIN_ARRAY(8).NHBI_KIN,
        IN_NKIN_ARRAY(8).NCOST_KIN,
        IN_NKIN_ARRAY(9).NHBI_KIN,
        IN_NKIN_ARRAY(9).NCOST_KIN,
        IN_NKIN_ARRAY(10).NHBI_KIN,
        IN_NKIN_ARRAY(10).NCOST_KIN,
        IN_NKIN_ARRAY(11).NHBI_KIN,
        IN_NKIN_ARRAY(11).NCOST_KIN,
        IN_NKIN_ARRAY(12).NHBI_KIN,
        IN_NKIN_ARRAY(12).NCOST_KIN,
        IN_NKIN_ARRAY(13).NHBI_KIN,
        IN_NKIN_ARRAY(13).NCOST_KIN,
        IN_NKIN_ARRAY(14).NHBI_KIN,
        IN_NKIN_ARRAY(14).NCOST_KIN,
        IN_NKIN_ARRAY(15).NHBI_KIN,
        IN_NKIN_ARRAY(15).NCOST_KIN,
        IN_NKIN_ARRAY(16).NHBI_KIN,
        IN_NKIN_ARRAY(16).NCOST_KIN,
        IN_NKIN_ARRAY(17).NHBI_KIN,
        IN_NKIN_ARRAY(17).NCOST_KIN,
        IN_NKIN_ARRAY(18).NHBI_KIN,
        IN_NKIN_ARRAY(18).NCOST_KIN,
        IN_NKIN_ARRAY(19).NHBI_KIN,
        IN_NKIN_ARRAY(19).NCOST_KIN,
        IN_NKIN_ARRAY(20).NHBI_KIN,
        IN_NKIN_ARRAY(20).NCOST_KIN,
        IN_NKIN_ARRAY(21).NHBI_KIN,
        IN_NKIN_ARRAY(21).NCOST_KIN,
        IN_NKIN_ARRAY(22).NHBI_KIN,
        IN_NKIN_ARRAY(22).NCOST_KIN,
        IN_NKIN_ARRAY(23).NHBI_KIN,
        IN_NKIN_ARRAY(23).NCOST_KIN,
        IN_NKIN_ARRAY(24).NHBI_KIN,
        IN_NKIN_ARRAY(24).NCOST_KIN,
        IN_NKIN_ARRAY(25).NHBI_KIN,
        IN_NKIN_ARRAY(25).NCOST_KIN,
        IN_NKIN_ARRAY(26).NHBI_KIN,
        IN_NKIN_ARRAY(26).NCOST_KIN,
        IN_NKIN_ARRAY(27).NHBI_KIN,
        IN_NKIN_ARRAY(27).NCOST_KIN,
        IN_NKIN_ARRAY(28).NHBI_KIN,
        IN_NKIN_ARRAY(28).NCOST_KIN,
        IN_NKIN_ARRAY(29).NHBI_KIN,
        IN_NKIN_ARRAY(29).NCOST_KIN,
        IN_NKIN_ARRAY(30).NHBI_KIN,
        IN_NKIN_ARRAY(30).NCOST_KIN );

    TFJ323_cnt  := TFJ323_cnt + 1 ;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ323: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF ;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END ;

END PFGA3230 ;