CREATE OR REPLACE PACKAGE PFGA2030 AS
--********************************************************************
--�y �C�O�㗝�XAR�f�[�^�쐬�z
--  �߯����
--  PFGA2030
--  �Ăяo���K�w
--  CRE_TFJ203                            �C�O�㗝�XAR�f�[�^���쐬
--    +-- SET_TFJ203                      �C�O�㗝�XAR�f�[�^��ҏW
--    +-- INS_TFJ203                      �C�O�㗝�XAR�f�[�^��V�K�쐬
--********************************************************************

--************************************************
--�y �C�O�㗝�XAR�f�[�^�쐬�z�߯���ގd�l��
--     PFGA2030
--************************************************

    CURSOR CUR_AR_IF( KEY_DGYMDTM   TFJ201.DGYMDTM%TYPE
    ) IS
        SELECT AR.INVOICE_TX_ID,                          -- Primary Key
               AR.IMPORT_EXPORT_IND,
               AR.TRANSPORT_MODE,
               AR.COMPANY_ID,
               AR.CUSTOMER_NUMBER as AGENT_ID,
               AR.BILLTO_ADDRESS_NO,
               AR.DGYMDTM,
               AR.ACCOUNTING_DATE as GL_DATE,
               AR.INVOICE_DATE,
               AR.ORIGINAL_INVOICE_DATE,
               AR.WAYBILL_TYPE,
               AR.INVOICE_TYPE,
               AR.MWB_NO,
               AR.HWB_NO,
               AR.INVOICE_NO,
               AR.CORRECTION_NO,
               AR.MWB_TX_ID,
               AR.HWB_TX_ID,
               AR.PPC_IND,
               AR.CURRENCY_CODE,
               TRNS.EPRT_TAG,
               TRNS.LINKTO_LINE_NUMBER,
               TRNS.CONVERSION_RATE,
               TRNS.TOTAL_INVOICE_AMT,
               TRNS.LOCAL_INVOICE_AMT
         FROM
           (SELECT TFJ201.INVOICE_TX_ID,
                   NVL(TFM205.EURI_PRT_TAG9,'CHG')    as EPRT_TAG,
                   MAX(NVL(TFJ201.LINKTO_LINE_NUMBER,0)) LINKTO_LINE_NUMBER,
                   MAX(NVL(TFJ201.CONVERSION_RATE,1))    CONVERSION_RATE,
                   SUM(NVL(TFJ201.LINE_AMOUNT,0))        TOTAL_INVOICE_AMT,
                   SUM(NVL(TFJ201.LOCAL_INVOICE_AMT,0))  LOCAL_INVOICE_AMT
             FROM  TFJ201,
                   TFM205
             WHERE TFJ201.DGYMDTM              = KEY_DGYMDTM
               AND TFJ201.RECORD_IND           = 'AR'
               AND TFJ201.AGENT_ROLE           = 'Y'
               AND TFM205.COMPANY_ID(+)        = TFJ201.COMPANY_ID
               AND TFM205.IMPORT_EXPORT_IND(+) = TFJ201.IMPORT_EXPORT_IND
               AND TFM205.TRANSPORT_MODE(+)    = TFJ201.TRANSPORT_MODE
               AND TFM205.CHARGE_CODE(+)       = TFJ201.CHARGE_CODE
               AND TFM205.ESISNKBN(+)          = '1'
               AND TFM205.EDELKBN(+)           = '0'
             GROUP BY TFJ201.INVOICE_TX_ID,
                      NVL(TFM205.EURI_PRT_TAG9,'CHG')
           ) TRNS,
             TFJ201 AR
         WHERE AR.ROWID = ( SELECT ROWID FROM TFJ201 X
                             WHERE X.DGYMDTM       = KEY_DGYMDTM
                               AND X.RECORD_IND    = 'AR'
                               AND X.AGENT_ROLE    = 'Y'
                               AND X.INVOICE_TX_ID = TRNS.INVOICE_TX_ID
                               AND ROWNUM = 1)
         ORDER BY TRNS.INVOICE_TX_ID,TRNS.EPRT_TAG;

    --�y ܰ��ϐ� �z

    -- �װ�����ϐ�
    WK_ERROR               NUMBER;

    -- ���͌������ėpܰ��ϐ�
    WK_AR_IF_IN_CNT        NUMBER;
    WK_TFJ203_INS_CNT      NUMBER;


    --�y PROCEDURE / FUNCTION �z

    -- �C�O�㗝�XAR�f�[�^���쐬
    PROCEDURE CRE_TFJ203(
        IN_DATE           IN  DATE );               -- �v���(yyyymmdd)

    -- �C�O�㗝�XAR�f�[�^��ҏW
    PROCEDURE SET_TFJ203(
        IN_DATE           IN   DATE,               -- �v���(yyyymmdd)
        IN_AR_IF          IN   CUR_AR_IF%ROWTYPE,  -- AR_INTERFACE
        OUT_TFJ203        OUT  TFJ203%ROWTYPE );   -- �C�O�㗝�XAR�f�[�^

    -- �C�O�㗝�XAR�f�[�^��V�K�쐬
    PROCEDURE INS_TFJ203(
        IN_TFJ203  IN  TFJ203%ROWTYPE );           -- �C�O�㗝�XAR�f�[�^

    -- BILLTO_COUNTRY �擾
    PROCEDURE SEL_BILLTO_COUNTRY(
        IN_ADDRESS_NO     IN      ADDRESS.ADDRESS_NO%TYPE,
        OUT_COUNTRY_CODE  IN OUT  ADDRESS.COUNTRY_CODE%TYPE,
        OUT_IATA_TC_CODE  IN OUT  COUNTRY.IATA_CONFERENCE_CODE%TYPE );

END PFGA2030;
CREATE OR REPLACE PACKAGE BODY PFGA2030 AS
--************************************************
--�y �C�O�㗝�XAR�f�[�^�쐬�z�߯���ޖ{�̕�
--     PFGA2030
--************************************************

--================================================
-- �C�O�㗝�XAR�f�[�^���쐬
--
-- TFJ201����C�O�㗝�XAR�f�[�^�𒊏o����B
--================================================
PROCEDURE CRE_TFJ203(
    IN_DATE           IN  DATE )                -- �v���(yyyymmdd)
IS

    -- Key����
    WK_INVOICE_TX_ID     TFJ203.INVOICE_TX_ID%TYPE  := 0;

    WK_TFJ203            TFJ203%ROWTYPE;        -- �C�O�㗝�XAR�f�[�^

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2030', 'CRE_TFJ203' );
    PFGA3910.TRACE_LOG( 'I', '   �v���  =' || IN_DATE );

    WK_ERROR          := 0;

    -- �����������ėpܰ��ϐ�
    WK_AR_IF_IN_CNT   := 0;
    WK_TFJ203_INS_CNT := 0;

    FOR WK_REC IN CUR_AR_IF( IN_DATE ) LOOP
        WK_AR_IF_IN_CNT   := WK_AR_IF_IN_CNT + 1;

        IF WK_INVOICE_TX_ID != WK_REC.INVOICE_TX_ID THEN

            IF WK_INVOICE_TX_ID != 0 THEN
                -- �C�O�㗝�XAR�f�[�^��V�K�쐬
                INS_TFJ203( WK_TFJ203 );
            END IF;
            -- Key���ڃZ�b�g
            WK_INVOICE_TX_ID  := WK_REC.INVOICE_TX_ID;

            -- �C�O�㗝�XAR�f�[�^��ҏW
            SET_TFJ203( IN_DATE, WK_REC, WK_TFJ203 );

        END IF;

        IF WK_REC.EPRT_TAG = 'FRT' THEN
            -- �^��
            WK_TFJ203.TOTAL_FRT_AMT     := WK_REC.TOTAL_INVOICE_AMT;
            WK_TFJ203.LOCAL_FRT_AMT     := WK_REC.LOCAL_INVOICE_AMT;
        ELSIF WK_REC.EPRT_TAG = 'CHG' THEN
            -- �`���[�W
            WK_TFJ203.TOTAL_CHG_AMT     := WK_REC.TOTAL_INVOICE_AMT;
            WK_TFJ203.LOCAL_CHG_AMT     := WK_REC.LOCAL_INVOICE_AMT;
        ELSIF WK_REC.EPRT_TAG = 'DUT' THEN
            -- �֐�
            WK_TFJ203.TOTAL_DUT_AMT     := WK_REC.TOTAL_INVOICE_AMT;
            WK_TFJ203.LOCAL_DUT_AMT     := WK_REC.LOCAL_INVOICE_AMT;
        ELSIF WK_REC.EPRT_TAG = 'BBF' THEN
            -- �d����
            WK_TFJ203.TOTAL_BBF_AMT     := WK_REC.TOTAL_INVOICE_AMT;
            WK_TFJ203.LOCAL_BBF_AMT     := WK_REC.LOCAL_INVOICE_AMT;
        END IF;
    END LOOP;

    IF WK_INVOICE_TX_ID != 0 THEN
        -- �C�O�㗝�XAR�f�[�^��V�K�쐬
        INS_TFJ203( WK_TFJ203 );
    END IF;

    PFGA3910.TRACE_LOG( 'I', 'TFJ201 INVOICE     ���͌��� = ' || WK_AR_IF_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', '�C�O�㗝�XAR�f�[�^ �o�͌��� = ' || WK_TFJ203_INS_CNT );
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ201: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_LOG( 'E', '�G���[�f�[�^'
                                 || ' INVOICE_TX_ID=' || WK_INVOICE_TX_ID );
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �C�O�㗝�XAR�f�[�^��ҏW
--================================================
PROCEDURE SET_TFJ203(
    IN_DATE           IN   DATE,               -- �v���(yyyymmdd)
    IN_AR_IF          IN   CUR_AR_IF%ROWTYPE,  -- AR_INTERFACE
    OUT_TFJ203        OUT  TFJ203%ROWTYPE )    -- �C�O�㗝�XAR�f�[�^
IS

    -- Invoice Header���o�J�[�\��
    CURSOR CUR_IH( KEY_PIPELINE_TX_ID   INVOICE_HEADER.PIPELINE_TX_ID%TYPE ) IS
        SELECT IH.*
          FROM INVOICE_HEADER IH
          WHERE IH.PIPELINE_TX_ID      = KEY_PIPELINE_TX_ID;

    WK_PARTNER_ID           PIPELINE_PARTIES.PARTNER_ID%TYPE;
    WK_PARENT_PARTNER_ID    PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;
    WK_PARTNER_GROUP_CODE   PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2030', 'SET_TFJ203' );

    -- �j�d�x
    OUT_TFJ203.INVOICE_TX_ID         := IN_AR_IF.INVOICE_TX_ID;
    -- �R���g���[��
    OUT_TFJ203.IMPORT_EXPORT_IND     := IN_AR_IF.IMPORT_EXPORT_IND;
    OUT_TFJ203.TRANSPORT_MODE        := IN_AR_IF.TRANSPORT_MODE;
    OUT_TFJ203.COMPANY_ID            := IN_AR_IF.COMPANY_ID;
    -- AGENT TO
    OUT_TFJ203.AGENT_ID              := IN_AR_IF.AGENT_ID;
    OUT_TFJ203.BILLTO_ADDRESS_NO     := IN_AR_IF.BILLTO_ADDRESS_NO;
    -- BillTo Code�̎擾
    PFGA3950.SEL_PARTNER_ID( OUT_TFJ203.INVOICE_TX_ID,
                             'BT',
                             WK_PARTNER_ID,
                             WK_PARENT_PARTNER_ID,
                             WK_PARTNER_GROUP_CODE );
    OUT_TFJ203.BILLTO_ID             := WK_PARTNER_ID;
    -- Invoice Header���o
    FOR WK_REC IN CUR_IH( OUT_TFJ203.INVOICE_TX_ID ) LOOP
        --OUT_TFJ203.BILLTO_ADDRESS_NO := WK_REC.BILLTO_ADDRESS_NO;
        OUT_TFJ203.BILLTO_NAME       := WK_REC.BILLTO_NAME;
        -- 2005.04.18 BILL_TO��ADDRESS���擾
        SEL_BILLTO_COUNTRY( OUT_TFJ203.BILLTO_ADDRESS_NO,
                            OUT_TFJ203.BILLTO_COUNTRY_CODE,
                            OUT_TFJ203.BILLTO_TC_CODE );
    END LOOP;
    -- ���t
    OUT_TFJ203.DGYMDTM               := IN_AR_IF.DGYMDTM;
    OUT_TFJ203.GL_DATE               := IN_AR_IF.GL_DATE;
    OUT_TFJ203.INVOICE_DATE          := IN_AR_IF.INVOICE_DATE;
    OUT_TFJ203.ORIGINAL_INVOICE_DATE := IN_AR_IF.ORIGINAL_INVOICE_DATE;
    -- TYPE
    OUT_TFJ203.WAYBILL_TYPE          := IN_AR_IF.WAYBILL_TYPE;
    OUT_TFJ203.INVOICE_TYPE          := IN_AR_IF.INVOICE_TYPE;
    -- �ԍ�
    OUT_TFJ203.MWB_NO                := IN_AR_IF.MWB_NO;
    OUT_TFJ203.HWB_NO                := IN_AR_IF.HWB_NO;
    OUT_TFJ203.INVOICE_NO            := IN_AR_IF.INVOICE_NO;
    OUT_TFJ203.CORRECTION_NO         := IN_AR_IF.CORRECTION_NO;
    -- INVOICE SUMMARY KEY
    IF IN_AR_IF.WAYBILL_TYPE IS NULL THEN
        -- MISC
        OUT_TFJ203.INVOICE_NO_KEY    := SUBSTR(IN_AR_IF.INVOICE_NO,1,(LENGTH(IN_AR_IF.INVOICE_NO)-2));
        OUT_TFJ203.INVOICE_NO_SUFFIX := '00';
    ELSIF INSTR(IN_AR_IF.INVOICE_TYPE,'Invoice') > 0 THEN
        -- Invoice
        IF IN_AR_IF.INVOICE_TYPE = 'Invoice' THEN
            OUT_TFJ203.INVOICE_NO_KEY    := SUBSTR(IN_AR_IF.INVOICE_NO,1,(LENGTH(IN_AR_IF.INVOICE_NO)-2));
            OUT_TFJ203.INVOICE_NO_SUFFIX := '00';
        ELSE
            OUT_TFJ203.INVOICE_NO_KEY    := TRIM(IN_AR_IF.INVOICE_NO);
            OUT_TFJ203.INVOICE_NO_SUFFIX := '00';
        END IF;
    ELSE
        -- Debit Memo/Credit Memo
        IF IN_AR_IF.LINKTO_LINE_NUMBER = 0 THEN
            -- CCN:DebitCredit
            OUT_TFJ203.INVOICE_NO_KEY    := SUBSTR(IN_AR_IF.INVOICE_NO,1,(LENGTH(IN_AR_IF.INVOICE_NO)-2));
            OUT_TFJ203.INVOICE_NO_SUFFIX := SUBSTR(IN_AR_IF.INVOICE_NO,-2,2);
        ELSE
            -- CCN:Amended
            OUT_TFJ203.INVOICE_NO_KEY    := SUBSTR(IN_AR_IF.INVOICE_NO,1,(LENGTH(IN_AR_IF.INVOICE_NO)-2));
            OUT_TFJ203.INVOICE_NO_SUFFIX := '00';
        END IF;
    END IF;
    -- SHIPMENT LINK
    IF IN_AR_IF.WAYBILL_TYPE IS NULL THEN
        OUT_TFJ203.EDATKBN           := '8';
        OUT_TFJ203.PIPELINE_TX_ID    := IN_AR_IF.INVOICE_TX_ID;
    ELSIF IN_AR_IF.WAYBILL_TYPE = 'M'
       OR IN_AR_IF.WAYBILL_TYPE = 'MD' THEN
        OUT_TFJ203.EDATKBN           := '3';
        OUT_TFJ203.PIPELINE_TX_ID    := IN_AR_IF.MWB_TX_ID;
    ELSE
        OUT_TFJ203.EDATKBN           := '1';
        OUT_TFJ203.PIPELINE_TX_ID    := IN_AR_IF.HWB_TX_ID;
    END IF;
    -- TX_ID
    OUT_TFJ203.MWB_TX_ID             := IN_AR_IF.MWB_TX_ID;
    OUT_TFJ203.HWB_TX_ID             := IN_AR_IF.HWB_TX_ID;
    -- ACCOUNTING
    OUT_TFJ203.PPC_IND               := IN_AR_IF.PPC_IND;
    OUT_TFJ203.CURRENCY_CODE         := IN_AR_IF.CURRENCY_CODE;
    OUT_TFJ203.CONVERSION_RATE       := IN_AR_IF.CONVERSION_RATE;
    OUT_TFJ203.TOTAL_FRT_AMT         := 0;
    OUT_TFJ203.LOCAL_FRT_AMT         := 0;
    OUT_TFJ203.TOTAL_CHG_AMT         := 0;
    OUT_TFJ203.LOCAL_CHG_AMT         := 0;
    OUT_TFJ203.TOTAL_DUT_AMT         := 0;
    OUT_TFJ203.LOCAL_DUT_AMT         := 0;
    OUT_TFJ203.TOTAL_BBF_AMT         := 0;
    OUT_TFJ203.LOCAL_BBF_AMT         := 0;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �C�O�㗝�XAR�f�[�^��V�K�쐬
--================================================
PROCEDURE INS_TFJ203(
    IN_TFJ203  IN  TFJ203%ROWTYPE ) -- �C�O�㗝�XAR�f�[�^
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2030', 'INS_TFJ203' );

    INSERT INTO TFJ203(
          -- �j�d�x
          INVOICE_TX_ID,
          -- �R���g���[��
          IMPORT_EXPORT_IND,
          TRANSPORT_MODE,
          COMPANY_ID,
          -- BILL TO
          AGENT_ID,
          BILLTO_TC_CODE,
          BILLTO_COUNTRY_CODE,
          BILLTO_ADDRESS_NO,
          BILLTO_ID,
          BILLTO_NAME,
          -- ���t
          DGYMDTM,
          GL_DATE,
          INVOICE_DATE,
          ORIGINAL_INVOICE_DATE,
          -- TYPE
          WAYBILL_TYPE,
          INVOICE_TYPE,
          -- �ԍ�
          MWB_NO,
          HWB_NO,
          INVOICE_NO,
          CORRECTION_NO,
          -- INVOICE SUMMARY KEY
          INVOICE_NO_KEY,
          INVOICE_NO_SUFFIX,
          -- SHIPMENT LINK
          EDATKBN,
          PIPELINE_TX_ID,
          -- TX_ID
          MWB_TX_ID,
          HWB_TX_ID,
          -- ACCOUNTING
          PPC_IND,
          CURRENCY_CODE,
          CONVERSION_RATE,
          TOTAL_FRT_AMT,
          LOCAL_FRT_AMT,
          TOTAL_CHG_AMT,
          LOCAL_CHG_AMT,
          TOTAL_DUT_AMT,
          LOCAL_DUT_AMT,
          TOTAL_BBF_AMT,
          LOCAL_BBF_AMT )
      VALUES(
          -- �j�d�x
          IN_TFJ203.INVOICE_TX_ID,
          -- �R���g���[��
          IN_TFJ203.IMPORT_EXPORT_IND,
          IN_TFJ203.TRANSPORT_MODE,
          IN_TFJ203.COMPANY_ID,
          -- BILL TO
          IN_TFJ203.AGENT_ID,
          IN_TFJ203.BILLTO_TC_CODE,
          IN_TFJ203.BILLTO_COUNTRY_CODE,
          IN_TFJ203.BILLTO_ADDRESS_NO,
          IN_TFJ203.BILLTO_ID,
          IN_TFJ203.BILLTO_NAME,
          -- ���t
          IN_TFJ203.DGYMDTM,
          IN_TFJ203.GL_DATE,
          IN_TFJ203.INVOICE_DATE,
          IN_TFJ203.ORIGINAL_INVOICE_DATE,
          -- TYPE
          IN_TFJ203.WAYBILL_TYPE,
          IN_TFJ203.INVOICE_TYPE,
          -- �ԍ�
          IN_TFJ203.MWB_NO,
          IN_TFJ203.HWB_NO,
          IN_TFJ203.INVOICE_NO,
          IN_TFJ203.CORRECTION_NO,
          -- INVOICE SUMMARY KEY
          IN_TFJ203.INVOICE_NO_KEY,
          IN_TFJ203.INVOICE_NO_SUFFIX,
          -- SHIPMENT LINK
          IN_TFJ203.EDATKBN,
          IN_TFJ203.PIPELINE_TX_ID,
          -- TX_ID
          IN_TFJ203.MWB_TX_ID,
          IN_TFJ203.HWB_TX_ID,
          -- ACCOUNTING
          IN_TFJ203.PPC_IND,
          IN_TFJ203.CURRENCY_CODE,
          IN_TFJ203.CONVERSION_RATE,
          IN_TFJ203.TOTAL_FRT_AMT,
          IN_TFJ203.LOCAL_FRT_AMT,
          IN_TFJ203.TOTAL_CHG_AMT,
          IN_TFJ203.LOCAL_CHG_AMT,
          IN_TFJ203.TOTAL_DUT_AMT,
          IN_TFJ203.LOCAL_DUT_AMT,
          IN_TFJ203.TOTAL_BBF_AMT,
          IN_TFJ203.LOCAL_BBF_AMT );

    WK_TFJ203_INS_CNT := WK_TFJ203_INS_CNT + 1;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ203: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- BILLTO_COUNTRY �擾
--================================================
PROCEDURE SEL_BILLTO_COUNTRY(
    IN_ADDRESS_NO     IN      ADDRESS.ADDRESS_NO%TYPE,
    OUT_COUNTRY_CODE  IN OUT  ADDRESS.COUNTRY_CODE%TYPE,
    OUT_IATA_TC_CODE  IN OUT  COUNTRY.IATA_CONFERENCE_CODE%TYPE )
IS
    CURSOR CUR_COUNTRY(
        KEY_ADDRESS_NO    ADDRESS.ADDRESS_NO%TYPE
    ) IS
        SELECT ADDRESS.COUNTRY_CODE,
               COUNTRY.IATA_CONFERENCE_CODE
        FROM ADDRESS,COUNTRY
        WHERE ADDRESS.ADDRESS_NO = KEY_ADDRESS_NO
          AND COUNTRY.COUNTRY_CODE = ADDRESS.COUNTRY_CODE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2030', 'SEL_BILLTO_COUNTRY' );

    OUT_COUNTRY_CODE := '!';
    OUT_IATA_TC_CODE := '!';

    FOR WK_REC IN CUR_COUNTRY( IN_ADDRESS_NO ) LOOP
        OUT_COUNTRY_CODE         := WK_REC.COUNTRY_CODE;
        OUT_IATA_TC_CODE         := WK_REC.IATA_CONFERENCE_CODE;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 6;
            PFGA3910.TRACE_LOG('E','SEL_BILLTO_COUNTRY: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


END PFGA2030;