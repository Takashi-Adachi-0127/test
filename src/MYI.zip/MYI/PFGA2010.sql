CREATE OR REPLACE PACKAGE           PFGA2010 AS
--*****************************************************
--�y UASI/F�f�[�^���o �z
--  �p�b�P�[�W
--  PFGA2010
--  �Ăяo���K�w
--  CRE_TFJ201
--      INS_TFJ201
--      INS_TFJ202
--      GET_TFJ201_HWB
--      GET_TFJ201_INV
--      PFGA3940.HWB_PIPELINE_RELATIONS
--      PFGA3940.OSSHIP_INF_GET    --Overseas
--      PFGA3940.EMPLOYEE_GET      --Ovreseas
--      PFGA3950.SEL_PARTNER_ID    --Overseas
--  ���̑�
--  PFGA3910.TRACE_PROC_ENTRY
--  PFGA3910.TRACE_LOG
--  PFGA3910.TRACE_STACK
--  PFGA3910.TRACE_PROC_EXIT
--*****************************************************

--*****************************************************
--�y UASI/F�f�[�^���o �z�p�b�P�[�W�d�l��
--             PFGA2010
--*****************************************************

    -- �Ǘ��̈�i�T��ށA�R���ڔz��j
    -- ��������
    TYPE C_DATE_TYPE IS TABLE OF TFJ201.DGYMDTM%TYPE
        INDEX BY BINARY_INTEGER ;
    C_DATE            C_DATE_TYPE ;
    -- ���ŏI���R�[�h�ԍ� 2005.10.23 Upd HOST_RECORD_ID
    TYPE C_RECNO_TYPE IS TABLE OF TFJ202.HOST_RECORD_ID%TYPE
        INDEX BY BINARY_INTEGER ;
    C_RECNO           C_RECNO_TYPE ;
    -- �l�`�w���R�[�h�ԍ� 2005.10.23 Upd HOST_RECORD_ID
    TYPE M_RECNO_TYPE IS TABLE OF TFJ202.HOST_RECORD_ID%TYPE
        INDEX BY BINARY_INTEGER ;
    M_RECNO           M_RECNO_TYPE ;
    -- �V�ŏI���R�[�h�ԍ� 2005.10.23 Upd HOST_RECORD_ID
    TYPE N_RECNO_TYPE IS TABLE OF TFJ202.HOST_RECORD_ID%TYPE
        INDEX BY BINARY_INTEGER ;
    N_RECNO           N_RECNO_TYPE ;
    -- ���R�[�h����
    TYPE N_REC_CNT_TYPE IS TABLE OF TFJ202.NREC_CNT%TYPE
        INDEX BY BINARY_INTEGER ;
    N_REC_CNT         N_REC_CNT_TYPE ;
    -- ���o����
    TYPE N_PIC_OUT_TYPE IS TABLE OF TFJ202.NPICK_OUT%TYPE
        INDEX BY BINARY_INTEGER ;
    N_PIC_OUT         N_PIC_OUT_TYPE ;
    -- Interface Queue���o���t
    TYPE INTERFACE_LAST_DATE_TYPE IS TABLE OF TFJ202.INTERFACE_QUEUE_LAST_DATE%TYPE
        INDEX BY BINARY_INTEGER ;
    INTERFACE_LAST_DATE INTERFACE_LAST_DATE_TYPE ;

    -- AR(ART001)�����̒��o
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    CURSOR CUR_ART001(
        WK_HOST_ID           TFJ202.HOST_ID%TYPE,         -- 2005.10.23 Add
        WK_LINE_FROM         TFJ202.HOST_RECORD_ID%TYPE,
        WK_COMPANY_ID        TFJ201.COMPANY_ID%TYPE,
        WK_IMPORT_EXPORT_IND TFJ201.IMPORT_EXPORT_IND%TYPE,
        WK_TRANSPORT_MODE    TFJ201.TRANSPORT_MODE%TYPE
    ) IS
        SELECT  *
          FROM  AR_INTERFACE_LINES
         WHERE  TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--           AND  TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),4)) > WK_LINE_FROM
           AND  ARL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM))
           AND  ARL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM + 1000000))
           AND  COMPANY = WK_COMPANY_ID
           AND  IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
           AND  TRANSPORT_MODE = WK_TRANSPORT_MODE
         ORDER  BY ARL_RECORD_ID;

    -- AR(ART001)�������R�[�h�̈�
    REC_ART001          CUR_ART001%ROWTYPE ;
    -- AR(ART001)�����̒��o�p�v�j�ϐ��J�E���^
    ART001_CNT              NUMBER ;

    -- GL(GLT001)���̒��o
    -- 2004.06.20 ACCOUNT != 'SAME'��OMIT���͂����B
    --            ���W�b�N�œ���PC_RECORD_ID��OMIT����悤�ɂ���B
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
    CURSOR CUR_GLT001(
        WK_HOST_ID           TFJ202.HOST_ID%TYPE,         -- 2005.10.23 Add
        WK_LINE_FROM         TFJ202.HOST_RECORD_ID%TYPE,
        WK_COMPANY_ID        TFJ201.COMPANY_ID%TYPE,
        WK_IMPORT_EXPORT_IND TFJ201.IMPORT_EXPORT_IND%TYPE,
        WK_TRANSPORT_MODE    TFJ201.TRANSPORT_MODE%TYPE
    ) IS
        SELECT  *
          FROM  GL_INTERFACE
         WHERE  TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--           AND  TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),4)) > WK_LINE_FROM
           AND  GLI_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM))
          -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--           AND  GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM)) + 1000000
           AND  GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM + 1000000))
           AND  COMPANY = WK_COMPANY_ID
           AND  IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
           AND  TRANSPORT_MODE = WK_TRANSPORT_MODE
    --     AND  ACCOUNT != 'SAME'                           -- 2004.05.02 �ǉ��iSAME�̏���OMMIT)
         ORDER  BY PC_RECORD_ID,GLI_RECORD_ID;

    -- GL(GLT001)�����R�[�h�̈�
    REC_GLT001          CUR_GLT001%ROWTYPE ;
    -- GL(GLT001)���̒��o�p�v�j�ϐ��J�E���^
    GLT001_CNT              NUMBER ;

    -- AP(APT001)�����̒��o
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
    CURSOR CUR_APT001(
        WK_HOST_ID           TFJ202.HOST_ID%TYPE,         -- 2005.10.23 Add
        WK_LINE_FROM         TFJ202.HOST_RECORD_ID%TYPE,
        WK_COMPANY_ID        TFJ201.COMPANY_ID%TYPE,
        WK_IMPORT_EXPORT_IND TFJ201.IMPORT_EXPORT_IND%TYPE,
        WK_TRANSPORT_MODE    TFJ201.TRANSPORT_MODE%TYPE
    ) IS
                --<<AP(HEAD)�FAPT000>>
        SELECT  A0.PIPELINE_TX_ID,
                A0.HWB_NO,
                A0.MWB_NO,
                A0.CONSOL_NO,
                A0.CORRECTION_NO,
                A0.INVOICE_DATE,
                A0.CURRENCY_CODE,
                A0.CONVERSION_RATE,
                A0.HWB_TX_ID,
                A0.MWB_TX_ID,
                A0.CONSOL_TX_ID,
                A0.WAYBILL_TYPE,
                --<<AP(LINE)�FAPT001>>
                A1.APL_RECORD_ID,
                A1.VENDOR_INVOICE_NUMBER,
                A1.VENDOR_NUMBER,
                A1.LINE_AMOUNT,
                A1.LINE_DESCRIPTION,
                A1.ACCOUNTING_DATE,
                A1.TERMINAL,
                A1.GL_GROUP,
                A1.SALES_RESPONSIBLE_OFFICE_ID,
                A1.LOCAL_COST_AMT,
                A1.CHARGE_CODE,
                A1.PPC_IND,
                A1.INVD_RECORD_ID,
                A1.ORIGINAL_ACCOUNTING_DATE,
                A1.LINE_TYPE_LOOKUP_CODE as LINE_TYPE,
                A1.LINE_NUMBER
          FROM  AP_INTERFACE_HEADER A0 ,AP_INTERFACE_LINES A1
         WHERE  TO_NUMBER(SUBSTR(TO_CHAR(A1.APL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--           AND  TO_NUMBER(SUBSTR(TO_CHAR(A1.APL_RECORD_ID,'FM999999999999'),4)) > WK_LINE_FROM
           AND  A1.APL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM))
          -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--           AND  A1.APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM)) + 1000000
           AND  A1.APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(WK_LINE_FROM + 1000000))
           AND  A1.COMPANY = WK_COMPANY_ID
           AND  A0.IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
           AND  A0.TRANSPORT_MODE = WK_TRANSPORT_MODE
           AND  A0.APH_RECORD_ID = A1.APH_RECORD_ID
         ORDER  BY APL_RECORD_ID;

    -- AP(APT001)�������R�[�h�̈��`
    TYPE REC_APT001_TYPE IS RECORD(
       --<<AP(HEAD)�FAPT000>>
       PIPELINE_TX_ID              AP_INTERFACE_HEADER.PIPELINE_TX_ID%TYPE,   -- PIPELINE_TX_ID
       HWB_NO                      AP_INTERFACE_HEADER.HWB_NO%TYPE,           -- B/L�ԍ�(HOUSE)
       MWB_NO                      AP_INTERFACE_HEADER.MWB_NO%TYPE,           -- B/L�ԍ�(MASTER)
       CONSOL_NO                   AP_INTERFACE_HEADER.CONSOL_NO%TYPE,        -- CONSOL_NO
       CORRECTION_NO               AP_INTERFACE_HEADER.CORRECTION_NO%TYPE,    -- �C���ԍ�
       INVOICE_DATE                AP_INTERFACE_HEADER.INVOICE_DATE%TYPE,     -- ������
       CURRENCY_CODE               AP_INTERFACE_HEADER.CURRENCY_CODE%TYPE,    -- �ʉ�
       CONVERSION_RATE             AP_INTERFACE_HEADER.CONVERSION_RATE%TYPE,  -- �בփ��[�g
       HWB_TX_ID                   AP_INTERFACE_HEADER.HWB_TX_ID%TYPE,        -- HWB_TX_ID
       MWB_TX_ID                   AP_INTERFACE_HEADER.MWB_TX_ID%TYPE,        -- MWB_TX_ID
       CONSOL_TX_ID                AP_INTERFACE_HEADER.CONSOL_TX_ID%TYPE,     -- CONSOL_TX_ID
       WAYBILL_TYPE                AP_INTERFACE_HEADER.WAYBILL_TYPE%TYPE,     -- WAYBILL�^�C�v
       --<<AP(LINE)�FAPT001>>
       APL_RECORD_ID               AP_INTERFACE_LINES.APL_RECORD_ID%TYPE,     -- AP���C��ID
       VENDOR_INVOICE_NUMBER       AP_INTERFACE_LINES.VENDOR_INVOICE_NUMBER%TYPE,
                                                                              -- �C���{�C�X�ԍ�
       VENDOR_NUMBER               AP_INTERFACE_LINES.VENDOR_NUMBER%TYPE,     -- �d����R�[�h
       LINE_AMOUNT                 AP_INTERFACE_LINES.LINE_AMOUNT%TYPE,       -- �x�����z
       LINE_DESCRIPTION            AP_INTERFACE_LINES.LINE_DESCRIPTION%TYPE,  -- LINE_DESCRIPTION
       ACCOUNTING_DATE             AP_INTERFACE_LINES.ACCOUNTING_DATE%TYPE,   -- �o��������
       TERMINAL                    AP_INTERFACE_LINES.TERMINAL%TYPE,          -- �ӏ��R�[�h
       GL_GROUP                    AP_INTERFACE_LINES.GL_GROUP%TYPE,          -- GL_GROUP
       SALES_RESPONSIBLE_OFFICE_ID AP_INTERFACE_LINES.SALES_RESPONSIBLE_OFFICE_ID%TYPE,
                                                                              -- �̔��ӏ�
       LOCAL_COST_AMT              AP_INTERFACE_LINES.LOCAL_COST_AMT%TYPE,    -- ���[�J���x�����z
       CHARGE_CODE                 AP_INTERFACE_LINES.CHARGE_CODE%TYPE,       -- CHARGE_CODE
       PPC_IND                     AP_INTERFACE_LINES.PPC_IND%TYPE,           -- PPC�敪
       INVD_RECORD_ID              AP_INTERFACE_LINES.INVD_RECORD_ID%TYPE,    -- INVD_RECORD_ID
       ORIGINAL_ACCOUNTING_DATE    AP_INTERFACE_LINES.ORIGINAL_ACCOUNTING_DATE%TYPE,
       LINE_TYPE                   AP_INTERFACE_LINES.LINE_TYPE_LOOKUP_CODE%TYPE,
       LINE_NUMBER                 AP_INTERFACE_LINES.LINE_NUMBER%TYPE );

    -- AP(APT001)�������R�[�h�̈�
    REC_APT001          REC_APT001_TYPE ;
    -- AP(APT001)�������̒��o�p�v�j�ϐ��J�E���^
    APT001_CNT              NUMBER ;

    -- UASIF�f�[�^�EAR���R�[�h���o���R�[�h�̈�
    SEL_TFJ201          TFJ201%ROWTYPE ;

   -- UASIF�f�[�^�iTFJ201�j�}�����R�[�h�̈�
    REC_TFJ201          TFJ201%ROWTYPE ;

    -- UASIF�f�[�^�iTFJ201�j�}���p�v�j�ϐ��J�E���^
    REC201_CNT          NUMBER ;

    -- UASIF�f�[�^�iTFJ201�j�������}���p�v�j�ϐ��J�E���^
    REC201FUT_CNT       NUMBER ;

    -- UASIF�����iTFJ202�j�}�����R�[�h�̈�
    REC_TFJ202          TFJ202%ROWTYPE ;

    -- UASIF�����iTFJ202�j�}���p�v�j�ϐ��J�E���^
    REC202_CNT          NUMBER ;

    WK_ERROR     NUMBER;
    WK_PRCID     NUMBER;
--=====================================================
-- PROCEDURE / FUNCTION
--=====================================================
-- �f�[�^���o�E�쐬�v���V�[�W��
PROCEDURE CRE_TFJ201(
    in_date              IN  DATE,      -- �Ɩ�������
    in_company_id        IN  VARCHAR2,  -- ��ЃR�[�h
    in_import_export_ind IN  VARCHAR2,  -- �A�o�^�A���敪
    in_transport_mode    IN  VARCHAR2,  -- �Ɩ��敪
    in_host_id           IN  NUMBER     -- HOST ID          -- 2005.10.23 Add
 ) ;

-- UASIF�f�[�^INSERT����
PROCEDURE INS_TFJ201 ;

-- UASIF����INSERT����
PROCEDURE INS_TFJ202 ;

-- TFJ201 AR�f�[�^�擾�����iHWB_TX_ID���)
PROCEDURE GET_TFJ201_HWB(
    IN_HWB_TX_ID                    IN  TFJ201.HWB_TX_ID%TYPE,                   -- HWB_TX_ID
    IN_GYMDTM                       IN  TFJ201.DGYMDTM%TYPE,                     -- �Ɩ����t
    OUT_SHIPPER_ID                  OUT TFJ201.SHIPPER_ID%TYPE,                  -- SHIPER_ID
    OUT_AR_RESPONSIBLE_PERSON_ID    OUT TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE,    -- �̔��S���Һ���
    OUT_SA_RESPONSIBLE_OFFICE_ID    OUT TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE, -- �̔��ӏ�
    OUT_GL_GROUP                    OUT TFJ201.GL_GROUP%TYPE,                    -- ����             2004/07/11 Add
    OUT_CUSTOMER_NUMBER             OUT TFJ201.CUSTOMER_NUMBER%TYPE,             -- �ڋq�R�[�h       2004/05/22 Add
    OUT_INVOICE_DATE                OUT TFJ201.INVOICE_DATE%TYPE,                -- ������           2004/05/22 Add
    OUT_ORIGINAL_INVOICE_DATE       OUT TFJ201.ORIGINAL_INVOICE_DATE%TYPE,       -- �I���W�i�������� 2004/05/22 Add
    OUT_WAYBILL_TYPE                OUT TFJ201.WAYBILL_TYPE%TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
    OUT_RETURN_CD                   OUT NUMBER                                   -- ��������
 ) ;

-- TFJ201 AR�f�[�^�擾�����iINVOICE_TX_ID���)
PROCEDURE GET_TFJ201_INV(
    IN_INV_TX_ID                    IN  TFJ201.INVOICE_TX_ID%TYPE,               -- INVOICE_TX_ID
    IN_GYMDTM                       IN  TFJ201.DGYMDTM%TYPE,                     -- �Ɩ����t
    OUT_SHIPPER_ID                  OUT TFJ201.SHIPPER_ID%TYPE,                  -- SHIPER_ID
    OUT_AR_RESPONSIBLE_PERSON_ID    OUT TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE,    -- �̔��S���Һ���
    OUT_SA_RESPONSIBLE_OFFICE_ID    OUT TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE, -- �̔��ӏ�
    OUT_GL_GROUP                    OUT TFJ201.GL_GROUP%TYPE,                    -- ����             2004/07/11 Add
    OUT_CUSTOMER_NUMBER             OUT TFJ201.CUSTOMER_NUMBER%TYPE,             -- �ڋq�R�[�h       2004/05/22 Add
    OUT_INVOICE_DATE                OUT TFJ201.INVOICE_DATE%TYPE,                -- ������           2004/05/22 Add
    OUT_ORIGINAL_INVOICE_DATE       OUT TFJ201.ORIGINAL_INVOICE_DATE%TYPE,       -- �I���W�i�������� 2004/05/22 Add
    OUT_WAYBILL_TYPE                OUT TFJ201.WAYBILL_TYPE%TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
    OUT_RETURN_CD                   OUT NUMBER                                   -- ��������
 ) ;

END PFGA2010 ;
CREATE OR REPLACE PACKAGE BODY           PFGA2010 AS
--*****************************************************
--�y UASI/F�f�[�^���o �z�p�b�P�[�W�{�̕�
--             PFGA2010
--*****************************************************

--==========================================================
-- UASIF�f�[�^���o�EUASIF�f�[�^�E�����̍쐬
-- �iART001�AGLT001�AAPT000�AAPT001���o�j
-- �iTFJ201�ATFJ202�쐬�j
-- �C��  --2004.06.10 AP VENDOR�̐ݒ�
--         (MWB/HWB������ł��Z�b�g����悤�ɕύX)
-- �C��  --2004.06.20 GL OMIT���W�b�N�ǉ�
--         (PC_RECORD_ID�Ŕ��f)
-- �ǉ�  --2004.06.24 CHARGE_NFD_FLG�Z�b�g�ǉ�
--        �iCHARGE_NFD_FLG = '0'�j
-- �ǉ�  --2004.07.11 Overseas �Ή��ǉ�
--         HWB_TX_ID�擾�܂ł͓��l�̃��W�b�N
--         JAPAN�͌��s�ǂ���AOverseas����ǉ�
--         �׎�iSHIPPER_ID�j�̎�蒼��
--         �iPFGA3950.SEL_PARTNER_ID�̌ďo�j
--         �̔��ӏ��A����A�̔��S���Ҏ擾
--         �iPFGA3940.OSSHIP_INF_GET�̌ďo�j
--         Overseas����MISC�̔��S���Ҏ擾�p�ɕύX
--         �iPFGA3940.EMPLOYEE_GET)
--         ����Z�b�g������悤�ɒǉ�
--         �iGET_TFJ201_INV,GET_TFJ201_HWB)
-- �C��  --2004.07.11 TFJ202 PK �ύX
--        �iINS_TFJ202��INSERT�����ύX�j
-- �C��  --2004.07.18 AP��MISC�̍l��
--         (TFJ201(AR)���f�[�^��[��ǉ��j
-- �C��  --2004.07.20 AP��MISC�̍l���ɑ΂���C��
--        �iAP��GL�Ɠ����悤��MISC�̔��S���Ҏ擾���l���j
-- �ǉ�  --2004.07.31 EWB_TYPE�ǉ��ɔ��Ȃ�
--        �iAR�f�[�^�擾������WAYBILL_TYPE���ԋp�j
-- �ǉ�  --2004.08.02 CONSOL���z�����ɔ��Ȃ��ǉ�
--        �iAR�FMaster�f�[�^�����APIPELINE_TX_ID��MWB_TX_ID���Z�b�g�j
--        �iGL�FBBAB�APSAB�̏ꍇ�AAL�Ɠ������W�b�N�ɂ���j
-- �C��  --2004.08.02 EXCEPTION�������̃J�[�\���N���[�Y
-- �ǉ�  --2004.10.27 GUI_NO�̒ǉ�
-- �C��  --2005.01.26 �Ǘ��̈�̍ŏI�������R�[�h���o�����W�b�N��ύX�B

-- �C��  --2005.10.23 Accounting Table Replication�Ή�
--         TFJ202��HOST_ID��ǉ��B
-- �C��  --2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�

-- �C��  --2005.12.12 GL��Allocation Charge��OMIT������HWB_NO����
--                    VENDOR_NO�ɕύX
--
-- �C��  --2024.05.20 RECORD_ID�̌��オ��s��Ή�

--==========================================================
PROCEDURE CRE_TFJ201(
    in_date              IN  DATE,      -- �Ɩ�������
    in_company_id        IN  VARCHAR2,  -- ��ЃR�[�h
    in_import_export_ind IN  VARCHAR2,  -- �A�o�^�A���敪
    in_transport_mode    IN  VARCHAR2,  -- �Ɩ��敪
    in_host_id           IN  NUMBER     -- HOST ID          -- 2005.10.23 Add
) IS


    I                             NUMBER;
    WK_COUNT                      NUMBER;
    WK_GETDTM                     TFJ201.DGYMDTM%TYPE;
    WK_LINE_FROM                  TFJ202.HOST_RECORD_ID%TYPE;
    WK_LINE_TO                    TFJ202.HOST_RECORD_ID%TYPE;
    WK_INTERFACE_LAST_DATE        TFJ202.INTERFACE_QUEUE_LAST_DATE%TYPE;    -- 2005.04.17 Add
    WK_DGYMDTM                    TFJ201.DGYMDTM%TYPE;
    WK_COMPANY_ID                 TFJ201.COMPANY_ID%TYPE;
    WK_IMPORT_EXPORT_IND          TFJ201.IMPORT_EXPORT_IND%TYPE;
    WK_TRANSPORT_MODE             TFJ201.TRANSPORT_MODE%TYPE;
    WK_HOST_ID                    TFJ202.HOST_ID%TYPE;                      -- 2005.10.23 Add
    CWK_HWB_TX_ID                 TFJ201.HWB_TX_ID%TYPE;
    CWK_SHIPPER_ID                TFJ201.SHIPPER_ID%TYPE;
    CWK_AR_RESPONSIBLE_PERSON_ID  TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE;
    CWK_SA_RESPONSIBLE_OFFICE_ID  TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE;
    CWK_CUSTOMER_NUMBER           TFJ201.CUSTOMER_NUMBER%TYPE;              -- 2004/05/22 Add
    CWK_INVOICE_DATE              TFJ201.INVOICE_DATE%TYPE;                 -- 2004/05/22 Add
    CWK_ORIGINAL_INVOICE_DATE     TFJ201.ORIGINAL_INVOICE_DATE%TYPE;        -- 2004/05/22 Add
    WK_CUSTOMER_NUMBER            TFJ201.CUSTOMER_NUMBER%TYPE;              -- 2004/06/20 Add
    WK_INVOICE_DATE               TFJ201.INVOICE_DATE%TYPE;                 -- 2004/06/20 Add
    WK_ORIGINAL_INVOICE_DATE      TFJ201.ORIGINAL_INVOICE_DATE%TYPE;        -- 2004/06/20 Add

    WK_PARTNER_ROLE               PIPELINE_PARTIES.PARTNER_ROLE%TYPE;       -- 2004/07/11 Add
    CWK_PARENT_PARTNER_ID         PIPELINE_PARTIES.PARENT_PARTNER_ID%TYPE;  -- 2004/07/11 Add DMY
    CWK_PARTNER_GROUP_CODE        PIPELINE_PARTIES.PARTNER_GROUP_CODE%TYPE; -- 2004/07/11 Add DMY
    CWK_GL_GROUP                  TFJ201.GL_GROUP%TYPE;                     -- 2004/07/11 Add
    CWK_WAYBILL_TYPE              TFJ201.WAYBILL_TYPE%TYPE;                 -- 2004/07/31 Add

    CWK_RET                       NUMBER;
    WK_LENGTH                     NUMBER;
    WK_OMMIT_CNT                  NUMBER;
    WK_OMMIT_FLG                  NUMBER;

    WK_GYMDTM                     TFJ201.DGYMDTM%TYPE;
    WK_AR_TYPE                    VARCHAR2(10);
    WK_GL_TYPE                    VARCHAR2(10);
    WK_AP_TYPE                    VARCHAR2(10);
    WK_PC_RECORD_ID               GL_INTERFACE.PC_RECORD_ID%TYPE;           -- 2004/06/20 Add

    WK_GUI_NUMBER                 TFJ201.GUI_NUMBER%TYPE;                   -- 2004/10/27 GUI NUMBER
    WK_GUI_DATE                   TFJ201.GUI_DATE%TYPE;                     -- 2004/10/27 GUI DATE

    --2005.11.12 AGENT_ROLE�Ή�
    WK_CUSTOMER_IND         PARTNER.CUSTOMER_IND%TYPE;
    WK_SHIPPER_IND          PARTNER.SHIPPER_IND%TYPE;
    WK_CNEE_IND             PARTNER.CNEE_IND%TYPE;
    WK_VENDOR_IND           PARTNER.VENDOR_IND%TYPE;
    WK_AGENT_IND            PARTNER.AGENT_IND%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY('PFGA2010','CRE_TFJ201');
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || in_date );

    WK_DGYMDTM           := in_date;
    WK_COMPANY_ID        := in_company_id;
    WK_IMPORT_EXPORT_IND := TRIM(in_import_export_ind);
    WK_TRANSPORT_MODE    := in_transport_mode;
    WK_HOST_ID           := in_host_id;          -- 2005.10.23 Add


    -- �Ǘ��̈揉����
    FOR I IN 1 .. 3 LOOP
        C_DATE(I)     := NULL ;
        C_RECNO(I)    := 0 ;
        M_RECNO(I)    := 0 ;
        N_RECNO(I)    := 0 ;
        N_REC_CNT(I)  := 0 ;
        N_PIC_OUT(I)  := 0 ;
        INTERFACE_LAST_DATE(I)  := NULL ;    -- 2005.04.17
    END LOOP ;

    -- �ϐ��N���A
    WK_LINE_FROM            := 0 ;
    ART001_CNT              := 0 ;
    GLT001_CNT              := 0 ;
    APT001_CNT              := 0 ;
    REC201_CNT              := 0 ;
    REC202_CNT              := 0 ;
    REC201FUT_CNT           := 0 ;

    WK_COUNT                := 0 ;
    WK_ERROR                := 0 ;
    WK_OMMIT_CNT            := 0 ;

    -----------------------------------------------------------------------------------------
    WK_PRCID := 0;

    -- AR���R�[�h
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    CWK_RET := 0;
    BEGIN
        SELECT DGYMDTM, HOST_RECORD_ID, INTERFACE_QUEUE_LAST_DATE INTO WK_GETDTM, WK_LINE_FROM, WK_INTERFACE_LAST_DATE
            FROM  TFJ202
           WHERE  RECORD_IND        = 'AR'
             AND  COMPANY_ID        = WK_COMPANY_ID
             AND  IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
             AND  TRANSPORT_MODE    = WK_TRANSPORT_MODE
             AND  HOST_ID           = WK_HOST_ID
             AND  DGYMDTM      = ( SELECT MAX(B.DGYMDTM)
                                     FROM  TFJ202 B
                                    WHERE  B.RECORD_IND        = 'AR'
                                      AND  B.COMPANY_ID        = WK_COMPANY_ID
                                      AND  B.IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
                                      AND  B.TRANSPORT_MODE    = WK_TRANSPORT_MODE
                                      AND  B.HOST_ID           = WK_HOST_ID);
    EXCEPTION
          WHEN NO_DATA_FOUND THEN
              CWK_RET := -1;    -- AR���R�[�hNot Found
          WHEN OTHERS THEN
              RAISE ;
    END ;
    IF CWK_RET = 0 THEN
        C_DATE(1)  := WK_GETDTM;
        C_RECNO(1) := WK_LINE_FROM;
        INTERFACE_LAST_DATE(1)  := WK_INTERFACE_LAST_DATE ;    -- 2005.04.17
    END IF;
    PFGA3910.TRACE_LOG( 'I', 'AR = ' || WK_HOST_ID || WK_LINE_FROM );

    -- GL���R�[�h
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    CWK_RET := 0;
    BEGIN
        SELECT DGYMDTM, HOST_RECORD_ID, INTERFACE_QUEUE_LAST_DATE INTO WK_GETDTM, WK_LINE_FROM, WK_INTERFACE_LAST_DATE
            FROM  TFJ202
           WHERE  RECORD_IND        = 'GL'
             AND  COMPANY_ID        = WK_COMPANY_ID
             AND  IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
             AND  TRANSPORT_MODE    = WK_TRANSPORT_MODE
             AND  HOST_ID           = WK_HOST_ID
             AND  DGYMDTM      = ( SELECT MAX(B.DGYMDTM)
                                     FROM  TFJ202 B
                                    WHERE  B.RECORD_IND        = 'GL'
                                      AND  B.COMPANY_ID        = WK_COMPANY_ID
                                      AND  B.IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
                                      AND  B.TRANSPORT_MODE    = WK_TRANSPORT_MODE
                                      AND  B.HOST_ID           = WK_HOST_ID);
    EXCEPTION
          WHEN NO_DATA_FOUND THEN
              CWK_RET := -1;    -- GL���R�[�hNot Found
          WHEN OTHERS THEN
              RAISE ;
    END ;
    IF CWK_RET = 0 THEN
        C_DATE(2)  := WK_GETDTM;
        C_RECNO(2) := WK_LINE_FROM;
        INTERFACE_LAST_DATE(2)  := WK_INTERFACE_LAST_DATE ;    -- 2005.04.17
    END IF;
    PFGA3910.TRACE_LOG( 'I', 'GL = ' || WK_HOST_ID || WK_LINE_FROM );

    -- AP���R�[�h
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    CWK_RET := 0;
    BEGIN
        SELECT DGYMDTM, HOST_RECORD_ID, INTERFACE_QUEUE_LAST_DATE INTO WK_GETDTM, WK_LINE_FROM, WK_INTERFACE_LAST_DATE
            FROM  TFJ202
           WHERE  RECORD_IND        = 'AP'
             AND  COMPANY_ID        = WK_COMPANY_ID
             AND  IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
             AND  TRANSPORT_MODE    = WK_TRANSPORT_MODE
             AND  HOST_ID           = WK_HOST_ID
             AND  DGYMDTM    = ( SELECT MAX(B.DGYMDTM)
                                     FROM  TFJ202 B
                                    WHERE  B.RECORD_IND        = 'AP'
                                      AND  B.COMPANY_ID        = WK_COMPANY_ID
                                      AND  B.IMPORT_EXPORT_IND = WK_IMPORT_EXPORT_IND
                                      AND  B.TRANSPORT_MODE    = WK_TRANSPORT_MODE
                                      AND  B.HOST_ID           = WK_HOST_ID);
    EXCEPTION
          WHEN NO_DATA_FOUND THEN
              CWK_RET := -1;    -- AP���R�[�hNot Found
          WHEN OTHERS THEN
              RAISE ;
    END ;
    IF CWK_RET = 0 THEN
        C_DATE(3)  := WK_GETDTM;
        C_RECNO(3) := WK_LINE_FROM;
        INTERFACE_LAST_DATE(3)  := WK_INTERFACE_LAST_DATE ;    -- 2005.04.17
    END IF;
    PFGA3910.TRACE_LOG( 'I', 'AP = ' || WK_HOST_ID || WK_LINE_FROM );

    -- �������������̓p�����[�^�̋Ɩ��������Ɠ����ł���΁A�������I���iRe-Run�j�B
    IF C_DATE(1) = WK_DGYMDTM OR C_DATE(2) = WK_DGYMDTM OR C_DATE(3) = WK_DGYMDTM THEN
        PFGA3910.TRACE_LOG('W','PFGA2010  Re-Run Occur �Ɩ����t = ' || TO_CHAR(WK_DGYMDTM,'YYYY/MM/DD'));
        PFGA3910.TRACE_PROC_EXIT;
        RETURN;
    END IF ;

    -- AR(�����j�AGL�i���j�AAP�i�����j�̊e�e�[�u���̓Ǎ��݂ƃ��R�[�h�����A�V�ŏI���R�[�h�ԍ��̊Ǘ��̈�ւ̃Z�b�g�B
    -- AR(�����j�e�[�u��
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    SELECT COUNT(*) INTO WK_COUNT
        FROM  AR_INTERFACE_LINES
        WHERE TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--          AND TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),4)) > C_RECNO(1);
          AND ARL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--          AND ARL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1))) + 1000000;
          AND ARL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1) + 1000000));
    IF WK_COUNT > 0 THEN
        N_REC_CNT(1) := WK_COUNT;
        -- 2005.10.23 ARL_RECORD_ID��MAX����HOST_ID��������MAX�ɕύX�B
        SELECT MAX(TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),4))) INTO WK_LINE_TO
            FROM  AR_INTERFACE_LINES
            WHERE TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--              AND TO_NUMBER(SUBSTR(TO_CHAR(ARL_RECORD_ID,'FM999999999999'),4)) > C_RECNO(1);
              AND ARL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--              AND ARL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1))) + 1000000;
              AND ARL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(1) + 1000000));
        IF WK_LINE_TO IS NULL OR WK_LINE_TO = 0 THEN
            PFGA3910.TRACE_LOG('W','PFGA2010  AR�E���� Max���R�[�h�擾�G���[');
            PFGA3910.TRACE_PROC_EXIT;
            RETURN;
        END IF;
        M_RECNO(1) := WK_LINE_TO;
    END IF;

    -- GL�i���j�e�[�u��
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    SELECT COUNT(*) INTO WK_COUNT
        FROM  GL_INTERFACE
        WHERE TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--          AND TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),4)) > C_RECNO(2);
          AND GLI_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--          AND GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2))) + 1000000;
          AND GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2) + 1000000));
    IF WK_COUNT > 0 THEN
        N_REC_CNT(2) := WK_COUNT;
        -- 2005.10.23 GLI_RECORD_ID��MAX����HOST_ID��������MAX�ɕύX�B
        SELECT MAX(TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),4))) INTO WK_LINE_TO
            FROM  GL_INTERFACE
            WHERE TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--              AND TO_NUMBER(SUBSTR(TO_CHAR(GLI_RECORD_ID,'FM999999999999'),4)) > C_RECNO(2);
              AND GLI_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--              AND GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2))) + 1000000;
              AND GLI_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_CHAR(C_RECNO(2) + 1000000));
        IF WK_LINE_TO IS NULL OR WK_LINE_TO = 0 THEN
            PFGA3910.TRACE_LOG('W','PFGA2010  GL�E��   Max���R�[�h�擾�G���[');
            PFGA3910.TRACE_PROC_EXIT;
            RETURN;
        END IF;
        M_RECNO(2) := WK_LINE_TO;
    END IF;

    -- AP�i�����j�e�[�u��
    -- 2005.10.23 SELECT���̏�����HOST_ID��ǉ��B
    SELECT COUNT(*) INTO WK_COUNT
        FROM  AP_INTERFACE_LINES
        WHERE TO_NUMBER(SUBSTR(TO_CHAR(APL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--          AND TO_NUMBER(SUBSTR(TO_CHAR(APL_RECORD_ID,'FM999999999999'),4)) > C_RECNO(3);
          AND APL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--          AND APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3))) + 1000000;
          AND APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3) + 1000000));
    IF WK_COUNT > 0 THEN
        N_REC_CNT(3) := WK_COUNT;
        -- 2005.10.23 APL_RECORD_ID��MAX����HOST_ID��������MAX�ɕύX�B
        SELECT MAX(TO_NUMBER(SUBSTR(TO_CHAR(APL_RECORD_ID,'FM999999999999'),4))) INTO WK_LINE_TO
            FROM  AP_INTERFACE_LINES
            WHERE TO_NUMBER(SUBSTR(TO_CHAR(APL_RECORD_ID,'FM999999999999'),1,3)) = WK_HOST_ID
--              AND TO_NUMBER(SUBSTR(TO_CHAR(APL_RECORD_ID,'FM999999999999'),4)) > C_RECNO(3);
              AND APL_RECORD_ID > TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3)))
    -- 2024.05.20 RECORD_ID�̌��オ��s��Ή�
--              AND APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3))) + 1000000;
              AND APL_RECORD_ID <= TO_NUMBER(TO_CHAR(WK_HOST_ID) || TO_NUMBER(C_RECNO(3) + 1000000));
        IF WK_LINE_TO IS NULL OR WK_LINE_TO = 0 THEN
            PFGA3910.TRACE_LOG('W','PFGA2010  AP�E���� Max���R�[�h�擾�G���[');
            PFGA3910.TRACE_PROC_EXIT;
            RETURN;
        END IF;
        M_RECNO(3) := WK_LINE_TO;
    END IF;

    -- �V�ŏI���R�[�h�ԍ����S��0�̏ꍇ�A�����������ׂ��f�[�^�����݂��Ȃ��ׁA�����I���iUASIF�����e�[�u���̏��o�����s��Ȃ��j
    IF N_REC_CNT(1) = 0 AND N_REC_CNT(2) = 0 AND N_REC_CNT(3) = 0 THEN
        PFGA3910.TRACE_LOG('W','PFGA2010  �����������ׂ��f�[�^�����݂��Ȃ�' );
        PFGA3910.TRACE_PROC_EXIT;
        RETURN;
    END IF ;

    -- �V�ŏI���R�[�h�ԍ���0�̏ꍇ�A���ŏI���R�[�h�ԍ���V�ŏI���R�[�h�ԍ��ɃZ�b�g����B
    FOR I IN 1 .. 3 LOOP
        IF M_RECNO(I) = 0 THEN
            M_RECNO(I) := C_RECNO(I);
        END IF ;
    END LOOP ;

    -- �C��  --2004.07.18 AP��MISC�̍l��
    -- �C��  --2004.08.02 AR��MASTER�̍l��
    -- 2005.12.01 AR:Master��INVOICE_TX_ID���Z�b�g
    -----------------------------------------------------------------------------------------
    --       TYPE             PIPELINE_TX_ID    HWB_TX_ID     MWB_TX_ID     INVOICE_TX_ID
    --  AR:  SHIP:�ʏ�        HWB_TX_ID         ��            ��            ��
    --       MISC:���̑�      INVOICE_TX_ID     0 �Œ�                      ��
    --       MASTER:          MWB_TX_ID         0 �Œ�        ��            ��
    --  GL:  SHIP:AL          HWB_TX_ID         ��            ��            0 �Œ�
    --       INV :������      HWB_TX_ID         ��            ��            ��
    --       MISC:            INVOICE_TX_ID     0 �Œ�                      ��
    --  AP:  MASTER:�d��      MWB_TX_ID         0 �Œ�        ��            0 �Œ�
    --       SHIP:BBAB,PSAB   HWB_TX_ID         ��            ��            0 �Œ�
    --       MISC:            INVOICE_TX_ID     0 �Œ�                      ��
    -----------------------------------------------------------------------------------------
    PFGA3910.TRACE_LOG( 'I', 'START AR' );
    WK_PRCID := 1;
    REC_TFJ201.COMPANY_ID        :=WK_COMPANY_ID;
    REC_TFJ201.IMPORT_EXPORT_IND :=TRIM(WK_IMPORT_EXPORT_IND);
    REC_TFJ201.TRANSPORT_MODE    :=WK_TRANSPORT_MODE;
    -- 2004.06.24 CHARGE_NFD_FLG�Z�b�g�ǉ�
    REC_TFJ201.CHARGE_NFD_FLG    :='0';

    -- AR(�����j�e�[�u�����o����
    -- �Ǘ��̈�AR�̃��R�[�h������0�łȂ���AR(�����j�e�[�u�����AUASIF�f�[�^�e�[�u���쐬
    IF N_REC_CNT(1)  != 0 THEN
        REC_TFJ201.RECORD_IND := 'AR';
        PFGA3910.TRACE_LOG('I','PFGA2010  AR�E�����e�[�u�����AUASIF�f�[�^�e�[�u���쐬' );
        -- AR(�����j�e�[�u���J�[�\���I�[�v��
        WK_LINE_FROM := C_RECNO(1);
        -- 2005.10.23 CURSOR��HOST_ID��ǉ��B
        OPEN CUR_ART001( WK_HOST_ID, WK_LINE_FROM, WK_COMPANY_ID, WK_IMPORT_EXPORT_IND, WK_TRANSPORT_MODE ) ;
        -- AR(�����j���R�[�h���o��
        LOOP
            FETCH CUR_ART001 INTO REC_ART001 ;
            EXIT WHEN CUR_ART001%NOTFOUND ;
            -- ���R�[�h�����������ꍇ�ȉ��̏������J��Ԃ��s���B
            -- 2005.10.23 ARL_RECORD_ID����HOST_ID���������������Z�b�g�B
            N_RECNO(1) := TO_NUMBER(SUBSTR(TO_CHAR(REC_ART001.ARL_RECORD_ID,'FM999999999999'),4));
            ART001_CNT  := ART001_CNT + 1 ;

            -- 2004/05/22 AR TYPE�̐ݒ�
            -- 2004.08.02 AR��MASTER�P�ʁFCONSOL�̔���グ����
            -- CONSOL��RollUp�iBBAB,PSAB�Ȃǁj
            IF REC_ART001.WAYBILL_TYPE IS NOT NULL AND
                   (REC_ART001.WAYBILL_TYPE = 'M' OR  REC_ART001.WAYBILL_TYPE = 'MD') THEN
                WK_AR_TYPE := 'MASTER';                -- CONSOL�iMATER�Ɠ��������j
            ELSE
                -- AR��INVOICE�P�ʁFPIPELINE_TX_ID�ɂ�INVOICE_HEADER��PIPELINE_TX_ID�������Ă���
            --  IF INSTR(REC_ART001.INVOICE_TYPE,'Misc',1,1) = 0 THEN
            --      WK_AR_TYPE := 'SHIP';              -- HWB SHIP��Invoice
            --  ELSE
            --      WK_AR_TYPE := 'MISC';              -- MISC�i���̑������j��Invoice
            --  END IF;
                IF REC_ART001.WAYBILL_TYPE IS NULL THEN
                    WK_AR_TYPE := 'MISC';              -- MISC�i���̑������j��Invoice
                ELSE
                    WK_AR_TYPE := 'SHIP';              -- HWB SHIP��Invoice
                END IF;
            END IF;
            -- AR���R�[�h�̍��ڂ�UASIF�f�[�^���R�[�h�̍��ڂֈڑ�
            REC_TFJ201.DGYMDTM                     := WK_DGYMDTM;
            REC_TFJ201.RECORD_ID                   := REC_ART001.ARL_RECORD_ID;
            REC_TFJ201.ACCOUNTING_DATE             := REC_ART001.GL_DATE;
            REC_TFJ201.INVOICE_DATE                := REC_ART001.INVOICE_DATE;
            REC_TFJ201.ORIGINAL_INVOICE_DATE       := REC_ART001.ORIGINAL_INVOICE_DATE;
            -- Global
            REC_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := NVL(REC_ART001.TERMINAL,'!');
            REC_TFJ201.GL_GROUP                    := NVL(REC_ART001.GL_GROUP,'!');
            --
            REC_TFJ201.VENDOR_NO                   := '#';
            REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := NVL(REC_ART001.AR_RESPONSIBLE_PERSON_ID,'!');
            REC_TFJ201.CUSTOMER_NUMBER             := REC_ART001.CUSTOMER_NUMBER;
            -- 2004.08.02 AR TYPE 'MASTER' ��ǉ�
            IF WK_AR_TYPE = 'SHIP' THEN
                REC_TFJ201.SHIPPER_ID              := NVL(REC_ART001.SHIPPER_ID,'!');
            ELSIF WK_AR_TYPE = 'MISC' THEN
                -- MISC��CUSTOMER_NO(BILL_TO)��SHIPPER��
                REC_TFJ201.SHIPPER_ID              := NVL(REC_ART001.CUSTOMER_NUMBER,'!');
            ELSE
                REC_TFJ201.SHIPPER_ID              := '!';
            END IF;
            REC_TFJ201.WAYBILL_TYPE                := REC_ART001.WAYBILL_TYPE;
            REC_TFJ201.HWB_NO                      := REC_ART001.HWB_NO;
            REC_TFJ201.MWB_NO                      := REC_ART001.MWB_NO;
            REC_TFJ201.CONSOL_NO                   := REC_ART001.CONSOL_NO;
            REC_TFJ201.CORRECTION_NO               := REC_ART001.CORRECTION_NO;
            REC_TFJ201.INVOICE_TYPE                := REC_ART001.INVOICE_TYPE;
            REC_TFJ201.INVOICE_NO                  := REC_ART001.INVOICE_NUMBER;
            IF WK_AR_TYPE = 'SHIP' THEN
                REC_TFJ201.HWB_TX_ID               := NVL(REC_ART001.HWB_TX_ID,0);
            ELSE
                REC_TFJ201.HWB_TX_ID               := 0;
            END IF;
            REC_TFJ201.MWB_TX_ID                   := NVL(REC_ART001.MWB_TX_ID,0);
            REC_TFJ201.CONSOL_TX_ID                := NVL(REC_ART001.CONSOL_TX_ID,0);
            REC_TFJ201.INVOICE_TX_ID               := NVL(REC_ART001.PIPELINE_TX_ID,0);
            -- 2004.08.02 AR TYPE 'MASTER' ��ǉ�
            -- 2005.12.01 AR:Master��INVOICE_TX_ID���Z�b�g
            --IF WK_AR_TYPE = 'MASTER' THEN
            --    REC_TFJ201.INVOICE_TX_ID           := 0;
            --END IF;
            REC_TFJ201.PPC_IND                     := TRIM(REC_ART001.PPC_IND);
            REC_TFJ201.CHARGE_CODE                 := REC_ART001.CHARGE_CODE;
            REC_TFJ201.LINE_DESCRIPTION            := REC_ART001.LINE_DESCRIPTION;
            REC_TFJ201.CURRENCY_CODE               := REC_ART001.CURRENCY_CODE;
            REC_TFJ201.CONVERSION_RATE             := NVL(REC_ART001.CONVERSION_RATE,0);
            REC_TFJ201.LINE_AMOUNT                 := NVL(REC_ART001.LINE_AMOUNT,0);
            REC_TFJ201.LOCAL_INVOICE_AMT           := NVL(REC_ART001.LOCAL_INVOICE_AMT,0);
            REC_TFJ201.LINE_TYPE                   := REC_ART001.LINE_TYPE;
            REC_TFJ201.GUI_NUMBER                  := NULL;
            REC_TFJ201.GUI_DATE                    := NULL;
            --2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�
            REC_TFJ201.LINE_NUMBER                 := REC_ART001.INVOICE_LINE_NUMBER;
            REC_TFJ201.LINKTO_INVOICE_NUMBER       := REC_ART001.LINK_TO_INVOICE_NUMBER;
            IF REC_ART001.INVOICE_TYPE = 'Invoice' THEN
                REC_TFJ201.LINKTO_LINE_NUMBER      := NULL;
            ELSE
                REC_TFJ201.LINKTO_LINE_NUMBER      := REC_ART001.LINKTO_INVOICE_LINE_NUMBER;
            END IF;
            PFGA3950.SEL_PARTNER_INDICATION( REC_TFJ201.CUSTOMER_NUMBER,
                                             WK_CUSTOMER_IND,
                                             WK_SHIPPER_IND,
                                             WK_CNEE_IND,
                                             WK_VENDOR_IND,
                                             WK_AGENT_IND );
            REC_TFJ201.AGENT_ROLE                  := NVL(WK_AGENT_IND,'N');
            REC_TFJ201.BILLTO_ADDRESS_NO           := REC_ART001.BILL_TO_ADDRESS_NO;

            IF WK_AR_TYPE = 'SHIP' THEN
                IF REC_TFJ201.HWB_TX_ID = 0 THEN
                    -- ���ʊ֐��iSEL_PIPELINE_RELATIONS�j��p����HWB_TX_ID���擾����B
                    PFGA3940.HWB_PIPELINE_RELATIONS( REC_TFJ201.INVOICE_TX_ID,
                                                     'IN',
                                                     'SH',
                                                     CWK_HWB_TX_ID );
                    REC_TFJ201.HWB_TX_ID       := CWK_HWB_TX_ID;
                END IF;
            END IF;

            -- PIPELINE_TX_ID �ǉ� 2004.05.02
            -- PIPELINE_TX_ID=0�̓G���[�f�[�^
            -- 2004.08.02 AR TYPE 'MASTER' ��ǉ�
            IF WK_AR_TYPE = 'SHIP' THEN                                  -- HWB SHIPMENT
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.HWB_TX_ID;
            ELSIF WK_AR_TYPE = 'MISC' THEN                               -- MISC:���̑�����
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.INVOICE_TX_ID;
            ELSE                                                         -- MASTER�FCONSOL
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.MWB_TX_ID;
            END IF;

            -- 2004/10/27 Add KWETR UAS GUI_NUMBER�擾
            --IF WK_COMPANY_ID in ('590','591','592') THEN                 -- KWETW
            --    IF WK_AR_TYPE in ('SHIP','MISC') THEN                    -- INVOICE�̏ꍇ
            --        PFGA3940.GUI_NO_GET(REC_TFJ201.RECORD_ID,
            --                            WK_GUI_NUMBER,
            --                            WK_GUI_DATE,
            --                            CWK_RET);
            --        IF CWK_RET = 0 THEN
            --            REC_TFJ201.GUI_NUMBER := WK_GUI_NUMBER;
            --            REC_TFJ201.GUI_DATE   := WK_GUI_DATE;
            --        END IF;
            --    END IF;
            --END IF;


            -- �׎�擾 --SHIPPER_ID--�iAR_TYPE = 'SHIP'�̎��������j
            IF REC_TFJ201.HWB_TX_ID != 0 AND WK_AR_TYPE = 'SHIP' THEN
                IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                    WK_PARTNER_ROLE := 'S';     -- SHIPPER
                ELSE
                    WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                END IF;
                PFGA3950.SEL_PARTNER_ID(  REC_TFJ201.HWB_TX_ID,
                                          WK_PARTNER_ROLE,
                                          CWK_SHIPPER_ID,
                                          CWK_PARENT_PARTNER_ID,     --DMY
                                          CWK_PARTNER_GROUP_CODE);   --DMY
                IF CWK_SHIPPER_ID != '!' THEN
                    REC_TFJ201.SHIPPER_ID := CWK_SHIPPER_ID;
                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 PARTER ID GET ERROR'
                                        || ' RECORD_ID='   || REC_ART001.ARL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID
                                        || ' PARTNER_ROLE='   || WK_PARTNER_ROLE );
                END IF;
            END IF;
            -- �̔��S���ҁA�̔��ӏ��A����擾 --�iAR_TYPE = 'SHIP'�̎��������j
            IF REC_TFJ201.HWB_TX_ID != 0 AND WK_AR_TYPE = 'SHIP' THEN
                -- ���ʊ֐��iOVERSEAS SHIPMENT_���擾�����j��p���Ď擾����B
                -- ���ʊ֐��ďo�p�����[�^���Z�b�g���iHWB_TX_ID�j�A���ʊ֐����Ăяo���B
                PFGA3940.OSSHIP_INF_GET(  REC_TFJ201.HWB_TX_ID,
                                          WK_IMPORT_EXPORT_IND,
                                          CWK_WAYBILL_TYPE,
                                          CWK_AR_RESPONSIBLE_PERSON_ID,
                                          CWK_SA_RESPONSIBLE_OFFICE_ID,
                                          CWK_GL_GROUP,
                                          CWK_RET);
                IF CWK_RET = 0 THEN
                    -- �̔��S���҂͖������ɃZ�b�g
                    IF CWK_AR_RESPONSIBLE_PERSON_ID != '!' THEN
                        REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                    ELSE
                        PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                              WK_IMPORT_EXPORT_IND,
                                              WK_TRANSPORT_MODE,
                                              REC_TFJ201.SHIPPER_ID,
                                              WK_PARTNER_ROLE,
                                              CWK_AR_RESPONSIBLE_PERSON_ID,
                                              CWK_RET);
                        REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                    END IF;
                ELSE
                     PFGA3910.TRACE_LOG('W','PFGA2010 SALES OFFICE/PERSON GET ERROR RET='  || CWK_RET
                                        || ' RECORD_ID='   || REC_ART001.ARL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                END IF;
            END IF;
            -- MISC �̔��S���Ҏ擾 --�iAR_TYPE = 'MISC'�̎��������j
            -- MISC��CUSTOMER_NO(BILL_TO)��SHIPPER_ID��
            IF REC_TFJ201.SHIPPER_ID != '!' AND WK_AR_TYPE = 'MISC' THEN
                IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                    WK_PARTNER_ROLE := 'S';     -- SHIPPER
                ELSE
                    WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                END IF;
                PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                      WK_IMPORT_EXPORT_IND,
                                      WK_TRANSPORT_MODE,
                                      REC_TFJ201.SHIPPER_ID,
                                      WK_PARTNER_ROLE,
                                      CWK_AR_RESPONSIBLE_PERSON_ID,
                                      CWK_RET);
                IF CWK_RET = 0 THEN
                    REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 EMPLOYEE GET ERROR RET='  || CWK_RET
                                        || ' RECORD_ID='   || REC_ART001.ARL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                END IF;
            END IF;
            -- UASIF�f�[�^�ǉ�����
            -- UASIF�f�[�^INSERT�����ďo��
            -- 2005.04.17 Add PIPELINE_TX_ID=0�̓G���[�f�[�^
            IF REC_TFJ201.PIPELINE_TX_ID <> 0 THEN
                INS_TFJ201 ;
            ELSE
                PFGA3910.TRACE_LOG('E','PFGA2010 AR�FPIPELINE_TX_ID ERROR --> DATA OMIT'  ||
                                                 ' RECORD_ID=' || REC_ART001.ARL_RECORD_ID);
            END IF;
            -- �Ǘ��̈�̒��o�������Z
            N_PIC_OUT(1)  := N_PIC_OUT(1) + 1 ;
        END LOOP ;
        -- AR(�����j�e�[�u���J�[�\���N���[�Y
        CLOSE CUR_ART001 ;
    END IF;

    -----------------------------------------------------------------------------------------
    PFGA3910.TRACE_LOG( 'I', 'START GL' );
    WK_PRCID := 2;
    -- GL�i���j�e�[�u�����o����
    -- �Ǘ��̈�GL�̃��R�[�h������0�łȂ���GL�i���j�e�[�u�����AUASIF�f�[�^�e�[�u���쐬
    IF N_REC_CNT(2)  != 0 THEN
        REC_TFJ201.RECORD_IND := 'GL';
        PFGA3910.TRACE_LOG('I','PFGA2010  GL�E��  �e�[�u�����AUASIF�f�[�^�e�[�u���쐬' );
        WK_PC_RECORD_ID := 0;               -- 2004/06/20 Add ������
        -- GL�i���j�e�[�u���J�[�\���I�[�v��
        WK_LINE_FROM := C_RECNO(2);
        -- 2005.10.23 CURSOR��HOST_ID��ǉ��B
        OPEN CUR_GLT001( WK_HOST_ID, WK_LINE_FROM, WK_COMPANY_ID, WK_IMPORT_EXPORT_IND, WK_TRANSPORT_MODE ) ;
        -- GL�i���j���R�[�h���o��
        LOOP
            FETCH CUR_GLT001 INTO REC_GLT001 ;
            EXIT WHEN CUR_GLT001%NOTFOUND ;
            -- ���R�[�h�����������ꍇ�ȉ��̏������J��Ԃ��s���B
            -- 2005.10.23 GLI_RECORD_ID����HOST_ID���������������Z�b�g�B
            -- 2005.12.12 GL��RECORD_ID���ł͂Ȃ��Ή�
            IF TO_NUMBER(SUBSTR(TO_CHAR(REC_GLT001.GLI_RECORD_ID,'FM999999999999'),4)) > N_RECNO(2) THEN
                N_RECNO(2) := TO_NUMBER(SUBSTR(TO_CHAR(REC_GLT001.GLI_RECORD_ID,'FM999999999999'),4));
            END IF;
            -- GL��SHIPMENT�P�ʁFAllocated�iAL)�̉��l�y��BBAB,PSAB�̉��l
            --     INVOICE�P�� �FAdvanced(AD)�^Absorbed(AB)�̉��l
            -- 2004/05/22 GL TYPE�̐ݒ�
            WK_LENGTH :=  LENGTH(REC_GLT001.CHARGE_CODE) - 1 ;
            -- 2004/08/02 GL TYPE�� SHIP�ݒ� BBAB,PSAB �ǉ�
            -- 2006.02.03 ��Q�̂��ߌ��ɖ߂�
            IF SUBSTR(REC_GLT001.CHARGE_CODE,WK_LENGTH,2) = 'AL' OR
               REC_GLT001.CHARGE_CODE = 'BBAB'       OR
               REC_GLT001.CHARGE_CODE = 'PSAB'       THEN
                WK_GL_TYPE := 'SHIP';               -- HWB SHIP�̉��l�y��BBAB,PSAB
            -- 2005.12.12 SHIP�̔��f��ύX
            --IF REC_GLT001.PIPELINE_TX_ID = NVL(REC_GLT001.MWB_TX_ID,0)    OR
            --   REC_GLT001.PIPELINE_TX_ID = NVL(REC_GLT001.HWB_TX_ID,0)    OR
            --   REC_GLT001.PIPELINE_TX_ID = NVL(REC_GLT001.CONSOL_TX_ID,0) THEN
            --    WK_GL_TYPE := 'SHIP';               -- HWB SHIP�̉��l�y��BBAB,PSAB
            ELSE
                -- 2005.11.11
                IF   (SUBSTR(REC_GLT001.HWB_NO,5,1) = 'M' AND
                      REC_GLT001.MWB_NO IS NULL)
                  OR (INSTR(REC_GLT001.HWB_NO,'MI') > 0 AND
                      REC_GLT001.MWB_NO IS NULL) THEN
                    WK_GL_TYPE := 'MISC';           -- MISC�i���̑������j�̉��l
                ELSE
                    WK_GL_TYPE := 'INV';            -- Invoice�̉��l
                END IF;
            END IF;
            WK_OMMIT_FLG := 0;                      -- 2004/06/20 Add ������
            IF WK_GL_TYPE = 'SHIP' THEN
                -- 2004.05.02 �ǉ� (CHARGE_CODE 'AL' �̎� HAWB_NO ��NULL�̎�����OMIT�j
                -- 2005.12.12 GL��Allocation Charge��OMIT������HWB_NO����VENDOR_NO�ɕύX
                -- 2006.02.10 IMPORT��BBAB/PSAB��OMIT������HWB_NO�ɖ߂�
                IF WK_IMPORT_EXPORT_IND = 'I'            AND
                   (REC_GLT001.CHARGE_CODE = 'BBAB'  OR
                    REC_GLT001.CHARGE_CODE = 'PSAB')     THEN
                    IF REC_GLT001.HWB_NO IS NULL THEN
                        WK_OMMIT_FLG := 1;
                        WK_OMMIT_CNT := WK_OMMIT_CNT + 1;
                    END IF;
                ELSE
                    IF REC_GLT001.VENDOR_NO IS NULL THEN
                        WK_OMMIT_FLG := 1;
                        WK_OMMIT_CNT := WK_OMMIT_CNT + 1;
                    END IF;
                END IF;
            ELSE
                -- 2004.06.20 �ǉ� (Invoice�̉��l�F����PC_RECORD_ID��OMIT�j
                -- 2004.06.20 �ǉ� (MISC�i���̑������j�̉��l�F����PC_RECORD_ID��OMIT�j
                IF WK_PC_RECORD_ID = REC_GLT001.PC_RECORD_ID THEN
                    WK_OMMIT_FLG := 1;
                    WK_OMMIT_CNT := WK_OMMIT_CNT + 1;
                END IF;
            END IF;
            WK_PC_RECORD_ID := NVL(REC_GLT001.PC_RECORD_ID,0);  -- 2004/06/20 Add �ݒ�
            IF WK_OMMIT_FLG  = 0 THEN
                GLT001_CNT  := GLT001_CNT + 1 ;

                -- GL���R�[�h�̍��ڂ�UASIF�f�[�^���R�[�h�̍��ڂֈڑ�
                REC_TFJ201.DGYMDTM                     := WK_DGYMDTM;
                REC_TFJ201.RECORD_ID                   := REC_GLT001.GLI_RECORD_ID;
                REC_TFJ201.ACCOUNTING_DATE             := REC_GLT001.ACCOUNTING_DATE;
                REC_TFJ201.INVOICE_DATE                := NULL;                      -- AR���擾
                REC_TFJ201.ORIGINAL_INVOICE_DATE       := NULL;                      -- AR���擾
                -- Global
                REC_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := NVL(REC_GLT001.TERMINAL,'!');
                REC_TFJ201.GL_GROUP                    := NVL(REC_GLT001.GL_GROUP,'!');
                --
                REC_TFJ201.VENDOR_NO                   := NVL(REC_GLT001.VENDOR_NO,'!');
                REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := '!';        --�inote�F3�j     AR���擾
                REC_TFJ201.CUSTOMER_NUMBER             := NULL;                      -- AR���擾
                REC_TFJ201.SHIPPER_ID                  := '!';        --�inote�F4�j     AR���擾
                REC_TFJ201.WAYBILL_TYPE                := NULL;
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC
                    REC_TFJ201.HWB_NO                  := NULL;
                ELSE
                    REC_TFJ201.HWB_NO                  := REC_GLT001.HWB_NO;
                END IF;
                REC_TFJ201.MWB_NO                      := REC_GLT001.MWB_NO;
                REC_TFJ201.CONSOL_NO                   := REC_GLT001.CONSOL_NO;
                REC_TFJ201.CORRECTION_NO               := REC_GLT001.CORRECTION_NO;
                REC_TFJ201.INVOICE_TYPE                := NULL;
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC
                    REC_TFJ201.INVOICE_NO              := REC_GLT001.HWB_NO;
                ELSE
                    REC_TFJ201.INVOICE_NO              := REC_GLT001.INVOICE_NO;
                END IF;
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC
                    REC_TFJ201.HWB_TX_ID               := 0;
                ELSE
                    REC_TFJ201.HWB_TX_ID               := NVL(REC_GLT001.HWB_TX_ID,0);
                END IF;
                REC_TFJ201.MWB_TX_ID                   := NVL(REC_GLT001.MWB_TX_ID,0);
                REC_TFJ201.CONSOL_TX_ID                := NVL(REC_GLT001.CONSOL_TX_ID,0);
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC
                    REC_TFJ201.INVOICE_TX_ID           := NVL(REC_GLT001.PIPELINE_TX_ID,0);
                ELSIF WK_GL_TYPE = 'SHIP' THEN                        -- SHIPMENT(AL)
                    REC_TFJ201.INVOICE_TX_ID           := 0;
                ELSE                                                  -- INVOICE(AD,AB)
                    REC_TFJ201.INVOICE_TX_ID           := NVL(REC_GLT001.PIPELINE_TX_ID,0);
                END IF;
                REC_TFJ201.PPC_IND                     := NULL;
                REC_TFJ201.CHARGE_CODE                 := REC_GLT001.CHARGE_CODE;
                REC_TFJ201.LINE_DESCRIPTION            := NULL;
                REC_TFJ201.CURRENCY_CODE               := REC_GLT001.CURRENCY_CODE;
                REC_TFJ201.CONVERSION_RATE             := 0;
                REC_TFJ201.LINE_AMOUNT                 := NVL(REC_GLT001.GL_AMOUNT,0);
                IF NVL(REC_GLT001.OC_CONVERTED_AMOUNT,0) = 0 THEN
                    REC_TFJ201.LOCAL_INVOICE_AMT       := NVL(REC_GLT001.GL_AMOUNT,0);
                ELSE
                    REC_TFJ201.LOCAL_INVOICE_AMT       := NVL(REC_GLT001.OC_CONVERTED_AMOUNT,0);
                END IF;
                REC_TFJ201.LINE_TYPE                   := NULL;
                REC_TFJ201.GUI_NUMBER                  := NULL;
                REC_TFJ201.GUI_DATE                    := NULL;
                --2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�
                REC_TFJ201.LINE_NUMBER                 := NULL;
                REC_TFJ201.LINKTO_INVOICE_NUMBER       := NULL;
                REC_TFJ201.LINKTO_LINE_NUMBER          := NULL;
                REC_TFJ201.AGENT_ROLE                  := 'N';
                REC_TFJ201.BILLTO_ADDRESS_NO           := NULL;

                IF WK_GL_TYPE = 'INV' THEN
                    IF REC_TFJ201.HWB_TX_ID = 0 THEN
                        -- ���ʊ֐��iSEL_PIPELINE_RELATIONS�j��p����HWB_TX_ID���擾����B
                        PFGA3940.HWB_PIPELINE_RELATIONS( REC_TFJ201.INVOICE_TX_ID,
                                                         'IN',
                                                         'SH',
                                                         CWK_HWB_TX_ID );
                        REC_TFJ201.HWB_TX_ID       := CWK_HWB_TX_ID;
                    END IF;
                END IF;
                IF WK_GL_TYPE = 'INV' THEN                           -- INVOICE(AD,AB)
                    IF REC_TFJ201.HWB_TX_ID = REC_TFJ201.INVOICE_TX_ID THEN
                        REC_TFJ201.INVOICE_TX_ID       := 0;         -- ���޲��P�ʂł͂��邪�AVENDOR��������ꂽ�P�[�X
                    END IF;
                END IF;

                -- PIPELINE_TX_ID �ǉ� 2004.05.02
                -- PIPELINE_TX_ID=0�̓G���[�f�[�^
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC:���̑�����
                    REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.INVOICE_TX_ID;
                ELSE                                                  -- HWB(AL.AB.AD)
                    REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.HWB_TX_ID;
                END IF;

                -- TFJ201(AR)���f�[�^��[
                IF TO_CHAR(REC_TFJ201.ACCOUNTING_DATE,'YYYYMMDD') > TO_CHAR(REC_TFJ201.DGYMDTM,'YYYYMMDD') THEN
                    WK_GYMDTM := REC_TFJ201.ACCOUNTING_DATE;
                ELSE
                    WK_GYMDTM := REC_TFJ201.DGYMDTM;
                END IF;
                IF WK_GL_TYPE = 'MISC' THEN                           -- MISC:���̑�����
                    GET_TFJ201_INV(REC_TFJ201.INVOICE_TX_ID,        -- INVOICE_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   CWK_CUSTOMER_NUMBER,             -- �ڋq�R�[�h       2004/05/22 Add
                                   CWK_INVOICE_DATE,                -- ������           2004/05/22 Add
                                   CWK_ORIGINAL_INVOICE_DATE,       -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                ELSIF WK_GL_TYPE = 'SHIP' THEN                           -- SHIPMENT(AL)
                    GET_TFJ201_HWB(REC_TFJ201.HWB_TX_ID,            -- HWB_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   CWK_CUSTOMER_NUMBER,             -- �ڋq�R�[�h       2004/05/22 Add
                                   CWK_INVOICE_DATE,                -- ������           2004/05/22 Add
                                   CWK_ORIGINAL_INVOICE_DATE,       -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                ELSE
                    IF REC_TFJ201.INVOICE_TX_ID = 0 THEN
                        GET_TFJ201_HWB(REC_TFJ201.HWB_TX_ID,        -- HWB_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   CWK_CUSTOMER_NUMBER,             -- �ڋq�R�[�h       2004/05/22 Add
                                   CWK_INVOICE_DATE,                -- ������           2004/05/22 Add
                                   CWK_ORIGINAL_INVOICE_DATE,       -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                    ELSE
                    -- 2004/06/18 SHIPER_ID,�̔��S���Һ���,�̔��ӏ���SHIPMENT��AR���
                    --            �ڋq�R�[�h,������,�I���W�i����������INVOICE��AR���ҏW
                        GET_TFJ201_INV(REC_TFJ201.INVOICE_TX_ID,    -- INVOICE_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   WK_CUSTOMER_NUMBER,              -- �ڋq�R�[�h       2004/05/22 Add
                                   WK_INVOICE_DATE,                 -- ������           2004/05/22 Add
                                   WK_ORIGINAL_INVOICE_DATE,        -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                        IF CWK_RET = 0 THEN
                            GET_TFJ201_HWB(REC_TFJ201.HWB_TX_ID,    -- HWB_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   CWK_CUSTOMER_NUMBER,             -- �ڋq�R�[�h       2004/05/22 Add
                                   CWK_INVOICE_DATE,                -- ������           2004/05/22 Add
                                   CWK_ORIGINAL_INVOICE_DATE,       -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                            --  �ڋq�R�[�h,������,�I���W�i����������INVOICE��AR���ҏW(2004/06/18)
                            CWK_CUSTOMER_NUMBER       := WK_CUSTOMER_NUMBER;          -- INVOICE��� �ڋq�R�[�h
                            CWK_INVOICE_DATE          := WK_INVOICE_DATE;             -- INVOICE��� ������
                            CWK_ORIGINAL_INVOICE_DATE := WK_ORIGINAL_INVOICE_DATE;    -- INVOICE��� �I���W�i��������
                        ELSE
                            GET_TFJ201_HWB(REC_TFJ201.HWB_TX_ID,    -- HWB_TX_ID
                                   WK_GYMDTM,                       -- �Ɩ����t
                                   CWK_SHIPPER_ID,                  -- SHIPER_ID
                                   CWK_AR_RESPONSIBLE_PERSON_ID,    -- �̔��S���Һ���
                                   CWK_SA_RESPONSIBLE_OFFICE_ID,    -- �̔��ӏ�
                                   CWK_GL_GROUP,                    -- ����             2004/07/11 Add
                                   CWK_CUSTOMER_NUMBER,             -- �ڋq�R�[�h       2004/05/22 Add
                                   CWK_INVOICE_DATE,                -- ������           2004/05/22 Add
                                   CWK_ORIGINAL_INVOICE_DATE,       -- �I���W�i�������� 2004/05/22 Add
                                   CWK_WAYBILL_TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
                                   CWK_RET);                        -- ��������
                        END IF;
                     END IF;
                END IF;
                IF CWK_RET = 0 THEN
                    REC_TFJ201.INVOICE_DATE                := CWK_INVOICE_DATE;                -- AR���擾
                    REC_TFJ201.ORIGINAL_INVOICE_DATE       := CWK_ORIGINAL_INVOICE_DATE;       -- AR���擾
                    REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;    -- AR���擾
                    REC_TFJ201.CUSTOMER_NUMBER             := CWK_CUSTOMER_NUMBER;             -- AR���擾
                    REC_TFJ201.SHIPPER_ID                  := CWK_SHIPPER_ID;                  -- AR���擾
                    -- 2004/06/18 �̔��ӏ���AR����擾����悤�ɒ���
                    REC_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := CWK_SA_RESPONSIBLE_OFFICE_ID;
                    REC_TFJ201.GL_GROUP := CWK_GL_GROUP;            -- ���� AR���擾 2004/07/11 Add
                    REC_TFJ201.WAYBILL_TYPE := CWK_WAYBILL_TYPE;    -- WAYBILL_TYPE AR���擾 2004/07/31 Add

                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 GL:AR RECORD NOT FOUND RET='  || CWK_RET
                                            || ' RECORD_ID='      || REC_GLT001.GLI_RECORD_ID
                                            || ' HWB_NO='         || REC_TFJ201.HWB_NO
                                            || ' HWB_TX_ID='      || REC_TFJ201.HWB_TX_ID
                                            || ' INVOICE_TX_ID='  || REC_TFJ201.INVOICE_TX_ID );
                    -- �׎�擾 --SHIPPER_ID--�iGL_TYPE = 'SHIP'/'INV'�̎��������j
                    IF REC_TFJ201.HWB_TX_ID != 0 AND WK_GL_TYPE != 'MISC' THEN
                        IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                            WK_PARTNER_ROLE := 'S';     -- SHIPPER
                        ELSE
                            WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                        END IF;
                        PFGA3950.SEL_PARTNER_ID(  REC_TFJ201.HWB_TX_ID,
                                                  WK_PARTNER_ROLE,
                                                  CWK_SHIPPER_ID,
                                                  CWK_PARENT_PARTNER_ID,     --DMY
                                                  CWK_PARTNER_GROUP_CODE);   --DMY
                        IF CWK_SHIPPER_ID != '!' THEN
                            REC_TFJ201.SHIPPER_ID := CWK_SHIPPER_ID;
                        ELSE
                            PFGA3910.TRACE_LOG('W','PFGA2010 PARTER ID GET ERROR'
                                                || ' RECORD_ID='   || REC_GLT001.GLI_RECORD_ID
                                                || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID
                                                || ' PARTNER_ROLE='   || WK_PARTNER_ROLE );
                        END IF;
                    END IF;
                    -- �̔��S���ҁA�̔��ӏ��A����擾 --�iGL_TYPE = 'SHIP'/'INV'�̎��������j
                    IF REC_TFJ201.HWB_TX_ID != 0 AND WK_GL_TYPE != 'MISC' THEN
                        -- ���ʊ֐��iOVERSEAS SHIPMENT_���擾�����j��p���Ď擾����B
                        -- ���ʊ֐��ďo�p�����[�^���Z�b�g���iHWB_TX_ID�j�A���ʊ֐����Ăяo���B
                        PFGA3940.OSSHIP_INF_GET(  REC_TFJ201.HWB_TX_ID,
                                                  WK_IMPORT_EXPORT_IND,
                                                  CWK_WAYBILL_TYPE,
                                                  CWK_AR_RESPONSIBLE_PERSON_ID,
                                                  CWK_SA_RESPONSIBLE_OFFICE_ID,
                                                  CWK_GL_GROUP,
                                                  CWK_RET);
                        IF CWK_RET = 0 THEN
                            -- �̔��S���҂͖������ɃZ�b�g
                            IF CWK_AR_RESPONSIBLE_PERSON_ID != '!' THEN
                                REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                            ELSE
                                PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                                      WK_IMPORT_EXPORT_IND,
                                                      WK_TRANSPORT_MODE,
                                                      REC_TFJ201.SHIPPER_ID,
                                                      WK_PARTNER_ROLE,
                                                      CWK_AR_RESPONSIBLE_PERSON_ID,
                                                      CWK_RET);
                                REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                            END IF;
                            REC_TFJ201.WAYBILL_TYPE                := CWK_WAYBILL_TYPE;
                        ELSE
                             PFGA3910.TRACE_LOG('W','PFGA2010 SALES OFFICE/PERSON GET ERROR RET='  || CWK_RET
                                                || ' RECORD_ID='   || REC_GLT001.GLI_RECORD_ID
                                                || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                        END IF;
                    END IF;
                    -- MISC �̔��S���Ҏ擾 --�iGL_TYPE = 'MISC'�̎��������j
                    -- MISC��CUSTOMER_NO(BILL_TO)��SHIPPER_ID��
                    IF REC_TFJ201.SHIPPER_ID != '!' AND WK_GL_TYPE = 'MISC' THEN
                        IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                            WK_PARTNER_ROLE := 'S';     -- SHIPPER
                        ELSE
                            WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                        END IF;
                        PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                              WK_IMPORT_EXPORT_IND,
                                              WK_TRANSPORT_MODE,
                                              REC_TFJ201.SHIPPER_ID,
                                              WK_PARTNER_ROLE,
                                              CWK_AR_RESPONSIBLE_PERSON_ID,
                                              CWK_RET);
                        IF CWK_RET = 0 THEN
                            REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                        ELSE
                            PFGA3910.TRACE_LOG('W','PFGA2010 EMPLOYEE GET ERROR RET='  || CWK_RET
                                                || ' RECORD_ID='   || REC_GLT001.GLI_RECORD_ID
                                                || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                        END IF;
                    END IF;
                END IF;
                -- UASIF�f�[�^�ǉ�����
                -- UASIF�f�[�^INSERT�����ďo��
                -- 2005.04.17 Add PIPELINE_TX_ID=0�̓G���[�f�[�^
                IF REC_TFJ201.PIPELINE_TX_ID <> 0 THEN
                    INS_TFJ201 ;
                ELSE
                    PFGA3910.TRACE_LOG('E','PFGA2010 GL�FPIPELINE_TX_ID ERROR --> DATA OMIT'  ||
                                                     ' RECORD_ID=' || REC_GLT001.GLI_RECORD_ID);
                END IF;
                -- �Ǘ��̈�̒��o�������Z
                N_PIC_OUT(2)  := N_PIC_OUT(2) + 1 ;
            END IF;
        END LOOP ;
        -- GL�i���j�e�[�u���J�[�\���N���[�Y
        CLOSE CUR_GLT001 ;
    END IF;

    -----------------------------------------------------------------------------------------
    PFGA3910.TRACE_LOG( 'I', 'START AP' );
    WK_PRCID := 3;
    -- AP�i�����j�e�[�u�����o����
    -- �Ǘ��̈�AP�̃��R�[�h������0�łȂ���AP�i�����j�e�[�u�����AUASIF�f�[�^�e�[�u���쐬
    IF N_REC_CNT(3)  != 0 THEN
        REC_TFJ201.RECORD_IND := 'AP';
        PFGA3910.TRACE_LOG('I','PFGA2010  AP�E�����e�[�u�����AUASIF�f�[�^�e�[�u���쐬' );
        -- AP�i�����j�e�[�u���J�[�\���I�[�v��
        WK_LINE_FROM := C_RECNO(3);
        -- 2005.10.23 CURSOR��HOST_ID��ǉ��B
        OPEN CUR_APT001( WK_HOST_ID, WK_LINE_FROM, WK_COMPANY_ID, WK_IMPORT_EXPORT_IND, WK_TRANSPORT_MODE ) ;
        -- AP�i�����j���R�[�h���o��
        LOOP
            FETCH CUR_APT001 INTO REC_APT001 ;
            EXIT WHEN CUR_APT001%NOTFOUND ;
            -- ���R�[�h�����������ꍇ�ȉ��̏������J��Ԃ��s���B
            -- 2005.10.23 APL_RECORD_ID����HOST_ID���������������Z�b�g�B
            N_RECNO(3) := TO_NUMBER(SUBSTR(TO_CHAR(REC_APT001.APL_RECORD_ID,'FM999999999999'),4));
            APT001_CNT  := APT001_CNT + 1 ;

            -- AP��MASTER�P��  �FMASTER�̎d���l
            --     SHIPMENT�P�ʁFBBAB/PSAB���̉��l
            -- �C��  --2004.07.18 AP��MISC�̍l��
            -- 2004/05/22 AP TYPE�̐ݒ�
            -- 2005.11.07 Direct Collect�̑Ή�
            IF REC_APT001.WAYBILL_TYPE IS NULL THEN
                WK_AP_TYPE := 'MISC';                   -- MISC INVOICE
            ELSE
                IF REC_APT001.WAYBILL_TYPE = 'M' THEN
                    WK_AP_TYPE := 'MASTER';             -- MWB
                ELSIF REC_APT001.WAYBILL_TYPE = 'MD' THEN
                    IF REC_APT001.PPC_IND = 'C' AND
                       REC_APT001.INVD_RECORD_ID IS NOT NULL THEN
                        WK_AP_TYPE := 'MDCOLL';         -- Direct Collect
                    ELSE
                        WK_AP_TYPE := 'MASTER';         -- MWB
                    END IF;
                ELSIF REC_APT001.WAYBILL_TYPE = 'HD' THEN
                    IF REC_APT001.PPC_IND = 'C' THEN
                        WK_AP_TYPE := 'HDCOLL';         -- Direct Collect
                    ELSE
                        WK_AP_TYPE := 'SHIP';           -- SHIP
                    END IF;
                ELSE
                    WK_AP_TYPE := 'SHIP';               -- SHIP
                END IF;
            END IF;
            -- AP���R�[�h�̍��ڂ�UASIF�f�[�^���R�[�h�̍��ڂֈڑ�
            REC_TFJ201.DGYMDTM                     := WK_DGYMDTM;
            REC_TFJ201.RECORD_ID                   := REC_APT001.APL_RECORD_ID;
            REC_TFJ201.ACCOUNTING_DATE             := REC_APT001.ACCOUNTING_DATE;
            REC_TFJ201.INVOICE_DATE                := REC_APT001.INVOICE_DATE;
            REC_TFJ201.ORIGINAL_INVOICE_DATE       := REC_APT001.ORIGINAL_ACCOUNTING_DATE;
            -- Global
            REC_TFJ201.SALES_RESPONSIBLE_OFFICE_ID := NVL(REC_APT001.TERMINAL,'!');
            REC_TFJ201.GL_GROUP                    := NVL(REC_APT001.GL_GROUP,'!');
            --
            -- 2004.06.10 AP VENDOR�̐ݒ�iMWB/HWB������ł��Z�b�g����悤�ɕύX)
            --IF WK_AP_TYPE = 'MASTER' THEN                           -- MWB
            --    REC_TFJ201.VENDOR_NO               := REC_APT001.VENDOR_NUMBER;
            --ELSE
            --    REC_TFJ201.VENDOR_NO               := '!';
            --END IF;
            REC_TFJ201.VENDOR_NO                   := NVL(REC_APT001.VENDOR_NUMBER,'!');
            REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := '!';        --�inote�F3�j
            REC_TFJ201.CUSTOMER_NUMBER             := NULL;
            REC_TFJ201.SHIPPER_ID                  := '!';        --�inote�F4�j
            -- �C��  --2005.11.07 Direct Collect�̑Ή�
            IF WK_AP_TYPE = 'MDCOLL' THEN                         -- Direct Collect(MD)
                REC_TFJ201.WAYBILL_TYPE            := 'HD';
            ELSE
                REC_TFJ201.WAYBILL_TYPE            := REC_APT001.WAYBILL_TYPE;
            END IF;
            -- �C��  --2004.07.18 AP��MISC�̍l��
            IF WK_AP_TYPE = 'MISC' THEN                           -- MISC
                REC_TFJ201.HWB_NO                  := NULL;
            ELSE
                REC_TFJ201.HWB_NO                  := REC_APT001.HWB_NO;
            END IF;
            REC_TFJ201.MWB_NO                      := REC_APT001.MWB_NO;
            REC_TFJ201.CONSOL_NO                   := REC_APT001.CONSOL_NO;
            REC_TFJ201.CORRECTION_NO               := REC_APT001.CORRECTION_NO;
            REC_TFJ201.INVOICE_TYPE                := NULL;
            -- �C��  --2004.07.18 AP��MISC�̍l��
            IF WK_AP_TYPE = 'MISC' THEN                           -- MISC
                REC_TFJ201.INVOICE_NO              := REC_APT001.HWB_NO;
            ELSE
                REC_TFJ201.INVOICE_NO              := REC_APT001.VENDOR_INVOICE_NUMBER;
            END IF;
            IF WK_AP_TYPE = 'SHIP'   OR                           -- SHIP
               WK_AP_TYPE = 'HDCOLL' OR                           -- Direct Collect(HD)
               WK_AP_TYPE = 'MDCOLL' THEN                         -- Direct Collect(MD)
                REC_TFJ201.HWB_TX_ID               := NVL(REC_APT001.HWB_TX_ID,0);
            ELSE
                REC_TFJ201.HWB_TX_ID               := 0;
            END IF;
            REC_TFJ201.MWB_TX_ID                   := NVL(REC_APT001.MWB_TX_ID,0);
            REC_TFJ201.CONSOL_TX_ID                := NVL(REC_APT001.CONSOL_TX_ID,0);
            -- �C��  --2004.07.18 AP��MISC�̍l��
            IF WK_AP_TYPE = 'MISC' THEN                          -- MISC
                REC_TFJ201.INVOICE_TX_ID           := NVL(REC_APT001.PIPELINE_TX_ID,0);
            ELSE
                REC_TFJ201.INVOICE_TX_ID           := 0;
            END IF;
            REC_TFJ201.PPC_IND                     := TRIM(REC_APT001.PPC_IND);
            REC_TFJ201.CHARGE_CODE                 := REC_APT001.CHARGE_CODE;
            REC_TFJ201.LINE_DESCRIPTION            := REC_APT001.LINE_DESCRIPTION;
            REC_TFJ201.CURRENCY_CODE               := REC_APT001.CURRENCY_CODE;
            REC_TFJ201.CONVERSION_RATE             := NVL(REC_APT001.CONVERSION_RATE,0);
            REC_TFJ201.LINE_AMOUNT                 := NVL(REC_APT001.LINE_AMOUNT,0);
            REC_TFJ201.LOCAL_INVOICE_AMT           := NVL(REC_APT001.LOCAL_COST_AMT,0);
            REC_TFJ201.LINE_TYPE                   := REC_APT001.LINE_TYPE;
            REC_TFJ201.GUI_NUMBER                  := NULL;
            REC_TFJ201.GUI_DATE                    := NULL;
            --2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�
            REC_TFJ201.LINE_NUMBER                 := REC_APT001.LINE_NUMBER;
            REC_TFJ201.LINKTO_INVOICE_NUMBER       := NULL;
            REC_TFJ201.LINKTO_LINE_NUMBER          := NULL;
            PFGA3950.SEL_PARTNER_INDICATION( REC_TFJ201.VENDOR_NO,
                                             WK_CUSTOMER_IND,
                                             WK_SHIPPER_IND,
                                             WK_CNEE_IND,
                                             WK_VENDOR_IND,
                                             WK_AGENT_IND );
            REC_TFJ201.AGENT_ROLE                  := NVL(WK_AGENT_IND,'N');
            REC_TFJ201.BILLTO_ADDRESS_NO           := NULL;

            -- PIPELINE_TX_ID �ǉ� 2004.05.02
            -- PIPELINE_TX_ID=0�̓G���[�f�[�^
            -- �C��  --2004.07.18 AP��MISC�̍l��
            IF WK_AP_TYPE = 'MASTER' THEN                                -- MWB
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.MWB_TX_ID;
            ELSIF WK_AP_TYPE = 'MDCOLL' THEN                             -- Direct Collect(MD)
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.HWB_TX_ID;
            ELSIF WK_AP_TYPE = 'SHIP' THEN                               -- SHIP
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.HWB_TX_ID;
            ELSIF WK_AP_TYPE = 'HDCOLL' THEN                             -- Direct Collect(HD)
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.HWB_TX_ID;
            ELSE                                                         -- MISC
                REC_TFJ201.PIPELINE_TX_ID := REC_TFJ201.INVOICE_TX_ID;
            END IF;
            -- �׎�擾 --SHIPPER_ID--�iAP_TYPE = 'SHIP','MDCOLL','HDCOLL'�̎��������j
            IF REC_TFJ201.HWB_TX_ID != 0 THEN
                IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                    WK_PARTNER_ROLE := 'S';     -- SHIPPER
                ELSE
                    WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                END IF;
                PFGA3950.SEL_PARTNER_ID(  REC_TFJ201.HWB_TX_ID,
                                          WK_PARTNER_ROLE,
                                          CWK_SHIPPER_ID,
                                          CWK_PARENT_PARTNER_ID,     --DMY
                                          CWK_PARTNER_GROUP_CODE);   --DMY
                IF CWK_SHIPPER_ID != '!' THEN
                    REC_TFJ201.SHIPPER_ID := CWK_SHIPPER_ID;
                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 PARTER ID GET ERROR'
                                        || ' RECORD_ID='   || REC_APT001.APL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID
                                        || ' PARTNER_ROLE='   || WK_PARTNER_ROLE );
                END IF;
            END IF;
            -- �̔��S���ҁA�̔��ӏ��A����擾 --�iAP_TYPE = 'SHIP','MDCOLL','HDCOLL'�̎��������j
            IF REC_TFJ201.HWB_TX_ID != 0 THEN
                -- ���ʊ֐��iOVERSEAS SHIPMENT_���擾�����j��p���Ď擾����B
                -- ���ʊ֐��ďo�p�����[�^���Z�b�g���iHWB_TX_ID�j�A���ʊ֐����Ăяo���B
                PFGA3940.OSSHIP_INF_GET(  REC_TFJ201.HWB_TX_ID,
                                          WK_IMPORT_EXPORT_IND,
                                          CWK_WAYBILL_TYPE,
                                          CWK_AR_RESPONSIBLE_PERSON_ID,
                                          CWK_SA_RESPONSIBLE_OFFICE_ID,
                                          CWK_GL_GROUP,
                                          CWK_RET);
                IF CWK_RET = 0 THEN
                    -- �̔��S���҂͖������ɃZ�b�g
                    IF CWK_AR_RESPONSIBLE_PERSON_ID != '!' THEN
                        REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                    ELSE
                        PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                              WK_IMPORT_EXPORT_IND,
                                              WK_TRANSPORT_MODE,
                                              REC_TFJ201.SHIPPER_ID,
                                              WK_PARTNER_ROLE,
                                              CWK_AR_RESPONSIBLE_PERSON_ID,
                                              CWK_RET);
                        REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                    END IF;
                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 SALES OFFICE/PERSON GET ERROR RET='  || CWK_RET
                                        || ' RECORD_ID='   || REC_APT001.APL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                END IF;
            END IF;
            -- MISC �̔��S���Ҏ擾 --�iAP_TYPE = 'MISC'�̎��������j
            -- MISC��CUSTOMER_NO(BILL_TO)��SHIPPER_ID��
            IF REC_TFJ201.SHIPPER_ID != '!' AND WK_AP_TYPE = 'MISC' THEN
                IF  WK_IMPORT_EXPORT_IND = 'E' THEN
                    WK_PARTNER_ROLE := 'S';     -- SHIPPER
                ELSE
                    WK_PARTNER_ROLE := 'C';     -- CONSIGNEE
                END IF;
                PFGA3940.EMPLOYEE_GET(WK_COMPANY_ID,
                                      WK_IMPORT_EXPORT_IND,
                                      WK_TRANSPORT_MODE,
                                      REC_TFJ201.SHIPPER_ID,
                                      WK_PARTNER_ROLE,
                                      CWK_AR_RESPONSIBLE_PERSON_ID,
                                      CWK_RET);
                IF CWK_RET = 0 THEN
                    REC_TFJ201.AR_RESPONSIBLE_PERSON_ID    := CWK_AR_RESPONSIBLE_PERSON_ID;
                ELSE
                    PFGA3910.TRACE_LOG('W','PFGA2010 EMPLOYEE GET ERROR RET='  || CWK_RET
                                        || ' RECORD_ID='   || REC_APT001.APL_RECORD_ID
                                        || ' HWB_TX_ID='   || REC_TFJ201.HWB_TX_ID );
                END IF;
            END IF;
            -- UASIF�f�[�^�ǉ�����
            -- UASIF�f�[�^INSERT�����ďo��
            -- 2005.04.17 Add PIPELINE_TX_ID=0�̓G���[�f�[�^
            IF REC_TFJ201.PIPELINE_TX_ID <> 0 THEN
                INS_TFJ201 ;
            ELSE
                PFGA3910.TRACE_LOG('E','PFGA2010 AP�FPIPELINE_TX_ID ERROR --> DATA OMIT'  ||
                                                 ' RECORD_ID=' || REC_APT001.APL_RECORD_ID);
            END IF;
            -- �Ǘ��̈�̒��o�������Z
            N_PIC_OUT(3)  := N_PIC_OUT(3) + 1 ;
        END LOOP ;
        -- AP�i�����j�e�[�u���J�[�\���N���[�Y
        CLOSE CUR_APT001 ;
    END IF;

    -----------------------------------------------------------------------------------------
    PFGA3910.TRACE_LOG( 'I', 'Update TFJ202' );
    WK_PRCID := 4;
    -- UASIF�������R�[�h�o�^
    -- �Ǘ��̈�̐V���R�[�h�����A�V���o���������ɁA�R���R�[�h���o���B
    -- UASIF����INSERT�����ďo��
    PFGA3910.TRACE_LOG( 'I', 'TFJ202 DGYMDTM = ' || WK_DGYMDTM ||
                                   ' COMPANY_ID = ' || WK_COMPANY_ID ||
                                   ' IMPORT_EXPORT_IND = ' || TRIM(WK_IMPORT_EXPORT_IND) ||
                                   ' TRANSPORT_MODE = ' || WK_TRANSPORT_MODE ||
                                   ' HOST_ID = ' || WK_HOST_ID );
    REC_TFJ202.DGYMDTM           := WK_DGYMDTM;
    REC_TFJ202.COMPANY_ID        := WK_COMPANY_ID;
    REC_TFJ202.IMPORT_EXPORT_IND := TRIM(WK_IMPORT_EXPORT_IND);
    REC_TFJ202.TRANSPORT_MODE    := WK_TRANSPORT_MODE;
    REC_TFJ202.HOST_ID           := WK_HOST_ID;          -- 2005.10.23 Add
    --AR���R�[�h
    REC_TFJ202.RECORD_IND := 'AR';
    PFGA3910.TRACE_LOG( 'I', 'AR TFJ202 C_RECNO = ' || C_RECNO(1) ||
                                      ' N_RECNO = ' || N_RECNO(1) ||
                                      ' M_RECNO = ' || M_RECNO(1) ||
                                      ' N_REC_CNT = ' || N_REC_CNT(1) ||
                                      ' N_PIC_OUT = ' || N_PIC_OUT(1) );
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    IF M_RECNO(1) > N_RECNO(1) THEN
        REC_TFJ202.HOST_RECORD_ID  := M_RECNO(1);
    ELSE
        REC_TFJ202.HOST_RECORD_ID  := N_RECNO(1);
    END IF;
    REC_TFJ202.RECORD_ID  := WK_HOST_ID || REC_TFJ202.HOST_RECORD_ID;
    REC_TFJ202.NREC_CNT   := N_REC_CNT(1);
    REC_TFJ202.NPICK_OUT  := N_PIC_OUT(1);
    REC_TFJ202.INTERFACE_QUEUE_LAST_DATE  := INTERFACE_LAST_DATE(1);  -- 2005.04.17
    INS_TFJ202;

    --GL���R�[�h
    REC_TFJ202.RECORD_IND := 'GL';
    PFGA3910.TRACE_LOG( 'I', 'GL TFJ202 C_RECNO = ' || C_RECNO(2) ||
                                      ' N_RECNO = ' || N_RECNO(2) ||
                                      ' M_RECNO = ' || M_RECNO(2) ||
                                      ' N_REC_CNT = ' || N_REC_CNT(2) ||
                                      ' N_PIC_OUT = ' || N_PIC_OUT(2) );
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    IF M_RECNO(2) > N_RECNO(2) THEN
        REC_TFJ202.HOST_RECORD_ID  := M_RECNO(2);
    ELSE
        REC_TFJ202.HOST_RECORD_ID  := N_RECNO(2);
    END IF;
    REC_TFJ202.RECORD_ID  := WK_HOST_ID || REC_TFJ202.HOST_RECORD_ID;
    REC_TFJ202.NREC_CNT   := N_REC_CNT(2);
    REC_TFJ202.NPICK_OUT  := N_PIC_OUT(2);
    REC_TFJ202.INTERFACE_QUEUE_LAST_DATE  := INTERFACE_LAST_DATE(2);  -- 2005.04.17
    INS_TFJ202;

    --AP���R�[�h
    REC_TFJ202.RECORD_IND := 'AP';
    PFGA3910.TRACE_LOG( 'I', 'AP TFJ202 C_RECNO = ' || C_RECNO(3) ||
                                      ' N_RECNO = ' || N_RECNO(3) ||
                                      ' M_RECNO = ' || M_RECNO(3) ||
                                      ' N_REC_CNT = ' || N_REC_CNT(3) ||
                                      ' N_PIC_OUT = ' || N_PIC_OUT(3) );
    -- 2005.10.23 TFJ202��HOST_ID��ǉ��BRECORD_ID���HOST_RECORD_ID�ɕύX
    IF M_RECNO(3) > N_RECNO(3) THEN
        REC_TFJ202.HOST_RECORD_ID  := M_RECNO(3);
    ELSE
        REC_TFJ202.HOST_RECORD_ID  := N_RECNO(3);
    END IF;
    REC_TFJ202.RECORD_ID  := WK_HOST_ID || REC_TFJ202.HOST_RECORD_ID;
    REC_TFJ202.NREC_CNT   := N_REC_CNT(3);
    REC_TFJ202.NPICK_OUT  := N_PIC_OUT(3);
    REC_TFJ202.INTERFACE_QUEUE_LAST_DATE  := INTERFACE_LAST_DATE(3);  -- 2005.04.17
    INS_TFJ202;

    -----------------------------------------------------------------------------------------
    -- �������ʂ����O�t�@�C���ɏ����o���B
    PFGA3910.TRACE_LOG( 'I', 'AR�E�������R�[�h���͌���    = ' || ART001_CNT );
    PFGA3910.TRACE_LOG( 'I', 'GL�E�����R�[�h���͌���      = ' || GLT001_CNT );
    PFGA3910.TRACE_LOG( 'I', 'AP�E�������R�[�h���͌���    = ' || APT001_CNT );
    PFGA3910.TRACE_LOG( 'I', 'UASIF�f�[�^���R�[�h�o�͌��� = ' || REC201_CNT );
    PFGA3910.TRACE_LOG( 'I', '(UASIF���������R�[�h���� = ' || REC201FUT_CNT || ')' );
    PFGA3910.TRACE_LOG( 'I', 'UASIF�������R�[�h�o�͌���   = ' || REC202_CNT );
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            IF WK_PRCID = 0 THEN
                PFGA3910.TRACE_LOG( 'E', 'TFJ202/ART001/GLT001/APT001 Imput Error' ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            ELSIF WK_PRCID = 1 THEN
                PFGA3910.TRACE_LOG( 'E', 'ART001 Edit Error' ||
                                 ' RECORD_ID  = ' || REC_ART001.ARL_RECORD_ID ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            ELSIF WK_PRCID = 2 THEN
                PFGA3910.TRACE_LOG( 'E', 'GLT001 Edit Error' ||
                                 ' RECORD_ID  = ' || REC_GLT001.GLI_RECORD_ID ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            ELSIF WK_PRCID = 3 THEN
                PFGA3910.TRACE_LOG( 'E', 'APT001 Edit Error' ||
                                 ' RECORD_ID  = ' || REC_APT001.APL_RECORD_ID ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            ELSIF WK_PRCID = 4 THEN
                PFGA3910.TRACE_LOG( 'E', 'Update TFJ202 Error' ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            ELSE
                PFGA3910.TRACE_LOG( 'E', 'Other Error' ||
                                 ' SQLCODE=' || TO_CHAR(SQLCODE) );
            END IF;
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        -- 2004.08.02 EXCEPTION�������̃J�[�\���N���[�Y
        IF CUR_ART001%ISOPEN THEN
            CLOSE CUR_ART001;
        END IF;
        IF CUR_GLT001%ISOPEN THEN
            CLOSE CUR_GLT001;
        END IF;
        IF CUR_APT001%ISOPEN THEN
            CLOSE CUR_APT001;
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- TFJ201 AR�f�[�^�擾�����iHWB_TX_ID���)
--==========================================
PROCEDURE GET_TFJ201_HWB(
    IN_HWB_TX_ID                    IN  TFJ201.HWB_TX_ID%TYPE,                   -- HWB_TX_ID
    IN_GYMDTM                       IN  TFJ201.DGYMDTM%TYPE,                     -- �Ɩ����t
    OUT_SHIPPER_ID                  OUT TFJ201.SHIPPER_ID%TYPE,                  -- SHIPER_ID
    OUT_AR_RESPONSIBLE_PERSON_ID    OUT TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE,    -- �̔��S���Һ���
    OUT_SA_RESPONSIBLE_OFFICE_ID    OUT TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE, -- �̔��ӏ�
    OUT_GL_GROUP                    OUT TFJ201.GL_GROUP%TYPE,                    -- ����             2004/07/11 Add
    OUT_CUSTOMER_NUMBER             OUT TFJ201.CUSTOMER_NUMBER%TYPE,             -- �ڋq�R�[�h       2004/05/22 Add
    OUT_INVOICE_DATE                OUT TFJ201.INVOICE_DATE%TYPE,                -- ������           2004/05/22 Add
    OUT_ORIGINAL_INVOICE_DATE       OUT TFJ201.ORIGINAL_INVOICE_DATE%TYPE,       -- �I���W�i�������� 2004/05/22 Add
    OUT_WAYBILL_TYPE                OUT TFJ201.WAYBILL_TYPE%TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
    OUT_RETURN_CD                   OUT NUMBER                                   -- ��������
 )
IS
    WK_SHIPPER_ID                   TFJ201.SHIPPER_ID%TYPE;
    WK_AR_RESPONSIBLE_PERSON_ID     TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE;
    WK_SA_RESPONSIBLE_OFFICE_ID     TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE;
    WK_GL_GROUP                     TFJ201.GL_GROUP%TYPE;                     -- 2004/07/11 Add
    WK_CUSTOMER_NUMBER              TFJ201.CUSTOMER_NUMBER%TYPE;              -- 2004/05/22 Add
    WK_INVOICE_DATE                 TFJ201.INVOICE_DATE%TYPE;                 -- 2004/05/22 Add
    WK_ORIGINAL_INVOICE_DATE        TFJ201.ORIGINAL_INVOICE_DATE%TYPE;        -- 2004/05/22 Add
    WK_WAYBILL_TYPE                 TFJ201.WAYBILL_TYPE%TYPE;                 -- 2004/07/31 Add
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2010', 'GET_SHP_ID_CD' );

    -- �߂�l���������i�o�̓f�t�H���g�Z�b�g�A��������-1�j
    OUT_SA_RESPONSIBLE_OFFICE_ID    := '!'; -- �̔��ӏ�
    OUT_GL_GROUP                    := '!'; -- ����             2004/07/11 Add
    OUT_AR_RESPONSIBLE_PERSON_ID    := '!'; -- �̔��S���Һ���
    OUT_SHIPPER_ID                  := '!'; -- SHIPER_ID
    OUT_RETURN_CD                   := -2;  -- ��������

    -- HWB_TX_ID�����UASIF�f�[�^�̍ŐVAR(�����j���R�[�h��Ǎ��ށB
    -- ���R�[�h�����݂��鎞�ASHPPER_ID�A�̔��S���҃R�[�h�A�̔��ӏ��A�������ʂP���Z�b�g���߂�B
    BEGIN
        SELECT  A.SHIPPER_ID, A.AR_RESPONSIBLE_PERSON_ID, A.SALES_RESPONSIBLE_OFFICE_ID,
                A.GL_GROUP,A.WAYBILL_TYPE,
                A.CUSTOMER_NUMBER, A.INVOICE_DATE, A.ORIGINAL_INVOICE_DATE
          INTO  WK_SHIPPER_ID ,WK_AR_RESPONSIBLE_PERSON_ID, WK_SA_RESPONSIBLE_OFFICE_ID,
                WK_GL_GROUP,WK_WAYBILL_TYPE,
                WK_CUSTOMER_NUMBER, WK_INVOICE_DATE, WK_ORIGINAL_INVOICE_DATE
          FROM  TFJ201 A
        WHERE  RECORD_IND = 'AR'
          AND  RECORD_ID  = ( SELECT  MAX( B.RECORD_ID )
                                    FROM  TFJ201 B
                                   WHERE  B.RECORD_IND =  'AR'
                                     AND  B.DGYMDTM   <= IN_GYMDTM
                                     AND  B.HWB_TX_ID  = IN_HWB_TX_ID );
    EXCEPTION
          WHEN NO_DATA_FOUND THEN
              OUT_RETURN_CD := -1;    -- AR(�����j���R�[�hNot Found
          WHEN OTHERS THEN
              RAISE ;
    END ;
    IF OUT_RETURN_CD != -1 THEN
        OUT_SHIPPER_ID                  := WK_SHIPPER_ID;               -- SHIPER_ID
        OUT_SA_RESPONSIBLE_OFFICE_ID    := WK_SA_RESPONSIBLE_OFFICE_ID; -- �̔��ӏ�
        OUT_GL_GROUP                    := WK_GL_GROUP;                 -- ����             2004/07/11 Add
        OUT_AR_RESPONSIBLE_PERSON_ID    := WK_AR_RESPONSIBLE_PERSON_ID; -- �̔��S���Һ���
        OUT_CUSTOMER_NUMBER             := WK_CUSTOMER_NUMBER;          -- �ڋq�R�[�h       2004/05/22 Add
        OUT_INVOICE_DATE                := WK_INVOICE_DATE;             -- ������           2004/05/22 Add
        OUT_ORIGINAL_INVOICE_DATE       := WK_ORIGINAL_INVOICE_DATE;    -- �I���W�i�������� 2004/05/22 Add
        OUT_ORIGINAL_INVOICE_DATE       := WK_ORIGINAL_INVOICE_DATE;    -- �I���W�i�������� 2004/05/22 Add
        OUT_WAYBILL_TYPE                := WK_WAYBILL_TYPE;             -- WAYBILL_TYPE     2004/07/31 Add
        OUT_RETURN_CD                   := 0;   -- ��������
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 11;
            PFGA3910.TRACE_LOG( 'E', 'SHIPPER_ID�E�S���҃R�[�h�擾�����G���[' ||
                                 '  SQLCODE=' || TO_CHAR(SQLCODE) );
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- TFJ201 AR�f�[�^�擾�����iINVOICE_TX_ID���)
--==========================================
PROCEDURE GET_TFJ201_INV(
    IN_INV_TX_ID                    IN  TFJ201.INVOICE_TX_ID%TYPE,               -- INVOICE_TX_ID
    IN_GYMDTM                       IN  TFJ201.DGYMDTM%TYPE,                     -- �Ɩ����t
    OUT_SHIPPER_ID                  OUT TFJ201.SHIPPER_ID%TYPE,                  -- SHIPER_ID
    OUT_AR_RESPONSIBLE_PERSON_ID    OUT TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE,    -- �̔��S���Һ���
    OUT_SA_RESPONSIBLE_OFFICE_ID    OUT TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE, -- �̔��ӏ�
    OUT_GL_GROUP                    OUT TFJ201.GL_GROUP%TYPE,                    -- ����             2004/07/11 Add
    OUT_CUSTOMER_NUMBER             OUT TFJ201.CUSTOMER_NUMBER%TYPE,             -- �ڋq�R�[�h       2004/05/22 Add
    OUT_INVOICE_DATE                OUT TFJ201.INVOICE_DATE%TYPE,                -- ������           2004/05/22 Add
    OUT_ORIGINAL_INVOICE_DATE       OUT TFJ201.ORIGINAL_INVOICE_DATE%TYPE,       -- �I���W�i�������� 2004/05/22 Add
    OUT_WAYBILL_TYPE                OUT TFJ201.WAYBILL_TYPE%TYPE,                -- WAYBILL_TYPE     2004/07/31 Add
    OUT_RETURN_CD                   OUT NUMBER                                   -- ��������
 )
IS
    WK_SHIPPER_ID                   TFJ201.SHIPPER_ID%TYPE;
    WK_AR_RESPONSIBLE_PERSON_ID     TFJ201.AR_RESPONSIBLE_PERSON_ID%TYPE;
    WK_SA_RESPONSIBLE_OFFICE_ID     TFJ201.SALES_RESPONSIBLE_OFFICE_ID%TYPE;
    WK_GL_GROUP                     TFJ201.GL_GROUP%TYPE;                     -- 2004/07/11 Add
    WK_CUSTOMER_NUMBER              TFJ201.CUSTOMER_NUMBER%TYPE;              -- 2004/05/22 Add
    WK_INVOICE_DATE                 TFJ201.INVOICE_DATE%TYPE;                 -- 2004/05/22 Add
    WK_ORIGINAL_INVOICE_DATE        TFJ201.ORIGINAL_INVOICE_DATE%TYPE;        -- 2004/05/22 Add
    WK_WAYBILL_TYPE                 TFJ201.WAYBILL_TYPE%TYPE;                 -- 2004/07/31 Add
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2010', 'GET_SHP_ID_CD' );

    -- �߂�l���������i�o�̓f�t�H���g�Z�b�g�A��������-1�j
    OUT_SA_RESPONSIBLE_OFFICE_ID    := '!'; -- �̔��ӏ�
    OUT_GL_GROUP                    := '!'; -- ����             2004/07/11 Add
    OUT_AR_RESPONSIBLE_PERSON_ID    := '!'; -- �̔��S���Һ���
    OUT_SHIPPER_ID                  := '!'; -- SHIPER_ID
    OUT_RETURN_CD                   := -2;  -- ��������

    -- HWB_TX_ID�����UASIF�f�[�^�̍ŐVAR(�����j���R�[�h��Ǎ��ށB
    -- ���R�[�h�����݂��鎞�ASHPPER_ID�A�̔��S���҃R�[�h�A�̔��ӏ��A�������ʂP���Z�b�g���߂�B
    BEGIN
        SELECT  A.SHIPPER_ID, A.AR_RESPONSIBLE_PERSON_ID, A.SALES_RESPONSIBLE_OFFICE_ID,
                A.GL_GROUP,A.WAYBILL_TYPE,
                A.CUSTOMER_NUMBER, A.INVOICE_DATE, A.ORIGINAL_INVOICE_DATE
          INTO  WK_SHIPPER_ID ,WK_AR_RESPONSIBLE_PERSON_ID, WK_SA_RESPONSIBLE_OFFICE_ID,
                WK_GL_GROUP,WK_WAYBILL_TYPE,
                WK_CUSTOMER_NUMBER, WK_INVOICE_DATE, WK_ORIGINAL_INVOICE_DATE
          FROM  TFJ201 A
        WHERE  RECORD_IND = 'AR'
          AND  RECORD_ID  = ( SELECT  MAX( B.RECORD_ID )
                                    FROM  TFJ201 B
                                   WHERE  B.RECORD_IND =  'AR'
                                     AND  B.DGYMDTM   <= IN_GYMDTM
                                     AND  B.INVOICE_TX_ID  = IN_INV_TX_ID );
    EXCEPTION
          WHEN NO_DATA_FOUND THEN
              OUT_RETURN_CD := -1;    -- AR(�����j���R�[�hNot Found
          WHEN OTHERS THEN
              RAISE ;
    END ;
    IF OUT_RETURN_CD != -1 THEN
        OUT_SHIPPER_ID                  := WK_SHIPPER_ID;               -- SHIPER_ID
        OUT_SA_RESPONSIBLE_OFFICE_ID    := WK_SA_RESPONSIBLE_OFFICE_ID; -- �̔��ӏ�
        OUT_GL_GROUP                    := WK_GL_GROUP;                 -- ����             2004/07/11 Add
        OUT_AR_RESPONSIBLE_PERSON_ID    := WK_AR_RESPONSIBLE_PERSON_ID; -- �̔��S���Һ���
        OUT_CUSTOMER_NUMBER             := WK_CUSTOMER_NUMBER;          -- �ڋq�R�[�h       2004/05/22 Add
        OUT_INVOICE_DATE                := WK_INVOICE_DATE;             -- ������           2004/05/22 Add
        OUT_ORIGINAL_INVOICE_DATE       := WK_ORIGINAL_INVOICE_DATE;    -- �I���W�i�������� 2004/05/22 Add
        OUT_WAYBILL_TYPE                := WK_WAYBILL_TYPE;             -- WAYBILL_TYPE     2004/07/31 Add
        OUT_RETURN_CD                   := 0;   -- ��������
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 11;
            PFGA3910.TRACE_LOG( 'E', 'SHIPPER_ID�E�S���҃R�[�h�擾�����G���[' ||
                                 '  SQLCODE=' || TO_CHAR(SQLCODE) );
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- UASIF�f�[�^INSERT����
-- UASIF�f�[�^ں���ܰ�(REC_TFJ201)�ɾ�čς�
--==========================================
PROCEDURE INS_TFJ201
IS

    WK_GYMDTM                       TFJ201.DGYMDTM%TYPE;
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2010', 'INS_TFJ201' );

    -- �Ɩ����t�Z�b�g�����ύX 2004.05.17
    -- ACCOUNTING_DATE��INVOICE_DATE�̑傫������I��
    IF REC_TFJ201.INVOICE_DATE IS NOT NULL THEN
        IF TO_CHAR(REC_TFJ201.ACCOUNTING_DATE,'YYYYMMDD') > TO_CHAR(REC_TFJ201.INVOICE_DATE,'YYYYMMDD') THEN
            WK_GYMDTM := REC_TFJ201.ACCOUNTING_DATE;
        ELSE
            WK_GYMDTM := REC_TFJ201.INVOICE_DATE;
        END IF;
    ELSE
        WK_GYMDTM := REC_TFJ201.ACCOUNTING_DATE;
    END IF;
    -- WK_GYMDTM > �Ɩ����t�̎��i�������j --> �Ɩ����t��WK_GYMDTM���Z�b�g
    IF TO_CHAR(WK_GYMDTM,'YYYYMMDD') > TO_CHAR(REC_TFJ201.DGYMDTM,'YYYYMMDD') THEN
        REC_TFJ201.DGYMDTM := WK_GYMDTM;
        REC201FUT_CNT := REC201FUT_CNT + 1;
    END IF;

    INSERT INTO TFJ201
          ( RECORD_IND,
            RECORD_ID,
            COMPANY_ID,
            IMPORT_EXPORT_IND,
            TRANSPORT_MODE,
            DGYMDTM,
            ACCOUNTING_DATE,
            INVOICE_DATE,
            ORIGINAL_INVOICE_DATE,
            SALES_RESPONSIBLE_OFFICE_ID,
            GL_GROUP,
            VENDOR_NO,
            AR_RESPONSIBLE_PERSON_ID,
            CUSTOMER_NUMBER,
            SHIPPER_ID,
            WAYBILL_TYPE,
            HWB_NO,
            MWB_NO,
            CONSOL_NO,
            CORRECTION_NO,
            INVOICE_TYPE,
            INVOICE_NO,
            PIPELINE_TX_ID,
            HWB_TX_ID,
            MWB_TX_ID,
            CONSOL_TX_ID,
            INVOICE_TX_ID,
            PPC_IND,
            CHARGE_CODE,
            LINE_DESCRIPTION,
            CURRENCY_CODE,
            CONVERSION_RATE,
            LINE_AMOUNT,
            LOCAL_INVOICE_AMT,
            LINE_TYPE,
-- 2004.10.27
            GUI_NUMBER,
            GUI_DATE,
-- 2004.06.24 CHARGE_NFD_FLG�Z�b�g�ǉ�
            CHARGE_NFD_FLG,
--2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�
            LINE_NUMBER,
            LINKTO_INVOICE_NUMBER,
            LINKTO_LINE_NUMBER,
            AGENT_ROLE,
            BILLTO_ADDRESS_NO )
    VALUES( REC_TFJ201.RECORD_IND,
            REC_TFJ201.RECORD_ID,
            REC_TFJ201.COMPANY_ID,
            REC_TFJ201.IMPORT_EXPORT_IND,
            REC_TFJ201.TRANSPORT_MODE,
            REC_TFJ201.DGYMDTM,
            REC_TFJ201.ACCOUNTING_DATE,
            REC_TFJ201.INVOICE_DATE,
            REC_TFJ201.ORIGINAL_INVOICE_DATE,
            REC_TFJ201.SALES_RESPONSIBLE_OFFICE_ID,
            REC_TFJ201.GL_GROUP,
            REC_TFJ201.VENDOR_NO,
            REC_TFJ201.AR_RESPONSIBLE_PERSON_ID,
            REC_TFJ201.CUSTOMER_NUMBER,
            REC_TFJ201.SHIPPER_ID,
            REC_TFJ201.WAYBILL_TYPE,
            REC_TFJ201.HWB_NO,
            REC_TFJ201.MWB_NO,
            REC_TFJ201.CONSOL_NO,
            REC_TFJ201.CORRECTION_NO,
            REC_TFJ201.INVOICE_TYPE,
            REC_TFJ201.INVOICE_NO,
            REC_TFJ201.PIPELINE_TX_ID,
            REC_TFJ201.HWB_TX_ID,
            REC_TFJ201.MWB_TX_ID,
            REC_TFJ201.CONSOL_TX_ID,
            REC_TFJ201.INVOICE_TX_ID,
            REC_TFJ201.PPC_IND,
            REC_TFJ201.CHARGE_CODE,
            REC_TFJ201.LINE_DESCRIPTION,
            REC_TFJ201.CURRENCY_CODE,
            REC_TFJ201.CONVERSION_RATE,
            REC_TFJ201.LINE_AMOUNT,
            REC_TFJ201.LOCAL_INVOICE_AMT,
            REC_TFJ201.LINE_TYPE,
-- 2004.10.27
            REC_TFJ201.GUI_NUMBER,
            REC_TFJ201.GUI_DATE,
-- 2004.06.24 CHARGE_NFD_FLG�Z�b�g�ǉ�
            REC_TFJ201.CHARGE_NFD_FLG,
--2005.11.12 LINKTO�Ή� And AGENT_ROLE�Ή�
            REC_TFJ201.LINE_NUMBER,
            REC_TFJ201.LINKTO_INVOICE_NUMBER,
            REC_TFJ201.LINKTO_LINE_NUMBER,
            REC_TFJ201.AGENT_ROLE,
            REC_TFJ201.BILLTO_ADDRESS_NO );

    REC201_CNT := REC201_CNT + 1;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 12;
            PFGA3910.TRACE_LOG( 'E', 'TFJ201 Insert�G���['
                            || ' RECORD_IND =' || REC_TFJ201.RECORD_IND
                            || ' RECORD_ID  =' || REC_TFJ201.RECORD_ID
                            || ' SQLCODE=' || TO_CHAR(SQLCODE) );
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

--==========================================
-- UASIF����INSERT����
-- UASIF����ں���ܰ�(REC_TFJ202)�ɾ�čς�
--==========================================
PROCEDURE INS_TFJ202
IS

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA2010', 'INS_TFJ202' );

    INSERT INTO TFJ202
          ( DGYMDTM,
            COMPANY_ID,
            IMPORT_EXPORT_IND,
            TRANSPORT_MODE,
            RECORD_IND,
            RECORD_ID,
            NREC_CNT,
            NPICK_OUT,
            -- 2005.04.17 Add
            INTERFACE_QUEUE_LAST_DATE,
            -- 2005.10.23 Add
            HOST_ID,
            HOST_RECORD_ID )
    VALUES( REC_TFJ202.DGYMDTM,
            REC_TFJ202.COMPANY_ID,
            REC_TFJ202.IMPORT_EXPORT_IND,
            REC_TFJ202.TRANSPORT_MODE,
            REC_TFJ202.RECORD_IND,
            REC_TFJ202.RECORD_ID,
            REC_TFJ202.NREC_CNT,
            REC_TFJ202.NPICK_OUT,
            -- 2005.04.17 Add
            REC_TFJ202.INTERFACE_QUEUE_LAST_DATE,
            -- 2005.10.23 Add
            REC_TFJ202.HOST_ID,
            REC_TFJ202.HOST_RECORD_ID );

    REC202_CNT := REC202_CNT + 1;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 12;
            PFGA3910.TRACE_LOG( 'E', 'TFJ202 Insert�G���[' ||
                                 '  SQLCODE=' || TO_CHAR(SQLCODE) );
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

END PFGA2010 ;