CREATE OR REPLACE PACKAGE PFGA3320 AS
--********************************************************************
--�y �ڋq�ʕ��ʎ��э쐬 �z
--  �߯����
--  PFGA3320
--  �Ăяo���K�w
--  CRE_BUTSURYOU_JISSEKI                      �ڋq�ʕ��ʎ��т��쐬
--    +-- SUM_KASYO_BUTSURYOU                  �ڋq�ʕ��ʎ��т�݌v
--          +-- SEL_TFJ332                     �ڋq�ʕ��ʎ��т�����
--          +-- ADD_BUTSURYOU                  ���ʎ��тɉ��Z����
--          +-- INS_TFJ332                     �ڋq�ʕ��ʎ��т�V�K�쐬
--********************************************************************

--************************************************
--�y �ڋq�ʕ��ʎ��э쐬 �z�߯���ގd�l��
--     PFGA3320
--************************************************

--�y ܰ��ϐ� �z

    -- �װ�����ϐ�
    WK_ERROR                NUMBER;

    -- ���͌������ėpܰ��ϐ�
    WK_TFJ301_IN_CNT        NUMBER;

    -- �o�^�������ėpܰ��ϐ�
    WK_FWD_OUT_CNT          NUMBER;
    WK_CLE_OUT_CNT          NUMBER;

    -- �o�^�������ėpܰ��ϐ�
    WK_TFJ332_INS_CNT       NUMBER;
    WK_TFJ332_UPD_CNT       NUMBER;

    -- ���ʏ��
    TYPE WK_BASE_RECTYPE IS RECORD(
        NUM_PIECES                     TFJ301.NUM_PIECES%TYPE,
        CHARGEABLE_WEIGHT              TFJ301.CHARGEABLE_WEIGHT%TYPE,
        CHARGEABLE_WEIGHT_UOM_CODE     TFJ301.CHARGEABLE_WEIGHT_UOM_CODE%TYPE,
        TOTAL_ACTUAL_WEIGHT            TFJ301.TOTAL_ACTUAL_WEIGHT%TYPE,
        ACTUAL_WEIGHT_UOM_CODE         TFJ301.ACTUAL_WEIGHT_UOM_CODE%TYPE,
        TOTAL_VOLUME                   TFJ301.TOTAL_VOLUME%TYPE,
        VOLUME_UOM_CODE                TFJ301.VOLUME_UOM_CODE%TYPE,
        TOTAL_VOLUME_WEIGHT            TFJ301.TOTAL_VOLUME_WEIGHT%TYPE,
        VOLUME_WEIGHT_UOM_CODE         TFJ301.VOLUME_WEIGHT_UOM_CODE%TYPE,
        CONTAINER_20FT                 TFJ301.CONTAINER_20FT%TYPE,
        CONTAINER_40FT                 TFJ301.CONTAINER_20FT%TYPE,
        CONTAINER_ETC                  TFJ301.CONTAINER_ETC%TYPE
    );

    --�y PROCEDURE / FUNCTION �z

    -- �ڋq�ʕ��ʎ��т��쐬
    PROCEDURE CRE_BUTSURYOU_JISSEKI(
        IN_DATE     IN DATE );                -- �Ɩ����t(yyyymmdd)

    -- �ڋq�ʕ��ʎ��т�݌v
    PROCEDURE SUM_KASYO_BUTSURYOU(
        IN_DATE         IN      DATE,                    -- �Ɩ����t(yyyymmdd)
        IN_EWT_TAG      IN      TFJ332.EWT_TAG%TYPE,     -- ����Tag
        IN_TFJ301       IN      TFJ301%ROWTYPE );        -- ���і���

    -- �ڋq�ʕ��ʎ��т�����
    FUNCTION SEL_TFJ332(
        IN_DGYMDTM        IN     DATE,
        IN_EIM_EX_IND     IN     TFJ332.EIM_EX_IND%TYPE,
        IN_ETRANS_MODE    IN     TFJ332.ETRANS_MODE%TYPE,
        IN_EWB_TYPE       IN     TFJ332.EWB_TYPE%TYPE,
        IN_DKJODTM        IN     TFJ332.DKJODTM%TYPE,
        IN_ECOMPANY_ID    IN     TFJ332.ECOMPANY_ID%TYPE,
        IN_ETERMINAL_ID   IN     TFJ332.ETERMINAL_ID%TYPE,
        IN_EDEPARTMENT_ID IN     TFJ332.EDEPARTMENT_ID%TYPE,
        IN_EHBI_TNTCD     IN     TFJ332.EHBI_TNTCD%TYPE,
        IN_ECNORCD        IN     TFJ332.ECNORCD%TYPE,
        IN_EWT_TAG        IN     TFJ332.EWT_TAG%TYPE,
        OUT_TFJ332        IN OUT TFJ332%ROWTYPE )
    RETURN NUMBER;

    -- ���ʎ��тɉ��Z����
    PROCEDURE ADD_BUTSURYOU(
        IN_TFJ301       IN      TFJ301%ROWTYPE,
        OUT_TFJ332      IN OUT  TFJ332%ROWTYPE );

    -- �ڋq�ʕ��ʎ��т�V�K�쐬
    PROCEDURE INS_TFJ332(
        IN_TFJ332   IN  TFJ332%ROWTYPE );         -- �ڋq�ʕ��ʎ���

END PFGA3320;
CREATE OR REPLACE PACKAGE BODY PFGA3320 AS
--************************************************
--�y �ڋq�ʕ��ʎ��э쐬 �z�߯���ޖ{�̕�
--     PFGA3320
--
-- ���і��ׂ���w��̃f�[�^�敪�E�Ɩ����t�̃f�[�^
-- �𒊏o���A�ڋq�ʕ��ʎ��т��쐬����B
--************************************************

--================================================
-- �ڋq�ʕ��ʎ��т��쐬
-- �C��  --2005.04.17 STATUS=CNF�̎����ʎ��ю擾�B
--================================================
PROCEDURE CRE_BUTSURYOU_JISSEKI(
    IN_DATE     IN DATE                 -- �Ɩ����t(yyyymmdd)
) IS
    -- ���і��ג��o�J�[�\��
    CURSOR CUR_MEISAI( WK_DATE     DATE ) IS
        SELECT *
          FROM TFJ301
          WHERE EDATKBN = '1'
            AND DGYMDTM = WK_DATE
          ORDER BY PIPELINE_TX_ID;

    -- KEY
    ER_PIPELINE_TX_ID      TFJ301.PIPELINE_TX_ID%TYPE     := 0;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3320', 'CRE_BUTSURYOU_JISSEKI' );
    PFGA3910.TRACE_LOG( 'I', '�Ɩ����t=' || IN_DATE );

    WK_ERROR              := 0;
    WK_TFJ301_IN_CNT      := 0;
    WK_FWD_OUT_CNT        := 0;
    WK_CLE_OUT_CNT        := 0;
    WK_TFJ332_INS_CNT     := 0;
    WK_TFJ332_UPD_CNT     := 0;

    FOR WK_REC IN CUR_MEISAI( IN_DATE ) LOOP

        WK_TFJ301_IN_CNT     := WK_TFJ301_IN_CNT + 1;
        ER_PIPELINE_TX_ID    := WK_REC.PIPELINE_TX_ID;

        IF (WK_REC.EIM_EX_IND = 'E' AND NVL(WK_REC.EXPORT_TX_STATUS,'CNF') = 'CNF') OR
           (WK_REC.EIM_EX_IND = 'I' AND NVL(WK_REC.IMPORT_TX_STATUS,'ICF') = 'ICF') THEN
            -- FWD���Б��Ћ敪 �����Ђ̏ꍇ
            IF WK_REC.EFWD_JTKBN = '1' THEN
                -- �ӏ��ʕ��ʎ��т�݌v�i�a�k���ʎ��сj
                SUM_KASYO_BUTSURYOU( IN_DATE, 'FWD', WK_REC );
                WK_FWD_OUT_CNT := WK_FWD_OUT_CNT + 1;
            END IF;

            -- �ʊ֎��Б��Ћ敪 �����Ђ̏ꍇ
            IF WK_REC.ETKN_JTKBN = '1' THEN
               -- �ӏ��ʕ��ʎ��т�݌v�i�ʊ֕��ʎ��сj
               SUM_KASYO_BUTSURYOU( IN_DATE, 'CLE', WK_REC );
               WK_CLE_OUT_CNT := WK_CLE_OUT_CNT + 1;
            END IF;
        END IF;

    END LOOP;

    PFGA3910.TRACE_LOG( 'I', '���і��� ���͌��� = ' || WK_TFJ301_IN_CNT );
    PFGA3910.TRACE_LOG( 'I', '���ʎ��� FWD����  = ' || WK_FWD_OUT_CNT );
    PFGA3910.TRACE_LOG( 'I', '���ʎ��� CLE����  = ' || WK_CLE_OUT_CNT );
    PFGA3910.TRACE_LOG( 'I', '���ʎ��� �V�K���� = ' || WK_TFJ332_INS_CNT );
    PFGA3910.TRACE_LOG( 'I', '���ʎ��� �X�V���� = ' || WK_TFJ332_UPD_CNT );
    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 1;
            PFGA3910.TRACE_LOG('E','TFJ301: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_LOG( 'E', '�G���[�f�[�^'
                            || ' PIPELINE_TX_ID = '   || ER_PIPELINE_TX_ID );
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �ڋq�ʕ��ʎ��т�݌v
--================================================
PROCEDURE SUM_KASYO_BUTSURYOU(
    IN_DATE         IN      DATE,                      -- �Ɩ����t(yyyymmdd)
    IN_EWT_TAG      IN      TFJ332.EWT_TAG%TYPE,       -- ����Tag
    IN_TFJ301       IN      TFJ301%ROWTYPE )           -- ���і���
IS
    WK_EWB_TYPE     TFJ322.EWB_TYPE%TYPE;
    WK_RC           NUMBER;
    WK_TFJ332       TFJ332%ROWTYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3320', 'SUM_KASYO_BUTSURYOU' );

    -- �Ɩ����ނR(C:Consolidation/D:Direct)
    IF IN_TFJ301.PIPELINE_REF_TYPE = 'HD' THEN
        WK_EWB_TYPE   := 'D';
    ELSE
        WK_EWB_TYPE   := 'C';
    END IF;

    -- �ڋq�ʕ��ʎ��т�����
    WK_RC := SEL_TFJ332( IN_DATE,
                         IN_TFJ301.EIM_EX_IND,
                         IN_TFJ301.ETRANS_MODE,
                         WK_EWB_TYPE,
                         IN_TFJ301.DKJODTM,
                         IN_TFJ301.ECOMPANY_ID,
                         IN_TFJ301.ETERMINAL_ID,
                         IN_TFJ301.EDEPARTMENT_ID,
                         IN_TFJ301.EHBI_TNTCD,
                         IN_TFJ301.ECNORCD,
                         IN_EWT_TAG,
                         WK_TFJ332 );

    IF WK_RC = 0 THEN
        -- �ڋq�ʕ��ʎ��т�ҏW
        -- ����
        WK_TFJ332.ETRKDTM     := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
        WK_TFJ332.EUPDDTM     := TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS');
        WK_TFJ332.DHNEDTM     := SYSDATE;
        WK_TFJ332.EUPD_OFCCD  := '!';
        WK_TFJ332.EUPD_TNTCD  := '!';

        -- �j�d�x
        WK_TFJ332.DGYMDTM               := IN_DATE;
        WK_TFJ332.EIM_EX_IND            := IN_TFJ301.EIM_EX_IND;
        WK_TFJ332.ETRANS_MODE           := IN_TFJ301.ETRANS_MODE;
        WK_TFJ332.EWB_TYPE              := WK_EWB_TYPE;
        WK_TFJ332.DKJODTM               := IN_TFJ301.DKJODTM;
        WK_TFJ332.ECOMPANY_ID           := IN_TFJ301.ECOMPANY_ID;
        WK_TFJ332.ETERMINAL_ID          := IN_TFJ301.ETERMINAL_ID;
        WK_TFJ332.EDEPARTMENT_ID        := IN_TFJ301.EDEPARTMENT_ID;
        WK_TFJ332.EHBI_TNTCD            := IN_TFJ301.EHBI_TNTCD;
        WK_TFJ332.ECNORCD               := IN_TFJ301.ECNORCD;
        WK_TFJ332.EWT_TAG               := IN_EWT_TAG;
        -- �R�[�h
        WK_TFJ332.EOYA_ECNORCD          := IN_TFJ301.EOYA_ECNORCD;
        -- ����
        WK_TFJ332.EOYA_ECNORNM          := IN_TFJ301.EOYA_ECNORNM;
        WK_TFJ332.JOYA_ECNORNM          := IN_TFJ301.JOYA_ECNORNM;
        WK_TFJ332.ECNORNM               := IN_TFJ301.ECNORNM;
        WK_TFJ332.JCNORNM               := IN_TFJ301.JCNORNM;
        WK_TFJ332.ETERMNM               := IN_TFJ301.ETERMNM;
        WK_TFJ332.JTERMNM               := IN_TFJ301.JTERMNM;
        WK_TFJ332.EDEPARTNM             := IN_TFJ301.EDEPARTNM;
        WK_TFJ332.JDEPARTNM             := IN_TFJ301.JDEPARTNM;
        WK_TFJ332.ETNTNM                := IN_TFJ301.ETNTNM;
        WK_TFJ332.JTNTNM                := IN_TFJ301.JTNTNM;
        -- CY���    FCL
        WK_TFJ332.NHSI_CY_HONSU_GKI     := 0;
        WK_TFJ332.NSYSI_CY_HONSU_GKI    := 0;
        WK_TFJ332.NHSI_CY_CNT           := 0;
        WK_TFJ332.NSYSI_CY_CNT          := 0;
        WK_TFJ332.NHSI_CY_PCS           := 0;
        WK_TFJ332.NSYSI_CY_PCS          := 0;
        WK_TFJ332.NHSI_CY_WT            := 0;
        WK_TFJ332.NSYSI_CY_WT           := 0;
        WK_TFJ332.NHSI_CY_M3            := 0;
        WK_TFJ332.NSYSI_CY_M3           := 0;
        WK_TFJ332.NHSI_CY_RT            := 0;
        WK_TFJ332.NSYSI_CY_RT           := 0;
        -- CFS���   LCL KWE_BOX
        WK_TFJ332.NHSI_CFS_CNT          := 0;
        WK_TFJ332.NSYSI_CFS_CNT         := 0;
        WK_TFJ332.NHSI_CFS_PCS          := 0;
        WK_TFJ332.NSYSI_CFS_PCS         := 0;
        WK_TFJ332.NHSI_CFS_WT           := 0;
        WK_TFJ332.NSYSI_CFS_WT          := 0;
        WK_TFJ332.NHSI_CFS_M3           := 0;
        WK_TFJ332.NSYSI_CFS_M3          := 0;
        WK_TFJ332.NHSI_CFS_RT           := 0;
        WK_TFJ332.NSYSI_CFS_RT          := 0;
        -- CFS���   LCL CO-Load
        WK_TFJ332.NHSI_CLD_CNT          := 0;
        WK_TFJ332.NSYSI_CLD_CNT         := 0;
        WK_TFJ332.NHSI_CLD_PCS          := 0;
        WK_TFJ332.NSYSI_CLD_PCS         := 0;
        WK_TFJ332.NHSI_CLD_WT           := 0;
        WK_TFJ332.NSYSI_CLD_WT          := 0;
        WK_TFJ332.NHSI_CLD_M3           := 0;
        WK_TFJ332.NSYSI_CLD_M3          := 0;
        WK_TFJ332.NHSI_CLD_RT           := 0;
        WK_TFJ332.NSYSI_CLD_RT          := 0;
        -- ����
        WK_TFJ332.NHSI_CNT              := 0;
        WK_TFJ332.NSYSI_CNT             := 0;
        -- �ݕ���
        WK_TFJ332.NHSI_CRG_PCS          := 0;
        WK_TFJ332.NSYSI_CRG_PCS         := 0;
        WK_TFJ332.NHSI_20FT_HONSU       := 0;
        WK_TFJ332.NSYSI_20FT_HONSU      := 0;
        WK_TFJ332.NHSI_40FT_HONSU       := 0;
        WK_TFJ332.NSYSI_40FT_HONSU      := 0;
        WK_TFJ332.NHSI_ETC_HONSU        := 0;
        WK_TFJ332.NSYSI_ETC_HONSU       := 0;
        -- �ݕ��d�ʁE�e��
        WK_TFJ332.NHSI_CRG_ACTWT        := 0;
        WK_TFJ332.NSYSI_CRG_ACTWT       := 0;
        WK_TFJ332.NHSI_CRG_CHGWT        := 0;
        WK_TFJ332.NSYSI_CRG_CHGWT       := 0;
        WK_TFJ332.NHSI_CRG_M3           := 0;
        WK_TFJ332.NSYSI_CRG_M3          := 0;

        -- ���ʎ��тɉ��Z����
        ADD_BUTSURYOU( IN_TFJ301, WK_TFJ332 );

        -- �ڋq�ʕ��ʎ��т�V�K�쐬
        INS_TFJ332( WK_TFJ332 );

        WK_TFJ332_INS_CNT := WK_TFJ332_INS_CNT + 1;
    ELSE
        -- ���ʎ��тɉ��Z����
        ADD_BUTSURYOU( IN_TFJ301, WK_TFJ332 );

        UPDATE TFJ332
          SET EUPDDTM         = TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),
              DHNEDTM         = SYSDATE,
              EUPD_OFCCD      = '!',
              EUPD_TNTCD      = '!',
              -- CY���    FCL
              NHSI_CY_HONSU_GKI     = WK_TFJ332.NHSI_CY_HONSU_GKI,
              NSYSI_CY_HONSU_GKI    = WK_TFJ332.NSYSI_CY_HONSU_GKI,
              NHSI_CY_CNT           = WK_TFJ332.NHSI_CY_CNT,
              NSYSI_CY_CNT          = WK_TFJ332.NSYSI_CY_CNT,
              NHSI_CY_PCS           = WK_TFJ332.NHSI_CY_PCS,
              NSYSI_CY_PCS          = WK_TFJ332.NSYSI_CY_PCS,
              NHSI_CY_WT            = WK_TFJ332.NHSI_CY_WT,
              NSYSI_CY_WT           = WK_TFJ332.NSYSI_CY_WT,
              NHSI_CY_M3            = WK_TFJ332.NHSI_CY_M3,
              NSYSI_CY_M3           = WK_TFJ332.NSYSI_CY_M3,
              NHSI_CY_RT            = WK_TFJ332.NHSI_CY_RT,
              NSYSI_CY_RT           = WK_TFJ332.NSYSI_CY_RT,
              -- CFS���   LCL KWE_BOX
              NHSI_CFS_CNT          = WK_TFJ332.NHSI_CFS_CNT,
              NSYSI_CFS_CNT         = WK_TFJ332.NSYSI_CFS_CNT,
              NHSI_CFS_PCS          = WK_TFJ332.NHSI_CFS_PCS,
              NSYSI_CFS_PCS         = WK_TFJ332.NSYSI_CFS_PCS,
              NHSI_CFS_WT           = WK_TFJ332.NHSI_CFS_WT,
              NSYSI_CFS_WT          = WK_TFJ332.NSYSI_CFS_WT,
              NHSI_CFS_M3           = WK_TFJ332.NHSI_CFS_M3,
              NSYSI_CFS_M3          = WK_TFJ332.NSYSI_CFS_M3,
              NHSI_CFS_RT           = WK_TFJ332.NHSI_CFS_RT,
              NSYSI_CFS_RT          = WK_TFJ332.NSYSI_CFS_RT,
              -- CFS���   LCL  CO-Load
              NHSI_CLD_CNT          = WK_TFJ332.NHSI_CLD_CNT,
              NSYSI_CLD_CNT         = WK_TFJ332.NSYSI_CLD_CNT,
              NHSI_CLD_PCS          = WK_TFJ332.NHSI_CLD_PCS,
              NSYSI_CLD_PCS         = WK_TFJ332.NSYSI_CLD_PCS,
              NHSI_CLD_WT           = WK_TFJ332.NHSI_CLD_WT,
              NSYSI_CLD_WT          = WK_TFJ332.NSYSI_CLD_WT,
              NHSI_CLD_M3           = WK_TFJ332.NHSI_CLD_M3,
              NSYSI_CLD_M3          = WK_TFJ332.NSYSI_CLD_M3,
              NHSI_CLD_RT           = WK_TFJ332.NHSI_CLD_RT,
              NSYSI_CLD_RT          = WK_TFJ332.NSYSI_CLD_RT,
              -- ����
              NHSI_CNT              = WK_TFJ332.NHSI_CNT,
              NSYSI_CNT             = WK_TFJ332.NSYSI_CNT,
              -- �ݕ���
              NHSI_CRG_PCS          = WK_TFJ332.NHSI_CRG_PCS,
              NSYSI_CRG_PCS         = WK_TFJ332.NSYSI_CRG_PCS,
              NHSI_20FT_HONSU       = WK_TFJ332.NHSI_20FT_HONSU,
              NSYSI_20FT_HONSU      = WK_TFJ332.NSYSI_20FT_HONSU,
              NHSI_40FT_HONSU       = WK_TFJ332.NHSI_40FT_HONSU,
              NSYSI_40FT_HONSU      = WK_TFJ332.NSYSI_40FT_HONSU,
              NHSI_ETC_HONSU        = WK_TFJ332.NHSI_ETC_HONSU,
              NSYSI_ETC_HONSU       = WK_TFJ332.NSYSI_ETC_HONSU,
              -- �ݕ��d�ʁE�e��
              NHSI_CRG_ACTWT        = WK_TFJ332.NHSI_CRG_ACTWT,
              NSYSI_CRG_ACTWT       = WK_TFJ332.NSYSI_CRG_ACTWT,
              NHSI_CRG_CHGWT        = WK_TFJ332.NHSI_CRG_CHGWT,
              NSYSI_CRG_CHGWT       = WK_TFJ332.NSYSI_CRG_CHGWT,
              NHSI_CRG_M3           = WK_TFJ332.NHSI_CRG_M3,
              NSYSI_CRG_M3          = WK_TFJ332.NSYSI_CRG_M3
          WHERE DGYMDTM        = WK_TFJ332.DGYMDTM
            AND EIM_EX_IND     = WK_TFJ332.EIM_EX_IND
            AND ETRANS_MODE    = WK_TFJ332.ETRANS_MODE
            AND EWB_TYPE       = WK_TFJ332.EWB_TYPE
            AND DKJODTM        = WK_TFJ332.DKJODTM
            AND ECOMPANY_ID    = WK_TFJ332.ECOMPANY_ID
            AND ETERMINAL_ID   = WK_TFJ332.ETERMINAL_ID
            AND EDEPARTMENT_ID = WK_TFJ332.EDEPARTMENT_ID
            AND EHBI_TNTCD     = WK_TFJ332.EHBI_TNTCD
            AND ECNORCD        = WK_TFJ332.ECNORCD
            AND EWT_TAG        = WK_TFJ332.EWT_TAG;

        WK_TFJ332_UPD_CNT := WK_TFJ332_UPD_CNT + 1;
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 2;
            PFGA3910.TRACE_LOG('E','TFJ332: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �ڋq�ʕ��ʎ��т�����
--================================================
FUNCTION SEL_TFJ332(
    IN_DGYMDTM        IN     DATE,
    IN_EIM_EX_IND     IN     TFJ332.EIM_EX_IND%TYPE,
    IN_ETRANS_MODE    IN     TFJ332.ETRANS_MODE%TYPE,
    IN_EWB_TYPE       IN     TFJ332.EWB_TYPE%TYPE,
    IN_DKJODTM        IN     TFJ332.DKJODTM%TYPE,
    IN_ECOMPANY_ID    IN     TFJ332.ECOMPANY_ID%TYPE,
    IN_ETERMINAL_ID   IN     TFJ332.ETERMINAL_ID%TYPE,
    IN_EDEPARTMENT_ID IN     TFJ332.EDEPARTMENT_ID%TYPE,
    IN_EHBI_TNTCD     IN     TFJ332.EHBI_TNTCD%TYPE,
    IN_ECNORCD        IN     TFJ332.ECNORCD%TYPE,
    IN_EWT_TAG        IN     TFJ332.EWT_TAG%TYPE,
    OUT_TFJ332        IN OUT TFJ332%ROWTYPE )
    RETURN NUMBER
IS
    -- �ڋq�ʕ��ʎ��ђ��o�J�[�\��
    CURSOR CUR_TFJ332( KEY_DGYMDTM        IN     DATE,
                       KEY_EIM_EX_IND     IN     TFJ332.EIM_EX_IND%TYPE,
                       KEY_ETRANS_MODE    IN     TFJ332.ETRANS_MODE%TYPE,
                       KEY_EWB_TYPE       IN     TFJ332.EWB_TYPE%TYPE,
                       KEY_DKJODTM        IN     TFJ332.DKJODTM%TYPE,
                       KEY_ECOMPANY_ID    IN     TFJ332.ECOMPANY_ID%TYPE,
                       KEY_ETERMINAL_ID   IN     TFJ332.ETERMINAL_ID%TYPE,
                       KEY_EDEPARTMENT_ID IN     TFJ332.EDEPARTMENT_ID%TYPE,
                       KEY_EHBI_TNTCD     IN     TFJ332.EHBI_TNTCD%TYPE,
                       KEY_ECNORCD        IN     TFJ332.ECNORCD%TYPE,
                       KEY_EWT_TAG        IN     TFJ332.EWT_TAG%TYPE ) IS
        SELECT *
          FROM TFJ332
          WHERE DGYMDTM        = KEY_DGYMDTM
            AND EIM_EX_IND     = KEY_EIM_EX_IND
            AND ETRANS_MODE    = KEY_ETRANS_MODE
            AND EWB_TYPE       = KEY_EWB_TYPE
            AND DKJODTM        = KEY_DKJODTM
            AND ECOMPANY_ID    = KEY_ECOMPANY_ID
            AND ETERMINAL_ID   = KEY_ETERMINAL_ID
            AND EDEPARTMENT_ID = KEY_EDEPARTMENT_ID
            AND EHBI_TNTCD     = KEY_EHBI_TNTCD
            AND ECNORCD        = KEY_ECNORCD
            AND EWT_TAG        = KEY_EWT_TAG;

    WK_RC         NUMBER;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3320', 'SEL_TFJ332' );

    WK_RC := 0;
    OUT_TFJ332 := NULL;

    FOR WK_REC IN CUR_TFJ332( IN_DGYMDTM,
                              IN_EIM_EX_IND,
                              IN_ETRANS_MODE,
                              IN_EWB_TYPE,
                              IN_DKJODTM,
                              IN_ECOMPANY_ID,
                              IN_ETERMINAL_ID,
                              IN_EDEPARTMENT_ID,
                              IN_EHBI_TNTCD,
                              IN_ECNORCD,
                              IN_EWT_TAG ) LOOP
        WK_RC := 1;
        OUT_TFJ332 := WK_REC;
    END LOOP;

    PFGA3910.TRACE_PROC_EXIT;
    RETURN WK_RC;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 3;
            PFGA3910.TRACE_LOG('E','TFJ332: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- ���ʎ��тɉ��Z����
--================================================
PROCEDURE ADD_BUTSURYOU(
    IN_TFJ301       IN      TFJ301%ROWTYPE,
    OUT_TFJ332      IN OUT  TFJ332%ROWTYPE )
IS
    WK_WT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_M3_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_RT_UOM_CODE     UOM_CONVERSION.TO_UOM_CODE%TYPE;
    WK_WT_RND          NUMBER;
    WK_M3_RND          NUMBER;
    WK_RT_RND          NUMBER;

    WK_NAKKBN          TFJ301.NAKKBN%TYPE;

BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3220', 'ADD_BUTSURYOU' );

    WK_WT_UOM_CODE := 'KG';
    WK_M3_UOM_CODE := 'CBM';
    WK_RT_UOM_CODE := 'CBM';
    WK_WT_RND := 1;
    WK_M3_RND := 3;
    WK_RT_RND := 3;

    WK_NAKKBN   := IN_TFJ301.NAKKBN;

    IF IN_TFJ301.EOPE_KBN = '0' THEN
        -- ��������
        IF IN_TFJ301.ETRANS_MODE     = 'O' THEN
            IF IN_TFJ301.SERVICE_TYPE = 'FCL' THEN
                -- CY���    FCL
                OUT_TFJ332.NHSI_CY_HONSU_GKI    := OUT_TFJ332.NHSI_CY_HONSU_GKI
                        + ( IN_TFJ301.CONTAINER_20FT +IN_TFJ301.CONTAINER_40FT
                          + IN_TFJ301.CONTAINER_ETC ) * WK_NAKKBN;
                OUT_TFJ332.NHSI_CY_CNT  := OUT_TFJ332.NHSI_CY_CNT + WK_NAKKBN;
                OUT_TFJ332.NHSI_CY_PCS  := OUT_TFJ332.NHSI_CY_PCS
                              + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                OUT_TFJ332.NHSI_CY_WT   := OUT_TFJ332.NHSI_CY_WT
                        + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                OUT_TFJ332.NHSI_CY_M3   := OUT_TFJ332.NHSI_CY_M3
                        + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                OUT_TFJ332.NHSI_CY_RT  := OUT_TFJ332.NHSI_CY_RT
                        + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
            ELSE
                IF IN_TFJ301.CARRIER_TYPE = 'O' THEN
                    -- CFS���   LCL KWE_BOX
                    OUT_TFJ332.NHSI_CFS_CNT := OUT_TFJ332.NHSI_CFS_CNT
                                  + WK_NAKKBN;
                    OUT_TFJ332.NHSI_CFS_PCS := OUT_TFJ332.NHSI_CFS_PCS
                                  + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                    OUT_TFJ332.NHSI_CFS_WT  := OUT_TFJ332.NHSI_CFS_WT
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                    OUT_TFJ332.NHSI_CFS_M3  := OUT_TFJ332.NHSI_CFS_M3
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                    OUT_TFJ332.NHSI_CFS_RT  := OUT_TFJ332.NHSI_CFS_RT
                            + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
                ELSE
                    -- CFS���   LCL CO-Load
                    OUT_TFJ332.NHSI_CLD_CNT := OUT_TFJ332.NHSI_CLD_CNT
                                  + WK_NAKKBN;
                    OUT_TFJ332.NHSI_CLD_PCS := OUT_TFJ332.NHSI_CLD_PCS
                                  + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                    OUT_TFJ332.NHSI_CLD_WT  := OUT_TFJ332.NHSI_CLD_WT
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                    OUT_TFJ332.NHSI_CLD_M3  := OUT_TFJ332.NHSI_CLD_M3
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                    OUT_TFJ332.NHSI_CLD_RT  := OUT_TFJ332.NHSI_CLD_RT
                            + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
                END IF;
            END IF;
        END IF;

        -- ����
        OUT_TFJ332.NHSI_CNT         := OUT_TFJ332.NHSI_CNT + WK_NAKKBN;
        -- �ݕ���
        OUT_TFJ332.NHSI_CRG_PCS     := OUT_TFJ332.NHSI_CRG_PCS
                          + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
        OUT_TFJ332.NHSI_20FT_HONSU  := OUT_TFJ332.NHSI_20FT_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_20FT;
        OUT_TFJ332.NHSI_40FT_HONSU  := OUT_TFJ332.NHSI_40FT_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_40FT;
        OUT_TFJ332.NHSI_ETC_HONSU   := OUT_TFJ332.NHSI_ETC_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_ETC;
        -- �ݕ��d�ʁE�e��
        OUT_TFJ332.NHSI_CRG_ACTWT   := OUT_TFJ332.NHSI_CRG_ACTWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
        IF IN_TFJ301.ETRANS_MODE     = 'O' THEN
            OUT_TFJ332.NHSI_CRG_CHGWT   := OUT_TFJ332.NHSI_CRG_CHGWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
        ELSE
            OUT_TFJ332.NHSI_CRG_CHGWT   := OUT_TFJ332.NHSI_CRG_CHGWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
        END IF;
        OUT_TFJ332.NHSI_CRG_M3      := OUT_TFJ332.NHSI_CRG_M3
                    + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
    ELSE
        -- �����C��
        IF IN_TFJ301.ETRANS_MODE     = 'O' THEN
            IF IN_TFJ301.SERVICE_TYPE = 'FCL' THEN
                -- CY���    FCL
                OUT_TFJ332.NSYSI_CY_HONSU_GKI   := OUT_TFJ332.NSYSI_CY_HONSU_GKI
                        + ( IN_TFJ301.CONTAINER_20FT +IN_TFJ301.CONTAINER_40FT
                          + IN_TFJ301.CONTAINER_ETC ) * WK_NAKKBN;
                OUT_TFJ332.NSYSI_CY_CNT := OUT_TFJ332.NSYSI_CY_CNT
                              + WK_NAKKBN;
                OUT_TFJ332.NSYSI_CY_PCS := OUT_TFJ332.NSYSI_CY_PCS
                              + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                OUT_TFJ332.NSYSI_CY_WT  := OUT_TFJ332.NSYSI_CY_WT
                        + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                OUT_TFJ332.NSYSI_CY_M3  := OUT_TFJ332.NSYSI_CY_M3
                        + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                OUT_TFJ332.NSYSI_CY_RT  := OUT_TFJ332.NSYSI_CY_RT
                        + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
            ELSE
                IF IN_TFJ301.CARRIER_TYPE = 'O' THEN
                    -- CFS���   LCL KWE_BOX
                    OUT_TFJ332.NSYSI_CFS_CNT:= OUT_TFJ332.NSYSI_CFS_CNT
                                  + WK_NAKKBN;
                    OUT_TFJ332.NSYSI_CFS_PCS:= OUT_TFJ332.NSYSI_CFS_PCS
                                  + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                    OUT_TFJ332.NSYSI_CFS_WT := OUT_TFJ332.NSYSI_CFS_WT
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                    OUT_TFJ332.NSYSI_CFS_M3 := OUT_TFJ332.NSYSI_CFS_M3
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                    OUT_TFJ332.NSYSI_CFS_RT  := OUT_TFJ332.NSYSI_CFS_RT
                            + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
                ELSE
                    -- CFS���   LCL CO-Load
                    OUT_TFJ332.NSYSI_CLD_CNT:= OUT_TFJ332.NSYSI_CLD_CNT
                                  + WK_NAKKBN;
                    OUT_TFJ332.NSYSI_CLD_PCS:= OUT_TFJ332.NSYSI_CLD_PCS
                                  + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
                    OUT_TFJ332.NSYSI_CLD_WT := OUT_TFJ332.NSYSI_CLD_WT
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
                    OUT_TFJ332.NSYSI_CLD_M3 := OUT_TFJ332.NSYSI_CLD_M3
                            + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
                    OUT_TFJ332.NSYSI_CLD_RT  := OUT_TFJ332.NSYSI_CLD_RT
                            + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
                END IF;
            END IF;
        END IF;

        -- ����
        OUT_TFJ332.NSYSI_CNT        := OUT_TFJ332.NSYSI_CNT + WK_NAKKBN;
        -- �ݕ���
        OUT_TFJ332.NSYSI_CRG_PCS    := OUT_TFJ332.NSYSI_CRG_PCS
                          + WK_NAKKBN * IN_TFJ301.NUM_PIECES;
        OUT_TFJ332.NSYSI_20FT_HONSU := OUT_TFJ332.NSYSI_20FT_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_20FT;
        OUT_TFJ332.NSYSI_40FT_HONSU := OUT_TFJ332.NSYSI_40FT_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_40FT;
        OUT_TFJ332.NSYSI_ETC_HONSU  := OUT_TFJ332.NSYSI_ETC_HONSU
                          + WK_NAKKBN * IN_TFJ301.CONTAINER_ETC;
        -- �ݕ��d�ʁE�e��
        OUT_TFJ332.NSYSI_CRG_ACTWT  := OUT_TFJ332.NSYSI_CRG_ACTWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_ACTUAL_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.ACTUAL_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
        IF IN_TFJ301.ETRANS_MODE     = 'O' THEN
            OUT_TFJ332.NSYSI_CRG_CHGWT  := OUT_TFJ332.NSYSI_CRG_CHGWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_RT_UOM_CODE),WK_RT_RND);
        ELSE
            OUT_TFJ332.NSYSI_CRG_CHGWT  := OUT_TFJ332.NSYSI_CRG_CHGWT
                    + WK_NAKKBN * ROUND(IN_TFJ301.CHARGEABLE_WEIGHT
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.CHARGEABLE_WEIGHT_UOM_CODE,
                                                WK_WT_UOM_CODE),WK_WT_RND);
        END IF;
        OUT_TFJ332.NSYSI_CRG_M3     := OUT_TFJ332.NSYSI_CRG_M3
                    + WK_NAKKBN * ROUND(IN_TFJ301.TOTAL_VOLUME
                  * PFGA3950.SEL_UOM_CONVERSION(IN_TFJ301.VOLUME_UOM_CODE,
                                                WK_M3_UOM_CODE),WK_M3_RND);
    END IF;

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 4;
            PFGA3910.TRACE_LOG('E','SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;


--================================================
-- �ڋq�ʕ��ʎ��т��쐬
--================================================
PROCEDURE INS_TFJ332(
    IN_TFJ332   IN  TFJ332%ROWTYPE )         -- �ڋq�ʕ��ʎ���
IS
BEGIN
    PFGA3910.TRACE_PROC_ENTRY( 'PFGA3320', 'INS_TFJ332' );

    INSERT INTO TFJ332(
                        -- ����
        ETRKDTM,
        EUPDDTM,
        DHNEDTM,
        EUPD_OFCCD,
        EUPD_TNTCD,
                        -- �j�d�x
        DGYMDTM,
        EIM_EX_IND,
        ETRANS_MODE,
        EWB_TYPE,
        DKJODTM,
        ECOMPANY_ID,
        ETERMINAL_ID,
        EDEPARTMENT_ID,
        EHBI_TNTCD,
        ECNORCD,
        EWT_TAG,
                        -- �R�[�h
        EOYA_ECNORCD,
                        -- ����
        EOYA_ECNORNM,
        JOYA_ECNORNM,
        ECNORNM,
        JCNORNM,
        ETERMNM,
        JTERMNM,
        EDEPARTNM,
        JDEPARTNM,
        ETNTNM,
        JTNTNM,
                        -- CY���    FCL
        NHSI_CY_HONSU_GKI,
        NSYSI_CY_HONSU_GKI,
        NHSI_CY_CNT,
        NSYSI_CY_CNT,
        NHSI_CY_PCS,
        NSYSI_CY_PCS,
        NHSI_CY_WT,
        NSYSI_CY_WT,
        NHSI_CY_M3,
        NSYSI_CY_M3,
        NHSI_CY_RT,
        NSYSI_CY_RT,
                        -- CFS���   LCL KWE_BOX
        NHSI_CFS_CNT,
        NSYSI_CFS_CNT,
        NHSI_CFS_PCS,
        NSYSI_CFS_PCS,
        NHSI_CFS_WT,
        NSYSI_CFS_WT,
        NHSI_CFS_M3,
        NSYSI_CFS_M3,
        NHSI_CFS_RT,
        NSYSI_CFS_RT,
                        -- CFS���   LCL CO-Load
        NHSI_CLD_CNT,
        NSYSI_CLD_CNT,
        NHSI_CLD_PCS,
        NSYSI_CLD_PCS,
        NHSI_CLD_WT,
        NSYSI_CLD_WT,
        NHSI_CLD_M3,
        NSYSI_CLD_M3,
        NHSI_CLD_RT,
        NSYSI_CLD_RT,
                        -- ����
        NHSI_CNT,
        NSYSI_CNT,
                        -- �ݕ���
        NHSI_CRG_PCS,
        NSYSI_CRG_PCS,
        NHSI_20FT_HONSU,
        NSYSI_20FT_HONSU,
        NHSI_40FT_HONSU,
        NSYSI_40FT_HONSU,
        NHSI_ETC_HONSU,
        NSYSI_ETC_HONSU,
                        -- �ݕ��d�ʁE�e��
        NHSI_CRG_ACTWT,
        NSYSI_CRG_ACTWT,
        NHSI_CRG_CHGWT,
        NSYSI_CRG_CHGWT,
        NHSI_CRG_M3,
        NSYSI_CRG_M3 )
      VALUES(
                        -- ����
        IN_TFJ332.ETRKDTM,
        IN_TFJ332.EUPDDTM,
        IN_TFJ332.DHNEDTM,
        IN_TFJ332.EUPD_OFCCD,
        IN_TFJ332.EUPD_TNTCD,
                        -- �j�d�x
        IN_TFJ332.DGYMDTM,
        IN_TFJ332.EIM_EX_IND,
        IN_TFJ332.ETRANS_MODE,
        IN_TFJ332.EWB_TYPE,
        IN_TFJ332.DKJODTM,
        IN_TFJ332.ECOMPANY_ID,
        IN_TFJ332.ETERMINAL_ID,
        IN_TFJ332.EDEPARTMENT_ID,
        IN_TFJ332.EHBI_TNTCD,
        IN_TFJ332.ECNORCD,
        IN_TFJ332.EWT_TAG,
                        -- �R�[�h
        IN_TFJ332.EOYA_ECNORCD,
                        -- ����
        IN_TFJ332.EOYA_ECNORNM,
        IN_TFJ332.JOYA_ECNORNM,
        IN_TFJ332.ECNORNM,
        IN_TFJ332.JCNORNM,
        IN_TFJ332.ETERMNM,
        IN_TFJ332.JTERMNM,
        IN_TFJ332.EDEPARTNM,
        IN_TFJ332.JDEPARTNM,
        IN_TFJ332.ETNTNM,
        IN_TFJ332.JTNTNM,
                        -- CY���    FCL
        IN_TFJ332.NHSI_CY_HONSU_GKI,
        IN_TFJ332.NSYSI_CY_HONSU_GKI,
        IN_TFJ332.NHSI_CY_CNT,
        IN_TFJ332.NSYSI_CY_CNT,
        IN_TFJ332.NHSI_CY_PCS,
        IN_TFJ332.NSYSI_CY_PCS,
        IN_TFJ332.NHSI_CY_WT,
        IN_TFJ332.NSYSI_CY_WT,
        IN_TFJ332.NHSI_CY_M3,
        IN_TFJ332.NSYSI_CY_M3,
        IN_TFJ332.NHSI_CY_RT,
        IN_TFJ332.NSYSI_CY_RT,
                        -- CFS���   LCL KWE_BOX
        IN_TFJ332.NHSI_CFS_CNT,
        IN_TFJ332.NSYSI_CFS_CNT,
        IN_TFJ332.NHSI_CFS_PCS,
        IN_TFJ332.NSYSI_CFS_PCS,
        IN_TFJ332.NHSI_CFS_WT,
        IN_TFJ332.NSYSI_CFS_WT,
        IN_TFJ332.NHSI_CFS_M3,
        IN_TFJ332.NSYSI_CFS_M3,
        IN_TFJ332.NHSI_CFS_RT,
        IN_TFJ332.NSYSI_CFS_RT,
                        -- CFS���   LCL CO-Load
        IN_TFJ332.NHSI_CLD_CNT,
        IN_TFJ332.NSYSI_CLD_CNT,
        IN_TFJ332.NHSI_CLD_PCS,
        IN_TFJ332.NSYSI_CLD_PCS,
        IN_TFJ332.NHSI_CLD_WT,
        IN_TFJ332.NSYSI_CLD_WT,
        IN_TFJ332.NHSI_CLD_M3,
        IN_TFJ332.NSYSI_CLD_M3,
        IN_TFJ332.NHSI_CLD_RT,
        IN_TFJ332.NSYSI_CLD_RT,
                        -- ����
        IN_TFJ332.NHSI_CNT,
        IN_TFJ332.NSYSI_CNT,
                        -- �ݕ���
        IN_TFJ332.NHSI_CRG_PCS,
        IN_TFJ332.NSYSI_CRG_PCS,
        IN_TFJ332.NHSI_20FT_HONSU,
        IN_TFJ332.NSYSI_20FT_HONSU,
        IN_TFJ332.NHSI_40FT_HONSU,
        IN_TFJ332.NSYSI_40FT_HONSU,
        IN_TFJ332.NHSI_ETC_HONSU,
        IN_TFJ332.NSYSI_ETC_HONSU,
                        -- �ݕ��d�ʁE�e��
        IN_TFJ332.NHSI_CRG_ACTWT,
        IN_TFJ332.NSYSI_CRG_ACTWT,
        IN_TFJ332.NHSI_CRG_CHGWT,
        IN_TFJ332.NSYSI_CRG_CHGWT,
        IN_TFJ332.NHSI_CRG_M3,
        IN_TFJ332.NSYSI_CRG_M3 );

    PFGA3910.TRACE_PROC_EXIT;

EXCEPTION
    WHEN OTHERS THEN
        IF WK_ERROR = 0 THEN
            WK_ERROR := 5;
            PFGA3910.TRACE_LOG('E','TFJ332: SQLERRM=' || SQLERRM);
            PFGA3910.TRACE_STACK( 'E' );
        END IF;
        PFGA3910.TRACE_PROC_EXIT;
        RAISE;
END;

END PFGA3320;